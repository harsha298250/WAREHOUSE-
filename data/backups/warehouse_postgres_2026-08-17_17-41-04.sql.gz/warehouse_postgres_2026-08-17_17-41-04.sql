--
-- PostgreSQL database dump
--

\restrict 1yzrSlt6s1ZggpMNpZiE7tYvSA07zxrT6e0UETBn6rrngzXKefQrmTPhtl3owwU

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_log (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    username character varying(64) NOT NULL,
    warehouse_id character varying(20),
    action character varying(50) NOT NULL,
    ip_address character varying(45)
);


ALTER TABLE public.access_log OWNER TO postgres;

--
-- Name: access_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.access_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.access_log_id_seq OWNER TO postgres;

--
-- Name: access_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.access_log_id_seq OWNED BY public.access_log.id;


--
-- Name: ai_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_recommendations (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(50),
    title character varying(100) NOT NULL,
    risk_level character varying(20),
    action_recommended character varying(100) NOT NULL,
    confidence_score integer,
    input_factors text,
    status character varying(20),
    decision_by character varying(64),
    decision_time timestamp without time zone,
    notes text
);


ALTER TABLE public.ai_recommendations OWNER TO postgres;

--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_recommendations_id_seq OWNER TO postgres;

--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_recommendations_id_seq OWNED BY public.ai_recommendations.id;


--
-- Name: audit_ledger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_ledger (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    event_type character varying(50) NOT NULL,
    details text,
    prev_hash character varying(64) NOT NULL,
    hash character varying(64) NOT NULL
);


ALTER TABLE public.audit_ledger OWNER TO postgres;

--
-- Name: audit_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_ledger_id_seq OWNER TO postgres;

--
-- Name: audit_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_ledger_id_seq OWNED BY public.audit_ledger.id;


--
-- Name: backup_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_records (
    id integer NOT NULL,
    backup_id character varying(64) NOT NULL,
    filename character varying(255) NOT NULL,
    created_at timestamp without time zone,
    size_bytes integer,
    sha256 character varying(64),
    status character varying(20) NOT NULL,
    storage_key character varying(255),
    error_message text
);


ALTER TABLE public.backup_records OWNER TO postgres;

--
-- Name: backup_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.backup_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_records_id_seq OWNER TO postgres;

--
-- Name: backup_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.backup_records_id_seq OWNED BY public.backup_records.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id character varying(20) NOT NULL,
    name character varying(150) NOT NULL,
    category character varying(80),
    unit_cost double precision,
    lead_time_days integer,
    safety_stock integer,
    created_at timestamp without time zone
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: recovery_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recovery_codes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code_hash character varying(255) NOT NULL,
    used boolean NOT NULL,
    created_at timestamp without time zone,
    used_at timestamp without time zone
);


ALTER TABLE public.recovery_codes OWNER TO postgres;

--
-- Name: recovery_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recovery_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recovery_codes_id_seq OWNER TO postgres;

--
-- Name: recovery_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recovery_codes_id_seq OWNED BY public.recovery_codes.id;


--
-- Name: recovery_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recovery_credentials (
    id integer NOT NULL,
    user_id integer NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.recovery_credentials OWNER TO postgres;

--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recovery_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recovery_credentials_id_seq OWNER TO postgres;

--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recovery_credentials_id_seq OWNED BY public.recovery_credentials.id;


--
-- Name: shrinkage_flags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shrinkage_flags (
    id integer NOT NULL,
    date date NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    item_name character varying(150),
    deviation_score double precision,
    expected_quantity double precision,
    actual_quantity double precision,
    discrepancy_quantity double precision,
    estimated_exposure double precision,
    severity character varying(20),
    likely_cause character varying(80),
    explanation text
);


ALTER TABLE public.shrinkage_flags OWNER TO postgres;

--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shrinkage_flags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shrinkage_flags_id_seq OWNER TO postgres;

--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shrinkage_flags_id_seq OWNED BY public.shrinkage_flags.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    date date NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    stock_in integer,
    stock_out integer,
    closing_stock integer,
    is_anomaly boolean,
    anomaly_type character varying(30),
    entry_source character varying(20),
    entered_by character varying(64)
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_movements_id_seq OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    full_name character varying(120),
    google_subject_id character varying(128),
    created_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouses (
    id character varying(20) NOT NULL,
    name character varying(120) NOT NULL,
    location character varying(120),
    latitude double precision,
    longitude double precision,
    created_at timestamp without time zone
);


ALTER TABLE public.warehouses OWNER TO postgres;

--
-- Name: access_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log ALTER COLUMN id SET DEFAULT nextval('public.access_log_id_seq'::regclass);


--
-- Name: ai_recommendations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_recommendations ALTER COLUMN id SET DEFAULT nextval('public.ai_recommendations_id_seq'::regclass);


--
-- Name: audit_ledger id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_ledger ALTER COLUMN id SET DEFAULT nextval('public.audit_ledger_id_seq'::regclass);


--
-- Name: backup_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_records ALTER COLUMN id SET DEFAULT nextval('public.backup_records_id_seq'::regclass);


--
-- Name: recovery_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes ALTER COLUMN id SET DEFAULT nextval('public.recovery_codes_id_seq'::regclass);


--
-- Name: recovery_credentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials ALTER COLUMN id SET DEFAULT nextval('public.recovery_credentials_id_seq'::regclass);


--
-- Name: shrinkage_flags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shrinkage_flags ALTER COLUMN id SET DEFAULT nextval('public.shrinkage_flags_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: access_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access_log (id, "timestamp", username, warehouse_id, action, ip_address) FROM stdin;
\.


--
-- Data for Name: ai_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_recommendations (id, "timestamp", warehouse_id, item_id, title, risk_level, action_recommended, confidence_score, input_factors, status, decision_by, decision_time, notes) FROM stdin;
\.


--
-- Data for Name: audit_ledger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_ledger (id, "timestamp", event_type, details, prev_hash, hash) FROM stdin;
\.


--
-- Data for Name: backup_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_records (id, backup_id, filename, created_at, size_bytes, sha256, status, storage_key, error_message) FROM stdin;
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id, name, category, unit_cost, lead_time_days, safety_stock, created_at) FROM stdin;
ITM-CPU-01	AMD Ryzen 9 7900X Processor	Electronics	38000	5	15	2026-08-17 17:39:54.006049
ITM-GPU-01	Nvidia RTX 4080 Founders Edition	Electronics	95000	7	10	2026-08-17 17:39:54.010046
ITM-RAM-01	Corsair DDR5 32GB 6000MHz RAM	Electronics	8500	4	25	2026-08-17 17:39:54.014047
ITM-SSD-01	Samsung 990 Pro 2TB NVMe SSD	Storage	12000	3	30	2026-08-17 17:39:54.018522
ITM-HDD-01	WD Red Pro 8TB NAS Hard Drive	Storage	16500	5	20	2026-08-17 17:39:54.022374
ITM-CHG-01	Anker 100W GaN Wall Charger	Accessories	2500	2	50	2026-08-17 17:39:54.025395
ITM-CBL-01	Apple USB-C Braided Cable 2m	Accessories	800	1	100	2026-08-17 17:39:54.028969
\.


--
-- Data for Name: recovery_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recovery_codes (id, user_id, code_hash, used, created_at, used_at) FROM stdin;
\.


--
-- Data for Name: recovery_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recovery_credentials (id, user_id, password_hash, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shrinkage_flags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shrinkage_flags (id, date, warehouse_id, item_id, item_name, deviation_score, expected_quantity, actual_quantity, discrepancy_quantity, estimated_exposure, severity, likely_cause, explanation) FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, date, warehouse_id, item_id, stock_in, stock_out, closing_stock, is_anomaly, anomaly_type, entry_source, entered_by) FROM stdin;
1	2026-07-13	WH-BLR-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
2	2026-07-13	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
3	2026-07-13	WH-BLR-01	ITM-RAM-01	0	3	72	f	none	simulated	system_sim
4	2026-07-13	WH-BLR-01	ITM-SSD-01	0	3	87	f	none	simulated	system_sim
5	2026-07-13	WH-BLR-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
6	2026-07-13	WH-BLR-01	ITM-CHG-01	0	6	144	f	none	simulated	system_sim
7	2026-07-13	WH-BLR-01	ITM-CBL-01	0	3	297	f	none	simulated	system_sim
8	2026-07-13	WH-CHN-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
9	2026-07-13	WH-CHN-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
10	2026-07-13	WH-CHN-01	ITM-RAM-01	0	10	65	f	none	simulated	system_sim
11	2026-07-13	WH-CHN-01	ITM-SSD-01	0	1	89	f	none	simulated	system_sim
12	2026-07-13	WH-CHN-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
13	2026-07-13	WH-CHN-01	ITM-CHG-01	0	5	145	f	none	simulated	system_sim
14	2026-07-13	WH-CHN-01	ITM-CBL-01	0	2	298	f	none	simulated	system_sim
15	2026-07-13	WH-BOM-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
16	2026-07-13	WH-BOM-01	ITM-GPU-01	0	2	28	f	none	simulated	system_sim
17	2026-07-13	WH-BOM-01	ITM-RAM-01	0	3	72	f	none	simulated	system_sim
18	2026-07-13	WH-BOM-01	ITM-SSD-01	0	3	87	f	none	simulated	system_sim
19	2026-07-13	WH-BOM-01	ITM-HDD-01	0	1	59	f	none	simulated	system_sim
20	2026-07-13	WH-BOM-01	ITM-CHG-01	0	7	143	f	none	simulated	system_sim
21	2026-07-13	WH-BOM-01	ITM-CBL-01	0	7	293	f	none	simulated	system_sim
22	2026-07-13	WH-DEL-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
23	2026-07-13	WH-DEL-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
24	2026-07-13	WH-DEL-01	ITM-RAM-01	0	10	65	f	none	simulated	system_sim
25	2026-07-13	WH-DEL-01	ITM-SSD-01	0	2	88	f	none	simulated	system_sim
26	2026-07-13	WH-DEL-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
27	2026-07-13	WH-DEL-01	ITM-CHG-01	0	6	144	f	none	simulated	system_sim
28	2026-07-13	WH-DEL-01	ITM-CBL-01	0	1	299	f	none	simulated	system_sim
29	2026-07-13	WH-CCU-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
30	2026-07-13	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
31	2026-07-13	WH-CCU-01	ITM-RAM-01	0	1	74	f	none	simulated	system_sim
32	2026-07-13	WH-CCU-01	ITM-SSD-01	0	0	90	f	none	simulated	system_sim
33	2026-07-13	WH-CCU-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
34	2026-07-13	WH-CCU-01	ITM-CHG-01	0	2	148	f	none	simulated	system_sim
35	2026-07-13	WH-CCU-01	ITM-CBL-01	0	3	297	f	none	simulated	system_sim
36	2026-07-14	WH-BLR-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
37	2026-07-14	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
38	2026-07-14	WH-BLR-01	ITM-RAM-01	0	6	66	f	none	simulated	system_sim
39	2026-07-14	WH-BLR-01	ITM-SSD-01	0	1	86	f	none	simulated	system_sim
40	2026-07-14	WH-BLR-01	ITM-HDD-01	0	3	57	f	none	simulated	system_sim
41	2026-07-14	WH-BLR-01	ITM-CHG-01	0	1	143	f	none	simulated	system_sim
42	2026-07-14	WH-BLR-01	ITM-CBL-01	0	1	296	f	none	simulated	system_sim
43	2026-07-14	WH-CHN-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
44	2026-07-14	WH-CHN-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
45	2026-07-14	WH-CHN-01	ITM-RAM-01	0	6	59	f	none	simulated	system_sim
46	2026-07-14	WH-CHN-01	ITM-SSD-01	0	2	87	f	none	simulated	system_sim
47	2026-07-14	WH-CHN-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
48	2026-07-14	WH-CHN-01	ITM-CHG-01	0	3	142	f	none	simulated	system_sim
49	2026-07-14	WH-CHN-01	ITM-CBL-01	0	2	296	f	none	simulated	system_sim
50	2026-07-14	WH-BOM-01	ITM-CPU-01	0	1	44	f	none	simulated	system_sim
51	2026-07-14	WH-BOM-01	ITM-GPU-01	0	2	26	f	none	simulated	system_sim
52	2026-07-14	WH-BOM-01	ITM-RAM-01	0	10	62	f	none	simulated	system_sim
53	2026-07-14	WH-BOM-01	ITM-SSD-01	0	1	86	f	none	simulated	system_sim
54	2026-07-14	WH-BOM-01	ITM-HDD-01	0	0	59	f	none	simulated	system_sim
55	2026-07-14	WH-BOM-01	ITM-CHG-01	0	3	140	f	none	simulated	system_sim
56	2026-07-14	WH-BOM-01	ITM-CBL-01	0	3	290	f	none	simulated	system_sim
57	2026-07-14	WH-DEL-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
58	2026-07-14	WH-DEL-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
59	2026-07-14	WH-DEL-01	ITM-RAM-01	0	8	57	f	none	simulated	system_sim
60	2026-07-14	WH-DEL-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
61	2026-07-14	WH-DEL-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
62	2026-07-14	WH-DEL-01	ITM-CHG-01	0	1	143	f	none	simulated	system_sim
63	2026-07-14	WH-DEL-01	ITM-CBL-01	0	1	298	f	none	simulated	system_sim
64	2026-07-14	WH-CCU-01	ITM-CPU-01	0	3	39	f	none	simulated	system_sim
65	2026-07-14	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
66	2026-07-14	WH-CCU-01	ITM-RAM-01	0	9	65	f	none	simulated	system_sim
67	2026-07-14	WH-CCU-01	ITM-SSD-01	0	3	87	f	none	simulated	system_sim
68	2026-07-14	WH-CCU-01	ITM-HDD-01	0	3	57	f	none	simulated	system_sim
69	2026-07-14	WH-CCU-01	ITM-CHG-01	0	3	145	f	none	simulated	system_sim
70	2026-07-14	WH-CCU-01	ITM-CBL-01	0	4	293	f	none	simulated	system_sim
71	2026-07-15	WH-BLR-01	ITM-CPU-01	0	1	44	f	none	simulated	system_sim
72	2026-07-15	WH-BLR-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
73	2026-07-15	WH-BLR-01	ITM-RAM-01	0	6	60	f	none	simulated	system_sim
74	2026-07-15	WH-BLR-01	ITM-SSD-01	0	0	86	f	none	simulated	system_sim
75	2026-07-15	WH-BLR-01	ITM-HDD-01	0	3	54	f	none	simulated	system_sim
76	2026-07-15	WH-BLR-01	ITM-CHG-01	0	4	139	f	none	simulated	system_sim
77	2026-07-15	WH-BLR-01	ITM-CBL-01	0	2	294	f	none	simulated	system_sim
78	2026-07-15	WH-CHN-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
79	2026-07-15	WH-CHN-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
80	2026-07-15	WH-CHN-01	ITM-RAM-01	0	8	51	f	none	simulated	system_sim
81	2026-07-15	WH-CHN-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
82	2026-07-15	WH-CHN-01	ITM-HDD-01	0	1	59	f	none	simulated	system_sim
83	2026-07-15	WH-CHN-01	ITM-CHG-01	0	3	139	f	none	simulated	system_sim
84	2026-07-15	WH-CHN-01	ITM-CBL-01	0	7	289	f	none	simulated	system_sim
85	2026-07-15	WH-BOM-01	ITM-CPU-01	0	2	42	f	none	simulated	system_sim
86	2026-07-15	WH-BOM-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
87	2026-07-15	WH-BOM-01	ITM-RAM-01	0	7	55	f	none	simulated	system_sim
88	2026-07-15	WH-BOM-01	ITM-SSD-01	0	0	86	f	none	simulated	system_sim
89	2026-07-15	WH-BOM-01	ITM-HDD-01	0	3	56	f	none	simulated	system_sim
90	2026-07-15	WH-BOM-01	ITM-CHG-01	0	8	132	f	none	simulated	system_sim
91	2026-07-15	WH-BOM-01	ITM-CBL-01	0	8	282	f	none	simulated	system_sim
92	2026-07-15	WH-DEL-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
93	2026-07-15	WH-DEL-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
94	2026-07-15	WH-DEL-01	ITM-RAM-01	0	5	52	f	none	simulated	system_sim
95	2026-07-15	WH-DEL-01	ITM-SSD-01	0	3	85	f	none	simulated	system_sim
96	2026-07-15	WH-DEL-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
97	2026-07-15	WH-DEL-01	ITM-CHG-01	0	1	142	f	none	simulated	system_sim
98	2026-07-15	WH-DEL-01	ITM-CBL-01	0	10	288	f	none	simulated	system_sim
99	2026-07-15	WH-CCU-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
100	2026-07-15	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
101	2026-07-15	WH-CCU-01	ITM-RAM-01	0	8	57	f	none	simulated	system_sim
102	2026-07-15	WH-CCU-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
103	2026-07-15	WH-CCU-01	ITM-HDD-01	0	0	57	f	none	simulated	system_sim
104	2026-07-15	WH-CCU-01	ITM-CHG-01	0	5	140	f	none	simulated	system_sim
105	2026-07-15	WH-CCU-01	ITM-CBL-01	0	6	287	f	none	simulated	system_sim
106	2026-07-16	WH-BLR-01	ITM-CPU-01	0	1	43	f	none	simulated	system_sim
107	2026-07-16	WH-BLR-01	ITM-GPU-01	0	1	28	f	none	simulated	system_sim
108	2026-07-16	WH-BLR-01	ITM-RAM-01	0	9	51	f	none	simulated	system_sim
109	2026-07-16	WH-BLR-01	ITM-SSD-01	0	0	86	f	none	simulated	system_sim
110	2026-07-16	WH-BLR-01	ITM-HDD-01	0	2	52	f	none	simulated	system_sim
111	2026-07-16	WH-BLR-01	ITM-CHG-01	0	1	138	f	none	simulated	system_sim
112	2026-07-16	WH-BLR-01	ITM-CBL-01	0	8	286	f	none	simulated	system_sim
113	2026-07-16	WH-CHN-01	ITM-CPU-01	0	1	44	f	none	simulated	system_sim
114	2026-07-16	WH-CHN-01	ITM-GPU-01	0	1	28	f	none	simulated	system_sim
115	2026-07-16	WH-CHN-01	ITM-RAM-01	0	10	41	f	none	simulated	system_sim
116	2026-07-16	WH-CHN-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
117	2026-07-16	WH-CHN-01	ITM-HDD-01	0	0	59	f	none	simulated	system_sim
118	2026-07-16	WH-CHN-01	ITM-CHG-01	0	8	131	f	none	simulated	system_sim
119	2026-07-16	WH-CHN-01	ITM-CBL-01	0	8	281	f	none	simulated	system_sim
120	2026-07-16	WH-BOM-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
121	2026-07-16	WH-BOM-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
122	2026-07-16	WH-BOM-01	ITM-RAM-01	0	5	50	f	none	simulated	system_sim
123	2026-07-16	WH-BOM-01	ITM-SSD-01	0	1	85	f	none	simulated	system_sim
124	2026-07-16	WH-BOM-01	ITM-HDD-01	0	0	56	f	none	simulated	system_sim
125	2026-07-16	WH-BOM-01	ITM-CHG-01	0	8	124	f	none	simulated	system_sim
126	2026-07-16	WH-BOM-01	ITM-CBL-01	0	5	277	f	none	simulated	system_sim
127	2026-07-16	WH-DEL-01	ITM-CPU-01	0	3	39	f	none	simulated	system_sim
128	2026-07-16	WH-DEL-01	ITM-GPU-01	0	1	28	f	none	simulated	system_sim
129	2026-07-16	WH-DEL-01	ITM-RAM-01	0	10	42	f	none	simulated	system_sim
130	2026-07-16	WH-DEL-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
131	2026-07-16	WH-DEL-01	ITM-HDD-01	0	2	58	f	none	simulated	system_sim
132	2026-07-16	WH-DEL-01	ITM-CHG-01	0	3	139	f	none	simulated	system_sim
133	2026-07-16	WH-DEL-01	ITM-CBL-01	0	2	286	f	none	simulated	system_sim
134	2026-07-16	WH-CCU-01	ITM-CPU-01	0	1	38	f	none	simulated	system_sim
135	2026-07-16	WH-CCU-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
136	2026-07-16	WH-CCU-01	ITM-RAM-01	0	10	47	f	none	simulated	system_sim
137	2026-07-16	WH-CCU-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
138	2026-07-16	WH-CCU-01	ITM-HDD-01	0	2	55	f	none	simulated	system_sim
139	2026-07-16	WH-CCU-01	ITM-CHG-01	0	9	131	f	none	simulated	system_sim
140	2026-07-16	WH-CCU-01	ITM-CBL-01	0	10	277	f	none	simulated	system_sim
141	2026-07-17	WH-BLR-01	ITM-CPU-01	0	2	41	f	none	simulated	system_sim
142	2026-07-17	WH-BLR-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
143	2026-07-17	WH-BLR-01	ITM-RAM-01	0	3	48	f	none	simulated	system_sim
144	2026-07-17	WH-BLR-01	ITM-SSD-01	0	1	85	f	none	simulated	system_sim
145	2026-07-17	WH-BLR-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
146	2026-07-17	WH-BLR-01	ITM-CHG-01	0	7	131	f	none	simulated	system_sim
147	2026-07-17	WH-BLR-01	ITM-CBL-01	0	2	284	f	none	simulated	system_sim
148	2026-07-17	WH-CHN-01	ITM-CPU-01	0	1	43	f	none	simulated	system_sim
149	2026-07-17	WH-CHN-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
150	2026-07-17	WH-CHN-01	ITM-RAM-01	0	3	38	f	none	simulated	system_sim
151	2026-07-17	WH-CHN-01	ITM-SSD-01	0	1	86	f	none	simulated	system_sim
152	2026-07-17	WH-CHN-01	ITM-HDD-01	0	0	59	f	none	simulated	system_sim
153	2026-07-17	WH-CHN-01	ITM-CHG-01	0	4	127	f	none	simulated	system_sim
154	2026-07-17	WH-CHN-01	ITM-CBL-01	0	2	279	f	none	simulated	system_sim
155	2026-07-17	WH-BOM-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
156	2026-07-17	WH-BOM-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
157	2026-07-17	WH-BOM-01	ITM-RAM-01	0	3	47	f	none	simulated	system_sim
158	2026-07-17	WH-BOM-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
159	2026-07-17	WH-BOM-01	ITM-HDD-01	0	3	53	f	none	simulated	system_sim
160	2026-07-17	WH-BOM-01	ITM-CHG-01	0	10	114	f	none	simulated	system_sim
161	2026-07-17	WH-BOM-01	ITM-CBL-01	0	3	274	f	none	simulated	system_sim
162	2026-07-17	WH-DEL-01	ITM-CPU-01	0	2	37	f	none	simulated	system_sim
163	2026-07-17	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
164	2026-07-17	WH-DEL-01	ITM-RAM-01	0	2	40	f	none	simulated	system_sim
165	2026-07-17	WH-DEL-01	ITM-SSD-01	0	3	82	f	none	simulated	system_sim
166	2026-07-17	WH-DEL-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
167	2026-07-17	WH-DEL-01	ITM-CHG-01	0	3	136	f	none	simulated	system_sim
168	2026-07-17	WH-DEL-01	ITM-CBL-01	0	9	277	f	none	simulated	system_sim
169	2026-07-17	WH-CCU-01	ITM-CPU-01	0	0	38	f	none	simulated	system_sim
170	2026-07-17	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
171	2026-07-17	WH-CCU-01	ITM-RAM-01	0	3	44	f	none	simulated	system_sim
172	2026-07-17	WH-CCU-01	ITM-SSD-01	0	3	84	f	none	simulated	system_sim
173	2026-07-17	WH-CCU-01	ITM-HDD-01	0	0	55	f	none	simulated	system_sim
174	2026-07-17	WH-CCU-01	ITM-CHG-01	0	9	122	f	none	simulated	system_sim
175	2026-07-17	WH-CCU-01	ITM-CBL-01	0	6	271	f	none	simulated	system_sim
176	2026-07-18	WH-BLR-01	ITM-CPU-01	0	0	41	f	none	simulated	system_sim
177	2026-07-18	WH-BLR-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
178	2026-07-18	WH-BLR-01	ITM-RAM-01	0	2	46	f	none	simulated	system_sim
179	2026-07-18	WH-BLR-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
180	2026-07-18	WH-BLR-01	ITM-HDD-01	0	1	51	f	none	simulated	system_sim
181	2026-07-18	WH-BLR-01	ITM-CHG-01	0	1	130	f	none	simulated	system_sim
182	2026-07-18	WH-BLR-01	ITM-CBL-01	0	9	275	f	none	simulated	system_sim
183	2026-07-18	WH-CHN-01	ITM-CPU-01	0	3	40	f	none	simulated	system_sim
184	2026-07-18	WH-CHN-01	ITM-GPU-01	0	2	25	f	none	simulated	system_sim
185	2026-07-18	WH-CHN-01	ITM-RAM-01	0	7	31	f	none	simulated	system_sim
186	2026-07-18	WH-CHN-01	ITM-SSD-01	0	2	84	f	none	simulated	system_sim
187	2026-07-18	WH-CHN-01	ITM-HDD-01	0	1	58	f	none	simulated	system_sim
188	2026-07-18	WH-CHN-01	ITM-CHG-01	0	10	117	f	none	simulated	system_sim
189	2026-07-18	WH-CHN-01	ITM-CBL-01	0	8	271	f	none	simulated	system_sim
190	2026-07-18	WH-BOM-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
191	2026-07-18	WH-BOM-01	ITM-GPU-01	0	1	22	f	none	simulated	system_sim
192	2026-07-18	WH-BOM-01	ITM-RAM-01	0	4	43	f	none	simulated	system_sim
193	2026-07-18	WH-BOM-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
194	2026-07-18	WH-BOM-01	ITM-HDD-01	0	1	52	f	none	simulated	system_sim
195	2026-07-18	WH-BOM-01	ITM-CHG-01	0	2	112	f	none	simulated	system_sim
196	2026-07-18	WH-BOM-01	ITM-CBL-01	0	7	267	f	none	simulated	system_sim
197	2026-07-18	WH-DEL-01	ITM-CPU-01	0	0	37	f	none	simulated	system_sim
198	2026-07-18	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
199	2026-07-18	WH-DEL-01	ITM-RAM-01	0	7	33	f	none	simulated	system_sim
200	2026-07-18	WH-DEL-01	ITM-SSD-01	0	0	82	f	none	simulated	system_sim
201	2026-07-18	WH-DEL-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
202	2026-07-18	WH-DEL-01	ITM-CHG-01	0	7	129	f	none	simulated	system_sim
203	2026-07-18	WH-DEL-01	ITM-CBL-01	0	4	273	f	none	simulated	system_sim
204	2026-07-18	WH-CCU-01	ITM-CPU-01	0	1	37	f	none	simulated	system_sim
205	2026-07-18	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
206	2026-07-18	WH-CCU-01	ITM-RAM-01	0	4	40	f	none	simulated	system_sim
207	2026-07-18	WH-CCU-01	ITM-SSD-01	0	2	82	f	none	simulated	system_sim
208	2026-07-18	WH-CCU-01	ITM-HDD-01	0	1	54	f	none	simulated	system_sim
209	2026-07-18	WH-CCU-01	ITM-CHG-01	0	5	117	f	none	simulated	system_sim
210	2026-07-18	WH-CCU-01	ITM-CBL-01	0	5	266	f	none	simulated	system_sim
211	2026-07-19	WH-BLR-01	ITM-CPU-01	0	0	41	f	none	simulated	system_sim
212	2026-07-19	WH-BLR-01	ITM-GPU-01	0	2	25	f	none	simulated	system_sim
213	2026-07-19	WH-BLR-01	ITM-RAM-01	0	4	42	f	none	simulated	system_sim
214	2026-07-19	WH-BLR-01	ITM-SSD-01	0	1	84	f	none	simulated	system_sim
215	2026-07-19	WH-BLR-01	ITM-HDD-01	0	0	51	f	none	simulated	system_sim
216	2026-07-19	WH-BLR-01	ITM-CHG-01	0	3	127	f	none	simulated	system_sim
217	2026-07-19	WH-BLR-01	ITM-CBL-01	0	3	272	f	none	simulated	system_sim
218	2026-07-19	WH-CHN-01	ITM-CPU-01	0	0	40	f	none	simulated	system_sim
219	2026-07-19	WH-CHN-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
220	2026-07-19	WH-CHN-01	ITM-RAM-01	75	8	98	f	none	simulated	system_sim
221	2026-07-19	WH-CHN-01	ITM-SSD-01	0	1	83	f	none	simulated	system_sim
222	2026-07-19	WH-CHN-01	ITM-HDD-01	0	3	55	f	none	simulated	system_sim
223	2026-07-19	WH-CHN-01	ITM-CHG-01	0	1	116	f	none	simulated	system_sim
224	2026-07-19	WH-CHN-01	ITM-CBL-01	0	9	262	f	none	simulated	system_sim
225	2026-07-19	WH-BOM-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
226	2026-07-19	WH-BOM-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
227	2026-07-19	WH-BOM-01	ITM-RAM-01	0	3	40	f	none	simulated	system_sim
228	2026-07-19	WH-BOM-01	ITM-SSD-01	0	1	84	f	none	simulated	system_sim
229	2026-07-19	WH-BOM-01	ITM-HDD-01	0	2	50	f	none	simulated	system_sim
230	2026-07-19	WH-BOM-01	ITM-CHG-01	0	3	109	f	none	simulated	system_sim
231	2026-07-19	WH-BOM-01	ITM-CBL-01	0	4	263	f	none	simulated	system_sim
232	2026-07-19	WH-DEL-01	ITM-CPU-01	0	1	36	f	none	simulated	system_sim
233	2026-07-19	WH-DEL-01	ITM-GPU-01	0	2	26	f	none	simulated	system_sim
234	2026-07-19	WH-DEL-01	ITM-RAM-01	75	9	99	f	none	simulated	system_sim
235	2026-07-19	WH-DEL-01	ITM-SSD-01	0	1	81	f	none	simulated	system_sim
236	2026-07-19	WH-DEL-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
237	2026-07-19	WH-DEL-01	ITM-CHG-01	0	4	125	f	none	simulated	system_sim
238	2026-07-19	WH-DEL-01	ITM-CBL-01	0	7	266	f	none	simulated	system_sim
239	2026-07-19	WH-CCU-01	ITM-CPU-01	0	0	37	f	none	simulated	system_sim
240	2026-07-19	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
241	2026-07-19	WH-CCU-01	ITM-RAM-01	0	5	35	f	none	simulated	system_sim
242	2026-07-19	WH-CCU-01	ITM-SSD-01	0	3	79	f	none	simulated	system_sim
243	2026-07-19	WH-CCU-01	ITM-HDD-01	0	0	54	f	none	simulated	system_sim
244	2026-07-19	WH-CCU-01	ITM-CHG-01	0	2	115	f	none	simulated	system_sim
245	2026-07-19	WH-CCU-01	ITM-CBL-01	0	5	261	f	none	simulated	system_sim
246	2026-07-20	WH-BLR-01	ITM-CPU-01	0	2	39	f	none	simulated	system_sim
247	2026-07-20	WH-BLR-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
248	2026-07-20	WH-BLR-01	ITM-RAM-01	0	1	41	f	none	simulated	system_sim
249	2026-07-20	WH-BLR-01	ITM-SSD-01	0	0	84	f	none	simulated	system_sim
250	2026-07-20	WH-BLR-01	ITM-HDD-01	0	0	51	f	none	simulated	system_sim
251	2026-07-20	WH-BLR-01	ITM-CHG-01	0	2	125	f	none	simulated	system_sim
252	2026-07-20	WH-BLR-01	ITM-CBL-01	0	2	270	f	none	simulated	system_sim
253	2026-07-20	WH-CHN-01	ITM-CPU-01	0	1	39	f	none	simulated	system_sim
254	2026-07-20	WH-CHN-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
255	2026-07-20	WH-CHN-01	ITM-RAM-01	0	1	97	f	none	simulated	system_sim
256	2026-07-20	WH-CHN-01	ITM-SSD-01	0	3	80	f	none	simulated	system_sim
257	2026-07-20	WH-CHN-01	ITM-HDD-01	0	2	53	f	none	simulated	system_sim
258	2026-07-20	WH-CHN-01	ITM-CHG-01	0	9	107	f	none	simulated	system_sim
259	2026-07-20	WH-CHN-01	ITM-CBL-01	0	9	253	f	none	simulated	system_sim
260	2026-07-20	WH-BOM-01	ITM-CPU-01	0	1	41	f	none	simulated	system_sim
261	2026-07-20	WH-BOM-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
262	2026-07-20	WH-BOM-01	ITM-RAM-01	0	2	38	f	none	simulated	system_sim
263	2026-07-20	WH-BOM-01	ITM-SSD-01	0	2	82	f	none	simulated	system_sim
264	2026-07-20	WH-BOM-01	ITM-HDD-01	0	1	49	f	none	simulated	system_sim
265	2026-07-20	WH-BOM-01	ITM-CHG-01	0	9	100	f	none	simulated	system_sim
266	2026-07-20	WH-BOM-01	ITM-CBL-01	0	10	253	f	none	simulated	system_sim
267	2026-07-20	WH-DEL-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
268	2026-07-20	WH-DEL-01	ITM-GPU-01	0	2	24	f	none	simulated	system_sim
269	2026-07-20	WH-DEL-01	ITM-RAM-01	0	8	91	f	none	simulated	system_sim
270	2026-07-20	WH-DEL-01	ITM-SSD-01	0	0	81	f	none	simulated	system_sim
271	2026-07-20	WH-DEL-01	ITM-HDD-01	0	2	56	f	none	simulated	system_sim
272	2026-07-20	WH-DEL-01	ITM-CHG-01	0	10	115	f	none	simulated	system_sim
273	2026-07-20	WH-DEL-01	ITM-CBL-01	0	7	259	f	none	simulated	system_sim
274	2026-07-20	WH-CCU-01	ITM-CPU-01	0	1	36	f	none	simulated	system_sim
275	2026-07-20	WH-CCU-01	ITM-GPU-01	0	2	27	f	none	simulated	system_sim
276	2026-07-20	WH-CCU-01	ITM-RAM-01	75	6	104	f	none	simulated	system_sim
277	2026-07-20	WH-CCU-01	ITM-SSD-01	0	3	76	f	none	simulated	system_sim
278	2026-07-20	WH-CCU-01	ITM-HDD-01	0	0	54	f	none	simulated	system_sim
279	2026-07-20	WH-CCU-01	ITM-CHG-01	0	4	111	f	none	simulated	system_sim
280	2026-07-20	WH-CCU-01	ITM-CBL-01	0	3	258	f	none	simulated	system_sim
281	2026-07-21	WH-BLR-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
282	2026-07-21	WH-BLR-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
283	2026-07-21	WH-BLR-01	ITM-RAM-01	0	7	34	f	none	simulated	system_sim
284	2026-07-21	WH-BLR-01	ITM-SSD-01	0	1	83	f	none	simulated	system_sim
285	2026-07-21	WH-BLR-01	ITM-HDD-01	0	0	51	f	none	simulated	system_sim
286	2026-07-21	WH-BLR-01	ITM-CHG-01	0	2	123	f	none	simulated	system_sim
287	2026-07-21	WH-BLR-01	ITM-CBL-01	0	5	265	f	none	simulated	system_sim
288	2026-07-21	WH-CHN-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
289	2026-07-21	WH-CHN-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
290	2026-07-21	WH-CHN-01	ITM-RAM-01	0	8	89	f	none	simulated	system_sim
291	2026-07-21	WH-CHN-01	ITM-SSD-01	0	3	77	f	none	simulated	system_sim
292	2026-07-21	WH-CHN-01	ITM-HDD-01	0	1	52	f	none	simulated	system_sim
293	2026-07-21	WH-CHN-01	ITM-CHG-01	0	9	98	f	none	simulated	system_sim
294	2026-07-21	WH-CHN-01	ITM-CBL-01	0	4	249	f	none	simulated	system_sim
295	2026-07-21	WH-BOM-01	ITM-CPU-01	0	2	39	f	none	simulated	system_sim
296	2026-07-21	WH-BOM-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
297	2026-07-21	WH-BOM-01	ITM-RAM-01	0	8	30	f	none	simulated	system_sim
298	2026-07-21	WH-BOM-01	ITM-SSD-01	0	3	79	f	none	simulated	system_sim
299	2026-07-21	WH-BOM-01	ITM-HDD-01	0	2	47	f	none	simulated	system_sim
300	2026-07-21	WH-BOM-01	ITM-CHG-01	0	7	93	f	none	simulated	system_sim
301	2026-07-21	WH-BOM-01	ITM-CBL-01	0	9	244	f	none	simulated	system_sim
302	2026-07-21	WH-DEL-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
303	2026-07-21	WH-DEL-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
304	2026-07-21	WH-DEL-01	ITM-RAM-01	0	10	81	f	none	simulated	system_sim
305	2026-07-21	WH-DEL-01	ITM-SSD-01	0	1	80	f	none	simulated	system_sim
306	2026-07-21	WH-DEL-01	ITM-HDD-01	0	2	54	f	none	simulated	system_sim
307	2026-07-21	WH-DEL-01	ITM-CHG-01	0	10	105	f	none	simulated	system_sim
308	2026-07-21	WH-DEL-01	ITM-CBL-01	0	9	250	f	none	simulated	system_sim
309	2026-07-21	WH-CCU-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
310	2026-07-21	WH-CCU-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
311	2026-07-21	WH-CCU-01	ITM-RAM-01	0	9	95	f	none	simulated	system_sim
312	2026-07-21	WH-CCU-01	ITM-SSD-01	0	3	73	f	none	simulated	system_sim
313	2026-07-21	WH-CCU-01	ITM-HDD-01	0	3	51	f	none	simulated	system_sim
314	2026-07-21	WH-CCU-01	ITM-CHG-01	0	4	107	f	none	simulated	system_sim
315	2026-07-21	WH-CCU-01	ITM-CBL-01	0	2	256	f	none	simulated	system_sim
316	2026-07-22	WH-BLR-01	ITM-CPU-01	0	2	37	f	none	simulated	system_sim
317	2026-07-22	WH-BLR-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
318	2026-07-22	WH-BLR-01	ITM-RAM-01	75	2	107	f	none	simulated	system_sim
319	2026-07-22	WH-BLR-01	ITM-SSD-01	0	2	81	f	none	simulated	system_sim
320	2026-07-22	WH-BLR-01	ITM-HDD-01	0	3	48	f	none	simulated	system_sim
321	2026-07-22	WH-BLR-01	ITM-CHG-01	0	9	114	f	none	simulated	system_sim
322	2026-07-22	WH-BLR-01	ITM-CBL-01	0	10	255	f	none	simulated	system_sim
323	2026-07-22	WH-CHN-01	ITM-CPU-01	0	2	37	f	none	simulated	system_sim
324	2026-07-22	WH-CHN-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
325	2026-07-22	WH-CHN-01	ITM-RAM-01	0	5	84	f	none	simulated	system_sim
326	2026-07-22	WH-CHN-01	ITM-SSD-01	0	2	75	f	none	simulated	system_sim
327	2026-07-22	WH-CHN-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
328	2026-07-22	WH-CHN-01	ITM-CHG-01	0	5	93	f	none	simulated	system_sim
329	2026-07-22	WH-CHN-01	ITM-CBL-01	0	9	240	f	none	simulated	system_sim
330	2026-07-22	WH-BOM-01	ITM-CPU-01	0	3	36	f	none	simulated	system_sim
331	2026-07-22	WH-BOM-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
332	2026-07-22	WH-BOM-01	ITM-RAM-01	75	10	95	f	none	simulated	system_sim
333	2026-07-22	WH-BOM-01	ITM-SSD-01	0	0	79	f	none	simulated	system_sim
334	2026-07-22	WH-BOM-01	ITM-HDD-01	0	2	45	f	none	simulated	system_sim
335	2026-07-22	WH-BOM-01	ITM-CHG-01	0	3	90	f	none	simulated	system_sim
336	2026-07-22	WH-BOM-01	ITM-CBL-01	0	2	242	f	none	simulated	system_sim
337	2026-07-22	WH-DEL-01	ITM-CPU-01	0	3	33	f	none	simulated	system_sim
338	2026-07-22	WH-DEL-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
339	2026-07-22	WH-DEL-01	ITM-RAM-01	0	4	77	f	none	simulated	system_sim
340	2026-07-22	WH-DEL-01	ITM-SSD-01	0	0	80	f	none	simulated	system_sim
341	2026-07-22	WH-DEL-01	ITM-HDD-01	0	3	51	f	none	simulated	system_sim
342	2026-07-22	WH-DEL-01	ITM-CHG-01	0	5	100	f	none	simulated	system_sim
343	2026-07-22	WH-DEL-01	ITM-CBL-01	0	9	241	f	none	simulated	system_sim
344	2026-07-22	WH-CCU-01	ITM-CPU-01	0	2	34	f	none	simulated	system_sim
345	2026-07-22	WH-CCU-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
346	2026-07-22	WH-CCU-01	ITM-RAM-01	0	7	88	f	none	simulated	system_sim
347	2026-07-22	WH-CCU-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
348	2026-07-22	WH-CCU-01	ITM-HDD-01	0	0	51	f	none	simulated	system_sim
349	2026-07-22	WH-CCU-01	ITM-CHG-01	0	4	103	f	none	simulated	system_sim
350	2026-07-22	WH-CCU-01	ITM-CBL-01	0	3	253	f	none	simulated	system_sim
351	2026-07-23	WH-BLR-01	ITM-CPU-01	0	0	37	f	none	simulated	system_sim
352	2026-07-23	WH-BLR-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
353	2026-07-23	WH-BLR-01	ITM-RAM-01	0	5	102	f	none	simulated	system_sim
354	2026-07-23	WH-BLR-01	ITM-SSD-01	0	2	79	f	none	simulated	system_sim
355	2026-07-23	WH-BLR-01	ITM-HDD-01	0	2	46	f	none	simulated	system_sim
356	2026-07-23	WH-BLR-01	ITM-CHG-01	0	2	112	f	none	simulated	system_sim
357	2026-07-23	WH-BLR-01	ITM-CBL-01	0	6	249	f	none	simulated	system_sim
358	2026-07-23	WH-CHN-01	ITM-CPU-01	0	2	35	f	none	simulated	system_sim
359	2026-07-23	WH-CHN-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
360	2026-07-23	WH-CHN-01	ITM-RAM-01	0	2	82	f	none	simulated	system_sim
361	2026-07-23	WH-CHN-01	ITM-SSD-01	0	2	73	f	none	simulated	system_sim
362	2026-07-23	WH-CHN-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
363	2026-07-23	WH-CHN-01	ITM-CHG-01	0	4	89	f	none	simulated	system_sim
364	2026-07-23	WH-CHN-01	ITM-CBL-01	0	8	232	f	none	simulated	system_sim
365	2026-07-23	WH-BOM-01	ITM-CPU-01	0	3	33	f	none	simulated	system_sim
366	2026-07-23	WH-BOM-01	ITM-GPU-01	0	2	20	f	none	simulated	system_sim
367	2026-07-23	WH-BOM-01	ITM-RAM-01	0	10	85	f	none	simulated	system_sim
368	2026-07-23	WH-BOM-01	ITM-SSD-01	0	1	78	f	none	simulated	system_sim
369	2026-07-23	WH-BOM-01	ITM-HDD-01	0	0	45	f	none	simulated	system_sim
370	2026-07-23	WH-BOM-01	ITM-CHG-01	0	8	82	f	none	simulated	system_sim
371	2026-07-23	WH-BOM-01	ITM-CBL-01	0	6	236	f	none	simulated	system_sim
372	2026-07-23	WH-DEL-01	ITM-CPU-01	0	1	32	f	none	simulated	system_sim
373	2026-07-23	WH-DEL-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
374	2026-07-23	WH-DEL-01	ITM-RAM-01	0	8	69	f	none	simulated	system_sim
375	2026-07-23	WH-DEL-01	ITM-SSD-01	0	0	80	f	none	simulated	system_sim
376	2026-07-23	WH-DEL-01	ITM-HDD-01	0	0	51	f	none	simulated	system_sim
377	2026-07-23	WH-DEL-01	ITM-CHG-01	0	9	91	f	none	simulated	system_sim
378	2026-07-23	WH-DEL-01	ITM-CBL-01	0	6	235	f	none	simulated	system_sim
379	2026-07-23	WH-CCU-01	ITM-CPU-01	0	2	32	f	none	simulated	system_sim
380	2026-07-23	WH-CCU-01	ITM-GPU-01	0	2	25	f	none	simulated	system_sim
381	2026-07-23	WH-CCU-01	ITM-RAM-01	0	4	84	f	none	simulated	system_sim
382	2026-07-23	WH-CCU-01	ITM-SSD-01	0	1	72	f	none	simulated	system_sim
383	2026-07-23	WH-CCU-01	ITM-HDD-01	0	2	49	f	none	simulated	system_sim
384	2026-07-23	WH-CCU-01	ITM-CHG-01	0	8	95	f	none	simulated	system_sim
385	2026-07-23	WH-CCU-01	ITM-CBL-01	0	6	247	f	none	simulated	system_sim
386	2026-07-24	WH-BLR-01	ITM-CPU-01	0	2	35	f	none	simulated	system_sim
387	2026-07-24	WH-BLR-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
388	2026-07-24	WH-BLR-01	ITM-RAM-01	0	4	98	f	none	simulated	system_sim
389	2026-07-24	WH-BLR-01	ITM-SSD-01	0	0	79	f	none	simulated	system_sim
390	2026-07-24	WH-BLR-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
391	2026-07-24	WH-BLR-01	ITM-CHG-01	0	9	103	f	none	simulated	system_sim
392	2026-07-24	WH-BLR-01	ITM-CBL-01	0	1	248	f	none	simulated	system_sim
393	2026-07-24	WH-CHN-01	ITM-CPU-01	0	3	32	f	none	simulated	system_sim
394	2026-07-24	WH-CHN-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
395	2026-07-24	WH-CHN-01	ITM-RAM-01	0	3	79	f	none	simulated	system_sim
396	2026-07-24	WH-CHN-01	ITM-SSD-01	0	1	72	f	none	simulated	system_sim
397	2026-07-24	WH-CHN-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
398	2026-07-24	WH-CHN-01	ITM-CHG-01	0	4	85	f	none	simulated	system_sim
399	2026-07-24	WH-CHN-01	ITM-CBL-01	0	2	230	f	none	simulated	system_sim
400	2026-07-24	WH-BOM-01	ITM-CPU-01	0	2	31	f	none	simulated	system_sim
401	2026-07-24	WH-BOM-01	ITM-GPU-01	0	2	18	f	none	simulated	system_sim
402	2026-07-24	WH-BOM-01	ITM-RAM-01	0	7	78	f	none	simulated	system_sim
403	2026-07-24	WH-BOM-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
404	2026-07-24	WH-BOM-01	ITM-HDD-01	0	1	44	f	none	simulated	system_sim
405	2026-07-24	WH-BOM-01	ITM-CHG-01	0	6	76	f	none	simulated	system_sim
406	2026-07-24	WH-BOM-01	ITM-CBL-01	0	4	232	f	none	simulated	system_sim
407	2026-07-24	WH-DEL-01	ITM-CPU-01	0	0	32	f	none	simulated	system_sim
408	2026-07-24	WH-DEL-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
409	2026-07-24	WH-DEL-01	ITM-RAM-01	0	10	59	f	none	simulated	system_sim
410	2026-07-24	WH-DEL-01	ITM-SSD-01	0	0	80	f	none	simulated	system_sim
411	2026-07-24	WH-DEL-01	ITM-HDD-01	0	1	50	f	none	simulated	system_sim
412	2026-07-24	WH-DEL-01	ITM-CHG-01	0	7	84	f	none	simulated	system_sim
413	2026-07-24	WH-DEL-01	ITM-CBL-01	0	5	230	f	none	simulated	system_sim
414	2026-07-24	WH-CCU-01	ITM-CPU-01	0	2	30	f	none	simulated	system_sim
415	2026-07-24	WH-CCU-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
416	2026-07-24	WH-CCU-01	ITM-RAM-01	0	9	75	f	none	simulated	system_sim
417	2026-07-24	WH-CCU-01	ITM-SSD-01	0	0	72	f	none	simulated	system_sim
418	2026-07-24	WH-CCU-01	ITM-HDD-01	0	3	46	f	none	simulated	system_sim
419	2026-07-24	WH-CCU-01	ITM-CHG-01	0	3	92	f	none	simulated	system_sim
420	2026-07-24	WH-CCU-01	ITM-CBL-01	0	8	239	f	none	simulated	system_sim
421	2026-07-25	WH-BLR-01	ITM-CPU-01	0	0	35	f	none	simulated	system_sim
422	2026-07-25	WH-BLR-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
423	2026-07-25	WH-BLR-01	ITM-RAM-01	0	8	90	f	none	simulated	system_sim
424	2026-07-25	WH-BLR-01	ITM-SSD-01	0	0	79	f	none	simulated	system_sim
425	2026-07-25	WH-BLR-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
426	2026-07-25	WH-BLR-01	ITM-CHG-01	0	10	93	f	none	simulated	system_sim
427	2026-07-25	WH-BLR-01	ITM-CBL-01	0	8	240	f	none	simulated	system_sim
428	2026-07-25	WH-CHN-01	ITM-CPU-01	0	0	17	t	shrinkage	simulated	system_sim
429	2026-07-25	WH-CHN-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
430	2026-07-25	WH-CHN-01	ITM-RAM-01	0	3	76	f	none	simulated	system_sim
431	2026-07-25	WH-CHN-01	ITM-SSD-01	0	3	69	f	none	simulated	system_sim
432	2026-07-25	WH-CHN-01	ITM-HDD-01	0	3	49	f	none	simulated	system_sim
433	2026-07-25	WH-CHN-01	ITM-CHG-01	0	1	84	f	none	simulated	system_sim
434	2026-07-25	WH-CHN-01	ITM-CBL-01	0	9	221	f	none	simulated	system_sim
435	2026-07-25	WH-BOM-01	ITM-CPU-01	0	0	31	f	none	simulated	system_sim
436	2026-07-25	WH-BOM-01	ITM-GPU-01	0	2	16	f	none	simulated	system_sim
437	2026-07-25	WH-BOM-01	ITM-RAM-01	0	7	71	f	none	simulated	system_sim
438	2026-07-25	WH-BOM-01	ITM-SSD-01	0	1	77	f	none	simulated	system_sim
439	2026-07-25	WH-BOM-01	ITM-HDD-01	0	2	42	f	none	simulated	system_sim
440	2026-07-25	WH-BOM-01	ITM-CHG-01	0	3	73	f	none	simulated	system_sim
441	2026-07-25	WH-BOM-01	ITM-CBL-01	0	4	228	f	none	simulated	system_sim
442	2026-07-25	WH-DEL-01	ITM-CPU-01	0	1	31	f	none	simulated	system_sim
443	2026-07-25	WH-DEL-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
444	2026-07-25	WH-DEL-01	ITM-RAM-01	0	10	49	f	none	simulated	system_sim
445	2026-07-25	WH-DEL-01	ITM-SSD-01	0	1	79	f	none	simulated	system_sim
446	2026-07-25	WH-DEL-01	ITM-HDD-01	0	0	50	f	none	simulated	system_sim
447	2026-07-25	WH-DEL-01	ITM-CHG-01	0	1	83	f	none	simulated	system_sim
448	2026-07-25	WH-DEL-01	ITM-CBL-01	0	9	221	f	none	simulated	system_sim
449	2026-07-25	WH-CCU-01	ITM-CPU-01	0	1	29	f	none	simulated	system_sim
450	2026-07-25	WH-CCU-01	ITM-GPU-01	0	1	24	f	none	simulated	system_sim
451	2026-07-25	WH-CCU-01	ITM-RAM-01	0	6	69	f	none	simulated	system_sim
452	2026-07-25	WH-CCU-01	ITM-SSD-01	0	3	69	f	none	simulated	system_sim
453	2026-07-25	WH-CCU-01	ITM-HDD-01	0	1	45	f	none	simulated	system_sim
454	2026-07-25	WH-CCU-01	ITM-CHG-01	0	2	90	f	none	simulated	system_sim
455	2026-07-25	WH-CCU-01	ITM-CBL-01	0	3	236	f	none	simulated	system_sim
456	2026-07-26	WH-BLR-01	ITM-CPU-01	0	1	34	f	none	simulated	system_sim
457	2026-07-26	WH-BLR-01	ITM-GPU-01	0	1	22	f	none	simulated	system_sim
458	2026-07-26	WH-BLR-01	ITM-RAM-01	0	7	83	f	none	simulated	system_sim
459	2026-07-26	WH-BLR-01	ITM-SSD-01	0	2	77	f	none	simulated	system_sim
460	2026-07-26	WH-BLR-01	ITM-HDD-01	0	1	45	f	none	simulated	system_sim
461	2026-07-26	WH-BLR-01	ITM-CHG-01	0	9	84	f	none	simulated	system_sim
462	2026-07-26	WH-BLR-01	ITM-CBL-01	0	6	234	f	none	simulated	system_sim
463	2026-07-26	WH-CHN-01	ITM-CPU-01	45	0	62	f	none	simulated	system_sim
464	2026-07-26	WH-CHN-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
465	2026-07-26	WH-CHN-01	ITM-RAM-01	0	3	73	f	none	simulated	system_sim
466	2026-07-26	WH-CHN-01	ITM-SSD-01	0	2	67	f	none	simulated	system_sim
467	2026-07-26	WH-CHN-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
468	2026-07-26	WH-CHN-01	ITM-CHG-01	0	8	76	f	none	simulated	system_sim
469	2026-07-26	WH-CHN-01	ITM-CBL-01	0	8	213	f	none	simulated	system_sim
470	2026-07-26	WH-BOM-01	ITM-CPU-01	0	0	31	f	none	simulated	system_sim
471	2026-07-26	WH-BOM-01	ITM-GPU-01	0	1	15	f	none	simulated	system_sim
472	2026-07-26	WH-BOM-01	ITM-RAM-01	0	7	64	f	none	simulated	system_sim
473	2026-07-26	WH-BOM-01	ITM-SSD-01	0	3	74	f	none	simulated	system_sim
474	2026-07-26	WH-BOM-01	ITM-HDD-01	0	0	42	f	none	simulated	system_sim
475	2026-07-26	WH-BOM-01	ITM-CHG-01	150	2	221	f	none	simulated	system_sim
476	2026-07-26	WH-BOM-01	ITM-CBL-01	0	5	223	f	none	simulated	system_sim
477	2026-07-26	WH-DEL-01	ITM-CPU-01	0	2	29	f	none	simulated	system_sim
478	2026-07-26	WH-DEL-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
479	2026-07-26	WH-DEL-01	ITM-RAM-01	0	7	42	f	none	simulated	system_sim
480	2026-07-26	WH-DEL-01	ITM-SSD-01	0	3	76	f	none	simulated	system_sim
481	2026-07-26	WH-DEL-01	ITM-HDD-01	0	2	48	f	none	simulated	system_sim
482	2026-07-26	WH-DEL-01	ITM-CHG-01	0	6	77	f	none	simulated	system_sim
483	2026-07-26	WH-DEL-01	ITM-CBL-01	0	1	220	f	none	simulated	system_sim
484	2026-07-26	WH-CCU-01	ITM-CPU-01	0	1	28	f	none	simulated	system_sim
485	2026-07-26	WH-CCU-01	ITM-GPU-01	0	2	22	f	none	simulated	system_sim
486	2026-07-26	WH-CCU-01	ITM-RAM-01	0	6	63	f	none	simulated	system_sim
487	2026-07-26	WH-CCU-01	ITM-SSD-01	0	0	69	f	none	simulated	system_sim
488	2026-07-26	WH-CCU-01	ITM-HDD-01	0	0	45	f	none	simulated	system_sim
489	2026-07-26	WH-CCU-01	ITM-CHG-01	0	2	88	f	none	simulated	system_sim
490	2026-07-26	WH-CCU-01	ITM-CBL-01	0	8	228	f	none	simulated	system_sim
491	2026-07-27	WH-BLR-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
492	2026-07-27	WH-BLR-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
493	2026-07-27	WH-BLR-01	ITM-RAM-01	0	6	77	f	none	simulated	system_sim
494	2026-07-27	WH-BLR-01	ITM-SSD-01	0	0	77	f	none	simulated	system_sim
495	2026-07-27	WH-BLR-01	ITM-HDD-01	0	1	44	f	none	simulated	system_sim
496	2026-07-27	WH-BLR-01	ITM-CHG-01	0	3	81	f	none	simulated	system_sim
497	2026-07-27	WH-BLR-01	ITM-CBL-01	0	6	228	f	none	simulated	system_sim
498	2026-07-27	WH-CHN-01	ITM-CPU-01	0	0	62	f	none	simulated	system_sim
499	2026-07-27	WH-CHN-01	ITM-GPU-01	0	1	22	f	none	simulated	system_sim
500	2026-07-27	WH-CHN-01	ITM-RAM-01	0	4	69	f	none	simulated	system_sim
501	2026-07-27	WH-CHN-01	ITM-SSD-01	0	0	67	f	none	simulated	system_sim
502	2026-07-27	WH-CHN-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
503	2026-07-27	WH-CHN-01	ITM-CHG-01	0	2	74	f	none	simulated	system_sim
504	2026-07-27	WH-CHN-01	ITM-CBL-01	0	6	207	f	none	simulated	system_sim
505	2026-07-27	WH-BOM-01	ITM-CPU-01	0	0	31	f	none	simulated	system_sim
506	2026-07-27	WH-BOM-01	ITM-GPU-01	0	1	14	f	none	simulated	system_sim
507	2026-07-27	WH-BOM-01	ITM-RAM-01	0	9	55	f	none	simulated	system_sim
508	2026-07-27	WH-BOM-01	ITM-SSD-01	0	2	72	f	none	simulated	system_sim
509	2026-07-27	WH-BOM-01	ITM-HDD-01	0	3	39	f	none	simulated	system_sim
510	2026-07-27	WH-BOM-01	ITM-CHG-01	0	7	214	f	none	simulated	system_sim
511	2026-07-27	WH-BOM-01	ITM-CBL-01	0	9	214	f	none	simulated	system_sim
512	2026-07-27	WH-DEL-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
513	2026-07-27	WH-DEL-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
514	2026-07-27	WH-DEL-01	ITM-RAM-01	0	2	40	f	none	simulated	system_sim
515	2026-07-27	WH-DEL-01	ITM-SSD-01	0	0	76	f	none	simulated	system_sim
516	2026-07-27	WH-DEL-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
517	2026-07-27	WH-DEL-01	ITM-CHG-01	0	5	72	f	none	simulated	system_sim
518	2026-07-27	WH-DEL-01	ITM-CBL-01	0	6	214	f	none	simulated	system_sim
519	2026-07-27	WH-CCU-01	ITM-CPU-01	0	0	28	f	none	simulated	system_sim
520	2026-07-27	WH-CCU-01	ITM-GPU-01	0	2	20	f	none	simulated	system_sim
521	2026-07-27	WH-CCU-01	ITM-RAM-01	0	6	57	f	none	simulated	system_sim
522	2026-07-27	WH-CCU-01	ITM-SSD-01	0	3	66	f	none	simulated	system_sim
523	2026-07-27	WH-CCU-01	ITM-HDD-01	0	2	43	f	none	simulated	system_sim
524	2026-07-27	WH-CCU-01	ITM-CHG-01	0	2	86	f	none	simulated	system_sim
525	2026-07-27	WH-CCU-01	ITM-CBL-01	0	2	226	f	none	simulated	system_sim
526	2026-07-28	WH-BLR-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
527	2026-07-28	WH-BLR-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
528	2026-07-28	WH-BLR-01	ITM-RAM-01	0	10	67	f	none	simulated	system_sim
529	2026-07-28	WH-BLR-01	ITM-SSD-01	0	0	77	f	none	simulated	system_sim
530	2026-07-28	WH-BLR-01	ITM-HDD-01	0	3	41	f	none	simulated	system_sim
531	2026-07-28	WH-BLR-01	ITM-CHG-01	0	4	77	f	none	simulated	system_sim
532	2026-07-28	WH-BLR-01	ITM-CBL-01	0	8	220	f	none	simulated	system_sim
533	2026-07-28	WH-CHN-01	ITM-CPU-01	0	3	59	f	none	simulated	system_sim
534	2026-07-28	WH-CHN-01	ITM-GPU-01	0	2	20	f	none	simulated	system_sim
535	2026-07-28	WH-CHN-01	ITM-RAM-01	0	8	61	f	none	simulated	system_sim
536	2026-07-28	WH-CHN-01	ITM-SSD-01	0	2	65	f	none	simulated	system_sim
537	2026-07-28	WH-CHN-01	ITM-HDD-01	0	3	46	f	none	simulated	system_sim
538	2026-07-28	WH-CHN-01	ITM-CHG-01	150	6	218	f	none	simulated	system_sim
539	2026-07-28	WH-CHN-01	ITM-CBL-01	0	5	202	f	none	simulated	system_sim
540	2026-07-28	WH-BOM-01	ITM-CPU-01	0	3	28	f	none	simulated	system_sim
541	2026-07-28	WH-BOM-01	ITM-GPU-01	30	2	42	f	none	simulated	system_sim
542	2026-07-28	WH-BOM-01	ITM-RAM-01	0	2	53	f	none	simulated	system_sim
543	2026-07-28	WH-BOM-01	ITM-SSD-01	0	0	72	f	none	simulated	system_sim
544	2026-07-28	WH-BOM-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
545	2026-07-28	WH-BOM-01	ITM-CHG-01	0	6	208	f	none	simulated	system_sim
546	2026-07-28	WH-BOM-01	ITM-CBL-01	0	1	213	f	none	simulated	system_sim
547	2026-07-28	WH-DEL-01	ITM-CPU-01	0	1	28	f	none	simulated	system_sim
548	2026-07-28	WH-DEL-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
549	2026-07-28	WH-DEL-01	ITM-RAM-01	0	1	39	f	none	simulated	system_sim
550	2026-07-28	WH-DEL-01	ITM-SSD-01	0	0	76	f	none	simulated	system_sim
551	2026-07-28	WH-DEL-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
552	2026-07-28	WH-DEL-01	ITM-CHG-01	150	10	212	f	none	simulated	system_sim
553	2026-07-28	WH-DEL-01	ITM-CBL-01	0	1	213	f	none	simulated	system_sim
554	2026-07-28	WH-CCU-01	ITM-CPU-01	0	1	27	f	none	simulated	system_sim
555	2026-07-28	WH-CCU-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
556	2026-07-28	WH-CCU-01	ITM-RAM-01	0	3	54	f	none	simulated	system_sim
557	2026-07-28	WH-CCU-01	ITM-SSD-01	0	2	64	f	none	simulated	system_sim
558	2026-07-28	WH-CCU-01	ITM-HDD-01	0	1	42	f	none	simulated	system_sim
559	2026-07-28	WH-CCU-01	ITM-CHG-01	0	7	79	f	none	simulated	system_sim
560	2026-07-28	WH-CCU-01	ITM-CBL-01	0	10	216	f	none	simulated	system_sim
561	2026-07-29	WH-BLR-01	ITM-CPU-01	0	2	32	f	none	simulated	system_sim
562	2026-07-29	WH-BLR-01	ITM-GPU-01	0	1	21	f	none	simulated	system_sim
563	2026-07-29	WH-BLR-01	ITM-RAM-01	0	2	65	f	none	simulated	system_sim
564	2026-07-29	WH-BLR-01	ITM-SSD-01	0	3	74	f	none	simulated	system_sim
565	2026-07-29	WH-BLR-01	ITM-HDD-01	0	2	39	f	none	simulated	system_sim
566	2026-07-29	WH-BLR-01	ITM-CHG-01	0	8	69	f	none	simulated	system_sim
567	2026-07-29	WH-BLR-01	ITM-CBL-01	0	10	210	f	none	simulated	system_sim
568	2026-07-29	WH-CHN-01	ITM-CPU-01	0	1	58	f	none	simulated	system_sim
569	2026-07-29	WH-CHN-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
570	2026-07-29	WH-CHN-01	ITM-RAM-01	0	8	53	f	none	simulated	system_sim
571	2026-07-29	WH-CHN-01	ITM-SSD-01	0	1	64	f	none	simulated	system_sim
572	2026-07-29	WH-CHN-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
573	2026-07-29	WH-CHN-01	ITM-CHG-01	0	7	211	f	none	simulated	system_sim
574	2026-07-29	WH-CHN-01	ITM-CBL-01	0	5	197	f	none	simulated	system_sim
575	2026-07-29	WH-BOM-01	ITM-CPU-01	0	2	26	f	none	simulated	system_sim
576	2026-07-29	WH-BOM-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
577	2026-07-29	WH-BOM-01	ITM-RAM-01	0	7	46	f	none	simulated	system_sim
578	2026-07-29	WH-BOM-01	ITM-SSD-01	0	1	71	f	none	simulated	system_sim
579	2026-07-29	WH-BOM-01	ITM-HDD-01	0	1	38	f	none	simulated	system_sim
580	2026-07-29	WH-BOM-01	ITM-CHG-01	0	10	198	f	none	simulated	system_sim
581	2026-07-29	WH-BOM-01	ITM-CBL-01	0	9	204	f	none	simulated	system_sim
582	2026-07-29	WH-DEL-01	ITM-CPU-01	0	2	26	f	none	simulated	system_sim
583	2026-07-29	WH-DEL-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
584	2026-07-29	WH-DEL-01	ITM-RAM-01	0	8	31	f	none	simulated	system_sim
585	2026-07-29	WH-DEL-01	ITM-SSD-01	0	1	75	f	none	simulated	system_sim
586	2026-07-29	WH-DEL-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
587	2026-07-29	WH-DEL-01	ITM-CHG-01	0	7	205	f	none	simulated	system_sim
588	2026-07-29	WH-DEL-01	ITM-CBL-01	0	5	208	f	none	simulated	system_sim
589	2026-07-29	WH-CCU-01	ITM-CPU-01	0	0	27	f	none	simulated	system_sim
590	2026-07-29	WH-CCU-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
591	2026-07-29	WH-CCU-01	ITM-RAM-01	0	8	46	f	none	simulated	system_sim
592	2026-07-29	WH-CCU-01	ITM-SSD-01	0	1	63	f	none	simulated	system_sim
593	2026-07-29	WH-CCU-01	ITM-HDD-01	0	0	42	f	none	simulated	system_sim
594	2026-07-29	WH-CCU-01	ITM-CHG-01	0	9	70	f	none	simulated	system_sim
595	2026-07-29	WH-CCU-01	ITM-CBL-01	0	5	211	f	none	simulated	system_sim
596	2026-07-30	WH-BLR-01	ITM-CPU-01	0	1	31	f	none	simulated	system_sim
597	2026-07-30	WH-BLR-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
598	2026-07-30	WH-BLR-01	ITM-RAM-01	0	5	60	f	none	simulated	system_sim
599	2026-07-30	WH-BLR-01	ITM-SSD-01	0	0	74	f	none	simulated	system_sim
600	2026-07-30	WH-BLR-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
601	2026-07-30	WH-BLR-01	ITM-CHG-01	150	2	217	f	none	simulated	system_sim
602	2026-07-30	WH-BLR-01	ITM-CBL-01	0	1	209	f	none	simulated	system_sim
603	2026-07-30	WH-CHN-01	ITM-CPU-01	0	0	58	f	none	simulated	system_sim
604	2026-07-30	WH-CHN-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
605	2026-07-30	WH-CHN-01	ITM-RAM-01	0	4	49	f	none	simulated	system_sim
606	2026-07-30	WH-CHN-01	ITM-SSD-01	0	0	64	f	none	simulated	system_sim
607	2026-07-30	WH-CHN-01	ITM-HDD-01	0	3	43	f	none	simulated	system_sim
608	2026-07-30	WH-CHN-01	ITM-CHG-01	0	6	205	f	none	simulated	system_sim
609	2026-07-30	WH-CHN-01	ITM-CBL-01	0	4	193	f	none	simulated	system_sim
610	2026-07-30	WH-BOM-01	ITM-CPU-01	0	2	24	f	none	simulated	system_sim
611	2026-07-30	WH-BOM-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
612	2026-07-30	WH-BOM-01	ITM-RAM-01	0	6	40	f	none	simulated	system_sim
613	2026-07-30	WH-BOM-01	ITM-SSD-01	0	0	71	f	none	simulated	system_sim
614	2026-07-30	WH-BOM-01	ITM-HDD-01	0	3	35	f	none	simulated	system_sim
615	2026-07-30	WH-BOM-01	ITM-CHG-01	0	1	197	f	none	simulated	system_sim
616	2026-07-30	WH-BOM-01	ITM-CBL-01	0	8	196	f	none	simulated	system_sim
617	2026-07-30	WH-DEL-01	ITM-CPU-01	0	1	25	f	none	simulated	system_sim
618	2026-07-30	WH-DEL-01	ITM-GPU-01	0	1	23	f	none	simulated	system_sim
619	2026-07-30	WH-DEL-01	ITM-RAM-01	75	2	104	f	none	simulated	system_sim
620	2026-07-30	WH-DEL-01	ITM-SSD-01	0	0	75	f	none	simulated	system_sim
621	2026-07-30	WH-DEL-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
622	2026-07-30	WH-DEL-01	ITM-CHG-01	0	4	201	f	none	simulated	system_sim
623	2026-07-30	WH-DEL-01	ITM-CBL-01	0	9	199	f	none	simulated	system_sim
624	2026-07-30	WH-CCU-01	ITM-CPU-01	0	0	27	f	none	simulated	system_sim
625	2026-07-30	WH-CCU-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
626	2026-07-30	WH-CCU-01	ITM-RAM-01	0	5	41	f	none	simulated	system_sim
627	2026-07-30	WH-CCU-01	ITM-SSD-01	0	1	62	f	none	simulated	system_sim
628	2026-07-30	WH-CCU-01	ITM-HDD-01	0	0	42	f	none	simulated	system_sim
629	2026-07-30	WH-CCU-01	ITM-CHG-01	150	8	212	f	none	simulated	system_sim
630	2026-07-30	WH-CCU-01	ITM-CBL-01	0	9	202	f	none	simulated	system_sim
631	2026-07-31	WH-BLR-01	ITM-CPU-01	0	1	30	f	none	simulated	system_sim
632	2026-07-31	WH-BLR-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
633	2026-07-31	WH-BLR-01	ITM-RAM-01	0	10	50	f	none	simulated	system_sim
634	2026-07-31	WH-BLR-01	ITM-SSD-01	0	3	71	f	none	simulated	system_sim
635	2026-07-31	WH-BLR-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
636	2026-07-31	WH-BLR-01	ITM-CHG-01	0	8	209	f	none	simulated	system_sim
637	2026-07-31	WH-BLR-01	ITM-CBL-01	0	4	205	f	none	simulated	system_sim
638	2026-07-31	WH-CHN-01	ITM-CPU-01	0	0	58	f	none	simulated	system_sim
639	2026-07-31	WH-CHN-01	ITM-GPU-01	0	1	19	f	none	simulated	system_sim
640	2026-07-31	WH-CHN-01	ITM-RAM-01	0	10	39	f	none	simulated	system_sim
641	2026-07-31	WH-CHN-01	ITM-SSD-01	0	0	64	f	none	simulated	system_sim
642	2026-07-31	WH-CHN-01	ITM-HDD-01	0	2	41	f	none	simulated	system_sim
643	2026-07-31	WH-CHN-01	ITM-CHG-01	0	9	196	f	none	simulated	system_sim
644	2026-07-31	WH-CHN-01	ITM-CBL-01	0	5	188	f	none	simulated	system_sim
645	2026-07-31	WH-BOM-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
646	2026-07-31	WH-BOM-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
647	2026-07-31	WH-BOM-01	ITM-RAM-01	0	7	33	f	none	simulated	system_sim
648	2026-07-31	WH-BOM-01	ITM-SSD-01	0	1	70	f	none	simulated	system_sim
649	2026-07-31	WH-BOM-01	ITM-HDD-01	0	1	34	f	none	simulated	system_sim
650	2026-07-31	WH-BOM-01	ITM-CHG-01	0	1	196	f	none	simulated	system_sim
651	2026-07-31	WH-BOM-01	ITM-CBL-01	0	8	188	f	none	simulated	system_sim
652	2026-07-31	WH-DEL-01	ITM-CPU-01	0	3	22	f	none	simulated	system_sim
653	2026-07-31	WH-DEL-01	ITM-GPU-01	0	2	21	f	none	simulated	system_sim
654	2026-07-31	WH-DEL-01	ITM-RAM-01	0	7	97	f	none	simulated	system_sim
655	2026-07-31	WH-DEL-01	ITM-SSD-01	0	0	75	f	none	simulated	system_sim
656	2026-07-31	WH-DEL-01	ITM-HDD-01	0	2	46	f	none	simulated	system_sim
657	2026-07-31	WH-DEL-01	ITM-CHG-01	0	4	197	f	none	simulated	system_sim
658	2026-07-31	WH-DEL-01	ITM-CBL-01	0	8	191	f	none	simulated	system_sim
659	2026-07-31	WH-CCU-01	ITM-CPU-01	0	3	24	f	none	simulated	system_sim
660	2026-07-31	WH-CCU-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
661	2026-07-31	WH-CCU-01	ITM-RAM-01	0	7	34	f	none	simulated	system_sim
662	2026-07-31	WH-CCU-01	ITM-SSD-01	0	2	60	f	none	simulated	system_sim
663	2026-07-31	WH-CCU-01	ITM-HDD-01	0	0	42	f	none	simulated	system_sim
664	2026-07-31	WH-CCU-01	ITM-CHG-01	0	1	211	f	none	simulated	system_sim
665	2026-07-31	WH-CCU-01	ITM-CBL-01	0	7	195	f	none	simulated	system_sim
666	2026-08-01	WH-BLR-01	ITM-CPU-01	0	0	30	f	none	simulated	system_sim
667	2026-08-01	WH-BLR-01	ITM-GPU-01	0	1	18	f	none	simulated	system_sim
668	2026-08-01	WH-BLR-01	ITM-RAM-01	0	7	43	f	none	simulated	system_sim
669	2026-08-01	WH-BLR-01	ITM-SSD-01	0	3	68	f	none	simulated	system_sim
670	2026-08-01	WH-BLR-01	ITM-HDD-01	0	1	38	f	none	simulated	system_sim
671	2026-08-01	WH-BLR-01	ITM-CHG-01	0	3	206	f	none	simulated	system_sim
672	2026-08-01	WH-BLR-01	ITM-CBL-01	0	2	203	f	none	simulated	system_sim
673	2026-08-01	WH-CHN-01	ITM-CPU-01	0	3	55	f	none	simulated	system_sim
674	2026-08-01	WH-CHN-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
675	2026-08-01	WH-CHN-01	ITM-RAM-01	0	4	35	f	none	simulated	system_sim
676	2026-08-01	WH-CHN-01	ITM-SSD-01	0	0	64	f	none	simulated	system_sim
677	2026-08-01	WH-CHN-01	ITM-HDD-01	0	1	40	f	none	simulated	system_sim
678	2026-08-01	WH-CHN-01	ITM-CHG-01	0	1	195	f	none	simulated	system_sim
679	2026-08-01	WH-CHN-01	ITM-CBL-01	0	10	178	f	none	simulated	system_sim
680	2026-08-01	WH-BOM-01	ITM-CPU-01	0	3	21	f	none	simulated	system_sim
681	2026-08-01	WH-BOM-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
682	2026-08-01	WH-BOM-01	ITM-RAM-01	75	8	100	f	none	simulated	system_sim
683	2026-08-01	WH-BOM-01	ITM-SSD-01	0	1	69	f	none	simulated	system_sim
684	2026-08-01	WH-BOM-01	ITM-HDD-01	0	0	34	f	none	simulated	system_sim
685	2026-08-01	WH-BOM-01	ITM-CHG-01	0	2	194	f	none	simulated	system_sim
686	2026-08-01	WH-BOM-01	ITM-CBL-01	0	5	183	f	none	simulated	system_sim
687	2026-08-01	WH-DEL-01	ITM-CPU-01	45	0	67	f	none	simulated	system_sim
688	2026-08-01	WH-DEL-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
689	2026-08-01	WH-DEL-01	ITM-RAM-01	0	4	93	f	none	simulated	system_sim
690	2026-08-01	WH-DEL-01	ITM-SSD-01	0	2	73	f	none	simulated	system_sim
691	2026-08-01	WH-DEL-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
692	2026-08-01	WH-DEL-01	ITM-CHG-01	0	10	187	f	none	simulated	system_sim
693	2026-08-01	WH-DEL-01	ITM-CBL-01	0	8	183	f	none	simulated	system_sim
694	2026-08-01	WH-CCU-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
695	2026-08-01	WH-CCU-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
696	2026-08-01	WH-CCU-01	ITM-RAM-01	75	4	105	f	none	simulated	system_sim
697	2026-08-01	WH-CCU-01	ITM-SSD-01	0	0	60	f	none	simulated	system_sim
698	2026-08-01	WH-CCU-01	ITM-HDD-01	0	3	39	f	none	simulated	system_sim
699	2026-08-01	WH-CCU-01	ITM-CHG-01	0	2	209	f	none	simulated	system_sim
700	2026-08-01	WH-CCU-01	ITM-CBL-01	0	2	193	f	none	simulated	system_sim
701	2026-08-02	WH-BLR-01	ITM-CPU-01	0	2	28	f	none	simulated	system_sim
702	2026-08-02	WH-BLR-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
703	2026-08-02	WH-BLR-01	ITM-RAM-01	0	2	41	f	none	simulated	system_sim
704	2026-08-02	WH-BLR-01	ITM-SSD-01	0	0	68	f	none	simulated	system_sim
705	2026-08-02	WH-BLR-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
706	2026-08-02	WH-BLR-01	ITM-CHG-01	0	10	196	f	none	simulated	system_sim
707	2026-08-02	WH-BLR-01	ITM-CBL-01	0	1	202	f	none	simulated	system_sim
708	2026-08-02	WH-CHN-01	ITM-CPU-01	0	1	54	f	none	simulated	system_sim
709	2026-08-02	WH-CHN-01	ITM-GPU-01	0	1	18	f	none	simulated	system_sim
710	2026-08-02	WH-CHN-01	ITM-RAM-01	75	7	103	f	none	simulated	system_sim
711	2026-08-02	WH-CHN-01	ITM-SSD-01	0	3	61	f	none	simulated	system_sim
712	2026-08-02	WH-CHN-01	ITM-HDD-01	0	3	37	f	none	simulated	system_sim
713	2026-08-02	WH-CHN-01	ITM-CHG-01	0	10	185	f	none	simulated	system_sim
714	2026-08-02	WH-CHN-01	ITM-CBL-01	0	10	168	f	none	simulated	system_sim
715	2026-08-02	WH-BOM-01	ITM-CPU-01	45	0	66	f	none	simulated	system_sim
716	2026-08-02	WH-BOM-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
717	2026-08-02	WH-BOM-01	ITM-RAM-01	0	5	95	f	none	simulated	system_sim
718	2026-08-02	WH-BOM-01	ITM-SSD-01	0	0	69	f	none	simulated	system_sim
719	2026-08-02	WH-BOM-01	ITM-HDD-01	0	1	33	f	none	simulated	system_sim
720	2026-08-02	WH-BOM-01	ITM-CHG-01	0	4	190	f	none	simulated	system_sim
721	2026-08-02	WH-BOM-01	ITM-CBL-01	0	8	175	f	none	simulated	system_sim
722	2026-08-02	WH-DEL-01	ITM-CPU-01	0	0	67	f	none	simulated	system_sim
723	2026-08-02	WH-DEL-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
724	2026-08-02	WH-DEL-01	ITM-RAM-01	0	7	86	f	none	simulated	system_sim
725	2026-08-02	WH-DEL-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
726	2026-08-02	WH-DEL-01	ITM-HDD-01	0	2	44	f	none	simulated	system_sim
727	2026-08-02	WH-DEL-01	ITM-CHG-01	0	9	178	f	none	simulated	system_sim
728	2026-08-02	WH-DEL-01	ITM-CBL-01	0	10	173	f	none	simulated	system_sim
729	2026-08-02	WH-CCU-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
730	2026-08-02	WH-CCU-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
731	2026-08-02	WH-CCU-01	ITM-RAM-01	0	6	99	f	none	simulated	system_sim
732	2026-08-02	WH-CCU-01	ITM-SSD-01	0	0	60	f	none	simulated	system_sim
733	2026-08-02	WH-CCU-01	ITM-HDD-01	0	2	37	f	none	simulated	system_sim
734	2026-08-02	WH-CCU-01	ITM-CHG-01	0	5	204	f	none	simulated	system_sim
735	2026-08-02	WH-CCU-01	ITM-CBL-01	0	2	191	f	none	simulated	system_sim
736	2026-08-03	WH-BLR-01	ITM-CPU-01	0	3	25	f	none	simulated	system_sim
737	2026-08-03	WH-BLR-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
738	2026-08-03	WH-BLR-01	ITM-RAM-01	0	1	40	f	none	simulated	system_sim
739	2026-08-03	WH-BLR-01	ITM-SSD-01	0	1	67	f	none	simulated	system_sim
740	2026-08-03	WH-BLR-01	ITM-HDD-01	0	3	35	f	none	simulated	system_sim
741	2026-08-03	WH-BLR-01	ITM-CHG-01	0	6	190	f	none	simulated	system_sim
742	2026-08-03	WH-BLR-01	ITM-CBL-01	0	6	196	f	none	simulated	system_sim
743	2026-08-03	WH-CHN-01	ITM-CPU-01	0	3	51	f	none	simulated	system_sim
744	2026-08-03	WH-CHN-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
745	2026-08-03	WH-CHN-01	ITM-RAM-01	0	6	97	f	none	simulated	system_sim
746	2026-08-03	WH-CHN-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
747	2026-08-03	WH-CHN-01	ITM-HDD-01	0	0	37	f	none	simulated	system_sim
748	2026-08-03	WH-CHN-01	ITM-CHG-01	0	7	178	f	none	simulated	system_sim
749	2026-08-03	WH-CHN-01	ITM-CBL-01	0	1	167	f	none	simulated	system_sim
750	2026-08-03	WH-BOM-01	ITM-CPU-01	0	2	64	f	none	simulated	system_sim
751	2026-08-03	WH-BOM-01	ITM-GPU-01	0	1	41	f	none	simulated	system_sim
752	2026-08-03	WH-BOM-01	ITM-RAM-01	0	1	94	f	none	simulated	system_sim
753	2026-08-03	WH-BOM-01	ITM-SSD-01	0	0	69	f	none	simulated	system_sim
754	2026-08-03	WH-BOM-01	ITM-HDD-01	0	2	31	f	none	simulated	system_sim
755	2026-08-03	WH-BOM-01	ITM-CHG-01	0	6	184	f	none	simulated	system_sim
756	2026-08-03	WH-BOM-01	ITM-CBL-01	0	9	166	f	none	simulated	system_sim
757	2026-08-03	WH-DEL-01	ITM-CPU-01	0	2	65	f	none	simulated	system_sim
758	2026-08-03	WH-DEL-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
759	2026-08-03	WH-DEL-01	ITM-RAM-01	0	2	84	f	none	simulated	system_sim
760	2026-08-03	WH-DEL-01	ITM-SSD-01	0	2	71	f	none	simulated	system_sim
761	2026-08-03	WH-DEL-01	ITM-HDD-01	0	3	41	f	none	simulated	system_sim
762	2026-08-03	WH-DEL-01	ITM-CHG-01	0	2	176	f	none	simulated	system_sim
763	2026-08-03	WH-DEL-01	ITM-CBL-01	0	4	169	f	none	simulated	system_sim
764	2026-08-03	WH-CCU-01	ITM-CPU-01	0	1	23	f	none	simulated	system_sim
765	2026-08-03	WH-CCU-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
766	2026-08-03	WH-CCU-01	ITM-RAM-01	0	8	91	f	none	simulated	system_sim
767	2026-08-03	WH-CCU-01	ITM-SSD-01	0	2	58	f	none	simulated	system_sim
768	2026-08-03	WH-CCU-01	ITM-HDD-01	0	1	36	f	none	simulated	system_sim
769	2026-08-03	WH-CCU-01	ITM-CHG-01	0	1	203	f	none	simulated	system_sim
770	2026-08-03	WH-CCU-01	ITM-CBL-01	0	3	188	f	none	simulated	system_sim
771	2026-08-04	WH-BLR-01	ITM-CPU-01	0	2	23	f	none	simulated	system_sim
772	2026-08-04	WH-BLR-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
773	2026-08-04	WH-BLR-01	ITM-RAM-01	0	2	38	f	none	simulated	system_sim
774	2026-08-04	WH-BLR-01	ITM-SSD-01	0	1	66	f	none	simulated	system_sim
775	2026-08-04	WH-BLR-01	ITM-HDD-01	0	2	33	f	none	simulated	system_sim
776	2026-08-04	WH-BLR-01	ITM-CHG-01	0	4	186	f	none	simulated	system_sim
777	2026-08-04	WH-BLR-01	ITM-CBL-01	0	6	190	f	none	simulated	system_sim
778	2026-08-04	WH-CHN-01	ITM-CPU-01	0	0	51	f	none	simulated	system_sim
779	2026-08-04	WH-CHN-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
780	2026-08-04	WH-CHN-01	ITM-RAM-01	0	8	89	f	none	simulated	system_sim
781	2026-08-04	WH-CHN-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
782	2026-08-04	WH-CHN-01	ITM-HDD-01	0	0	37	f	none	simulated	system_sim
783	2026-08-04	WH-CHN-01	ITM-CHG-01	0	4	174	f	none	simulated	system_sim
784	2026-08-04	WH-CHN-01	ITM-CBL-01	0	9	158	f	none	simulated	system_sim
785	2026-08-04	WH-BOM-01	ITM-CPU-01	0	0	64	f	none	simulated	system_sim
786	2026-08-04	WH-BOM-01	ITM-GPU-01	0	0	41	f	none	simulated	system_sim
787	2026-08-04	WH-BOM-01	ITM-RAM-01	0	7	87	f	none	simulated	system_sim
788	2026-08-04	WH-BOM-01	ITM-SSD-01	0	2	67	f	none	simulated	system_sim
789	2026-08-04	WH-BOM-01	ITM-HDD-01	0	2	29	f	none	simulated	system_sim
790	2026-08-04	WH-BOM-01	ITM-CHG-01	0	6	178	f	none	simulated	system_sim
791	2026-08-04	WH-BOM-01	ITM-CBL-01	0	4	162	f	none	simulated	system_sim
792	2026-08-04	WH-DEL-01	ITM-CPU-01	0	3	62	f	none	simulated	system_sim
793	2026-08-04	WH-DEL-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
794	2026-08-04	WH-DEL-01	ITM-RAM-01	0	4	80	f	none	simulated	system_sim
795	2026-08-04	WH-DEL-01	ITM-SSD-01	0	2	69	f	none	simulated	system_sim
796	2026-08-04	WH-DEL-01	ITM-HDD-01	0	0	41	f	none	simulated	system_sim
797	2026-08-04	WH-DEL-01	ITM-CHG-01	0	7	169	f	none	simulated	system_sim
798	2026-08-04	WH-DEL-01	ITM-CBL-01	0	5	164	f	none	simulated	system_sim
799	2026-08-04	WH-CCU-01	ITM-CPU-01	0	0	23	f	none	simulated	system_sim
800	2026-08-04	WH-CCU-01	ITM-GPU-01	0	2	18	f	none	simulated	system_sim
801	2026-08-04	WH-CCU-01	ITM-RAM-01	0	10	81	f	none	simulated	system_sim
802	2026-08-04	WH-CCU-01	ITM-SSD-01	0	0	58	f	none	simulated	system_sim
803	2026-08-04	WH-CCU-01	ITM-HDD-01	0	0	36	f	none	simulated	system_sim
804	2026-08-04	WH-CCU-01	ITM-CHG-01	0	10	193	f	none	simulated	system_sim
805	2026-08-04	WH-CCU-01	ITM-CBL-01	0	5	183	f	none	simulated	system_sim
806	2026-08-05	WH-BLR-01	ITM-CPU-01	0	2	21	f	none	simulated	system_sim
807	2026-08-05	WH-BLR-01	ITM-GPU-01	0	0	8	t	shrinkage	simulated	system_sim
808	2026-08-05	WH-BLR-01	ITM-RAM-01	0	3	35	f	none	simulated	system_sim
809	2026-08-05	WH-BLR-01	ITM-SSD-01	0	1	65	f	none	simulated	system_sim
810	2026-08-05	WH-BLR-01	ITM-HDD-01	0	0	33	f	none	simulated	system_sim
811	2026-08-05	WH-BLR-01	ITM-CHG-01	0	3	183	f	none	simulated	system_sim
812	2026-08-05	WH-BLR-01	ITM-CBL-01	0	5	185	f	none	simulated	system_sim
813	2026-08-05	WH-CHN-01	ITM-CPU-01	0	0	51	f	none	simulated	system_sim
814	2026-08-05	WH-CHN-01	ITM-GPU-01	0	2	15	f	none	simulated	system_sim
815	2026-08-05	WH-CHN-01	ITM-RAM-01	0	7	82	f	none	simulated	system_sim
816	2026-08-05	WH-CHN-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
817	2026-08-05	WH-CHN-01	ITM-HDD-01	0	2	35	f	none	simulated	system_sim
818	2026-08-05	WH-CHN-01	ITM-CHG-01	0	10	164	f	none	simulated	system_sim
819	2026-08-05	WH-CHN-01	ITM-CBL-01	0	2	156	f	none	simulated	system_sim
820	2026-08-05	WH-BOM-01	ITM-CPU-01	0	2	62	f	none	simulated	system_sim
821	2026-08-05	WH-BOM-01	ITM-GPU-01	0	2	39	f	none	simulated	system_sim
822	2026-08-05	WH-BOM-01	ITM-RAM-01	0	9	78	f	none	simulated	system_sim
823	2026-08-05	WH-BOM-01	ITM-SSD-01	0	3	64	f	none	simulated	system_sim
824	2026-08-05	WH-BOM-01	ITM-HDD-01	60	0	89	f	none	simulated	system_sim
825	2026-08-05	WH-BOM-01	ITM-CHG-01	0	4	174	f	none	simulated	system_sim
826	2026-08-05	WH-BOM-01	ITM-CBL-01	0	9	153	f	none	simulated	system_sim
827	2026-08-05	WH-DEL-01	ITM-CPU-01	0	0	62	f	none	simulated	system_sim
828	2026-08-05	WH-DEL-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
829	2026-08-05	WH-DEL-01	ITM-RAM-01	0	1	79	f	none	simulated	system_sim
830	2026-08-05	WH-DEL-01	ITM-SSD-01	0	1	68	f	none	simulated	system_sim
831	2026-08-05	WH-DEL-01	ITM-HDD-01	0	1	40	f	none	simulated	system_sim
832	2026-08-05	WH-DEL-01	ITM-CHG-01	0	1	168	f	none	simulated	system_sim
833	2026-08-05	WH-DEL-01	ITM-CBL-01	0	1	163	f	none	simulated	system_sim
834	2026-08-05	WH-CCU-01	ITM-CPU-01	0	0	23	f	none	simulated	system_sim
835	2026-08-05	WH-CCU-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
836	2026-08-05	WH-CCU-01	ITM-RAM-01	0	7	74	f	none	simulated	system_sim
837	2026-08-05	WH-CCU-01	ITM-SSD-01	0	1	57	f	none	simulated	system_sim
838	2026-08-05	WH-CCU-01	ITM-HDD-01	0	0	36	f	none	simulated	system_sim
839	2026-08-05	WH-CCU-01	ITM-CHG-01	0	7	186	f	none	simulated	system_sim
840	2026-08-05	WH-CCU-01	ITM-CBL-01	0	9	174	f	none	simulated	system_sim
841	2026-08-06	WH-BLR-01	ITM-CPU-01	45	1	65	f	none	simulated	system_sim
842	2026-08-06	WH-BLR-01	ITM-GPU-01	30	2	36	f	none	simulated	system_sim
843	2026-08-06	WH-BLR-01	ITM-RAM-01	75	9	101	f	none	simulated	system_sim
844	2026-08-06	WH-BLR-01	ITM-SSD-01	0	0	65	f	none	simulated	system_sim
845	2026-08-06	WH-BLR-01	ITM-HDD-01	0	1	32	f	none	simulated	system_sim
846	2026-08-06	WH-BLR-01	ITM-CHG-01	0	10	173	f	none	simulated	system_sim
847	2026-08-06	WH-BLR-01	ITM-CBL-01	0	7	178	f	none	simulated	system_sim
848	2026-08-06	WH-CHN-01	ITM-CPU-01	0	0	51	f	none	simulated	system_sim
849	2026-08-06	WH-CHN-01	ITM-GPU-01	0	2	13	f	none	simulated	system_sim
850	2026-08-06	WH-CHN-01	ITM-RAM-01	0	1	81	f	none	simulated	system_sim
851	2026-08-06	WH-CHN-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
852	2026-08-06	WH-CHN-01	ITM-HDD-01	0	3	32	f	none	simulated	system_sim
853	2026-08-06	WH-CHN-01	ITM-CHG-01	0	5	159	f	none	simulated	system_sim
854	2026-08-06	WH-CHN-01	ITM-CBL-01	0	5	151	f	none	simulated	system_sim
855	2026-08-06	WH-BOM-01	ITM-CPU-01	0	1	61	f	none	simulated	system_sim
856	2026-08-06	WH-BOM-01	ITM-GPU-01	0	0	39	f	none	simulated	system_sim
857	2026-08-06	WH-BOM-01	ITM-RAM-01	0	2	76	f	none	simulated	system_sim
858	2026-08-06	WH-BOM-01	ITM-SSD-01	0	1	63	f	none	simulated	system_sim
859	2026-08-06	WH-BOM-01	ITM-HDD-01	0	0	89	f	none	simulated	system_sim
860	2026-08-06	WH-BOM-01	ITM-CHG-01	0	6	168	f	none	simulated	system_sim
861	2026-08-06	WH-BOM-01	ITM-CBL-01	0	1	152	f	none	simulated	system_sim
862	2026-08-06	WH-DEL-01	ITM-CPU-01	0	0	62	f	none	simulated	system_sim
863	2026-08-06	WH-DEL-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
864	2026-08-06	WH-DEL-01	ITM-RAM-01	0	3	76	f	none	simulated	system_sim
865	2026-08-06	WH-DEL-01	ITM-SSD-01	0	2	66	f	none	simulated	system_sim
866	2026-08-06	WH-DEL-01	ITM-HDD-01	0	0	40	f	none	simulated	system_sim
867	2026-08-06	WH-DEL-01	ITM-CHG-01	0	4	164	f	none	simulated	system_sim
868	2026-08-06	WH-DEL-01	ITM-CBL-01	0	2	161	f	none	simulated	system_sim
869	2026-08-06	WH-CCU-01	ITM-CPU-01	0	1	22	f	none	simulated	system_sim
870	2026-08-06	WH-CCU-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
871	2026-08-06	WH-CCU-01	ITM-RAM-01	0	6	68	f	none	simulated	system_sim
872	2026-08-06	WH-CCU-01	ITM-SSD-01	0	0	57	f	none	simulated	system_sim
873	2026-08-06	WH-CCU-01	ITM-HDD-01	0	0	36	f	none	simulated	system_sim
874	2026-08-06	WH-CCU-01	ITM-CHG-01	0	10	176	f	none	simulated	system_sim
875	2026-08-06	WH-CCU-01	ITM-CBL-01	0	4	170	f	none	simulated	system_sim
876	2026-08-07	WH-BLR-01	ITM-CPU-01	0	0	65	f	none	simulated	system_sim
877	2026-08-07	WH-BLR-01	ITM-GPU-01	0	0	36	f	none	simulated	system_sim
878	2026-08-07	WH-BLR-01	ITM-RAM-01	0	6	95	f	none	simulated	system_sim
879	2026-08-07	WH-BLR-01	ITM-SSD-01	0	0	65	f	none	simulated	system_sim
880	2026-08-07	WH-BLR-01	ITM-HDD-01	0	3	29	f	none	simulated	system_sim
881	2026-08-07	WH-BLR-01	ITM-CHG-01	0	7	166	f	none	simulated	system_sim
882	2026-08-07	WH-BLR-01	ITM-CBL-01	0	2	176	f	none	simulated	system_sim
883	2026-08-07	WH-CHN-01	ITM-CPU-01	0	0	51	f	none	simulated	system_sim
884	2026-08-07	WH-CHN-01	ITM-GPU-01	30	0	43	f	none	simulated	system_sim
885	2026-08-07	WH-CHN-01	ITM-RAM-01	0	4	77	f	none	simulated	system_sim
886	2026-08-07	WH-CHN-01	ITM-SSD-01	0	2	59	f	none	simulated	system_sim
887	2026-08-07	WH-CHN-01	ITM-HDD-01	0	0	32	f	none	simulated	system_sim
888	2026-08-07	WH-CHN-01	ITM-CHG-01	0	3	156	f	none	simulated	system_sim
889	2026-08-07	WH-CHN-01	ITM-CBL-01	0	6	145	f	none	simulated	system_sim
890	2026-08-07	WH-BOM-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
891	2026-08-07	WH-BOM-01	ITM-GPU-01	0	0	39	f	none	simulated	system_sim
892	2026-08-07	WH-BOM-01	ITM-RAM-01	0	7	69	f	none	simulated	system_sim
893	2026-08-07	WH-BOM-01	ITM-SSD-01	0	0	63	f	none	simulated	system_sim
894	2026-08-07	WH-BOM-01	ITM-HDD-01	0	3	86	f	none	simulated	system_sim
895	2026-08-07	WH-BOM-01	ITM-CHG-01	0	4	164	f	none	simulated	system_sim
896	2026-08-07	WH-BOM-01	ITM-CBL-01	0	2	150	f	none	simulated	system_sim
897	2026-08-07	WH-DEL-01	ITM-CPU-01	0	2	60	f	none	simulated	system_sim
898	2026-08-07	WH-DEL-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
899	2026-08-07	WH-DEL-01	ITM-RAM-01	0	6	70	f	none	simulated	system_sim
900	2026-08-07	WH-DEL-01	ITM-SSD-01	0	2	64	f	none	simulated	system_sim
901	2026-08-07	WH-DEL-01	ITM-HDD-01	0	0	40	f	none	simulated	system_sim
902	2026-08-07	WH-DEL-01	ITM-CHG-01	0	6	158	f	none	simulated	system_sim
903	2026-08-07	WH-DEL-01	ITM-CBL-01	0	6	155	f	none	simulated	system_sim
904	2026-08-07	WH-CCU-01	ITM-CPU-01	45	3	64	f	none	simulated	system_sim
905	2026-08-07	WH-CCU-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
906	2026-08-07	WH-CCU-01	ITM-RAM-01	0	9	59	f	none	simulated	system_sim
907	2026-08-07	WH-CCU-01	ITM-SSD-01	0	0	57	f	none	simulated	system_sim
908	2026-08-07	WH-CCU-01	ITM-HDD-01	0	2	34	f	none	simulated	system_sim
909	2026-08-07	WH-CCU-01	ITM-CHG-01	0	5	171	f	none	simulated	system_sim
910	2026-08-07	WH-CCU-01	ITM-CBL-01	0	3	167	f	none	simulated	system_sim
911	2026-08-08	WH-BLR-01	ITM-CPU-01	0	1	64	f	none	simulated	system_sim
912	2026-08-08	WH-BLR-01	ITM-GPU-01	0	0	36	f	none	simulated	system_sim
913	2026-08-08	WH-BLR-01	ITM-RAM-01	0	2	93	f	none	simulated	system_sim
914	2026-08-08	WH-BLR-01	ITM-SSD-01	0	0	65	f	none	simulated	system_sim
915	2026-08-08	WH-BLR-01	ITM-HDD-01	60	1	88	f	none	simulated	system_sim
916	2026-08-08	WH-BLR-01	ITM-CHG-01	0	8	158	f	none	simulated	system_sim
917	2026-08-08	WH-BLR-01	ITM-CBL-01	0	2	174	f	none	simulated	system_sim
918	2026-08-08	WH-CHN-01	ITM-CPU-01	0	3	48	f	none	simulated	system_sim
919	2026-08-08	WH-CHN-01	ITM-GPU-01	0	0	43	f	none	simulated	system_sim
920	2026-08-08	WH-CHN-01	ITM-RAM-01	0	3	74	f	none	simulated	system_sim
921	2026-08-08	WH-CHN-01	ITM-SSD-01	0	2	57	f	none	simulated	system_sim
922	2026-08-08	WH-CHN-01	ITM-HDD-01	0	0	32	f	none	simulated	system_sim
923	2026-08-08	WH-CHN-01	ITM-CHG-01	0	7	149	f	none	simulated	system_sim
924	2026-08-08	WH-CHN-01	ITM-CBL-01	300	8	437	f	none	simulated	system_sim
925	2026-08-08	WH-BOM-01	ITM-CPU-01	0	3	58	f	none	simulated	system_sim
926	2026-08-08	WH-BOM-01	ITM-GPU-01	0	0	39	f	none	simulated	system_sim
927	2026-08-08	WH-BOM-01	ITM-RAM-01	0	10	59	f	none	simulated	system_sim
928	2026-08-08	WH-BOM-01	ITM-SSD-01	0	3	60	f	none	simulated	system_sim
929	2026-08-08	WH-BOM-01	ITM-HDD-01	0	2	84	f	none	simulated	system_sim
930	2026-08-08	WH-BOM-01	ITM-CHG-01	0	5	159	f	none	simulated	system_sim
931	2026-08-08	WH-BOM-01	ITM-CBL-01	0	9	141	f	none	simulated	system_sim
932	2026-08-08	WH-DEL-01	ITM-CPU-01	0	3	57	f	none	simulated	system_sim
933	2026-08-08	WH-DEL-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
934	2026-08-08	WH-DEL-01	ITM-RAM-01	0	1	69	f	none	simulated	system_sim
935	2026-08-08	WH-DEL-01	ITM-SSD-01	0	2	62	f	none	simulated	system_sim
936	2026-08-08	WH-DEL-01	ITM-HDD-01	0	3	37	f	none	simulated	system_sim
937	2026-08-08	WH-DEL-01	ITM-CHG-01	0	10	148	f	none	simulated	system_sim
938	2026-08-08	WH-DEL-01	ITM-CBL-01	0	7	148	f	none	simulated	system_sim
939	2026-08-08	WH-CCU-01	ITM-CPU-01	0	0	64	f	none	simulated	system_sim
940	2026-08-08	WH-CCU-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
941	2026-08-08	WH-CCU-01	ITM-RAM-01	0	6	53	f	none	simulated	system_sim
942	2026-08-08	WH-CCU-01	ITM-SSD-01	0	0	57	f	none	simulated	system_sim
943	2026-08-08	WH-CCU-01	ITM-HDD-01	0	3	31	f	none	simulated	system_sim
944	2026-08-08	WH-CCU-01	ITM-CHG-01	0	10	161	f	none	simulated	system_sim
945	2026-08-08	WH-CCU-01	ITM-CBL-01	0	9	158	f	none	simulated	system_sim
946	2026-08-09	WH-BLR-01	ITM-CPU-01	0	0	64	f	none	simulated	system_sim
947	2026-08-09	WH-BLR-01	ITM-GPU-01	0	1	35	f	none	simulated	system_sim
948	2026-08-09	WH-BLR-01	ITM-RAM-01	0	5	88	f	none	simulated	system_sim
949	2026-08-09	WH-BLR-01	ITM-SSD-01	0	0	65	f	none	simulated	system_sim
950	2026-08-09	WH-BLR-01	ITM-HDD-01	0	0	88	f	none	simulated	system_sim
951	2026-08-09	WH-BLR-01	ITM-CHG-01	0	3	155	f	none	simulated	system_sim
952	2026-08-09	WH-BLR-01	ITM-CBL-01	0	5	169	f	none	simulated	system_sim
953	2026-08-09	WH-CHN-01	ITM-CPU-01	0	3	45	f	none	simulated	system_sim
954	2026-08-09	WH-CHN-01	ITM-GPU-01	0	2	41	f	none	simulated	system_sim
955	2026-08-09	WH-CHN-01	ITM-RAM-01	0	3	71	f	none	simulated	system_sim
956	2026-08-09	WH-CHN-01	ITM-SSD-01	0	0	57	f	none	simulated	system_sim
957	2026-08-09	WH-CHN-01	ITM-HDD-01	0	0	32	f	none	simulated	system_sim
958	2026-08-09	WH-CHN-01	ITM-CHG-01	0	9	140	f	none	simulated	system_sim
959	2026-08-09	WH-CHN-01	ITM-CBL-01	0	1	436	f	none	simulated	system_sim
960	2026-08-09	WH-BOM-01	ITM-CPU-01	0	1	57	f	none	simulated	system_sim
961	2026-08-09	WH-BOM-01	ITM-GPU-01	0	0	39	f	none	simulated	system_sim
962	2026-08-09	WH-BOM-01	ITM-RAM-01	0	2	57	f	none	simulated	system_sim
963	2026-08-09	WH-BOM-01	ITM-SSD-01	0	3	57	f	none	simulated	system_sim
964	2026-08-09	WH-BOM-01	ITM-HDD-01	0	3	81	f	none	simulated	system_sim
965	2026-08-09	WH-BOM-01	ITM-CHG-01	0	2	157	f	none	simulated	system_sim
966	2026-08-09	WH-BOM-01	ITM-CBL-01	300	1	440	f	none	simulated	system_sim
967	2026-08-09	WH-DEL-01	ITM-CPU-01	0	3	54	f	none	simulated	system_sim
968	2026-08-09	WH-DEL-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
969	2026-08-09	WH-DEL-01	ITM-RAM-01	0	5	64	f	none	simulated	system_sim
970	2026-08-09	WH-DEL-01	ITM-SSD-01	0	1	61	f	none	simulated	system_sim
971	2026-08-09	WH-DEL-01	ITM-HDD-01	0	0	37	f	none	simulated	system_sim
972	2026-08-09	WH-DEL-01	ITM-CHG-01	0	10	138	f	none	simulated	system_sim
973	2026-08-09	WH-DEL-01	ITM-CBL-01	300	10	438	f	none	simulated	system_sim
974	2026-08-09	WH-CCU-01	ITM-CPU-01	0	2	62	f	none	simulated	system_sim
975	2026-08-09	WH-CCU-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
976	2026-08-09	WH-CCU-01	ITM-RAM-01	0	7	46	f	none	simulated	system_sim
977	2026-08-09	WH-CCU-01	ITM-SSD-01	0	3	54	f	none	simulated	system_sim
978	2026-08-09	WH-CCU-01	ITM-HDD-01	0	1	30	f	none	simulated	system_sim
979	2026-08-09	WH-CCU-01	ITM-CHG-01	0	6	155	f	none	simulated	system_sim
980	2026-08-09	WH-CCU-01	ITM-CBL-01	0	5	153	f	none	simulated	system_sim
981	2026-08-10	WH-BLR-01	ITM-CPU-01	0	1	63	f	none	simulated	system_sim
982	2026-08-10	WH-BLR-01	ITM-GPU-01	0	0	35	f	none	simulated	system_sim
983	2026-08-10	WH-BLR-01	ITM-RAM-01	0	2	86	f	none	simulated	system_sim
984	2026-08-10	WH-BLR-01	ITM-SSD-01	0	3	62	f	none	simulated	system_sim
985	2026-08-10	WH-BLR-01	ITM-HDD-01	0	0	88	f	none	simulated	system_sim
986	2026-08-10	WH-BLR-01	ITM-CHG-01	0	3	152	f	none	simulated	system_sim
987	2026-08-10	WH-BLR-01	ITM-CBL-01	0	4	165	f	none	simulated	system_sim
988	2026-08-10	WH-CHN-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
989	2026-08-10	WH-CHN-01	ITM-GPU-01	0	2	39	f	none	simulated	system_sim
990	2026-08-10	WH-CHN-01	ITM-RAM-01	0	10	61	f	none	simulated	system_sim
991	2026-08-10	WH-CHN-01	ITM-SSD-01	0	2	55	f	none	simulated	system_sim
992	2026-08-10	WH-CHN-01	ITM-HDD-01	0	0	32	f	none	simulated	system_sim
993	2026-08-10	WH-CHN-01	ITM-CHG-01	0	6	134	f	none	simulated	system_sim
994	2026-08-10	WH-CHN-01	ITM-CBL-01	0	10	426	f	none	simulated	system_sim
995	2026-08-10	WH-BOM-01	ITM-CPU-01	0	0	57	f	none	simulated	system_sim
996	2026-08-10	WH-BOM-01	ITM-GPU-01	0	0	39	f	none	simulated	system_sim
997	2026-08-10	WH-BOM-01	ITM-RAM-01	0	2	55	f	none	simulated	system_sim
998	2026-08-10	WH-BOM-01	ITM-SSD-01	0	0	57	f	none	simulated	system_sim
999	2026-08-10	WH-BOM-01	ITM-HDD-01	0	0	81	f	none	simulated	system_sim
1000	2026-08-10	WH-BOM-01	ITM-CHG-01	0	4	153	f	none	simulated	system_sim
1001	2026-08-10	WH-BOM-01	ITM-CBL-01	0	2	438	f	none	simulated	system_sim
1002	2026-08-10	WH-DEL-01	ITM-CPU-01	0	2	52	f	none	simulated	system_sim
1003	2026-08-10	WH-DEL-01	ITM-GPU-01	0	2	17	f	none	simulated	system_sim
1004	2026-08-10	WH-DEL-01	ITM-RAM-01	0	10	54	f	none	simulated	system_sim
1005	2026-08-10	WH-DEL-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
1006	2026-08-10	WH-DEL-01	ITM-HDD-01	0	0	37	f	none	simulated	system_sim
1007	2026-08-10	WH-DEL-01	ITM-CHG-01	0	1	137	f	none	simulated	system_sim
1008	2026-08-10	WH-DEL-01	ITM-CBL-01	0	1	437	f	none	simulated	system_sim
1009	2026-08-10	WH-CCU-01	ITM-CPU-01	0	2	60	f	none	simulated	system_sim
1010	2026-08-10	WH-CCU-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
1011	2026-08-10	WH-CCU-01	ITM-RAM-01	0	9	37	f	none	simulated	system_sim
1012	2026-08-10	WH-CCU-01	ITM-SSD-01	0	0	54	f	none	simulated	system_sim
1013	2026-08-10	WH-CCU-01	ITM-HDD-01	0	0	30	f	none	simulated	system_sim
1014	2026-08-10	WH-CCU-01	ITM-CHG-01	0	7	148	f	none	simulated	system_sim
1015	2026-08-10	WH-CCU-01	ITM-CBL-01	0	8	145	f	none	simulated	system_sim
1016	2026-08-11	WH-BLR-01	ITM-CPU-01	0	1	62	f	none	simulated	system_sim
1017	2026-08-11	WH-BLR-01	ITM-GPU-01	0	0	35	f	none	simulated	system_sim
1018	2026-08-11	WH-BLR-01	ITM-RAM-01	0	8	78	f	none	simulated	system_sim
1019	2026-08-11	WH-BLR-01	ITM-SSD-01	0	0	62	f	none	simulated	system_sim
1020	2026-08-11	WH-BLR-01	ITM-HDD-01	0	3	85	f	none	simulated	system_sim
1021	2026-08-11	WH-BLR-01	ITM-CHG-01	0	7	145	f	none	simulated	system_sim
1022	2026-08-11	WH-BLR-01	ITM-CBL-01	0	3	162	f	none	simulated	system_sim
1023	2026-08-11	WH-CHN-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
1024	2026-08-11	WH-CHN-01	ITM-GPU-01	0	1	38	f	none	simulated	system_sim
1025	2026-08-11	WH-CHN-01	ITM-RAM-01	0	1	60	f	none	simulated	system_sim
1026	2026-08-11	WH-CHN-01	ITM-SSD-01	0	1	54	f	none	simulated	system_sim
1027	2026-08-11	WH-CHN-01	ITM-HDD-01	0	2	30	f	none	simulated	system_sim
1028	2026-08-11	WH-CHN-01	ITM-CHG-01	0	3	131	f	none	simulated	system_sim
1029	2026-08-11	WH-CHN-01	ITM-CBL-01	0	8	418	f	none	simulated	system_sim
1030	2026-08-11	WH-BOM-01	ITM-CPU-01	0	3	54	f	none	simulated	system_sim
1031	2026-08-11	WH-BOM-01	ITM-GPU-01	0	2	37	f	none	simulated	system_sim
1032	2026-08-11	WH-BOM-01	ITM-RAM-01	0	3	52	f	none	simulated	system_sim
1033	2026-08-11	WH-BOM-01	ITM-SSD-01	0	3	54	f	none	simulated	system_sim
1034	2026-08-11	WH-BOM-01	ITM-HDD-01	0	1	80	f	none	simulated	system_sim
1035	2026-08-11	WH-BOM-01	ITM-CHG-01	0	2	151	f	none	simulated	system_sim
1036	2026-08-11	WH-BOM-01	ITM-CBL-01	0	2	436	f	none	simulated	system_sim
1037	2026-08-11	WH-DEL-01	ITM-CPU-01	0	3	49	f	none	simulated	system_sim
1038	2026-08-11	WH-DEL-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
1039	2026-08-11	WH-DEL-01	ITM-RAM-01	0	7	47	f	none	simulated	system_sim
1040	2026-08-11	WH-DEL-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
1041	2026-08-11	WH-DEL-01	ITM-HDD-01	0	1	36	f	none	simulated	system_sim
1042	2026-08-11	WH-DEL-01	ITM-CHG-01	0	4	133	f	none	simulated	system_sim
1043	2026-08-11	WH-DEL-01	ITM-CBL-01	0	1	436	f	none	simulated	system_sim
1044	2026-08-11	WH-CCU-01	ITM-CPU-01	0	0	60	f	none	simulated	system_sim
1045	2026-08-11	WH-CCU-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
1046	2026-08-11	WH-CCU-01	ITM-RAM-01	75	9	103	f	none	simulated	system_sim
1047	2026-08-11	WH-CCU-01	ITM-SSD-01	0	1	53	f	none	simulated	system_sim
1048	2026-08-11	WH-CCU-01	ITM-HDD-01	0	3	27	f	none	simulated	system_sim
1049	2026-08-11	WH-CCU-01	ITM-CHG-01	0	7	141	f	none	simulated	system_sim
1050	2026-08-11	WH-CCU-01	ITM-CBL-01	300	1	444	f	none	simulated	system_sim
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password_hash, role, full_name, google_subject_id, created_at) FROM stdin;
2	test_viewer	$2b$12$.3rBm/MVwVF4BZDx7a6pyOk0QepS0vuc1mKr6UzCux6IULd8w9F/C	viewer		\N	2026-08-17 17:40:38.685032
3	test_manager	$2b$12$4rqHoi9WyB7k4ImYvqE2FuXVWqrNAkWSFbY.CBIE773iVcIZXwbWO	manager		\N	2026-08-17 17:40:39.580667
1	test_admin	$2b$12$f.mZpast.NMJ6rgLJK9r0eGiHed0ZsuCAfWEePYisVq9lp4UVNghS	admin		\N	2026-08-17 17:36:34.532749
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouses (id, name, location, latitude, longitude, created_at) FROM stdin;
WH-BLR-01	Bangalore Fulfillment Center	Bangalore, Karnataka	12.971598	77.594566	2026-08-17 17:39:53.978886
WH-CHN-01	Chennai Port Logistics Hub	Chennai, Tamil Nadu	13.08268	80.270718	2026-08-17 17:39:53.988063
WH-BOM-01	Mumbai Container Terminal	Mumbai, Maharashtra	19.07609	72.877701	2026-08-17 17:39:53.992046
WH-DEL-01	Delhi NCR Logistics Park	Noida, Uttar Pradesh	28.535517	77.391029	2026-08-17 17:39:53.995048
WH-CCU-01	Kolkata Gateway Depot	Kolkata, West Bengal	22.572646	88.363895	2026-08-17 17:39:54.001047
\.


--
-- Name: access_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_log_id_seq', 65, true);


--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_recommendations_id_seq', 1, true);


--
-- Name: audit_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_ledger_id_seq', 46, true);


--
-- Name: backup_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.backup_records_id_seq', 2, true);


--
-- Name: recovery_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recovery_codes_id_seq', 8, true);


--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recovery_credentials_id_seq', 1, true);


--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shrinkage_flags_id_seq', 2, true);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 1075, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: access_log access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log
    ADD CONSTRAINT access_log_pkey PRIMARY KEY (id);


--
-- Name: ai_recommendations ai_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_recommendations
    ADD CONSTRAINT ai_recommendations_pkey PRIMARY KEY (id);


--
-- Name: audit_ledger audit_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_ledger
    ADD CONSTRAINT audit_ledger_pkey PRIMARY KEY (id);


--
-- Name: backup_records backup_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_records
    ADD CONSTRAINT backup_records_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: recovery_codes recovery_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: recovery_credentials recovery_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials
    ADD CONSTRAINT recovery_credentials_pkey PRIMARY KEY (id);


--
-- Name: shrinkage_flags shrinkage_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shrinkage_flags
    ADD CONSTRAINT shrinkage_flags_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: stock_movements uq_movement; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT uq_movement UNIQUE (date, warehouse_id, item_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: ix_access_log_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_access_log_timestamp ON public.access_log USING btree ("timestamp");


--
-- Name: ix_ai_recommendations_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_recommendations_timestamp ON public.ai_recommendations USING btree ("timestamp");


--
-- Name: ix_backup_records_backup_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_backup_records_backup_id ON public.backup_records USING btree (backup_id);


--
-- Name: ix_backup_records_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_backup_records_created_at ON public.backup_records USING btree (created_at);


--
-- Name: ix_recovery_codes_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_recovery_codes_user_id ON public.recovery_codes USING btree (user_id);


--
-- Name: ix_recovery_credentials_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_recovery_credentials_user_id ON public.recovery_credentials USING btree (user_id);


--
-- Name: ix_stock_movements_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_date ON public.stock_movements USING btree (date);


--
-- Name: ix_stock_movements_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_item_id ON public.stock_movements USING btree (item_id);


--
-- Name: ix_stock_movements_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_warehouse_id ON public.stock_movements USING btree (warehouse_id);


--
-- Name: ix_users_google_subject_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_google_subject_id ON public.users USING btree (google_subject_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: recovery_codes recovery_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: recovery_credentials recovery_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials
    ADD CONSTRAINT recovery_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id);


--
-- Name: stock_movements stock_movements_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 1yzrSlt6s1ZggpMNpZiE7tYvSA07zxrT6e0UETBn6rrngzXKefQrmTPhtl3owwU

