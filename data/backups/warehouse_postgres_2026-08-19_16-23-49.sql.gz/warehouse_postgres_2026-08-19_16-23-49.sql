--
-- PostgreSQL database dump
--

\restrict ns98XlkMcLeoxAhHnaeuITzzsTRUhPmaJOaUhfVuFqrwJb78TUWRyqezMdOPrsh

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_log (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    username character varying(64) NOT NULL,
    warehouse_id character varying(20),
    action character varying(50) NOT NULL,
    ip_address character varying(45)
);


ALTER TABLE public.access_log OWNER TO postgres;

--
-- Name: access_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.access_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.access_log_id_seq OWNER TO postgres;

--
-- Name: access_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.access_log_id_seq OWNED BY public.access_log.id;


--
-- Name: ai_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_recommendations (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(50),
    title character varying(100) NOT NULL,
    risk_level character varying(20),
    action_recommended character varying(100) NOT NULL,
    confidence_score integer,
    input_factors text,
    status character varying(20),
    decision_by character varying(64),
    decision_time timestamp without time zone,
    notes text,
    recommendation_type character varying(50),
    description text,
    priority character varying(20),
    score integer,
    confidence_or_reliability character varying(50),
    source_model character varying(50),
    source_entity_type character varying(50),
    source_entity_id character varying(50),
    recommended_action character varying(200),
    estimated_impact double precision,
    explanation text,
    supporting_metrics text,
    created_at timestamp without time zone NOT NULL,
    reviewed_at timestamp without time zone,
    reviewed_by character varying(64),
    review_notes text,
    expires_at timestamp without time zone,
    metadata text NOT NULL
);


ALTER TABLE public.ai_recommendations OWNER TO postgres;

--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_recommendations_id_seq OWNER TO postgres;

--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_recommendations_id_seq OWNED BY public.ai_recommendations.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: audit_ledger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_ledger (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    event_type character varying(50) NOT NULL,
    details text,
    prev_hash character varying(64) NOT NULL,
    hash character varying(64) NOT NULL
);


ALTER TABLE public.audit_ledger OWNER TO postgres;

--
-- Name: audit_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_ledger_id_seq OWNER TO postgres;

--
-- Name: audit_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_ledger_id_seq OWNED BY public.audit_ledger.id;


--
-- Name: backup_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_records (
    id integer NOT NULL,
    backup_id character varying(64) NOT NULL,
    filename character varying(255) NOT NULL,
    created_at timestamp without time zone,
    size_bytes integer,
    sha256 character varying(64),
    status character varying(20) NOT NULL,
    storage_key character varying(255),
    error_message text,
    backup_type character varying(50),
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    storage_provider character varying(50),
    bucket character varying(255),
    checksum_algorithm character varying(20),
    verification_status character varying(50),
    verification_at timestamp without time zone,
    restore_test_status character varying(50),
    restore_test_at timestamp without time zone,
    retention_status character varying(50),
    initiated_by character varying(100),
    audit_ref character varying(255)
);


ALTER TABLE public.backup_records OWNER TO postgres;

--
-- Name: backup_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.backup_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_records_id_seq OWNER TO postgres;

--
-- Name: backup_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.backup_records_id_seq OWNED BY public.backup_records.id;


--
-- Name: digital_twin_simulations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.digital_twin_simulations (
    id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    simulation_status character varying(20) NOT NULL,
    simulation_time_seconds double precision NOT NULL,
    speed_multiplier double precision NOT NULL,
    seed integer NOT NULL,
    mode character varying(20) NOT NULL,
    scenario_type character varying(30) NOT NULL,
    tick_count integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    started_at timestamp without time zone,
    paused_at timestamp without time zone,
    stopped_at timestamp without time zone,
    completed_at timestamp without time zone,
    error_message text,
    created_by character varying(64) NOT NULL
);


ALTER TABLE public.digital_twin_simulations OWNER TO postgres;

--
-- Name: digital_twin_simulations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.digital_twin_simulations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.digital_twin_simulations_id_seq OWNER TO postgres;

--
-- Name: digital_twin_simulations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.digital_twin_simulations_id_seq OWNED BY public.digital_twin_simulations.id;


--
-- Name: experiment_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.experiment_runs (
    id integer NOT NULL,
    experiment_id integer NOT NULL,
    repetition_number integer NOT NULL,
    random_seed integer NOT NULL,
    status character varying(20) NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    duration_seconds double precision,
    error_message text,
    metrics json,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.experiment_runs OWNER TO postgres;

--
-- Name: experiment_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.experiment_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.experiment_runs_id_seq OWNER TO postgres;

--
-- Name: experiment_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.experiment_runs_id_seq OWNED BY public.experiment_runs.id;


--
-- Name: experiments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.experiments (
    id integer NOT NULL,
    scenario_id integer NOT NULL,
    experiment_name character varying(150) NOT NULL,
    description text,
    status character varying(20) NOT NULL,
    algorithm_name character varying(50) NOT NULL,
    algorithm_version character varying(20) NOT NULL,
    configuration json NOT NULL,
    random_seed integer NOT NULL,
    repetitions integer NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    duration_seconds double precision,
    created_by character varying(64) NOT NULL,
    error_message text,
    metrics_summary json,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.experiments OWNER TO postgres;

--
-- Name: experiments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.experiments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.experiments_id_seq OWNER TO postgres;

--
-- Name: experiments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.experiments_id_seq OWNED BY public.experiments.id;


--
-- Name: health_thresholds; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health_thresholds (
    id integer NOT NULL,
    key character varying(64) NOT NULL,
    value double precision NOT NULL,
    description character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.health_thresholds OWNER TO postgres;

--
-- Name: health_thresholds_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.health_thresholds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.health_thresholds_id_seq OWNER TO postgres;

--
-- Name: health_thresholds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.health_thresholds_id_seq OWNED BY public.health_thresholds.id;


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    location_id character varying(50),
    on_hand integer NOT NULL,
    reserved integer NOT NULL,
    available integer NOT NULL,
    damaged integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_id_seq OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_id_seq OWNED BY public.inventory.id;


--
-- Name: inventory_reservations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_reservations (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    location_id character varying(50),
    reserved_qty integer NOT NULL,
    released_qty integer NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.inventory_reservations OWNER TO postgres;

--
-- Name: inventory_reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_reservations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_reservations_id_seq OWNER TO postgres;

--
-- Name: inventory_reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_reservations_id_seq OWNED BY public.inventory_reservations.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id character varying(20) NOT NULL,
    name character varying(150) NOT NULL,
    category character varying(80),
    unit_cost double precision,
    lead_time_days integer,
    safety_stock integer,
    sku character varying(64),
    description text,
    unit character varying(20),
    weight_kg double precision,
    dimensions character varying(50),
    barcode character varying(64),
    is_active boolean,
    reorder_threshold integer,
    preferred_storage_type character varying(20),
    created_at timestamp without time zone
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_preferences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    category character varying(50) NOT NULL,
    in_app_enabled boolean NOT NULL,
    email_enabled boolean NOT NULL,
    min_severity character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.notification_preferences OWNER TO postgres;

--
-- Name: notification_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_preferences_id_seq OWNER TO postgres;

--
-- Name: notification_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_preferences_id_seq OWNED BY public.notification_preferences.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    warehouse_id character varying(20),
    event_type character varying(50) NOT NULL,
    notification_type character varying(50) NOT NULL,
    title character varying(150) NOT NULL,
    message text NOT NULL,
    severity character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    channel character varying(20) NOT NULL,
    source_entity_type character varying(50),
    source_entity_id character varying(50),
    created_at timestamp without time zone NOT NULL,
    read_at timestamp without time zone,
    delivered_at timestamp without time zone,
    failed_at timestamp without time zone,
    retry_count integer NOT NULL,
    expires_at timestamp without time zone,
    metadata text NOT NULL,
    idempotency_key character varying(255)
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: order_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_events (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    "timestamp" timestamp without time zone,
    status character varying(30) NOT NULL,
    event_type character varying(50) NOT NULL,
    operator character varying(64),
    notes text
);


ALTER TABLE public.order_events OWNER TO postgres;

--
-- Name: order_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_events_id_seq OWNER TO postgres;

--
-- Name: order_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_events_id_seq OWNED BY public.order_events.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    requested_qty integer NOT NULL,
    reserved_qty integer NOT NULL,
    picked_qty integer NOT NULL,
    packed_qty integer NOT NULL,
    shipped_qty integer NOT NULL,
    status character varying(20) NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id character varying(20) NOT NULL,
    customer_ref character varying(100) NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    status character varying(30) NOT NULL,
    priority character varying(20) NOT NULL,
    total_items integer NOT NULL,
    notes text,
    created_by character varying(64)
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: otp_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otp_records (
    id integer NOT NULL,
    user_id integer NOT NULL,
    purpose character varying(50) NOT NULL,
    code_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    attempts integer NOT NULL,
    max_attempts integer NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    request_ip character varying(45),
    context_data text
);


ALTER TABLE public.otp_records OWNER TO postgres;

--
-- Name: otp_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.otp_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.otp_records_id_seq OWNER TO postgres;

--
-- Name: otp_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.otp_records_id_seq OWNED BY public.otp_records.id;


--
-- Name: packing_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.packing_records (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    operator character varying(64),
    package_count integer NOT NULL,
    weight_kg double precision,
    notes text
);


ALTER TABLE public.packing_records OWNER TO postgres;

--
-- Name: packing_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.packing_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.packing_records_id_seq OWNER TO postgres;

--
-- Name: packing_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.packing_records_id_seq OWNED BY public.packing_records.id;


--
-- Name: recovery_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recovery_codes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code_hash character varying(255) NOT NULL,
    used boolean NOT NULL,
    created_at timestamp without time zone,
    used_at timestamp without time zone
);


ALTER TABLE public.recovery_codes OWNER TO postgres;

--
-- Name: recovery_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recovery_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recovery_codes_id_seq OWNER TO postgres;

--
-- Name: recovery_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recovery_codes_id_seq OWNED BY public.recovery_codes.id;


--
-- Name: recovery_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recovery_credentials (
    id integer NOT NULL,
    user_id integer NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.recovery_credentials OWNER TO postgres;

--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recovery_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recovery_credentials_id_seq OWNER TO postgres;

--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recovery_credentials_id_seq OWNED BY public.recovery_credentials.id;


--
-- Name: robot_reservations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robot_reservations (
    id integer NOT NULL,
    robot_id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    tick integer NOT NULL
);


ALTER TABLE public.robot_reservations OWNER TO postgres;

--
-- Name: robot_reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.robot_reservations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.robot_reservations_id_seq OWNER TO postgres;

--
-- Name: robot_reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.robot_reservations_id_seq OWNED BY public.robot_reservations.id;


--
-- Name: robot_routes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robot_routes (
    id integer NOT NULL,
    robot_id integer NOT NULL,
    task_id integer,
    warehouse_id character varying(20) NOT NULL,
    start_x integer NOT NULL,
    start_y integer NOT NULL,
    goal_x integer NOT NULL,
    goal_y integer NOT NULL,
    algorithm character varying(30) NOT NULL,
    path_data text NOT NULL,
    distance double precision NOT NULL,
    cost double precision NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    completed_at timestamp without time zone
);


ALTER TABLE public.robot_routes OWNER TO postgres;

--
-- Name: robot_routes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.robot_routes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.robot_routes_id_seq OWNER TO postgres;

--
-- Name: robot_routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.robot_routes_id_seq OWNED BY public.robot_routes.id;


--
-- Name: robot_telemetry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robot_telemetry (
    id integer NOT NULL,
    robot_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    x double precision NOT NULL,
    y double precision NOT NULL,
    battery double precision NOT NULL,
    status character varying(30) NOT NULL,
    task_id integer,
    metadata text NOT NULL
);


ALTER TABLE public.robot_telemetry OWNER TO postgres;

--
-- Name: robot_telemetry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.robot_telemetry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.robot_telemetry_id_seq OWNER TO postgres;

--
-- Name: robot_telemetry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.robot_telemetry_id_seq OWNED BY public.robot_telemetry.id;


--
-- Name: robots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robots (
    id integer NOT NULL,
    robot_code character varying(30) NOT NULL,
    name character varying(100) NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    status character varying(30) NOT NULL,
    battery_level double precision NOT NULL,
    current_location_id character varying(50),
    current_x double precision NOT NULL,
    current_y double precision NOT NULL,
    target_location_id character varying(50),
    target_x double precision NOT NULL,
    target_y double precision NOT NULL,
    assigned_task_id integer,
    total_tasks_completed integer NOT NULL,
    total_distance double precision NOT NULL,
    total_operating_time double precision NOT NULL,
    utilization_percent double precision NOT NULL,
    failure_count integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    last_heartbeat_at timestamp without time zone NOT NULL,
    robot_type character varying(30) NOT NULL,
    max_payload double precision NOT NULL,
    max_speed double precision NOT NULL,
    enabled boolean NOT NULL,
    metadata text NOT NULL
);


ALTER TABLE public.robots OWNER TO postgres;

--
-- Name: robots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.robots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.robots_id_seq OWNER TO postgres;

--
-- Name: robots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.robots_id_seq OWNED BY public.robots.id;


--
-- Name: scenarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scenarios (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    warehouse_id character varying(20) NOT NULL,
    scenario_type character varying(30) NOT NULL,
    configuration json NOT NULL,
    random_seed integer NOT NULL,
    status character varying(20) NOT NULL,
    tags text NOT NULL,
    notes text,
    created_by character varying(64) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.scenarios OWNER TO postgres;

--
-- Name: scenarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.scenarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scenarios_id_seq OWNER TO postgres;

--
-- Name: scenarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.scenarios_id_seq OWNED BY public.scenarios.id;


--
-- Name: shipments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipments (
    id character varying(20) NOT NULL,
    order_id character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    tracking_reference character varying(100),
    carrier character varying(50),
    created_at timestamp without time zone,
    shipped_at timestamp without time zone,
    delivered_at timestamp without time zone
);


ALTER TABLE public.shipments OWNER TO postgres;

--
-- Name: shrinkage_flags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shrinkage_flags (
    id integer NOT NULL,
    date date NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    item_name character varying(150),
    deviation_score double precision,
    expected_quantity double precision,
    actual_quantity double precision,
    discrepancy_quantity double precision,
    estimated_exposure double precision,
    severity character varying(20),
    likely_cause character varying(80),
    explanation text
);


ALTER TABLE public.shrinkage_flags OWNER TO postgres;

--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shrinkage_flags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shrinkage_flags_id_seq OWNER TO postgres;

--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shrinkage_flags_id_seq OWNED BY public.shrinkage_flags.id;


--
-- Name: simulation_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.simulation_events (
    id integer NOT NULL,
    simulation_id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    event_type character varying(50) NOT NULL,
    severity character varying(10) NOT NULL,
    sim_time_seconds double precision NOT NULL,
    real_timestamp timestamp without time zone NOT NULL,
    robot_id integer,
    task_id integer,
    location_id character varying(50),
    route_id integer,
    message text NOT NULL,
    metadata text NOT NULL
);


ALTER TABLE public.simulation_events OWNER TO postgres;

--
-- Name: simulation_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.simulation_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.simulation_events_id_seq OWNER TO postgres;

--
-- Name: simulation_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.simulation_events_id_seq OWNED BY public.simulation_events.id;


--
-- Name: simulation_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.simulation_snapshots (
    id integer NOT NULL,
    simulation_id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    snapshot_version integer NOT NULL,
    taken_at timestamp without time zone NOT NULL,
    sim_time_seconds double precision NOT NULL,
    robot_states text NOT NULL,
    task_states text NOT NULL,
    obstacle_states text NOT NULL,
    sim_inventory_delta text NOT NULL,
    metadata text NOT NULL
);


ALTER TABLE public.simulation_snapshots OWNER TO postgres;

--
-- Name: simulation_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.simulation_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.simulation_snapshots_id_seq OWNER TO postgres;

--
-- Name: simulation_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.simulation_snapshots_id_seq OWNED BY public.simulation_snapshots.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    date date NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    stock_in integer,
    stock_out integer,
    closing_stock integer,
    is_anomaly boolean,
    anomaly_type character varying(30),
    entry_source character varying(20),
    entered_by character varying(64)
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_movements_id_seq OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: system_health_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_health_snapshots (
    id integer NOT NULL,
    service character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    latency_ms double precision,
    "timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public.system_health_snapshots OWNER TO postgres;

--
-- Name: system_health_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_health_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_health_snapshots_id_seq OWNER TO postgres;

--
-- Name: system_health_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_health_snapshots_id_seq OWNED BY public.system_health_snapshots.id;


--
-- Name: system_incidents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_incidents (
    id integer NOT NULL,
    category character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(100) NOT NULL,
    description text NOT NULL,
    source character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    fingerprint character varying(128),
    started_at timestamp without time zone NOT NULL,
    resolved_at timestamp without time zone,
    acknowledged_by character varying(64),
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.system_incidents OWNER TO postgres;

--
-- Name: system_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_incidents_id_seq OWNER TO postgres;

--
-- Name: system_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_incidents_id_seq OWNED BY public.system_incidents.id;


--
-- Name: task_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_events (
    id integer NOT NULL,
    task_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    previous_status character varying(30),
    new_status character varying(30),
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    reason text,
    metadata text NOT NULL
);


ALTER TABLE public.task_events OWNER TO postgres;

--
-- Name: task_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_events_id_seq OWNER TO postgres;

--
-- Name: task_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_events_id_seq OWNED BY public.task_events.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    task_number character varying(64) NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    task_type character varying(30) NOT NULL,
    priority character varying(20) NOT NULL,
    priority_score integer NOT NULL,
    status character varying(30) NOT NULL,
    source_type character varying(30),
    source_id character varying(64),
    order_id character varying(20),
    order_item_id integer,
    product_id character varying(20) NOT NULL,
    source_location_id character varying(50),
    destination_location_id character varying(50),
    requested_quantity integer NOT NULL,
    completed_quantity integer NOT NULL,
    assigned_user_id integer,
    assigned_robot_id character varying(50),
    created_at timestamp without time zone,
    prioritized_at timestamp without time zone,
    assigned_at timestamp without time zone,
    started_at timestamp without time zone,
    paused_at timestamp without time zone,
    completed_at timestamp without time zone,
    failed_at timestamp without time zone,
    cancelled_at timestamp without time zone,
    due_at timestamp without time zone,
    retry_count integer NOT NULL,
    failure_reason text,
    notes text,
    metadata text NOT NULL,
    depends_on_task_id integer
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    session_token_hash character varying(64) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    last_seen_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    revoked_at timestamp without time zone,
    revoke_reason character varying(100),
    login_method character varying(30),
    ip_address character varying(45),
    login_location character varying(255),
    user_agent character varying(500)
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_sessions_id_seq OWNER TO postgres;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: user_warehouse_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_warehouse_access (
    id integer NOT NULL,
    user_id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_warehouse_access OWNER TO postgres;

--
-- Name: user_warehouse_access_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_warehouse_access_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_warehouse_access_id_seq OWNER TO postgres;

--
-- Name: user_warehouse_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_warehouse_access_id_seq OWNED BY public.user_warehouse_access.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    email character varying(255),
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    full_name character varying(120),
    google_subject_id character varying(128),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_active boolean NOT NULL,
    is_verified boolean NOT NULL,
    last_login_at timestamp without time zone,
    last_logout_at timestamp without time zone,
    last_login_ip character varying(45),
    login_location character varying(255),
    login_method character varying(30),
    failed_login_count integer NOT NULL,
    locked_until timestamp without time zone,
    email_verified_at timestamp without time zone,
    password_changed_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: warehouse_grid_cells; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_grid_cells (
    id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    cell_type character varying(30) NOT NULL,
    traversable boolean NOT NULL,
    occupied boolean NOT NULL,
    restricted boolean NOT NULL,
    cost double precision NOT NULL,
    metadata text NOT NULL
);


ALTER TABLE public.warehouse_grid_cells OWNER TO postgres;

--
-- Name: warehouse_grid_cells_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.warehouse_grid_cells_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.warehouse_grid_cells_id_seq OWNER TO postgres;

--
-- Name: warehouse_grid_cells_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.warehouse_grid_cells_id_seq OWNED BY public.warehouse_grid_cells.id;


--
-- Name: warehouse_locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_locations (
    id character varying(50) NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    zone character varying(20) NOT NULL,
    aisle character varying(20) NOT NULL,
    rack character varying(20) NOT NULL,
    shelf character varying(20) NOT NULL,
    x double precision,
    y double precision,
    capacity integer,
    current_utilization integer,
    location_type character varying(20),
    status character varying(20),
    created_at timestamp without time zone
);


ALTER TABLE public.warehouse_locations OWNER TO postgres;

--
-- Name: warehouse_obstacles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_obstacles (
    id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    obstacle_type character varying(30) NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    active boolean NOT NULL,
    severity character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.warehouse_obstacles OWNER TO postgres;

--
-- Name: warehouse_obstacles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.warehouse_obstacles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.warehouse_obstacles_id_seq OWNER TO postgres;

--
-- Name: warehouse_obstacles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.warehouse_obstacles_id_seq OWNED BY public.warehouse_obstacles.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouses (
    id character varying(20) NOT NULL,
    name character varying(120) NOT NULL,
    location character varying(120),
    latitude double precision,
    longitude double precision,
    created_at timestamp without time zone
);


ALTER TABLE public.warehouses OWNER TO postgres;

--
-- Name: access_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log ALTER COLUMN id SET DEFAULT nextval('public.access_log_id_seq'::regclass);


--
-- Name: ai_recommendations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_recommendations ALTER COLUMN id SET DEFAULT nextval('public.ai_recommendations_id_seq'::regclass);


--
-- Name: audit_ledger id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_ledger ALTER COLUMN id SET DEFAULT nextval('public.audit_ledger_id_seq'::regclass);


--
-- Name: backup_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_records ALTER COLUMN id SET DEFAULT nextval('public.backup_records_id_seq'::regclass);


--
-- Name: digital_twin_simulations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.digital_twin_simulations ALTER COLUMN id SET DEFAULT nextval('public.digital_twin_simulations_id_seq'::regclass);


--
-- Name: experiment_runs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_runs ALTER COLUMN id SET DEFAULT nextval('public.experiment_runs_id_seq'::regclass);


--
-- Name: experiments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiments ALTER COLUMN id SET DEFAULT nextval('public.experiments_id_seq'::regclass);


--
-- Name: health_thresholds id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_thresholds ALTER COLUMN id SET DEFAULT nextval('public.health_thresholds_id_seq'::regclass);


--
-- Name: inventory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory ALTER COLUMN id SET DEFAULT nextval('public.inventory_id_seq'::regclass);


--
-- Name: inventory_reservations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations ALTER COLUMN id SET DEFAULT nextval('public.inventory_reservations_id_seq'::regclass);


--
-- Name: notification_preferences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences ALTER COLUMN id SET DEFAULT nextval('public.notification_preferences_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: order_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_events ALTER COLUMN id SET DEFAULT nextval('public.order_events_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: otp_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_records ALTER COLUMN id SET DEFAULT nextval('public.otp_records_id_seq'::regclass);


--
-- Name: packing_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packing_records ALTER COLUMN id SET DEFAULT nextval('public.packing_records_id_seq'::regclass);


--
-- Name: recovery_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes ALTER COLUMN id SET DEFAULT nextval('public.recovery_codes_id_seq'::regclass);


--
-- Name: recovery_credentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials ALTER COLUMN id SET DEFAULT nextval('public.recovery_credentials_id_seq'::regclass);


--
-- Name: robot_reservations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_reservations ALTER COLUMN id SET DEFAULT nextval('public.robot_reservations_id_seq'::regclass);


--
-- Name: robot_routes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes ALTER COLUMN id SET DEFAULT nextval('public.robot_routes_id_seq'::regclass);


--
-- Name: robot_telemetry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_telemetry ALTER COLUMN id SET DEFAULT nextval('public.robot_telemetry_id_seq'::regclass);


--
-- Name: robots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots ALTER COLUMN id SET DEFAULT nextval('public.robots_id_seq'::regclass);


--
-- Name: scenarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scenarios ALTER COLUMN id SET DEFAULT nextval('public.scenarios_id_seq'::regclass);


--
-- Name: shrinkage_flags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shrinkage_flags ALTER COLUMN id SET DEFAULT nextval('public.shrinkage_flags_id_seq'::regclass);


--
-- Name: simulation_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_events ALTER COLUMN id SET DEFAULT nextval('public.simulation_events_id_seq'::regclass);


--
-- Name: simulation_snapshots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_snapshots ALTER COLUMN id SET DEFAULT nextval('public.simulation_snapshots_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: system_health_snapshots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_health_snapshots ALTER COLUMN id SET DEFAULT nextval('public.system_health_snapshots_id_seq'::regclass);


--
-- Name: system_incidents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_incidents ALTER COLUMN id SET DEFAULT nextval('public.system_incidents_id_seq'::regclass);


--
-- Name: task_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_events ALTER COLUMN id SET DEFAULT nextval('public.task_events_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: user_warehouse_access id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access ALTER COLUMN id SET DEFAULT nextval('public.user_warehouse_access_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: warehouse_grid_cells id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_grid_cells ALTER COLUMN id SET DEFAULT nextval('public.warehouse_grid_cells_id_seq'::regclass);


--
-- Name: warehouse_obstacles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_obstacles ALTER COLUMN id SET DEFAULT nextval('public.warehouse_obstacles_id_seq'::regclass);


--
-- Data for Name: access_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access_log (id, "timestamp", username, warehouse_id, action, ip_address) FROM stdin;
262	2026-08-19 16:19:21.691828	admin		login	127.0.0.1
212	2026-08-18 01:23:14.934683	admin	WH-DEL-01	view	192.168.1.195
213	2026-08-17 13:14:14.935681	harsha200797@gmail.com		login	192.168.1.28
214	2026-08-17 21:49:14.935681	harsha200797@gmail.com		login	192.168.1.80
215	2026-08-16 17:53:14.935681	harsha200797@gmail.com		login	192.168.1.100
216	2026-08-18 08:17:14.935681	admin	WH-CHN-01	view	192.168.1.33
217	2026-08-17 04:08:14.935681	admin	WH-CHN-01	add_stock	192.168.1.153
218	2026-08-16 10:50:14.935681	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.71
219	2026-08-17 00:21:14.935681	harsha200797@gmail.com	WH-CCU-01	add_stock	192.168.1.164
220	2026-08-19 15:05:14.935681	admin	WH-DEL-01	add_stock	192.168.1.54
221	2026-08-18 03:40:14.935681	admin	WH-BOM-01	add_stock	192.168.1.62
222	2026-08-17 11:15:14.935681	harsha200797@gmail.com	WH-DEL-01	view	192.168.1.210
223	2026-08-18 01:21:14.935681	harsha200797@gmail.com	WH-DEL-01	view	192.168.1.132
224	2026-08-17 22:38:14.935681	admin	WH-CCU-01	view	192.168.1.32
225	2026-08-18 16:41:14.935681	harsha200797@gmail.com		login	192.168.1.26
226	2026-08-16 16:34:14.935681	admin	WH-CHN-01	add_stock	192.168.1.147
227	2026-08-19 07:44:14.935681	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.205
228	2026-08-16 06:39:14.935681	admin		login	192.168.1.131
229	2026-08-19 09:05:14.935681	admin	WH-DEL-01	add_stock	192.168.1.31
230	2026-08-16 05:08:14.935681	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.126
231	2026-08-18 03:25:14.935681	admin	WH-CHN-01	view	192.168.1.207
232	2026-08-17 08:38:14.935681	admin	WH-CHN-01	add_stock	192.168.1.226
233	2026-08-19 03:45:14.936681	harsha200797@gmail.com		login	192.168.1.88
234	2026-08-16 10:32:14.936681	admin	WH-BOM-01	view	192.168.1.197
235	2026-08-16 09:14:14.936681	admin	WH-BOM-01	view	192.168.1.202
236	2026-08-17 12:36:14.936681	admin	WH-BLR-01	view	192.168.1.16
237	2026-08-19 14:53:14.936681	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.65
238	2026-08-18 06:32:14.936681	harsha200797@gmail.com	WH-CHN-01	add_stock	192.168.1.115
239	2026-08-16 07:52:14.936681	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.76
240	2026-08-17 08:14:14.936681	admin	WH-BLR-01	view	192.168.1.223
241	2026-08-19 14:43:14.936681	admin	WH-BOM-01	add_stock	192.168.1.27
242	2026-08-19 07:27:14.936681	admin	WH-CHN-01	add_stock	192.168.1.161
243	2026-08-18 15:27:14.936681	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.129
244	2026-08-18 19:30:14.936681	harsha200797@gmail.com		login	192.168.1.72
245	2026-08-17 19:57:14.936681	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.135
246	2026-08-17 00:53:14.938689	admin		login	192.168.1.11
247	2026-08-17 18:27:14.938689	admin		login	192.168.1.238
248	2026-08-17 00:01:14.938689	admin		login	192.168.1.106
249	2026-08-18 19:39:14.938689	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.38
250	2026-08-17 01:52:14.938689	harsha200797@gmail.com	WH-DEL-01	add_stock	192.168.1.101
251	2026-08-16 22:18:14.938689	harsha200797@gmail.com	WH-DEL-01	view	192.168.1.16
252	2026-08-17 05:58:14.938689	harsha200797@gmail.com	WH-BLR-01	add_stock	192.168.1.168
253	2026-08-17 23:02:14.938689	admin		login	192.168.1.156
254	2026-08-16 13:54:14.938689	admin	WH-BOM-01	view	192.168.1.91
255	2026-08-18 06:00:14.938689	admin	WH-BLR-01	view	192.168.1.5
256	2026-08-18 08:51:14.938689	harsha200797@gmail.com		login	192.168.1.177
257	2026-08-19 15:50:14.938689	admin		login	192.168.1.35
258	2026-08-16 15:57:14.938689	admin	WH-CCU-01	view	192.168.1.174
259	2026-08-17 07:23:14.938689	admin	WH-BOM-01	view	192.168.1.82
260	2026-08-18 08:45:14.938689	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.137
261	2026-08-16 15:31:14.938689	admin	WH-CHN-01	view	192.168.1.148
\.


--
-- Data for Name: ai_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_recommendations (id, "timestamp", warehouse_id, item_id, title, risk_level, action_recommended, confidence_score, input_factors, status, decision_by, decision_time, notes, recommendation_type, description, priority, score, confidence_or_reliability, source_model, source_entity_type, source_entity_id, recommended_action, estimated_impact, explanation, supporting_metrics, created_at, reviewed_at, reviewed_by, review_notes, expires_at, metadata) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
c6a0f47c242e
\.


--
-- Data for Name: audit_ledger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_ledger (id, "timestamp", event_type, details, prev_hash, hash) FROM stdin;
1	2026-08-19 15:43:05	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	0000000000000000000000000000000000000000000000000000000000000000	ad8f32f19d808d29b5e73d8e1bf9d53a57893633451c53ce715768c395f9d712
2	2026-08-19 15:43:05	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	ad8f32f19d808d29b5e73d8e1bf9d53a57893633451c53ce715768c395f9d712	af8de1d7d027b3020dcc1e59b62383f479caefa82802bb22cafc3e64c414c321
3	2026-08-19 15:43:05	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	af8de1d7d027b3020dcc1e59b62383f479caefa82802bb22cafc3e64c414c321	1e1c20d52a81e3cd3b3749813ebd9d44a6d3cabf7911b594f94073d3a92569c1
4	2026-08-19 15:43:05	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	1e1c20d52a81e3cd3b3749813ebd9d44a6d3cabf7911b594f94073d3a92569c1	03ce28ea0c5ad75008e2432fc8731871d134ba1932be4adf8ac3fab220bd22be
5	2026-08-19 15:43:05	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	03ce28ea0c5ad75008e2432fc8731871d134ba1932be4adf8ac3fab220bd22be	3083c8d5f46b94e698d0be7d99b93f217f6b2c4352869d46403b1ea75812c6e0
6	2026-08-19 15:43:05	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	3083c8d5f46b94e698d0be7d99b93f217f6b2c4352869d46403b1ea75812c6e0	a18c6092eebbe3460d17d59417ed663527ed88da795621efc58ce9e2094c66ba
7	2026-08-19 15:43:05	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	a18c6092eebbe3460d17d59417ed663527ed88da795621efc58ce9e2094c66ba	645525b762fda241e15d71d22d190b5da040adefa06db807e95f63c9a3df44da
8	2026-08-19 15:43:05	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	645525b762fda241e15d71d22d190b5da040adefa06db807e95f63c9a3df44da	17a9ba9597e2df82351aa4558bcffa1e6f3fa66948139a6dc81ce68a5cbef0c1
9	2026-08-19 15:43:05	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	17a9ba9597e2df82351aa4558bcffa1e6f3fa66948139a6dc81ce68a5cbef0c1	d6b9c34f9e94709534807d27d5e4d4fcc9aa0d36c6638b2396dafdfd71c12d89
10	2026-08-19 15:43:05	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	d6b9c34f9e94709534807d27d5e4d4fcc9aa0d36c6638b2396dafdfd71c12d89	9a5436b3dcca4d7a1e7a6be1096e2c93f4d0ae1b43456d8319c187a11dc6182c
11	2026-08-19 15:43:05	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	9a5436b3dcca4d7a1e7a6be1096e2c93f4d0ae1b43456d8319c187a11dc6182c	4f8ea912a895a05940e79a477b492479fb6ff152a498fc5151660cacdea79d68
12	2026-08-19 15:43:05	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	4f8ea912a895a05940e79a477b492479fb6ff152a498fc5151660cacdea79d68	3ac26c8b0e3e33426813b86a35622d7d439e094a40b8e2ffcde0582b8d8fdcf4
13	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-18"}	3ac26c8b0e3e33426813b86a35622d7d439e094a40b8e2ffcde0582b8d8fdcf4	944dabfc806eb8b3fffd8c648fef66870a5b61dcba504eb7fe83196b1ce04557
14	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	944dabfc806eb8b3fffd8c648fef66870a5b61dcba504eb7fe83196b1ce04557	eba0041f5eacbdfff13598abe79cc05218c6f982014aebb0396ed7dc1cc2ad58
15	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	eba0041f5eacbdfff13598abe79cc05218c6f982014aebb0396ed7dc1cc2ad58	8086601575c3acccb7372c1b9ece4006ca95881dafb73f73d4f3ee42a8852b7f
16	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	8086601575c3acccb7372c1b9ece4006ca95881dafb73f73d4f3ee42a8852b7f	fe600e1fa700c032f051a01306bc674bb9a49798e43d08bea038927fd5b101bc
17	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	fe600e1fa700c032f051a01306bc674bb9a49798e43d08bea038927fd5b101bc	06afd9cc4776e31691a6cb7f2f34f1c06704527366d382f705642a6c5d1afdb7
18	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	06afd9cc4776e31691a6cb7f2f34f1c06704527366d382f705642a6c5d1afdb7	bfb20aa0253e56ece247dde17b703cc312b8ab100624059b70bcb0c421953ecf
19	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	bfb20aa0253e56ece247dde17b703cc312b8ab100624059b70bcb0c421953ecf	449081ba33ac56de47da9c5dd31cd055ed98f7c7edc1b38a9a543d77ed702c88
20	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	449081ba33ac56de47da9c5dd31cd055ed98f7c7edc1b38a9a543d77ed702c88	465c2303c176440095fd019732d7723b18cc2fa5abf6078d62c68592df994a30
21	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-27"}	465c2303c176440095fd019732d7723b18cc2fa5abf6078d62c68592df994a30	9b61c1db086dae7339463500c2ef371598db9f94ba90c4990a22daf8fea607b4
22	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-28"}	9b61c1db086dae7339463500c2ef371598db9f94ba90c4990a22daf8fea607b4	93caeda9185869d0a4501855e9ba6626e9096aa1fb8125f2499994621949d221
23	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-28"}	93caeda9185869d0a4501855e9ba6626e9096aa1fb8125f2499994621949d221	b5112af0b8f7060aca3757fb4c10f15231269de68da7ca3ef1517133183998f1
24	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-29"}	b5112af0b8f7060aca3757fb4c10f15231269de68da7ca3ef1517133183998f1	7e5c54a28568bd3fb40c64fe0684151e9efd4f68b3e2f574ed3dd9183d42e966
25	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-30"}	7e5c54a28568bd3fb40c64fe0684151e9efd4f68b3e2f574ed3dd9183d42e966	e6023ec82f565ae70855655d2ad0c017b868ffa30a4cdae41fc5dcb42fdf9b16
26	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-02"}	e6023ec82f565ae70855655d2ad0c017b868ffa30a4cdae41fc5dcb42fdf9b16	cb92ee9dad01ad24fecf3ad3258b5e76655201efaf7aef182133b15909b93a21
27	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	cb92ee9dad01ad24fecf3ad3258b5e76655201efaf7aef182133b15909b93a21	5454186db55b056b61f4c50582d779faffc79f5954228f2cda01c7f5308b3433
28	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	5454186db55b056b61f4c50582d779faffc79f5954228f2cda01c7f5308b3433	1fd7f2759bb6c6a1ac52649deee4b2359eca49c23574b21c31b7c3a9e4464a38
29	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	1fd7f2759bb6c6a1ac52649deee4b2359eca49c23574b21c31b7c3a9e4464a38	3a55218ce975a2081e69a98722173b8990dbecc0a5490c0b61a7ce9ec6015949
30	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-03"}	3a55218ce975a2081e69a98722173b8990dbecc0a5490c0b61a7ce9ec6015949	489f56d1f1431b786bfb1126e62f17b8723d440b16046bd0a726fc760df715c9
31	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	489f56d1f1431b786bfb1126e62f17b8723d440b16046bd0a726fc760df715c9	a9bf8381e585b55d3ba4afabbd062d8520f1b7e6550ec06b5e6e364e2064547a
32	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-04"}	a9bf8381e585b55d3ba4afabbd062d8520f1b7e6550ec06b5e6e364e2064547a	3ca47a829b3912859c94aa96d79249f5d2f5f3d028fa0498fd8771aab87f4e04
33	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-04"}	3ca47a829b3912859c94aa96d79249f5d2f5f3d028fa0498fd8771aab87f4e04	d6741aea9415c75d06961ed601a2ab381260376b137f539abec4f1a2165a03d9
34	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-05"}	d6741aea9415c75d06961ed601a2ab381260376b137f539abec4f1a2165a03d9	ef40fb2529d8f918a3502228e55ed94cf3f40c9e7085c92f05e090011da1e318
35	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-05"}	ef40fb2529d8f918a3502228e55ed94cf3f40c9e7085c92f05e090011da1e318	921eecc9e33abaec4ff9f12b5fb1270cc3455bbc1b2b2a2550b30853d1f13565
36	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	921eecc9e33abaec4ff9f12b5fb1270cc3455bbc1b2b2a2550b30853d1f13565	cc48bd54ecca79495cdfda1924bd6c3f8b0bdb7f4e697ff79fa7b0606de2035d
37	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-06"}	cc48bd54ecca79495cdfda1924bd6c3f8b0bdb7f4e697ff79fa7b0606de2035d	3c41ffa52dc328bdfe96ad6e99e8a633832b24d36d0300c7884f494f0d0ecb77
38	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-06"}	3c41ffa52dc328bdfe96ad6e99e8a633832b24d36d0300c7884f494f0d0ecb77	e5f259dbdc314aae695030a73ec2f759b40a1f90383059801c52884bcff9efef
39	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-07"}	e5f259dbdc314aae695030a73ec2f759b40a1f90383059801c52884bcff9efef	67a62198989d1b65ffe1bcd11faec2c0555a4486f50aeb54106da69639ee014b
40	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-07"}	67a62198989d1b65ffe1bcd11faec2c0555a4486f50aeb54106da69639ee014b	8f8c20a208c3b4636796f9cb5cc7e463b3106add03b5da0d5618897171e8a4b2
41	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-07"}	8f8c20a208c3b4636796f9cb5cc7e463b3106add03b5da0d5618897171e8a4b2	0df0bf1fa834fc0abb8f68d915f102cba62875feec3a44234a12d7dee37f1691
42	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-10"}	0df0bf1fa834fc0abb8f68d915f102cba62875feec3a44234a12d7dee37f1691	081f3ce3a91618d134d5adc032e0f9ccd598a45023da43e40d4abd53724eb30e
43	2026-08-19 15:43:05	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	081f3ce3a91618d134d5adc032e0f9ccd598a45023da43e40d4abd53724eb30e	40227628558902049b9e4d89052afb7b873268bc652a00c3673eb0f55a8ecedd
44	2026-08-19 15:43:05	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	40227628558902049b9e4d89052afb7b873268bc652a00c3673eb0f55a8ecedd	3e3f0cd60f4ac327bf00deecd93cc897f092bde6d05e91a1f6439f1beea10a7e
45	2026-08-19 15:43:05	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	3e3f0cd60f4ac327bf00deecd93cc897f092bde6d05e91a1f6439f1beea10a7e	9e89fe0d86a79c43efc13ca18bfc9193869c5eae82693089795b8f53a1d9d171
46	2026-08-19 15:43:33	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	9e89fe0d86a79c43efc13ca18bfc9193869c5eae82693089795b8f53a1d9d171	ba65fe818bbd0adc926e9c2076c41d4d256eba7ca56deb84853db58bca9c501f
47	2026-08-19 15:43:33	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	ba65fe818bbd0adc926e9c2076c41d4d256eba7ca56deb84853db58bca9c501f	1ca3693f007403abb572c4a35d59ee33edd38a6983bad5588c768475c6da6bb9
48	2026-08-19 15:43:33	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	1ca3693f007403abb572c4a35d59ee33edd38a6983bad5588c768475c6da6bb9	34f28080db1684fc252ea6de48b6c5e3ef7a29eb8aa4bf804897ce192f92bdaf
49	2026-08-19 15:43:33	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	34f28080db1684fc252ea6de48b6c5e3ef7a29eb8aa4bf804897ce192f92bdaf	1230308457c5d0e80282fa728f232d652562f6e5bfbb5c77a58fa3c5863b6c5c
50	2026-08-19 15:43:33	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	1230308457c5d0e80282fa728f232d652562f6e5bfbb5c77a58fa3c5863b6c5c	2daaa067a4e037390a30d9447a0181b271703f805a7faf0dacd9073efd33f835
51	2026-08-19 15:43:33	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	2daaa067a4e037390a30d9447a0181b271703f805a7faf0dacd9073efd33f835	54db878f1e10ec1f4ca0c68971c125299271e6574d842932ec00e6135f8402f6
52	2026-08-19 15:43:33	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	54db878f1e10ec1f4ca0c68971c125299271e6574d842932ec00e6135f8402f6	aa465291b42a1c3c428e7a9ea2bafe1e97ddb5de68f147ccea026a18b57f8687
53	2026-08-19 15:43:33	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	aa465291b42a1c3c428e7a9ea2bafe1e97ddb5de68f147ccea026a18b57f8687	5b1f506e56aee4fe1ea83c22ebe89d25d6fab3757e4ee95fae4261ca68248660
54	2026-08-19 15:43:33	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	5b1f506e56aee4fe1ea83c22ebe89d25d6fab3757e4ee95fae4261ca68248660	89c478485dd294a9582abde73685f622fee46f775df52315de66ffc95a50a05c
55	2026-08-19 15:43:33	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	89c478485dd294a9582abde73685f622fee46f775df52315de66ffc95a50a05c	66040bc70d1ebe00f9d17739a030e7caff94777043c1ba38a8e950a5f302fcef
56	2026-08-19 15:43:33	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	66040bc70d1ebe00f9d17739a030e7caff94777043c1ba38a8e950a5f302fcef	b28b686689362f51122a368db908ea45c4b6e2ed7f11e5d92e044229b3ae477b
57	2026-08-19 15:43:33	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	b28b686689362f51122a368db908ea45c4b6e2ed7f11e5d92e044229b3ae477b	fc3e771e8b677aae95b9e59b1a66e728e8018c7d878169ff0f744f0b24f5dfd7
58	2026-08-19 15:43:33	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	fc3e771e8b677aae95b9e59b1a66e728e8018c7d878169ff0f744f0b24f5dfd7	0bafe849206d8615780bc3ed43a72758b55415f1667d752521a8b7b78e8b8e48
59	2026-08-19 15:43:33	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	0bafe849206d8615780bc3ed43a72758b55415f1667d752521a8b7b78e8b8e48	b62be268b15cfed544fcd1dac454a1588fad5f3bd2c8f61187f3dabf3a4e9706
60	2026-08-19 15:43:33	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	b62be268b15cfed544fcd1dac454a1588fad5f3bd2c8f61187f3dabf3a4e9706	d5e7f9cec36c1710bd6da575c19193726d56dcaa80f355294c03c826fff2f020
61	2026-08-19 15:43:33	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	d5e7f9cec36c1710bd6da575c19193726d56dcaa80f355294c03c826fff2f020	62b70c9b7f8f8c065060801b3e781d73f6057a1ce3e42c79e6dafd69f539378a
62	2026-08-19 15:43:33	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	62b70c9b7f8f8c065060801b3e781d73f6057a1ce3e42c79e6dafd69f539378a	a56e4aff66cc5aa4fe8b5ed62db2af9f8e7fe8a910dfa91a9a076d9103060ebb
63	2026-08-19 15:43:33	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	a56e4aff66cc5aa4fe8b5ed62db2af9f8e7fe8a910dfa91a9a076d9103060ebb	4be0e683cc32a0d5b77596586982b53cbde64cd6d48d047031ebf7f95971267e
64	2026-08-19 15:43:33	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	4be0e683cc32a0d5b77596586982b53cbde64cd6d48d047031ebf7f95971267e	cdd815456d6926c8b2476b7b2ec462e3994e5992d249082d2574dbff296dd09b
65	2026-08-19 15:43:33	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	cdd815456d6926c8b2476b7b2ec462e3994e5992d249082d2574dbff296dd09b	9758b784a054efb40c5f64161653e247420a25ee8dd9081e3a2a14670eff6541
66	2026-08-19 15:43:33	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	9758b784a054efb40c5f64161653e247420a25ee8dd9081e3a2a14670eff6541	7f9fdc10c95e5554a0dc9cb0e4252fcdcff9a4e4c1b87975d8360e8863eab3a4
67	2026-08-19 15:43:33	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-29"}	7f9fdc10c95e5554a0dc9cb0e4252fcdcff9a4e4c1b87975d8360e8863eab3a4	06752c46af2ff83c748657f7bef2444648ebfa3e897a4eab6b6c9da410633476
68	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-31"}	06752c46af2ff83c748657f7bef2444648ebfa3e897a4eab6b6c9da410633476	8791ef204737acdea4710e3cb566e2b8284cb9c9f5fee2e83bd0c746a8a7965d
69	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-01"}	8791ef204737acdea4710e3cb566e2b8284cb9c9f5fee2e83bd0c746a8a7965d	0bc0d86e10d8f5c45b217e4c9bc6570150be77f2378359ddd1549deef42e5021
70	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-01"}	0bc0d86e10d8f5c45b217e4c9bc6570150be77f2378359ddd1549deef42e5021	2fc4adf2f63ca07e1d3e0ce9f13e9941fdde1c243c32bce4ec07dfb433802cb2
71	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-01"}	2fc4adf2f63ca07e1d3e0ce9f13e9941fdde1c243c32bce4ec07dfb433802cb2	f58df2d5aee9bb96ee81a2c86484c2345b3cae1fe54ed97c7c7f499961d3205a
72	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-01"}	f58df2d5aee9bb96ee81a2c86484c2345b3cae1fe54ed97c7c7f499961d3205a	d71c4692be62dd519a7859a88ce637d551d1f43d67308e28d5d315fb7dee85ac
73	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-08-01"}	d71c4692be62dd519a7859a88ce637d551d1f43d67308e28d5d315fb7dee85ac	cee5afe0794f71781cf31969c1fca78592a6f0e8942d2882408c019bc15825c2
74	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-02"}	cee5afe0794f71781cf31969c1fca78592a6f0e8942d2882408c019bc15825c2	a04a08d31090c85eca47edfdfc0bba7413f8e23904d63c0f8a52a40e21865567
75	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-02"}	a04a08d31090c85eca47edfdfc0bba7413f8e23904d63c0f8a52a40e21865567	271e2880703b2de49e5f7f893e0c5782fcfdb04cdc8e78bc6feb195ee16a71a1
76	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-03"}	271e2880703b2de49e5f7f893e0c5782fcfdb04cdc8e78bc6feb195ee16a71a1	8f91a6f66cfe36138e125a9e2069ee6ca5f6a44ffea23b8b5642136990cd24ec
77	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-04"}	8f91a6f66cfe36138e125a9e2069ee6ca5f6a44ffea23b8b5642136990cd24ec	6524c5907c7e86b0e52db3092cbc6505cedf4ee4344b728f5e2715954d2b87b5
78	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-05"}	6524c5907c7e86b0e52db3092cbc6505cedf4ee4344b728f5e2715954d2b87b5	c56ffbfdd8b5f071cb5fe05af798182170410312518ac464182bb9676feeabb7
79	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	c56ffbfdd8b5f071cb5fe05af798182170410312518ac464182bb9676feeabb7	17904977be18f3474d60fd195d6bd7bc500ebbf0cedc151ecbea166bdb509f82
80	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	17904977be18f3474d60fd195d6bd7bc500ebbf0cedc151ecbea166bdb509f82	2dac82f7b191b03d50533fede0517f330ae858c218161613b8d14f79a798fe6e
81	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-06"}	2dac82f7b191b03d50533fede0517f330ae858c218161613b8d14f79a798fe6e	ace66f8fc08be478159eac4ba58b6304015012f902b1327d75b7aa95ca60a475
82	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-07"}	ace66f8fc08be478159eac4ba58b6304015012f902b1327d75b7aa95ca60a475	a8a4b485059f4b5b5105898db8bd609c3936ebd8a26e6aa133c0309e67f77485
83	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-07"}	a8a4b485059f4b5b5105898db8bd609c3936ebd8a26e6aa133c0309e67f77485	e5a1dddf26f5e58ec210643fc9ac49186c75de329ed53ba975cb8e102a5bcddb
84	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-08"}	e5a1dddf26f5e58ec210643fc9ac49186c75de329ed53ba975cb8e102a5bcddb	a7cc87c2248041c130b255558f85bbddd2df858be9038f0aa2e1f1f0b5ec79bb
85	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	a7cc87c2248041c130b255558f85bbddd2df858be9038f0aa2e1f1f0b5ec79bb	ce9c8edc6a2dc6bf60a40104b2a13b5fafdcce878714aa72608765cbfec23502
112	2026-08-19 15:56:33	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	7086d2e3e6a8e45319c880050c53aa79315cab559d014abea52e1ae9cf433ad1	ab875242ff043ca3ff87cbc285e0f669a4f218a220451b30a3fa22969f36c8e3
86	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-09"}	ce9c8edc6a2dc6bf60a40104b2a13b5fafdcce878714aa72608765cbfec23502	5fd0093c743dfb1c87a9b52fe484754e13e5c138db381f34018f51863367bbae
87	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-09"}	5fd0093c743dfb1c87a9b52fe484754e13e5c138db381f34018f51863367bbae	7ddd39c1b757d9fbbe318b5dcaa5955d750e1a3bc9baf4fd8c2760d2277c2be8
88	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-10"}	7ddd39c1b757d9fbbe318b5dcaa5955d750e1a3bc9baf4fd8c2760d2277c2be8	48fb7f12fba4a231fd046a1ebd0aab66914be6cbffea5825470bbaa4a6400713
89	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-10"}	48fb7f12fba4a231fd046a1ebd0aab66914be6cbffea5825470bbaa4a6400713	2d26db42f6c80dbb218324dcf206b9f2250489ef3bb4dcc7dbc710585d0b8d03
90	2026-08-19 15:43:34	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-11"}	2d26db42f6c80dbb218324dcf206b9f2250489ef3bb4dcc7dbc710585d0b8d03	0eded40c8ed4595faf8eefe78a8c2ea622939fdbebd372b5ead85510962d385f
91	2026-08-19 15:43:34	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	0eded40c8ed4595faf8eefe78a8c2ea622939fdbebd372b5ead85510962d385f	4d23317844e42e6ad189d95b1a6a60d762eb94cab79af79846eacd7d494da82e
92	2026-08-19 15:43:34	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	4d23317844e42e6ad189d95b1a6a60d762eb94cab79af79846eacd7d494da82e	ef5c7a4569be412f0a422da08dbef87baf1b572e25ac5d0706609cd8cc77c65b
93	2026-08-19 15:43:39	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T15:43:39.766816"}	ef5c7a4569be412f0a422da08dbef87baf1b572e25ac5d0706609cd8cc77c65b	ce104a5442140b289fd4c78afd0838e0eb6feb4fcd539b44c5bb97376642cf45
94	2026-08-19 15:43:39	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "1", "source_entity_type": "USER", "recipients_count": 3}	ce104a5442140b289fd4c78afd0838e0eb6feb4fcd539b44c5bb97376642cf45	e57a3d90ee6e53c6bf699abb37e0b49e171311e74d0d029ad1ab52899508a8d8
95	2026-08-19 15:43:42	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T15:43:42.815467"}	e57a3d90ee6e53c6bf699abb37e0b49e171311e74d0d029ad1ab52899508a8d8	a4764c1b143aa42aec6607b4cbaab98a5cf823a4ac2604315ba89ec084a540ed
96	2026-08-19 15:43:42	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "1", "source_entity_type": "USER", "recipients_count": 3}	a4764c1b143aa42aec6607b4cbaab98a5cf823a4ac2604315ba89ec084a540ed	206b82c5d9b6b73e058e5ceb3e0738f03001791df45b88995cf6381b618016aa
97	2026-08-19 15:43:47	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T15:43:47.001162"}	206b82c5d9b6b73e058e5ceb3e0738f03001791df45b88995cf6381b618016aa	f8775d8ec72ba01f96899ee521ef71b93313302dd2d9125c0cdd73ea93baaf6d
98	2026-08-19 15:43:47	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "1", "source_entity_type": "USER", "recipients_count": 3}	f8775d8ec72ba01f96899ee521ef71b93313302dd2d9125c0cdd73ea93baaf6d	d390f77711b2a6f756a3433a4e147c2fa33d5f71375f2e8b188d674c9868adb9
99	2026-08-19 15:44:20	user_login	{"username": "test_viewer", "role": "viewer", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T15:44:20.697715"}	d390f77711b2a6f756a3433a4e147c2fa33d5f71375f2e8b188d674c9868adb9	f7ea4ef15615f6ea6143e85549ee9ad3c92b96b57c56ef3bc58b8b30ebfb9760
100	2026-08-19 15:44:20	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "4", "source_entity_type": "USER", "recipients_count": 3}	f7ea4ef15615f6ea6143e85549ee9ad3c92b96b57c56ef3bc58b8b30ebfb9760	dc67e63e2f692a04b2216dca0e3733877821f04ecd828cd89d8abb2a3c34c30a
101	2026-08-19 15:44:24	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T15:44:24.181223"}	dc67e63e2f692a04b2216dca0e3733877821f04ecd828cd89d8abb2a3c34c30a	e13c4eca6249c063035659f35117be79d174dc0dcdbeb6e39810fa00cc6c124a
102	2026-08-19 15:44:24	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "1", "source_entity_type": "USER", "recipients_count": 3}	e13c4eca6249c063035659f35117be79d174dc0dcdbeb6e39810fa00cc6c124a	7c1b91b21c4d6dad73312014fe103a64c064f3ac3e5dc31b2af8ee357e8d1a70
103	2026-08-19 15:45:00	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T15:45:00.764835"}	7c1b91b21c4d6dad73312014fe103a64c064f3ac3e5dc31b2af8ee357e8d1a70	0df4b3ed0f356d64ff83a5c6079e1538a0b23ece2752aca11df9119ae9e50f42
104	2026-08-19 15:45:01	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "1", "source_entity_type": "USER", "recipients_count": 3}	0df4b3ed0f356d64ff83a5c6079e1538a0b23ece2752aca11df9119ae9e50f42	f9c4ab9ea6adcd54b5a8e9487c069594d2a143bb87c50d30124c722eac06e03f
105	2026-08-19 15:45:11	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T15:45:11.724794"}	f9c4ab9ea6adcd54b5a8e9487c069594d2a143bb87c50d30124c722eac06e03f	88c41f9984f7745389dfdf77773e12e8b481b236f94fdec380d791637b2d04ba
106	2026-08-19 15:45:11	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "1", "source_entity_type": "USER", "recipients_count": 3}	88c41f9984f7745389dfdf77773e12e8b481b236f94fdec380d791637b2d04ba	ae0e3cf1a43e4154ee31f0318f7ba0bd530b1206a69e656765437da86206a64c
107	2026-08-19 15:56:33	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	ae0e3cf1a43e4154ee31f0318f7ba0bd530b1206a69e656765437da86206a64c	cfd3b0730a9f381cdfcaf81e28567978bdc57a35167ea8257a0c8ec8bfd9a2a4
108	2026-08-19 15:56:33	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	cfd3b0730a9f381cdfcaf81e28567978bdc57a35167ea8257a0c8ec8bfd9a2a4	4621c68cf4fb88d29e71bf9da68222f8531cbccc3262abe0bd28e8ba70d3f093
109	2026-08-19 15:56:33	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	4621c68cf4fb88d29e71bf9da68222f8531cbccc3262abe0bd28e8ba70d3f093	ce6def05fd3a77c38097e8afdd94c1d5dda6b75482238cebabf05f1988f69556
110	2026-08-19 15:56:33	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	ce6def05fd3a77c38097e8afdd94c1d5dda6b75482238cebabf05f1988f69556	3b6a55072b9eb5a63b8bf574ac460e41a9559a96b9998ca93803705280dee4b7
111	2026-08-19 15:56:33	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	3b6a55072b9eb5a63b8bf574ac460e41a9559a96b9998ca93803705280dee4b7	7086d2e3e6a8e45319c880050c53aa79315cab559d014abea52e1ae9cf433ad1
113	2026-08-19 15:56:33	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	ab875242ff043ca3ff87cbc285e0f669a4f218a220451b30a3fa22969f36c8e3	9a8d47bfd940fbbe6ccc5f1f78a8d43b327ab7c68ac3a7834cb7caab71e70bb0
114	2026-08-19 15:56:33	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	9a8d47bfd940fbbe6ccc5f1f78a8d43b327ab7c68ac3a7834cb7caab71e70bb0	da3b2f1487adde0b80010c55ba2084476496283c3509594a878ec3d1560dee3e
115	2026-08-19 15:56:33	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	da3b2f1487adde0b80010c55ba2084476496283c3509594a878ec3d1560dee3e	f22a844d1cbc02ad1f0a758b126f5e7d2f348c6ae540fcc04e30de2dff5d62b4
116	2026-08-19 15:56:33	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	f22a844d1cbc02ad1f0a758b126f5e7d2f348c6ae540fcc04e30de2dff5d62b4	65bf0807ab1814252bdeca934be5c3436987640c2c437e0bf500b31b6f5c28f2
117	2026-08-19 15:56:33	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	65bf0807ab1814252bdeca934be5c3436987640c2c437e0bf500b31b6f5c28f2	1d0423ef5e4810d29ab783de51a30e5fffd618adb26f120f9a14fe0068bf8dd4
118	2026-08-19 15:56:33	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	1d0423ef5e4810d29ab783de51a30e5fffd618adb26f120f9a14fe0068bf8dd4	313728c95e79949e1b850d4270f6ec511c3f11f5077e0cf1f91334b8496dccb5
119	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	313728c95e79949e1b850d4270f6ec511c3f11f5077e0cf1f91334b8496dccb5	bff8f1e0f1eccf7d8c19fec2ef1cb4c715a65eb93dadc1db6eb40b612005325e
120	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	bff8f1e0f1eccf7d8c19fec2ef1cb4c715a65eb93dadc1db6eb40b612005325e	effa04d94df62b817cac95b3f139dcc1925dc115313ded9f1f248e4b10507897
121	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	effa04d94df62b817cac95b3f139dcc1925dc115313ded9f1f248e4b10507897	d37d7bdf3d9148318c492ec3e1e25d75a36e04ad82ab90bad59e8e2831d9f381
122	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	d37d7bdf3d9148318c492ec3e1e25d75a36e04ad82ab90bad59e8e2831d9f381	a5bee70c94e8ed01718cec39da20ec4e692c6f6843cd24a927b5e9234c06c998
123	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	a5bee70c94e8ed01718cec39da20ec4e692c6f6843cd24a927b5e9234c06c998	80c03968be1e4b75ecb769af7074a3f7b68f60ce66971780869ed98c79697d71
124	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	80c03968be1e4b75ecb769af7074a3f7b68f60ce66971780869ed98c79697d71	2d63eeaa42af863260ae7c0d9ce3ebeddcd37805acb0bc9c6f41259ac6c7c492
125	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	2d63eeaa42af863260ae7c0d9ce3ebeddcd37805acb0bc9c6f41259ac6c7c492	bac832e19f9174bb165adb6f04fba1742230d6c97a06249482983f5b751569b5
126	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	bac832e19f9174bb165adb6f04fba1742230d6c97a06249482983f5b751569b5	38a1fa050b997088e4880c0418193e1262dfbd617a79144b656943593f1b91f8
127	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	38a1fa050b997088e4880c0418193e1262dfbd617a79144b656943593f1b91f8	879a272973c805534656e8da9670bfe8b00605e79b1cb3f86e4c356515ca0530
128	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	879a272973c805534656e8da9670bfe8b00605e79b1cb3f86e4c356515ca0530	670fe2f6a205d808ae19ac2028da3947657322053dc2f70e0853883a90529d9b
129	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	670fe2f6a205d808ae19ac2028da3947657322053dc2f70e0853883a90529d9b	f88207abfca2c537d5a50660836927750556ae3c2e1d4df8b18d2f9e51c76ccd
130	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	f88207abfca2c537d5a50660836927750556ae3c2e1d4df8b18d2f9e51c76ccd	76cf25b5ad3bac1978b195f128501806a1a35f63ef0d1b65a08edc6b66abf7c2
131	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-01"}	76cf25b5ad3bac1978b195f128501806a1a35f63ef0d1b65a08edc6b66abf7c2	6f95fb98241a9176d48f5e8023cbfffe4e2e273f54277955f5a35396085bad00
132	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	6f95fb98241a9176d48f5e8023cbfffe4e2e273f54277955f5a35396085bad00	4bfbbdd3896d84af78843a445bf131e1050649805478fa9faf2f48360889f82a
133	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-02"}	4bfbbdd3896d84af78843a445bf131e1050649805478fa9faf2f48360889f82a	2c5295b60317d91236801ced47a58cf07071ff876afd0e419696095fcb7e298e
134	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	2c5295b60317d91236801ced47a58cf07071ff876afd0e419696095fcb7e298e	5a65ae7dfabffce2a7d998b3fef0780d6a4bf8de5c385ae75ca55f93daad4e82
135	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-03"}	5a65ae7dfabffce2a7d998b3fef0780d6a4bf8de5c385ae75ca55f93daad4e82	a51677366da3eb083ac0e971c44b258e7c8b67e5cf960127aa3c8790a78558a4
136	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	a51677366da3eb083ac0e971c44b258e7c8b67e5cf960127aa3c8790a78558a4	345dddb32f6d3a5b7f2b2d947999cb0b10c0e54e1d402234433839d8b657401e
137	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-03"}	345dddb32f6d3a5b7f2b2d947999cb0b10c0e54e1d402234433839d8b657401e	3dda2c33abeec76022a09d155f0d283cad2691456bee61c786fac71dec59eb4d
138	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-03"}	3dda2c33abeec76022a09d155f0d283cad2691456bee61c786fac71dec59eb4d	de65e5ede4698984a7da3f67cc0b0661dd61e87218709ef5cbbe41a61d15e00f
139	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	de65e5ede4698984a7da3f67cc0b0661dd61e87218709ef5cbbe41a61d15e00f	481e5c4aa3839528e27f842359da236e7baf2fce8a659c09911106840e40c16c
140	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-04"}	481e5c4aa3839528e27f842359da236e7baf2fce8a659c09911106840e40c16c	3348d7723bb02c80e72fc95b9cad8fe3a2fe6b6677d48d2a3981d6503e73bac3
141	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-04"}	3348d7723bb02c80e72fc95b9cad8fe3a2fe6b6677d48d2a3981d6503e73bac3	016d85ef34054ebad9971ea9fbb2e49d59e9d83640539c302843599137d9d5ba
142	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	016d85ef34054ebad9971ea9fbb2e49d59e9d83640539c302843599137d9d5ba	196b4e45eada7693cf7a707a09ffd8864e0217594af652b0276402a9f1ebb484
143	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-06"}	196b4e45eada7693cf7a707a09ffd8864e0217594af652b0276402a9f1ebb484	f3b34142266fc6219848a87e052bc93d0e64dabc1b91e76804bbe06df1859949
144	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-08"}	f3b34142266fc6219848a87e052bc93d0e64dabc1b91e76804bbe06df1859949	4247563b53cdd288bdaf6e4f59ff2579e76e8e3434528221bce5907687123384
145	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-SSD-01", "quantity": 90, "date": "2026-08-09"}	4247563b53cdd288bdaf6e4f59ff2579e76e8e3434528221bce5907687123384	d1cd9e2930b2cfd1e6e6aff81f1aacaa5bce86fbc1bd9525b4033a5594583ef1
146	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	d1cd9e2930b2cfd1e6e6aff81f1aacaa5bce86fbc1bd9525b4033a5594583ef1	0ec7aa82fa1cb0b60cbf74c739797099c9fc440d912855df8dfb4464d35efb9a
147	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-10"}	0ec7aa82fa1cb0b60cbf74c739797099c9fc440d912855df8dfb4464d35efb9a	621f70c3354896b065373f5fea57ffa5c811f017e8829c9389aaf7202275b9bd
148	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-10"}	621f70c3354896b065373f5fea57ffa5c811f017e8829c9389aaf7202275b9bd	505623687f6fbef1f49418e314145154eff48a08336dc57d8e96f45281b51454
149	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-10"}	505623687f6fbef1f49418e314145154eff48a08336dc57d8e96f45281b51454	ab2060da46bde08709e10344dd7dc1e7b537ecb0508ad649386a5c67e2e4c710
150	2026-08-19 15:56:33	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	ab2060da46bde08709e10344dd7dc1e7b537ecb0508ad649386a5c67e2e4c710	359649b45d9bf0c63a50bae8c12c754d2ff6733d995e6d426027e41e4ea94dfb
151	2026-08-19 15:56:33	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	359649b45d9bf0c63a50bae8c12c754d2ff6733d995e6d426027e41e4ea94dfb	efe3bd06654aed438c22014787fdc156c25a8330ee71dd29819cffe811415dce
152	2026-08-19 15:56:33	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	efe3bd06654aed438c22014787fdc156c25a8330ee71dd29819cffe811415dce	083b4204f5c6ce075c17c426c33f5c7da2c1d796aae0edd4b7fcb5d69fca2754
153	2026-08-19 15:56:47	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T15:56:47.542665"}	083b4204f5c6ce075c17c426c33f5c7da2c1d796aae0edd4b7fcb5d69fca2754	aaa4e2dcfcb29d3ddf6fb8601fa8cb1e732633003e741762a0ad2d79878c71ef
154	2026-08-19 15:56:47	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "1", "source_entity_type": "USER", "recipients_count": 3}	aaa4e2dcfcb29d3ddf6fb8601fa8cb1e732633003e741762a0ad2d79878c71ef	f2086c407432a4ef70e533b7caee566f72f4af4b3dcf16f2123fd2eec4699573
155	2026-08-19 16:12:43	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	f2086c407432a4ef70e533b7caee566f72f4af4b3dcf16f2123fd2eec4699573	79978821620c3d17138880badfd547ad8de6cd61d854522fd664b8288d1bf060
156	2026-08-19 16:12:43	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	79978821620c3d17138880badfd547ad8de6cd61d854522fd664b8288d1bf060	fc0558f5628e892c0f2aa9cfd718e6f6187a716047ed32bc9f9436bced7c7311
157	2026-08-19 16:12:43	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	fc0558f5628e892c0f2aa9cfd718e6f6187a716047ed32bc9f9436bced7c7311	ec2a47e69357318433e030c2f54d587a54b3db233c0580df5fde197d276b8f95
158	2026-08-19 16:12:43	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	ec2a47e69357318433e030c2f54d587a54b3db233c0580df5fde197d276b8f95	d5fcd5eb272cede56c2085cbb86a0d7a43fad49cc8c3d28ac8314f2933cf21d1
159	2026-08-19 16:12:43	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	d5fcd5eb272cede56c2085cbb86a0d7a43fad49cc8c3d28ac8314f2933cf21d1	5c2b6f73977c74753bf11ae7a83178177cdffcc903dbad8f8cb0c1e7e4eebc35
160	2026-08-19 16:12:43	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	5c2b6f73977c74753bf11ae7a83178177cdffcc903dbad8f8cb0c1e7e4eebc35	2209ca62419caed5f193960c0e06c5ea8ad2919134f45bde4636c80d84c4cd73
161	2026-08-19 16:12:43	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	2209ca62419caed5f193960c0e06c5ea8ad2919134f45bde4636c80d84c4cd73	37b3c144e13c1321973dc114ed3677e17eed58f3bdf77298bbc38101c40ec736
162	2026-08-19 16:12:43	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	37b3c144e13c1321973dc114ed3677e17eed58f3bdf77298bbc38101c40ec736	46c20c23f8af2017dc516e437615f7f72e293c8f6ead8570f5fbd697aa1bde36
163	2026-08-19 16:12:43	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	46c20c23f8af2017dc516e437615f7f72e293c8f6ead8570f5fbd697aa1bde36	0f37cdff1957c0c83f8b0b61640f2d0ff7c6d80f5a59df0c1cddb2dbd450a543
164	2026-08-19 16:12:43	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	0f37cdff1957c0c83f8b0b61640f2d0ff7c6d80f5a59df0c1cddb2dbd450a543	9ba3d8d902c1819d05333e918bedfa09e81013410a67b5de23f1e55d6556940b
165	2026-08-19 16:12:43	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	9ba3d8d902c1819d05333e918bedfa09e81013410a67b5de23f1e55d6556940b	cc57de1e859b4d04aa7cf53a7eadb67887a8cfee42cc281330b81e89573255f7
166	2026-08-19 16:12:43	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	cc57de1e859b4d04aa7cf53a7eadb67887a8cfee42cc281330b81e89573255f7	42f3b871f40118456fad2a13b1a53422ce0bdfb387222cb97bd9529a9c68e55c
167	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-18"}	42f3b871f40118456fad2a13b1a53422ce0bdfb387222cb97bd9529a9c68e55c	b2d35ecac5d171ce2e3e473eee4aa15aa166eceee9c7f79cbf003044a1bc8c84
168	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	b2d35ecac5d171ce2e3e473eee4aa15aa166eceee9c7f79cbf003044a1bc8c84	577909e4491728cdc729bee16c4af62f8ab602cd162eb4b12ac3f8c6a8bff315
169	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	577909e4491728cdc729bee16c4af62f8ab602cd162eb4b12ac3f8c6a8bff315	3422ae8d73d96d1502edb895604c54756a7998cd760972a6e37c1238e1e6fd00
170	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	3422ae8d73d96d1502edb895604c54756a7998cd760972a6e37c1238e1e6fd00	81f4d5e2d82e49a10f3a3aee2caf69c3e77b03ad77d7e15d24ccc593a2fb9064
171	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-23"}	81f4d5e2d82e49a10f3a3aee2caf69c3e77b03ad77d7e15d24ccc593a2fb9064	a82a13e8b812c04f35d6862fff7d56745eed39ad7a7ba79d4b371d20159eefd0
172	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	a82a13e8b812c04f35d6862fff7d56745eed39ad7a7ba79d4b371d20159eefd0	86d88a0bef8074c843da9016593eb2c67f875726a1bab9f118e71ce1dd199eff
173	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	86d88a0bef8074c843da9016593eb2c67f875726a1bab9f118e71ce1dd199eff	07eb50e761b8317c08e412a9baaac0e51948a0ecbef6d61419ea82e0d9b333e1
174	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	07eb50e761b8317c08e412a9baaac0e51948a0ecbef6d61419ea82e0d9b333e1	8455394ebff82328ab58f77dc4e7977ae9879a5ccc6583cc46187f28644fe646
175	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	8455394ebff82328ab58f77dc4e7977ae9879a5ccc6583cc46187f28644fe646	3ab05a28ad4e978600536a0254416a4f5d9cf8429abb35ffc92340d1d4bf5e2f
176	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	3ab05a28ad4e978600536a0254416a4f5d9cf8429abb35ffc92340d1d4bf5e2f	59a972bce3b48ecaffb39f8a971fd3de3921fc42695c35fd61b327de8c424e85
177	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-29"}	59a972bce3b48ecaffb39f8a971fd3de3921fc42695c35fd61b327de8c424e85	866c9382397c49cab3336f28397ff0881ddc759368b9ed8603b4fb47928959b2
178	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-30"}	866c9382397c49cab3336f28397ff0881ddc759368b9ed8603b4fb47928959b2	5177bb0d44916ee511fcb07189eea41c75f442bf0ffb56ceaade1cfbed11b189
179	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-01"}	5177bb0d44916ee511fcb07189eea41c75f442bf0ffb56ceaade1cfbed11b189	61cf8aabd2ba4db21238e7816e014394192739fdf9859311b8287591b5232e96
180	2026-08-19 16:12:43	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-08-01"}	61cf8aabd2ba4db21238e7816e014394192739fdf9859311b8287591b5232e96	6e206d2e8614e14760478cf7ce887a8932a90f77d1e721ea957950099d3efc07
181	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-01"}	6e206d2e8614e14760478cf7ce887a8932a90f77d1e721ea957950099d3efc07	088671ef22b3ad2d903ed83ce97b51d0ef21dbf0bf0ae19160a5c7d8b8472245
182	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-02"}	088671ef22b3ad2d903ed83ce97b51d0ef21dbf0bf0ae19160a5c7d8b8472245	04e1b4c0275613c33fa5e1ecffc66dda2f845208ce67e82fd4cac6c163ff285e
183	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	04e1b4c0275613c33fa5e1ecffc66dda2f845208ce67e82fd4cac6c163ff285e	7154fb254606042243eacf34b87bdb92124f20eb671080f858db442d3a87b408
184	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	7154fb254606042243eacf34b87bdb92124f20eb671080f858db442d3a87b408	fc3c86f2ef29fc2213a5819d157df928dbef4593478c50fc7394269a1b12e5f8
185	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-04"}	fc3c86f2ef29fc2213a5819d157df928dbef4593478c50fc7394269a1b12e5f8	99ce48f6fc8c2790d525a53b99e113ce49f0fe9ea22f0bf92bd7366fc38385b5
186	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	99ce48f6fc8c2790d525a53b99e113ce49f0fe9ea22f0bf92bd7366fc38385b5	9c2735c1d36e269df9638ce28d296e2acd623e8caf08e076d50203165b7bb9d9
187	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-06"}	9c2735c1d36e269df9638ce28d296e2acd623e8caf08e076d50203165b7bb9d9	158a9a6b6529cae1dbfbbf3bbc7ecfc4558910a5f54351825c3a131887769457
188	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-06"}	158a9a6b6529cae1dbfbbf3bbc7ecfc4558910a5f54351825c3a131887769457	75284fc60e0fd897a9be1cfa254f86445fd8aef6f874c3e6a3d3b7358fefb46e
189	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-07"}	75284fc60e0fd897a9be1cfa254f86445fd8aef6f874c3e6a3d3b7358fefb46e	c3562a8c17d3cef66a4f4bdebfdc7f95898f790dd530c68e6bbf0fb83034e96b
190	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-07"}	c3562a8c17d3cef66a4f4bdebfdc7f95898f790dd530c68e6bbf0fb83034e96b	b8c94934f0510ac7fd13671f29d28395b45b8bf60e8219ec793d534e8efcea3d
191	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	b8c94934f0510ac7fd13671f29d28395b45b8bf60e8219ec793d534e8efcea3d	c3986f12bbf560ac476c64035405be7dc574016ba2521a9f1347708c0e0ff7a3
192	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-09"}	c3986f12bbf560ac476c64035405be7dc574016ba2521a9f1347708c0e0ff7a3	9c4d1dc095d6058007bf877a96e93958ac9c5aaf895be243099a76cf47b0f77d
193	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-09"}	9c4d1dc095d6058007bf877a96e93958ac9c5aaf895be243099a76cf47b0f77d	c10fc5a254db7a1ed0e781e4b070767e92da5c8914a099eef1acd9608c789b50
194	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-09"}	c10fc5a254db7a1ed0e781e4b070767e92da5c8914a099eef1acd9608c789b50	ecd2e2b86547acd0048d50a3a7ef2074a7cd792a5b4229167eba08311a8514d9
195	2026-08-19 16:12:44	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-11"}	ecd2e2b86547acd0048d50a3a7ef2074a7cd792a5b4229167eba08311a8514d9	81cc75b019be414bf0979e37b9c2ec90b81ae06179820a2b968dcb02f83fb06b
196	2026-08-19 16:12:44	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	81cc75b019be414bf0979e37b9c2ec90b81ae06179820a2b968dcb02f83fb06b	6fa1e1ae5e2966b1f9a0a41dc68017e0b150912c855b4084169cd2e0cfcf4d5c
197	2026-08-19 16:12:44	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	6fa1e1ae5e2966b1f9a0a41dc68017e0b150912c855b4084169cd2e0cfcf4d5c	a920153fb26062534a66b5dd73f269b594f37ed657f55e18a74d7f5a3403d1a5
198	2026-08-19 16:13:00	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T16:13:00.687456"}	a920153fb26062534a66b5dd73f269b594f37ed657f55e18a74d7f5a3403d1a5	98da5ff963092b51a7e629f6b45239ce1f784cbbe5586c90805815b62a8af403
199	2026-08-19 16:13:00	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "1", "source_entity_type": "USER", "recipients_count": 3}	98da5ff963092b51a7e629f6b45239ce1f784cbbe5586c90805815b62a8af403	0ad05845190995a7f35e87500db665eb3d71119211b790e37bfd7a0dbb4bbc45
200	2026-08-19 16:13:20	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T16:13:20.247682"}	0ad05845190995a7f35e87500db665eb3d71119211b790e37bfd7a0dbb4bbc45	663b14322d911300eeab42602e7d5e82268b7b72e75d3049fd316959634f7719
201	2026-08-19 16:13:20	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "1", "source_entity_type": "USER", "recipients_count": 3}	663b14322d911300eeab42602e7d5e82268b7b72e75d3049fd316959634f7719	73f1623c27e979cc525025ec1aac7dc4298428bad688a70439f784d4de4603d9
202	2026-08-19 16:13:22	AI_ASSISTANT_QUERY	{"user": "admin", "query": "Show me the robot fleet status", "warehouse_id": "WH-BLR-01"}	73f1623c27e979cc525025ec1aac7dc4298428bad688a70439f784d4de4603d9	79cb6da566608f7ca0ca7a1cbf2a582b7b16bfc2b5b6ba9ba5dd74d4570305e9
203	2026-08-19 16:13:25	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T16:13:25.682049"}	79cb6da566608f7ca0ca7a1cbf2a582b7b16bfc2b5b6ba9ba5dd74d4570305e9	c90d2b30b8a80d6278ddaa341b9d2343d726e161186aa1d4222e0ae548848306
204	2026-08-19 16:13:25	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "1", "source_entity_type": "USER", "recipients_count": 3}	c90d2b30b8a80d6278ddaa341b9d2343d726e161186aa1d4222e0ae548848306	504f2173c1e26b42f224bad3d711844ee273abc8409bc8e552371deef6d6283b
205	2026-08-19 16:19:14	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	504f2173c1e26b42f224bad3d711844ee273abc8409bc8e552371deef6d6283b	aff966387bd03162359f29293e99dc15a7133b6426adaf79317a1b93610a77df
206	2026-08-19 16:19:14	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	aff966387bd03162359f29293e99dc15a7133b6426adaf79317a1b93610a77df	257c9f61c11626411d10ac11de53cbd9dea68d5f0c9c310941b1d938294ebb42
207	2026-08-19 16:19:14	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	257c9f61c11626411d10ac11de53cbd9dea68d5f0c9c310941b1d938294ebb42	ede4ddafa1c074e8b262d7876d4ca08bca6befc49ee0d7590365ffe41c7013d3
208	2026-08-19 16:19:14	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	ede4ddafa1c074e8b262d7876d4ca08bca6befc49ee0d7590365ffe41c7013d3	5f6cc4f0f603dfb1425d26c56bcd77b46faea8825963a2c42b44822b9f58d605
209	2026-08-19 16:19:14	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	5f6cc4f0f603dfb1425d26c56bcd77b46faea8825963a2c42b44822b9f58d605	5c9db8732d5cdbb8d33e04d30d1a9b6af7268347b2b3816c22280489b6539a9e
210	2026-08-19 16:19:14	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	5c9db8732d5cdbb8d33e04d30d1a9b6af7268347b2b3816c22280489b6539a9e	ada7450bbbdc7e11bc4035877c8d72ab8a6f0b9f76023239e54100f2187a413e
211	2026-08-19 16:19:14	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	ada7450bbbdc7e11bc4035877c8d72ab8a6f0b9f76023239e54100f2187a413e	5259bbe8d6bd48f0e833e79418bc71a358e8bc50ce4cacfb3efae9b3d4a83343
212	2026-08-19 16:19:14	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	5259bbe8d6bd48f0e833e79418bc71a358e8bc50ce4cacfb3efae9b3d4a83343	dec95f1c1db856d687d2f1a1e31cac2ea64a0cc5596b4eafb4d7534e303e2455
213	2026-08-19 16:19:14	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	dec95f1c1db856d687d2f1a1e31cac2ea64a0cc5596b4eafb4d7534e303e2455	b16a7f7788f49b366fb0f0a619252472e08945e228c0f7508e1e0d97ce10d92f
214	2026-08-19 16:19:14	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	b16a7f7788f49b366fb0f0a619252472e08945e228c0f7508e1e0d97ce10d92f	ca6d45c34ccad3e6dea257496bc3abb4649a567889b3170930de8f8d3c79bc21
215	2026-08-19 16:19:14	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	ca6d45c34ccad3e6dea257496bc3abb4649a567889b3170930de8f8d3c79bc21	6a2bcabdf0f5520d3ea3f889108d46f1d39e4b4b1c178bf0536924a4820b4427
216	2026-08-19 16:19:14	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	6a2bcabdf0f5520d3ea3f889108d46f1d39e4b4b1c178bf0536924a4820b4427	efbadc519ddf58312c48868acd94017e308cc6df876d6382321014de31af1e48
217	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	efbadc519ddf58312c48868acd94017e308cc6df876d6382321014de31af1e48	74c43f8e4b7352f913a5b74fe7484684ce02ffb98f5c8a752966190cf8290596
218	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	74c43f8e4b7352f913a5b74fe7484684ce02ffb98f5c8a752966190cf8290596	2ffa769c27fb93b979db18f585faad3bfb822433e53b07b9937b78fd1ca4417a
219	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	2ffa769c27fb93b979db18f585faad3bfb822433e53b07b9937b78fd1ca4417a	04f02717f82f39c3feeeac769c164b0af6d7377b948ae196534dce96c2b157be
220	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	04f02717f82f39c3feeeac769c164b0af6d7377b948ae196534dce96c2b157be	f40d97018ec827b8d762b0e32e180f80d302a3de42a52b09093553364d91fe71
221	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	f40d97018ec827b8d762b0e32e180f80d302a3de42a52b09093553364d91fe71	c0f1fdcc57d95f20fd1f0ef692775be77e41b2d3fd5f249a0d21a15ef6cdad96
222	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-25"}	c0f1fdcc57d95f20fd1f0ef692775be77e41b2d3fd5f249a0d21a15ef6cdad96	ef76787abac39b885ba5d6633148e1aa378bfb900abfc5c107ba42cad79233fd
223	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	ef76787abac39b885ba5d6633148e1aa378bfb900abfc5c107ba42cad79233fd	e6a4574aa44dca9584f67b7ae7ba857db98b9ebdc89251f53c6199fb12efc147
224	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	e6a4574aa44dca9584f67b7ae7ba857db98b9ebdc89251f53c6199fb12efc147	7fb9cd23ddb8d47d187250446c8fd7f614098e5525c28207c4b09143cd71946f
225	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	7fb9cd23ddb8d47d187250446c8fd7f614098e5525c28207c4b09143cd71946f	0787272305e0dc97468ed91b4e9eacee05dd0a2bae9b6e67f40fde50e9659b00
226	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	0787272305e0dc97468ed91b4e9eacee05dd0a2bae9b6e67f40fde50e9659b00	b103bb87ae05dce13899ec8ef56c210d162a34b4b7b5fbe95f99eaec1d002e7c
227	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-28"}	b103bb87ae05dce13899ec8ef56c210d162a34b4b7b5fbe95f99eaec1d002e7c	89d424d99c01f499e7123b4f0d28fc980c91ddcb70d291ddea4f6a658783991b
228	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-31"}	89d424d99c01f499e7123b4f0d28fc980c91ddcb70d291ddea4f6a658783991b	726264fe1ebe96e3e35d2842120219e3b5b8c1dcdbbd65d0fe60b19d810b1f47
229	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-31"}	726264fe1ebe96e3e35d2842120219e3b5b8c1dcdbbd65d0fe60b19d810b1f47	34352b6022c5aa5048460bdbdf6c19c52561cb7c4bddfcc2173c81af7c0665a7
230	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-31"}	34352b6022c5aa5048460bdbdf6c19c52561cb7c4bddfcc2173c81af7c0665a7	dd7eb3d94be516cd8acf8f2bd7a0a72e21271fff4720c4b833956df6f99f0c32
231	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-01"}	dd7eb3d94be516cd8acf8f2bd7a0a72e21271fff4720c4b833956df6f99f0c32	b18957fe680d95b599b1994ac84dbf1577301c5791bdb047b7f996f17c485b83
232	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-01"}	b18957fe680d95b599b1994ac84dbf1577301c5791bdb047b7f996f17c485b83	0ff5432cd7a7b3568d8657f0be71baaafc248c9986929d75249997695ffa2774
233	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-01"}	0ff5432cd7a7b3568d8657f0be71baaafc248c9986929d75249997695ffa2774	fce338859d8857624202460131899265b0993b41fdccf07bedac0c1c77ef674f
234	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-02"}	fce338859d8857624202460131899265b0993b41fdccf07bedac0c1c77ef674f	e947f07b132ee8aac61930a847a802fb9e3a651b273a66f93d3ce06643eb20ef
235	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	e947f07b132ee8aac61930a847a802fb9e3a651b273a66f93d3ce06643eb20ef	0e176c0f87d49e21a607a26b5bdd6bf82d641c794d116d72be77084cc07fd561
236	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-04"}	0e176c0f87d49e21a607a26b5bdd6bf82d641c794d116d72be77084cc07fd561	2a1303756141add076c081ed2eabe228abfa7a01fa352e33002daa73ea7f13d0
237	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-04"}	2a1303756141add076c081ed2eabe228abfa7a01fa352e33002daa73ea7f13d0	067dd0f07c37a5a3df145d803d7dfd0c55bcd67c73b05b288f3cd90382661be1
238	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-04"}	067dd0f07c37a5a3df145d803d7dfd0c55bcd67c73b05b288f3cd90382661be1	b25df998f1966349da893739f529bc56a85d1a895271584f0597fb17c43dd0c7
239	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-05"}	b25df998f1966349da893739f529bc56a85d1a895271584f0597fb17c43dd0c7	312a6b0749f7a470845220ee93dcb09c0c3b98e6e83c899b3ee6c5969e66b2a3
240	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	312a6b0749f7a470845220ee93dcb09c0c3b98e6e83c899b3ee6c5969e66b2a3	9374adca0a990c3fbf3b75f0060f85fcdfd529227196aa103c9cdb191a4718c1
241	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-06"}	9374adca0a990c3fbf3b75f0060f85fcdfd529227196aa103c9cdb191a4718c1	008a27b08edbf88f85ee1878e548e4ee629c36e185213426d2e5e20e2b44617f
242	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-06"}	008a27b08edbf88f85ee1878e548e4ee629c36e185213426d2e5e20e2b44617f	622ad24cb3b19c20fc3707fc2dfa6046d80f21c3c6f6cb5c3a64cf4a1639c7ff
243	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-07"}	622ad24cb3b19c20fc3707fc2dfa6046d80f21c3c6f6cb5c3a64cf4a1639c7ff	d8c1d434fd3b36aebc7b3412fff17333c7d45cfce94009dbbc53628aec907a7b
244	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-08"}	d8c1d434fd3b36aebc7b3412fff17333c7d45cfce94009dbbc53628aec907a7b	1b95812f1a4593dc33f602fbdb7ffc859f11ce2aded95a4c20814bcb1ed48b97
245	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-08"}	1b95812f1a4593dc33f602fbdb7ffc859f11ce2aded95a4c20814bcb1ed48b97	ae3b5d8cffbd5e1027cf6054db346fb86f1be4bf3a510456b63bbb93bf802ff9
246	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-09"}	ae3b5d8cffbd5e1027cf6054db346fb86f1be4bf3a510456b63bbb93bf802ff9	2edea224c7ada2227200a0d879e86ef713c7d6cdfd238d80ab6980f3f9958a32
247	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	2edea224c7ada2227200a0d879e86ef713c7d6cdfd238d80ab6980f3f9958a32	2193f316a1554c05e38d29d416a2bdc11de541dfd8adbbcd8579a63559d2b5a3
248	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-10"}	2193f316a1554c05e38d29d416a2bdc11de541dfd8adbbcd8579a63559d2b5a3	ddaf534a07c17c909a1415748bf3b78fa09221f3aba1d9a6dc9cda626bf35167
249	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	ddaf534a07c17c909a1415748bf3b78fa09221f3aba1d9a6dc9cda626bf35167	3b54c5f2d50d7eab0e486edd31303fa14bc8069d39315e6a5803111485ba481c
250	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	3b54c5f2d50d7eab0e486edd31303fa14bc8069d39315e6a5803111485ba481c	ed1c5b06d5ecc838b5402de05ba25bb940cbdce81cabe919d4d3b224734f14aa
251	2026-08-19 16:19:14	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	ed1c5b06d5ecc838b5402de05ba25bb940cbdce81cabe919d4d3b224734f14aa	aa6e20a7df0cf1f140b62d6556127aba2c29042ce3db3dc0fd894fc0efa17dce
252	2026-08-19 16:19:14	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	aa6e20a7df0cf1f140b62d6556127aba2c29042ce3db3dc0fd894fc0efa17dce	fb04d52fbd5463645e9e1b19672df2496a20d04bbc73ce371fbbe95e1a0f57b6
253	2026-08-19 16:19:14	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	fb04d52fbd5463645e9e1b19672df2496a20d04bbc73ce371fbbe95e1a0f57b6	a41b458ccb1066c95bfe2cefb10318140de19716bbda4be3c09b743a682a194b
254	2026-08-19 16:19:21	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T16:19:21.708926"}	a41b458ccb1066c95bfe2cefb10318140de19716bbda4be3c09b743a682a194b	9f0dffbd1e5107de933f3de892d54a9bdbb7f64fc4e145be41714812e04610e1
255	2026-08-19 16:19:21	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "1", "source_entity_type": "USER", "recipients_count": 3}	9f0dffbd1e5107de933f3de892d54a9bdbb7f64fc4e145be41714812e04610e1	390bbafb2fcc64e83941c70e47e8cb932d112a6473dc66626a14a31afee23e52
\.


--
-- Data for Name: backup_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_records (id, backup_id, filename, created_at, size_bytes, sha256, status, storage_key, error_message, backup_type, started_at, completed_at, storage_provider, bucket, checksum_algorithm, verification_status, verification_at, restore_test_status, restore_test_at, retention_status, initiated_by, audit_ref) FROM stdin;
1	BK-DE66910CF7A81BD9	warehouse_postgres_2026-08-19_16-23-49.sql.gz	2026-08-19 16:23:49.107895	\N	\N	RUNNING	\N	\N	MANUAL	2026-08-19 16:23:49.097906	\N	Backblaze B2 Storage	harsha-warehouse-backups	SHA-256	PENDING	\N	PENDING	\N	ACTIVE	SYSTEM	\N
\.


--
-- Data for Name: digital_twin_simulations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.digital_twin_simulations (id, warehouse_id, simulation_status, simulation_time_seconds, speed_multiplier, seed, mode, scenario_type, tick_count, created_at, started_at, paused_at, stopped_at, completed_at, error_message, created_by) FROM stdin;
\.


--
-- Data for Name: experiment_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.experiment_runs (id, experiment_id, repetition_number, random_seed, status, started_at, completed_at, duration_seconds, error_message, metrics, created_at) FROM stdin;
\.


--
-- Data for Name: experiments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.experiments (id, scenario_id, experiment_name, description, status, algorithm_name, algorithm_version, configuration, random_seed, repetitions, started_at, completed_at, duration_seconds, created_by, error_message, metrics_summary, created_at) FROM stdin;
\.


--
-- Data for Name: health_thresholds; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health_thresholds (id, key, value, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (id, warehouse_id, item_id, location_id, on_hand, reserved, available, damaged, created_at, updated_at) FROM stdin;
141	WH-BLR-01	ITM-CPU-01	WH-WH-BLR-01-LOC-ITM-CPU-01-STORAGE	61	0	61	0	2026-08-19 16:19:14.892978	2026-08-19 16:19:14.892978
142	WH-BLR-01	ITM-GPU-01	WH-WH-BLR-01-LOC-ITM-GPU-01-STORAGE	29	0	29	0	2026-08-19 16:19:14.892978	2026-08-19 16:19:14.892978
143	WH-BLR-01	ITM-RAM-01	WH-WH-BLR-01-LOC-ITM-RAM-01-STORAGE	60	0	60	0	2026-08-19 16:19:14.892978	2026-08-19 16:19:14.892978
144	WH-BLR-01	ITM-SSD-01	WH-WH-BLR-01-LOC-ITM-SSD-01-STORAGE	64	0	64	0	2026-08-19 16:19:14.892978	2026-08-19 16:19:14.892978
145	WH-BLR-01	ITM-HDD-01	WH-WH-BLR-01-LOC-ITM-HDD-01-STORAGE	86	0	86	0	2026-08-19 16:19:14.892978	2026-08-19 16:19:14.892978
146	WH-BLR-01	ITM-CHG-01	WH-WH-BLR-01-LOC-ITM-CHG-01-STORAGE	135	0	135	0	2026-08-19 16:19:14.892978	2026-08-19 16:19:14.892978
147	WH-BLR-01	ITM-CBL-01	WH-WH-BLR-01-LOC-ITM-CBL-01-STORAGE	439	0	439	0	2026-08-19 16:19:14.892978	2026-08-19 16:19:14.892978
148	WH-CHN-01	ITM-CPU-01	WH-WH-CHN-01-LOC-ITM-CPU-01-STORAGE	62	0	62	0	2026-08-19 16:19:14.892978	2026-08-19 16:19:14.892978
149	WH-CHN-01	ITM-GPU-01	WH-WH-CHN-01-LOC-ITM-GPU-01-STORAGE	17	0	17	0	2026-08-19 16:19:14.892978	2026-08-19 16:19:14.892978
150	WH-CHN-01	ITM-RAM-01	WH-WH-CHN-01-LOC-ITM-RAM-01-STORAGE	62	0	62	0	2026-08-19 16:19:14.892978	2026-08-19 16:19:14.893973
151	WH-CHN-01	ITM-SSD-01	WH-WH-CHN-01-LOC-ITM-SSD-01-STORAGE	61	0	61	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
152	WH-CHN-01	ITM-HDD-01	WH-WH-CHN-01-LOC-ITM-HDD-01-STORAGE	80	0	80	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
153	WH-CHN-01	ITM-CHG-01	WH-WH-CHN-01-LOC-ITM-CHG-01-STORAGE	124	0	124	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
154	WH-CHN-01	ITM-CBL-01	WH-WH-CHN-01-LOC-ITM-CBL-01-STORAGE	439	0	439	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
155	WH-BOM-01	ITM-CPU-01	WH-WH-BOM-01-LOC-ITM-CPU-01-STORAGE	55	0	55	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
156	WH-BOM-01	ITM-GPU-01	WH-WH-BOM-01-LOC-ITM-GPU-01-STORAGE	42	0	42	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
157	WH-BOM-01	ITM-RAM-01	WH-WH-BOM-01-LOC-ITM-RAM-01-STORAGE	36	0	36	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
158	WH-BOM-01	ITM-SSD-01	WH-WH-BOM-01-LOC-ITM-SSD-01-STORAGE	60	0	60	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
159	WH-BOM-01	ITM-HDD-01	WH-WH-BOM-01-LOC-ITM-HDD-01-STORAGE	82	0	82	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
160	WH-BOM-01	ITM-CHG-01	WH-WH-BOM-01-LOC-ITM-CHG-01-STORAGE	137	0	137	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
161	WH-BOM-01	ITM-CBL-01	WH-WH-BOM-01-LOC-ITM-CBL-01-STORAGE	424	0	424	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
162	WH-DEL-01	ITM-CPU-01	WH-WH-DEL-01-LOC-ITM-CPU-01-STORAGE	58	0	58	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
163	WH-DEL-01	ITM-GPU-01	WH-WH-DEL-01-LOC-ITM-GPU-01-STORAGE	33	0	33	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
164	WH-DEL-01	ITM-RAM-01	WH-WH-DEL-01-LOC-ITM-RAM-01-STORAGE	89	0	89	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
165	WH-DEL-01	ITM-SSD-01	WH-WH-DEL-01-LOC-ITM-SSD-01-STORAGE	69	0	69	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
166	WH-DEL-01	ITM-HDD-01	WH-WH-DEL-01-LOC-ITM-HDD-01-STORAGE	73	0	73	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
167	WH-DEL-01	ITM-CHG-01	WH-WH-DEL-01-LOC-ITM-CHG-01-STORAGE	136	0	136	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
168	WH-DEL-01	ITM-CBL-01	WH-WH-DEL-01-LOC-ITM-CBL-01-STORAGE	444	0	444	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
169	WH-CCU-01	ITM-CPU-01	WH-WH-CCU-01-LOC-ITM-CPU-01-STORAGE	53	0	53	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
170	WH-CCU-01	ITM-GPU-01	WH-WH-CCU-01-LOC-ITM-GPU-01-STORAGE	37	0	37	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
171	WH-CCU-01	ITM-RAM-01	WH-WH-CCU-01-LOC-ITM-RAM-01-STORAGE	41	0	41	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
172	WH-CCU-01	ITM-SSD-01	WH-WH-CCU-01-LOC-ITM-SSD-01-STORAGE	62	0	62	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
173	WH-CCU-01	ITM-HDD-01	WH-WH-CCU-01-LOC-ITM-HDD-01-STORAGE	87	0	87	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
174	WH-CCU-01	ITM-CHG-01	WH-WH-CCU-01-LOC-ITM-CHG-01-STORAGE	152	0	152	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
175	WH-CCU-01	ITM-CBL-01	WH-WH-CCU-01-LOC-ITM-CBL-01-STORAGE	412	0	412	0	2026-08-19 16:19:14.893973	2026-08-19 16:19:14.893973
\.


--
-- Data for Name: inventory_reservations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_reservations (id, order_id, item_id, location_id, reserved_qty, released_qty, created_at) FROM stdin;
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id, name, category, unit_cost, lead_time_days, safety_stock, sku, description, unit, weight_kg, dimensions, barcode, is_active, reorder_threshold, preferred_storage_type, created_at) FROM stdin;
ITM-CPU-01	AMD Ryzen 9 7900X Processor	Electronics	38000	5	15	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 16:19:14.300161
ITM-GPU-01	Nvidia RTX 4080 Founders Edition	Electronics	95000	7	10	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 16:19:14.308573
ITM-RAM-01	Corsair DDR5 32GB 6000MHz RAM	Electronics	8500	4	25	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 16:19:14.314566
ITM-SSD-01	Samsung 990 Pro 2TB NVMe SSD	Storage	12000	3	30	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 16:19:14.320565
ITM-HDD-01	WD Red Pro 8TB NAS Hard Drive	Storage	16500	5	20	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 16:19:14.326568
ITM-CHG-01	Anker 100W GaN Wall Charger	Accessories	2500	2	50	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 16:19:14.333566
ITM-CBL-01	Apple USB-C Braided Cable 2m	Accessories	800	1	100	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 16:19:14.340566
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_preferences (id, user_id, category, in_app_enabled, email_enabled, min_severity, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, warehouse_id, event_type, notification_type, title, message, severity, status, channel, source_entity_type, source_entity_id, created_at, read_at, delivered_at, failed_at, retry_count, expires_at, metadata, idempotency_key) FROM stdin;
1	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 15:43:39.785825	\N	2026-08-19 15:43:39.808816	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_2_1787134419.785825
2	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 15:43:39.785825	\N	2026-08-19 15:43:39.832833	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_5_1787134419.785825
3	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 15:43:39.785825	\N	2026-08-19 15:43:39.856011	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_1_1787134419.785825
4	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_viewer logged in successfully.	INFO	DELIVERED	IN_APP	USER	4	2026-08-19 15:44:20.732712	\N	2026-08-19 15:44:20.760714	\N	0	\N	{"username": "test_viewer", "message": "User test_viewer logged in successfully."}	USER_LOGIN_4_2_1787134460.732712
5	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_viewer logged in successfully.	INFO	DELIVERED	IN_APP	USER	4	2026-08-19 15:44:20.732712	\N	2026-08-19 15:44:20.790715	\N	0	\N	{"username": "test_viewer", "message": "User test_viewer logged in successfully."}	USER_LOGIN_4_5_1787134460.732712
6	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_viewer logged in successfully.	INFO	DELIVERED	IN_APP	USER	4	2026-08-19 15:44:20.732712	\N	2026-08-19 15:44:20.820721	\N	0	\N	{"username": "test_viewer", "message": "User test_viewer logged in successfully."}	USER_LOGIN_4_1_1787134460.732712
7	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 15:56:47.633668	\N	2026-08-19 15:56:47.660216	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_2_1787135207.633668
8	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 15:56:47.633668	\N	2026-08-19 15:56:47.677739	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_5_1787135207.633668
9	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 15:56:47.633668	\N	2026-08-19 15:56:47.69074	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_1_1787135207.633668
10	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 16:13:00.712566	\N	2026-08-19 16:13:00.749099	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_2_1787136180.712566
11	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 16:13:00.712566	\N	2026-08-19 16:13:00.767109	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_5_1787136180.712566
12	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 16:13:00.712566	\N	2026-08-19 16:13:00.791698	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_1_1787136180.712566
13	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 16:19:21.719564	\N	2026-08-19 16:19:21.747653	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_2_1787136561.719564
14	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 16:19:21.719564	\N	2026-08-19 16:19:21.782911	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_5_1787136561.719564
15	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 16:19:21.719564	\N	2026-08-19 16:19:21.79548	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_1_1787136561.719564
\.


--
-- Data for Name: order_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_events (id, order_id, "timestamp", status, event_type, operator, notes) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, order_id, item_id, requested_qty, reserved_qty, picked_qty, packed_qty, shipped_qty, status) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, customer_ref, warehouse_id, created_at, updated_at, status, priority, total_items, notes, created_by) FROM stdin;
\.


--
-- Data for Name: otp_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.otp_records (id, user_id, purpose, code_hash, expires_at, attempts, max_attempts, consumed_at, created_at, request_ip, context_data) FROM stdin;
\.


--
-- Data for Name: packing_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.packing_records (id, order_id, status, started_at, completed_at, operator, package_count, weight_kg, notes) FROM stdin;
\.


--
-- Data for Name: recovery_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recovery_codes (id, user_id, code_hash, used, created_at, used_at) FROM stdin;
\.


--
-- Data for Name: recovery_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recovery_credentials (id, user_id, password_hash, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: robot_reservations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robot_reservations (id, robot_id, warehouse_id, x, y, tick) FROM stdin;
\.


--
-- Data for Name: robot_routes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robot_routes (id, robot_id, task_id, warehouse_id, start_x, start_y, goal_x, goal_y, algorithm, path_data, distance, cost, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: robot_telemetry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robot_telemetry (id, robot_id, event_type, "timestamp", x, y, battery, status, task_id, metadata) FROM stdin;
\.


--
-- Data for Name: robots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robots (id, robot_code, name, warehouse_id, status, battery_level, current_location_id, current_x, current_y, target_location_id, target_x, target_y, assigned_task_id, total_tasks_completed, total_distance, total_operating_time, utilization_percent, failure_count, created_at, updated_at, last_heartbeat_at, robot_type, max_payload, max_speed, enabled, metadata) FROM stdin;
29	RB-BLR-01	Bangalore AGV 01	WH-BLR-01	CHARGING	100	WH-WH-BLR-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	AGV	200	1.5	t	{}
30	RB-BLR-02	Bangalore AGV 02	WH-BLR-01	CHARGING	100	WH-WH-BLR-01-CHARGING-2	12	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	AGV	200	1.5	t	{}
31	RB-BLR-03	Bangalore AGV 03	WH-BLR-01	IDLE	92.5	WH-WH-BLR-01-RECEIVING	1	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	AGV	200	1.5	t	{}
32	RB-CHN-01	Chennai AGV 01	WH-CHN-01	CHARGING	100	WH-WH-CHN-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	AGV	200	1.5	t	{}
33	RB-BOM-01	Mumbai AGV 01	WH-BOM-01	CHARGING	100	WH-WH-BOM-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	AGV	200	1.5	t	{}
34	RB-DEL-01	Delhi AGV 01	WH-DEL-01	CHARGING	100	WH-WH-DEL-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	AGV	200	1.5	t	{}
35	RB-CCU-01	Kolkata AGV 01	WH-CCU-01	CHARGING	100	WH-WH-CCU-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	2026-08-19 16:19:14.910972	AGV	200	1.5	t	{}
\.


--
-- Data for Name: scenarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scenarios (id, name, description, warehouse_id, scenario_type, configuration, random_seed, status, tags, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipments (id, order_id, status, tracking_reference, carrier, created_at, shipped_at, delivered_at) FROM stdin;
\.


--
-- Data for Name: shrinkage_flags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shrinkage_flags (id, date, warehouse_id, item_id, item_name, deviation_score, expected_quantity, actual_quantity, discrepancy_quantity, estimated_exposure, severity, likely_cause, explanation) FROM stdin;
9	2026-08-05	WH-BLR-01	ITM-GPU-01	Nvidia RTX 4080 Founders Edition	0.85	15	5	-10	950000	CRITICAL	UNUSUAL_OUTBOUND_ACTIVITY	Sudden unrecorded drop of 10 units (Valued at ₹9,50,000) occurred outside regular stock-out operations.
10	2026-07-25	WH-CHN-01	ITM-CPU-01	AMD Ryzen 9 7900X Processor	0.72	20	5	-15	570000	HIGH	POSSIBLE_DAMAGE_OR_WASTAGE	Discrepancy of 15 units (Valued at ₹5,70,000) reported at the dock. Unrecorded scraping suspected.
\.


--
-- Data for Name: simulation_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.simulation_events (id, simulation_id, warehouse_id, event_type, severity, sim_time_seconds, real_timestamp, robot_id, task_id, location_id, route_id, message, metadata) FROM stdin;
\.


--
-- Data for Name: simulation_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.simulation_snapshots (id, simulation_id, warehouse_id, snapshot_version, taken_at, sim_time_seconds, robot_states, task_states, obstacle_states, sim_inventory_delta, metadata) FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, date, warehouse_id, item_id, stock_in, stock_out, closing_stock, is_anomaly, anomaly_type, entry_source, entered_by) FROM stdin;
4201	2026-07-13	WH-BLR-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
4202	2026-07-13	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
4203	2026-07-13	WH-BLR-01	ITM-RAM-01	0	1	74	f	none	simulated	system_sim
4204	2026-07-13	WH-BLR-01	ITM-SSD-01	0	0	90	f	none	simulated	system_sim
4205	2026-07-13	WH-BLR-01	ITM-HDD-01	0	1	59	f	none	simulated	system_sim
4206	2026-07-13	WH-BLR-01	ITM-CHG-01	0	5	145	f	none	simulated	system_sim
4207	2026-07-13	WH-BLR-01	ITM-CBL-01	0	6	294	f	none	simulated	system_sim
4208	2026-07-13	WH-CHN-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
4209	2026-07-13	WH-CHN-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
4210	2026-07-13	WH-CHN-01	ITM-RAM-01	0	8	67	f	none	simulated	system_sim
4211	2026-07-13	WH-CHN-01	ITM-SSD-01	0	1	89	f	none	simulated	system_sim
4212	2026-07-13	WH-CHN-01	ITM-HDD-01	0	3	57	f	none	simulated	system_sim
4213	2026-07-13	WH-CHN-01	ITM-CHG-01	0	9	141	f	none	simulated	system_sim
4214	2026-07-13	WH-CHN-01	ITM-CBL-01	0	10	290	f	none	simulated	system_sim
4215	2026-07-13	WH-BOM-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
4216	2026-07-13	WH-BOM-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
4217	2026-07-13	WH-BOM-01	ITM-RAM-01	0	6	69	f	none	simulated	system_sim
4218	2026-07-13	WH-BOM-01	ITM-SSD-01	0	3	87	f	none	simulated	system_sim
4219	2026-07-13	WH-BOM-01	ITM-HDD-01	0	3	57	f	none	simulated	system_sim
4220	2026-07-13	WH-BOM-01	ITM-CHG-01	0	7	143	f	none	simulated	system_sim
4221	2026-07-13	WH-BOM-01	ITM-CBL-01	0	10	290	f	none	simulated	system_sim
4222	2026-07-13	WH-DEL-01	ITM-CPU-01	0	1	44	f	none	simulated	system_sim
4223	2026-07-13	WH-DEL-01	ITM-GPU-01	0	2	28	f	none	simulated	system_sim
4224	2026-07-13	WH-DEL-01	ITM-RAM-01	0	6	69	f	none	simulated	system_sim
4225	2026-07-13	WH-DEL-01	ITM-SSD-01	0	0	90	f	none	simulated	system_sim
4226	2026-07-13	WH-DEL-01	ITM-HDD-01	0	3	57	f	none	simulated	system_sim
4227	2026-07-13	WH-DEL-01	ITM-CHG-01	0	7	143	f	none	simulated	system_sim
4228	2026-07-13	WH-DEL-01	ITM-CBL-01	0	7	293	f	none	simulated	system_sim
4229	2026-07-13	WH-CCU-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
4230	2026-07-13	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
4231	2026-07-13	WH-CCU-01	ITM-RAM-01	0	7	68	f	none	simulated	system_sim
4232	2026-07-13	WH-CCU-01	ITM-SSD-01	0	1	89	f	none	simulated	system_sim
4233	2026-07-13	WH-CCU-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
4234	2026-07-13	WH-CCU-01	ITM-CHG-01	0	2	148	f	none	simulated	system_sim
4235	2026-07-13	WH-CCU-01	ITM-CBL-01	0	7	293	f	none	simulated	system_sim
4236	2026-07-14	WH-BLR-01	ITM-CPU-01	0	1	41	f	none	simulated	system_sim
4237	2026-07-14	WH-BLR-01	ITM-GPU-01	0	2	28	f	none	simulated	system_sim
4238	2026-07-14	WH-BLR-01	ITM-RAM-01	0	3	71	f	none	simulated	system_sim
4239	2026-07-14	WH-BLR-01	ITM-SSD-01	0	2	88	f	none	simulated	system_sim
4240	2026-07-14	WH-BLR-01	ITM-HDD-01	0	1	58	f	none	simulated	system_sim
4241	2026-07-14	WH-BLR-01	ITM-CHG-01	0	9	136	f	none	simulated	system_sim
4242	2026-07-14	WH-BLR-01	ITM-CBL-01	0	5	289	f	none	simulated	system_sim
4243	2026-07-14	WH-CHN-01	ITM-CPU-01	0	3	39	f	none	simulated	system_sim
4244	2026-07-14	WH-CHN-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
4245	2026-07-14	WH-CHN-01	ITM-RAM-01	0	9	58	f	none	simulated	system_sim
4246	2026-07-14	WH-CHN-01	ITM-SSD-01	0	1	88	f	none	simulated	system_sim
4247	2026-07-14	WH-CHN-01	ITM-HDD-01	0	2	55	f	none	simulated	system_sim
4248	2026-07-14	WH-CHN-01	ITM-CHG-01	0	8	133	f	none	simulated	system_sim
4249	2026-07-14	WH-CHN-01	ITM-CBL-01	0	10	280	f	none	simulated	system_sim
4250	2026-07-14	WH-BOM-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
4251	2026-07-14	WH-BOM-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
4252	2026-07-14	WH-BOM-01	ITM-RAM-01	0	3	66	f	none	simulated	system_sim
4253	2026-07-14	WH-BOM-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
4254	2026-07-14	WH-BOM-01	ITM-HDD-01	0	2	55	f	none	simulated	system_sim
4255	2026-07-14	WH-BOM-01	ITM-CHG-01	0	6	137	f	none	simulated	system_sim
4256	2026-07-14	WH-BOM-01	ITM-CBL-01	0	5	285	f	none	simulated	system_sim
4257	2026-07-14	WH-DEL-01	ITM-CPU-01	0	3	41	f	none	simulated	system_sim
4258	2026-07-14	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
4259	2026-07-14	WH-DEL-01	ITM-RAM-01	0	3	66	f	none	simulated	system_sim
4260	2026-07-14	WH-DEL-01	ITM-SSD-01	0	3	87	f	none	simulated	system_sim
4261	2026-07-14	WH-DEL-01	ITM-HDD-01	0	3	54	f	none	simulated	system_sim
4262	2026-07-14	WH-DEL-01	ITM-CHG-01	0	3	140	f	none	simulated	system_sim
4263	2026-07-14	WH-DEL-01	ITM-CBL-01	0	2	291	f	none	simulated	system_sim
4264	2026-07-14	WH-CCU-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
4265	2026-07-14	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
4266	2026-07-14	WH-CCU-01	ITM-RAM-01	0	9	59	f	none	simulated	system_sim
4267	2026-07-14	WH-CCU-01	ITM-SSD-01	0	0	89	f	none	simulated	system_sim
4268	2026-07-14	WH-CCU-01	ITM-HDD-01	0	2	58	f	none	simulated	system_sim
4269	2026-07-14	WH-CCU-01	ITM-CHG-01	0	6	142	f	none	simulated	system_sim
4270	2026-07-14	WH-CCU-01	ITM-CBL-01	0	6	287	f	none	simulated	system_sim
4271	2026-07-15	WH-BLR-01	ITM-CPU-01	0	1	40	f	none	simulated	system_sim
4272	2026-07-15	WH-BLR-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
4273	2026-07-15	WH-BLR-01	ITM-RAM-01	0	6	65	f	none	simulated	system_sim
4274	2026-07-15	WH-BLR-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
4275	2026-07-15	WH-BLR-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
4276	2026-07-15	WH-BLR-01	ITM-CHG-01	0	5	131	f	none	simulated	system_sim
4277	2026-07-15	WH-BLR-01	ITM-CBL-01	0	5	284	f	none	simulated	system_sim
4278	2026-07-15	WH-CHN-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
4279	2026-07-15	WH-CHN-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
4280	2026-07-15	WH-CHN-01	ITM-RAM-01	0	4	54	f	none	simulated	system_sim
4281	2026-07-15	WH-CHN-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
4282	2026-07-15	WH-CHN-01	ITM-HDD-01	0	3	52	f	none	simulated	system_sim
4283	2026-07-15	WH-CHN-01	ITM-CHG-01	0	5	128	f	none	simulated	system_sim
4284	2026-07-15	WH-CHN-01	ITM-CBL-01	0	4	276	f	none	simulated	system_sim
4285	2026-07-15	WH-BOM-01	ITM-CPU-01	0	1	41	f	none	simulated	system_sim
4286	2026-07-15	WH-BOM-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
4287	2026-07-15	WH-BOM-01	ITM-RAM-01	0	10	56	f	none	simulated	system_sim
4288	2026-07-15	WH-BOM-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
4289	2026-07-15	WH-BOM-01	ITM-HDD-01	0	1	54	f	none	simulated	system_sim
4290	2026-07-15	WH-BOM-01	ITM-CHG-01	0	6	131	f	none	simulated	system_sim
4291	2026-07-15	WH-BOM-01	ITM-CBL-01	0	6	279	f	none	simulated	system_sim
4292	2026-07-15	WH-DEL-01	ITM-CPU-01	0	2	39	f	none	simulated	system_sim
4293	2026-07-15	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
4294	2026-07-15	WH-DEL-01	ITM-RAM-01	0	7	59	f	none	simulated	system_sim
4295	2026-07-15	WH-DEL-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
4296	2026-07-15	WH-DEL-01	ITM-HDD-01	0	0	54	f	none	simulated	system_sim
4297	2026-07-15	WH-DEL-01	ITM-CHG-01	0	3	137	f	none	simulated	system_sim
4298	2026-07-15	WH-DEL-01	ITM-CBL-01	0	4	287	f	none	simulated	system_sim
4299	2026-07-15	WH-CCU-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
4300	2026-07-15	WH-CCU-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
4301	2026-07-15	WH-CCU-01	ITM-RAM-01	0	3	56	f	none	simulated	system_sim
4302	2026-07-15	WH-CCU-01	ITM-SSD-01	0	0	89	f	none	simulated	system_sim
4303	2026-07-15	WH-CCU-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
4304	2026-07-15	WH-CCU-01	ITM-CHG-01	0	9	133	f	none	simulated	system_sim
4305	2026-07-15	WH-CCU-01	ITM-CBL-01	0	10	277	f	none	simulated	system_sim
4306	2026-07-16	WH-BLR-01	ITM-CPU-01	0	3	37	f	none	simulated	system_sim
4307	2026-07-16	WH-BLR-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
4308	2026-07-16	WH-BLR-01	ITM-RAM-01	0	10	55	f	none	simulated	system_sim
4309	2026-07-16	WH-BLR-01	ITM-SSD-01	0	1	87	f	none	simulated	system_sim
4310	2026-07-16	WH-BLR-01	ITM-HDD-01	0	1	57	f	none	simulated	system_sim
4311	2026-07-16	WH-BLR-01	ITM-CHG-01	0	9	122	f	none	simulated	system_sim
4312	2026-07-16	WH-BLR-01	ITM-CBL-01	0	5	279	f	none	simulated	system_sim
4313	2026-07-16	WH-CHN-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
4314	2026-07-16	WH-CHN-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
4315	2026-07-16	WH-CHN-01	ITM-RAM-01	0	5	49	f	none	simulated	system_sim
4316	2026-07-16	WH-CHN-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
4317	2026-07-16	WH-CHN-01	ITM-HDD-01	0	2	50	f	none	simulated	system_sim
4318	2026-07-16	WH-CHN-01	ITM-CHG-01	0	6	122	f	none	simulated	system_sim
4319	2026-07-16	WH-CHN-01	ITM-CBL-01	0	2	274	f	none	simulated	system_sim
4320	2026-07-16	WH-BOM-01	ITM-CPU-01	0	1	40	f	none	simulated	system_sim
4321	2026-07-16	WH-BOM-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
4322	2026-07-16	WH-BOM-01	ITM-RAM-01	0	2	54	f	none	simulated	system_sim
4323	2026-07-16	WH-BOM-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
4324	2026-07-16	WH-BOM-01	ITM-HDD-01	0	1	53	f	none	simulated	system_sim
4325	2026-07-16	WH-BOM-01	ITM-CHG-01	0	5	126	f	none	simulated	system_sim
4326	2026-07-16	WH-BOM-01	ITM-CBL-01	0	8	271	f	none	simulated	system_sim
4327	2026-07-16	WH-DEL-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
4328	2026-07-16	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
4329	2026-07-16	WH-DEL-01	ITM-RAM-01	0	5	54	f	none	simulated	system_sim
4330	2026-07-16	WH-DEL-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
4331	2026-07-16	WH-DEL-01	ITM-HDD-01	0	0	54	f	none	simulated	system_sim
4332	2026-07-16	WH-DEL-01	ITM-CHG-01	0	2	135	f	none	simulated	system_sim
4333	2026-07-16	WH-DEL-01	ITM-CBL-01	0	5	282	f	none	simulated	system_sim
4334	2026-07-16	WH-CCU-01	ITM-CPU-01	0	1	41	f	none	simulated	system_sim
4335	2026-07-16	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
4336	2026-07-16	WH-CCU-01	ITM-RAM-01	0	4	52	f	none	simulated	system_sim
4337	2026-07-16	WH-CCU-01	ITM-SSD-01	0	0	89	f	none	simulated	system_sim
4338	2026-07-16	WH-CCU-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
4339	2026-07-16	WH-CCU-01	ITM-CHG-01	0	4	129	f	none	simulated	system_sim
4340	2026-07-16	WH-CCU-01	ITM-CBL-01	0	1	276	f	none	simulated	system_sim
4341	2026-07-17	WH-BLR-01	ITM-CPU-01	0	0	37	f	none	simulated	system_sim
4342	2026-07-17	WH-BLR-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
4343	2026-07-17	WH-BLR-01	ITM-RAM-01	0	9	46	f	none	simulated	system_sim
4344	2026-07-17	WH-BLR-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
4345	2026-07-17	WH-BLR-01	ITM-HDD-01	0	3	54	f	none	simulated	system_sim
4346	2026-07-17	WH-BLR-01	ITM-CHG-01	0	6	116	f	none	simulated	system_sim
4347	2026-07-17	WH-BLR-01	ITM-CBL-01	0	1	278	f	none	simulated	system_sim
4348	2026-07-17	WH-CHN-01	ITM-CPU-01	0	3	36	f	none	simulated	system_sim
4349	2026-07-17	WH-CHN-01	ITM-GPU-01	0	2	28	f	none	simulated	system_sim
4350	2026-07-17	WH-CHN-01	ITM-RAM-01	0	6	43	f	none	simulated	system_sim
4351	2026-07-17	WH-CHN-01	ITM-SSD-01	0	3	85	f	none	simulated	system_sim
4352	2026-07-17	WH-CHN-01	ITM-HDD-01	0	0	50	f	none	simulated	system_sim
4353	2026-07-17	WH-CHN-01	ITM-CHG-01	0	7	115	f	none	simulated	system_sim
4354	2026-07-17	WH-CHN-01	ITM-CBL-01	0	2	272	f	none	simulated	system_sim
4355	2026-07-17	WH-BOM-01	ITM-CPU-01	0	2	38	f	none	simulated	system_sim
4356	2026-07-17	WH-BOM-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
4357	2026-07-17	WH-BOM-01	ITM-RAM-01	0	8	46	f	none	simulated	system_sim
4358	2026-07-17	WH-BOM-01	ITM-SSD-01	0	1	86	f	none	simulated	system_sim
4359	2026-07-17	WH-BOM-01	ITM-HDD-01	0	1	52	f	none	simulated	system_sim
4360	2026-07-17	WH-BOM-01	ITM-CHG-01	0	9	117	f	none	simulated	system_sim
4361	2026-07-17	WH-BOM-01	ITM-CBL-01	0	8	263	f	none	simulated	system_sim
4362	2026-07-17	WH-DEL-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
4363	2026-07-17	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
4364	2026-07-17	WH-DEL-01	ITM-RAM-01	0	3	51	f	none	simulated	system_sim
4365	2026-07-17	WH-DEL-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
4366	2026-07-17	WH-DEL-01	ITM-HDD-01	0	2	52	f	none	simulated	system_sim
4367	2026-07-17	WH-DEL-01	ITM-CHG-01	0	9	126	f	none	simulated	system_sim
4368	2026-07-17	WH-DEL-01	ITM-CBL-01	0	1	281	f	none	simulated	system_sim
4369	2026-07-17	WH-CCU-01	ITM-CPU-01	0	2	39	f	none	simulated	system_sim
4370	2026-07-17	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
4371	2026-07-17	WH-CCU-01	ITM-RAM-01	0	10	42	f	none	simulated	system_sim
4372	2026-07-17	WH-CCU-01	ITM-SSD-01	0	0	89	f	none	simulated	system_sim
4373	2026-07-17	WH-CCU-01	ITM-HDD-01	0	3	55	f	none	simulated	system_sim
4374	2026-07-17	WH-CCU-01	ITM-CHG-01	0	5	124	f	none	simulated	system_sim
4375	2026-07-17	WH-CCU-01	ITM-CBL-01	0	9	267	f	none	simulated	system_sim
4376	2026-07-18	WH-BLR-01	ITM-CPU-01	0	3	34	f	none	simulated	system_sim
4377	2026-07-18	WH-BLR-01	ITM-GPU-01	0	1	26	f	none	simulated	system_sim
4378	2026-07-18	WH-BLR-01	ITM-RAM-01	0	6	40	f	none	simulated	system_sim
4379	2026-07-18	WH-BLR-01	ITM-SSD-01	0	3	84	f	none	simulated	system_sim
4380	2026-07-18	WH-BLR-01	ITM-HDD-01	0	0	54	f	none	simulated	system_sim
4381	2026-07-18	WH-BLR-01	ITM-CHG-01	0	1	115	f	none	simulated	system_sim
4382	2026-07-18	WH-BLR-01	ITM-CBL-01	0	5	273	f	none	simulated	system_sim
4383	2026-07-18	WH-CHN-01	ITM-CPU-01	0	1	35	f	none	simulated	system_sim
4384	2026-07-18	WH-CHN-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
4385	2026-07-18	WH-CHN-01	ITM-RAM-01	0	3	40	f	none	simulated	system_sim
4386	2026-07-18	WH-CHN-01	ITM-SSD-01	0	1	84	f	none	simulated	system_sim
4387	2026-07-18	WH-CHN-01	ITM-HDD-01	0	0	50	f	none	simulated	system_sim
4388	2026-07-18	WH-CHN-01	ITM-CHG-01	0	4	111	f	none	simulated	system_sim
4389	2026-07-18	WH-CHN-01	ITM-CBL-01	0	4	268	f	none	simulated	system_sim
4390	2026-07-18	WH-BOM-01	ITM-CPU-01	0	0	38	f	none	simulated	system_sim
4391	2026-07-18	WH-BOM-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
4392	2026-07-18	WH-BOM-01	ITM-RAM-01	0	10	36	f	none	simulated	system_sim
4393	2026-07-18	WH-BOM-01	ITM-SSD-01	0	0	86	f	none	simulated	system_sim
4394	2026-07-18	WH-BOM-01	ITM-HDD-01	0	1	51	f	none	simulated	system_sim
4395	2026-07-18	WH-BOM-01	ITM-CHG-01	0	7	110	f	none	simulated	system_sim
4396	2026-07-18	WH-BOM-01	ITM-CBL-01	0	4	259	f	none	simulated	system_sim
4397	2026-07-18	WH-DEL-01	ITM-CPU-01	0	2	37	f	none	simulated	system_sim
4398	2026-07-18	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
4399	2026-07-18	WH-DEL-01	ITM-RAM-01	0	10	41	f	none	simulated	system_sim
4400	2026-07-18	WH-DEL-01	ITM-SSD-01	0	2	85	f	none	simulated	system_sim
4401	2026-07-18	WH-DEL-01	ITM-HDD-01	0	1	51	f	none	simulated	system_sim
4402	2026-07-18	WH-DEL-01	ITM-CHG-01	0	7	119	f	none	simulated	system_sim
4403	2026-07-18	WH-DEL-01	ITM-CBL-01	0	1	280	f	none	simulated	system_sim
4404	2026-07-18	WH-CCU-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
4405	2026-07-18	WH-CCU-01	ITM-GPU-01	0	2	27	f	none	simulated	system_sim
4406	2026-07-18	WH-CCU-01	ITM-RAM-01	0	9	33	f	none	simulated	system_sim
4407	2026-07-18	WH-CCU-01	ITM-SSD-01	0	0	89	f	none	simulated	system_sim
4408	2026-07-18	WH-CCU-01	ITM-HDD-01	0	1	54	f	none	simulated	system_sim
4409	2026-07-18	WH-CCU-01	ITM-CHG-01	0	2	122	f	none	simulated	system_sim
4410	2026-07-18	WH-CCU-01	ITM-CBL-01	0	2	265	f	none	simulated	system_sim
4411	2026-07-19	WH-BLR-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
4412	2026-07-19	WH-BLR-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
4413	2026-07-19	WH-BLR-01	ITM-RAM-01	0	10	30	f	none	simulated	system_sim
4414	2026-07-19	WH-BLR-01	ITM-SSD-01	0	0	84	f	none	simulated	system_sim
4415	2026-07-19	WH-BLR-01	ITM-HDD-01	0	0	54	f	none	simulated	system_sim
4416	2026-07-19	WH-BLR-01	ITM-CHG-01	0	8	107	f	none	simulated	system_sim
4417	2026-07-19	WH-BLR-01	ITM-CBL-01	0	1	272	f	none	simulated	system_sim
4418	2026-07-19	WH-CHN-01	ITM-CPU-01	0	2	33	f	none	simulated	system_sim
4419	2026-07-19	WH-CHN-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
4420	2026-07-19	WH-CHN-01	ITM-RAM-01	0	1	39	f	none	simulated	system_sim
4421	2026-07-19	WH-CHN-01	ITM-SSD-01	0	0	84	f	none	simulated	system_sim
4422	2026-07-19	WH-CHN-01	ITM-HDD-01	0	0	50	f	none	simulated	system_sim
4423	2026-07-19	WH-CHN-01	ITM-CHG-01	0	9	102	f	none	simulated	system_sim
4424	2026-07-19	WH-CHN-01	ITM-CBL-01	0	10	258	f	none	simulated	system_sim
4425	2026-07-19	WH-BOM-01	ITM-CPU-01	0	3	35	f	none	simulated	system_sim
4426	2026-07-19	WH-BOM-01	ITM-GPU-01	0	2	27	f	none	simulated	system_sim
4427	2026-07-19	WH-BOM-01	ITM-RAM-01	75	7	104	f	none	simulated	system_sim
4428	2026-07-19	WH-BOM-01	ITM-SSD-01	0	0	86	f	none	simulated	system_sim
4429	2026-07-19	WH-BOM-01	ITM-HDD-01	0	0	51	f	none	simulated	system_sim
4430	2026-07-19	WH-BOM-01	ITM-CHG-01	0	4	106	f	none	simulated	system_sim
4431	2026-07-19	WH-BOM-01	ITM-CBL-01	0	10	249	f	none	simulated	system_sim
4432	2026-07-19	WH-DEL-01	ITM-CPU-01	0	0	37	f	none	simulated	system_sim
4433	2026-07-19	WH-DEL-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
4434	2026-07-19	WH-DEL-01	ITM-RAM-01	0	6	35	f	none	simulated	system_sim
4435	2026-07-19	WH-DEL-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
4436	2026-07-19	WH-DEL-01	ITM-HDD-01	0	2	49	f	none	simulated	system_sim
4437	2026-07-19	WH-DEL-01	ITM-CHG-01	0	2	117	f	none	simulated	system_sim
4438	2026-07-19	WH-DEL-01	ITM-CBL-01	0	7	273	f	none	simulated	system_sim
4439	2026-07-19	WH-CCU-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
4440	2026-07-19	WH-CCU-01	ITM-GPU-01	0	2	25	f	none	simulated	system_sim
4441	2026-07-19	WH-CCU-01	ITM-RAM-01	75	9	99	f	none	simulated	system_sim
4442	2026-07-19	WH-CCU-01	ITM-SSD-01	0	0	89	f	none	simulated	system_sim
4443	2026-07-19	WH-CCU-01	ITM-HDD-01	0	0	54	f	none	simulated	system_sim
4444	2026-07-19	WH-CCU-01	ITM-CHG-01	0	5	117	f	none	simulated	system_sim
4445	2026-07-19	WH-CCU-01	ITM-CBL-01	0	5	260	f	none	simulated	system_sim
4446	2026-07-20	WH-BLR-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
4447	2026-07-20	WH-BLR-01	ITM-GPU-01	0	2	24	f	none	simulated	system_sim
4448	2026-07-20	WH-BLR-01	ITM-RAM-01	75	3	102	f	none	simulated	system_sim
4449	2026-07-20	WH-BLR-01	ITM-SSD-01	0	0	84	f	none	simulated	system_sim
4450	2026-07-20	WH-BLR-01	ITM-HDD-01	0	0	54	f	none	simulated	system_sim
4451	2026-07-20	WH-BLR-01	ITM-CHG-01	0	2	105	f	none	simulated	system_sim
4452	2026-07-20	WH-BLR-01	ITM-CBL-01	0	7	265	f	none	simulated	system_sim
4453	2026-07-20	WH-CHN-01	ITM-CPU-01	0	1	32	f	none	simulated	system_sim
4454	2026-07-20	WH-CHN-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
4455	2026-07-20	WH-CHN-01	ITM-RAM-01	0	10	29	f	none	simulated	system_sim
4456	2026-07-20	WH-CHN-01	ITM-SSD-01	0	3	81	f	none	simulated	system_sim
4457	2026-07-20	WH-CHN-01	ITM-HDD-01	0	1	49	f	none	simulated	system_sim
4458	2026-07-20	WH-CHN-01	ITM-CHG-01	0	3	99	f	none	simulated	system_sim
4459	2026-07-20	WH-CHN-01	ITM-CBL-01	0	3	255	f	none	simulated	system_sim
4460	2026-07-20	WH-BOM-01	ITM-CPU-01	0	0	35	f	none	simulated	system_sim
4461	2026-07-20	WH-BOM-01	ITM-GPU-01	0	2	25	f	none	simulated	system_sim
4462	2026-07-20	WH-BOM-01	ITM-RAM-01	0	8	96	f	none	simulated	system_sim
4463	2026-07-20	WH-BOM-01	ITM-SSD-01	0	0	86	f	none	simulated	system_sim
4464	2026-07-20	WH-BOM-01	ITM-HDD-01	0	3	48	f	none	simulated	system_sim
4465	2026-07-20	WH-BOM-01	ITM-CHG-01	0	9	97	f	none	simulated	system_sim
4466	2026-07-20	WH-BOM-01	ITM-CBL-01	0	8	241	f	none	simulated	system_sim
4467	2026-07-20	WH-DEL-01	ITM-CPU-01	0	2	35	f	none	simulated	system_sim
4468	2026-07-20	WH-DEL-01	ITM-GPU-01	0	1	26	f	none	simulated	system_sim
4469	2026-07-20	WH-DEL-01	ITM-RAM-01	75	1	109	f	none	simulated	system_sim
4470	2026-07-20	WH-DEL-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
4471	2026-07-20	WH-DEL-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
4472	2026-07-20	WH-DEL-01	ITM-CHG-01	0	4	113	f	none	simulated	system_sim
4473	2026-07-20	WH-DEL-01	ITM-CBL-01	0	4	269	f	none	simulated	system_sim
4474	2026-07-20	WH-CCU-01	ITM-CPU-01	0	1	38	f	none	simulated	system_sim
4475	2026-07-20	WH-CCU-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
4476	2026-07-20	WH-CCU-01	ITM-RAM-01	0	4	95	f	none	simulated	system_sim
4477	2026-07-20	WH-CCU-01	ITM-SSD-01	0	2	87	f	none	simulated	system_sim
4478	2026-07-20	WH-CCU-01	ITM-HDD-01	0	1	53	f	none	simulated	system_sim
4479	2026-07-20	WH-CCU-01	ITM-CHG-01	0	9	108	f	none	simulated	system_sim
4480	2026-07-20	WH-CCU-01	ITM-CBL-01	0	3	257	f	none	simulated	system_sim
4481	2026-07-21	WH-BLR-01	ITM-CPU-01	0	3	31	f	none	simulated	system_sim
4482	2026-07-21	WH-BLR-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
4483	2026-07-21	WH-BLR-01	ITM-RAM-01	0	10	92	f	none	simulated	system_sim
4484	2026-07-21	WH-BLR-01	ITM-SSD-01	0	2	82	f	none	simulated	system_sim
4485	2026-07-21	WH-BLR-01	ITM-HDD-01	0	2	52	f	none	simulated	system_sim
4486	2026-07-21	WH-BLR-01	ITM-CHG-01	0	2	103	f	none	simulated	system_sim
4487	2026-07-21	WH-BLR-01	ITM-CBL-01	0	2	263	f	none	simulated	system_sim
4488	2026-07-21	WH-CHN-01	ITM-CPU-01	0	2	30	f	none	simulated	system_sim
4489	2026-07-21	WH-CHN-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
4490	2026-07-21	WH-CHN-01	ITM-RAM-01	75	3	101	f	none	simulated	system_sim
4491	2026-07-21	WH-CHN-01	ITM-SSD-01	0	3	78	f	none	simulated	system_sim
4492	2026-07-21	WH-CHN-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
4493	2026-07-21	WH-CHN-01	ITM-CHG-01	0	4	95	f	none	simulated	system_sim
4494	2026-07-21	WH-CHN-01	ITM-CBL-01	0	3	252	f	none	simulated	system_sim
4495	2026-07-21	WH-BOM-01	ITM-CPU-01	0	0	35	f	none	simulated	system_sim
4496	2026-07-21	WH-BOM-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
4497	2026-07-21	WH-BOM-01	ITM-RAM-01	0	7	89	f	none	simulated	system_sim
4498	2026-07-21	WH-BOM-01	ITM-SSD-01	0	2	84	f	none	simulated	system_sim
4499	2026-07-21	WH-BOM-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
4500	2026-07-21	WH-BOM-01	ITM-CHG-01	0	3	94	f	none	simulated	system_sim
4501	2026-07-21	WH-BOM-01	ITM-CBL-01	0	8	233	f	none	simulated	system_sim
4502	2026-07-21	WH-DEL-01	ITM-CPU-01	0	1	34	f	none	simulated	system_sim
4503	2026-07-21	WH-DEL-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
4504	2026-07-21	WH-DEL-01	ITM-RAM-01	0	5	104	f	none	simulated	system_sim
4505	2026-07-21	WH-DEL-01	ITM-SSD-01	0	1	84	f	none	simulated	system_sim
4506	2026-07-21	WH-DEL-01	ITM-HDD-01	0	1	48	f	none	simulated	system_sim
4507	2026-07-21	WH-DEL-01	ITM-CHG-01	0	5	108	f	none	simulated	system_sim
4508	2026-07-21	WH-DEL-01	ITM-CBL-01	0	4	265	f	none	simulated	system_sim
4509	2026-07-21	WH-CCU-01	ITM-CPU-01	0	3	35	f	none	simulated	system_sim
4510	2026-07-21	WH-CCU-01	ITM-GPU-01	0	2	21	f	none	simulated	system_sim
4511	2026-07-21	WH-CCU-01	ITM-RAM-01	0	10	85	f	none	simulated	system_sim
4512	2026-07-21	WH-CCU-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
4513	2026-07-21	WH-CCU-01	ITM-HDD-01	0	0	53	f	none	simulated	system_sim
4514	2026-07-21	WH-CCU-01	ITM-CHG-01	0	8	100	f	none	simulated	system_sim
4515	2026-07-21	WH-CCU-01	ITM-CBL-01	0	4	253	f	none	simulated	system_sim
4516	2026-07-22	WH-BLR-01	ITM-CPU-01	0	0	31	f	none	simulated	system_sim
4517	2026-07-22	WH-BLR-01	ITM-GPU-01	0	2	22	f	none	simulated	system_sim
4518	2026-07-22	WH-BLR-01	ITM-RAM-01	0	8	84	f	none	simulated	system_sim
4519	2026-07-22	WH-BLR-01	ITM-SSD-01	0	1	81	f	none	simulated	system_sim
4520	2026-07-22	WH-BLR-01	ITM-HDD-01	0	3	49	f	none	simulated	system_sim
4521	2026-07-22	WH-BLR-01	ITM-CHG-01	0	10	93	f	none	simulated	system_sim
4522	2026-07-22	WH-BLR-01	ITM-CBL-01	0	2	261	f	none	simulated	system_sim
4523	2026-07-22	WH-CHN-01	ITM-CPU-01	0	3	27	f	none	simulated	system_sim
4524	2026-07-22	WH-CHN-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
4525	2026-07-22	WH-CHN-01	ITM-RAM-01	0	7	94	f	none	simulated	system_sim
4526	2026-07-22	WH-CHN-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
4527	2026-07-22	WH-CHN-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
4528	2026-07-22	WH-CHN-01	ITM-CHG-01	0	8	87	f	none	simulated	system_sim
4529	2026-07-22	WH-CHN-01	ITM-CBL-01	0	7	245	f	none	simulated	system_sim
4530	2026-07-22	WH-BOM-01	ITM-CPU-01	0	1	34	f	none	simulated	system_sim
4531	2026-07-22	WH-BOM-01	ITM-GPU-01	0	1	22	f	none	simulated	system_sim
4532	2026-07-22	WH-BOM-01	ITM-RAM-01	0	2	87	f	none	simulated	system_sim
4533	2026-07-22	WH-BOM-01	ITM-SSD-01	0	2	82	f	none	simulated	system_sim
4534	2026-07-22	WH-BOM-01	ITM-HDD-01	0	3	45	f	none	simulated	system_sim
4535	2026-07-22	WH-BOM-01	ITM-CHG-01	0	2	92	f	none	simulated	system_sim
4536	2026-07-22	WH-BOM-01	ITM-CBL-01	0	2	231	f	none	simulated	system_sim
4537	2026-07-22	WH-DEL-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
4538	2026-07-22	WH-DEL-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
4539	2026-07-22	WH-DEL-01	ITM-RAM-01	0	4	100	f	none	simulated	system_sim
4540	2026-07-22	WH-DEL-01	ITM-SSD-01	0	1	83	f	none	simulated	system_sim
4541	2026-07-22	WH-DEL-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
4542	2026-07-22	WH-DEL-01	ITM-CHG-01	0	5	103	f	none	simulated	system_sim
4543	2026-07-22	WH-DEL-01	ITM-CBL-01	0	2	263	f	none	simulated	system_sim
4544	2026-07-22	WH-CCU-01	ITM-CPU-01	0	1	34	f	none	simulated	system_sim
4545	2026-07-22	WH-CCU-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
4546	2026-07-22	WH-CCU-01	ITM-RAM-01	0	8	77	f	none	simulated	system_sim
4547	2026-07-22	WH-CCU-01	ITM-SSD-01	0	1	86	f	none	simulated	system_sim
4548	2026-07-22	WH-CCU-01	ITM-HDD-01	0	2	51	f	none	simulated	system_sim
4549	2026-07-22	WH-CCU-01	ITM-CHG-01	0	3	97	f	none	simulated	system_sim
4550	2026-07-22	WH-CCU-01	ITM-CBL-01	0	2	251	f	none	simulated	system_sim
4551	2026-07-23	WH-BLR-01	ITM-CPU-01	0	0	31	f	none	simulated	system_sim
4552	2026-07-23	WH-BLR-01	ITM-GPU-01	0	2	20	f	none	simulated	system_sim
4553	2026-07-23	WH-BLR-01	ITM-RAM-01	0	2	82	f	none	simulated	system_sim
4554	2026-07-23	WH-BLR-01	ITM-SSD-01	0	1	80	f	none	simulated	system_sim
4555	2026-07-23	WH-BLR-01	ITM-HDD-01	0	2	47	f	none	simulated	system_sim
4556	2026-07-23	WH-BLR-01	ITM-CHG-01	0	6	87	f	none	simulated	system_sim
4557	2026-07-23	WH-BLR-01	ITM-CBL-01	0	10	251	f	none	simulated	system_sim
4558	2026-07-23	WH-CHN-01	ITM-CPU-01	0	3	24	f	none	simulated	system_sim
4559	2026-07-23	WH-CHN-01	ITM-GPU-01	0	1	26	f	none	simulated	system_sim
4560	2026-07-23	WH-CHN-01	ITM-RAM-01	0	8	86	f	none	simulated	system_sim
4561	2026-07-23	WH-CHN-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
4562	2026-07-23	WH-CHN-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
4563	2026-07-23	WH-CHN-01	ITM-CHG-01	0	1	86	f	none	simulated	system_sim
4564	2026-07-23	WH-CHN-01	ITM-CBL-01	0	5	240	f	none	simulated	system_sim
4565	2026-07-23	WH-BOM-01	ITM-CPU-01	0	1	33	f	none	simulated	system_sim
4566	2026-07-23	WH-BOM-01	ITM-GPU-01	0	1	21	f	none	simulated	system_sim
4567	2026-07-23	WH-BOM-01	ITM-RAM-01	0	6	81	f	none	simulated	system_sim
4568	2026-07-23	WH-BOM-01	ITM-SSD-01	0	1	81	f	none	simulated	system_sim
4569	2026-07-23	WH-BOM-01	ITM-HDD-01	0	0	45	f	none	simulated	system_sim
4570	2026-07-23	WH-BOM-01	ITM-CHG-01	0	10	82	f	none	simulated	system_sim
4571	2026-07-23	WH-BOM-01	ITM-CBL-01	0	7	224	f	none	simulated	system_sim
4572	2026-07-23	WH-DEL-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
4573	2026-07-23	WH-DEL-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
4574	2026-07-23	WH-DEL-01	ITM-RAM-01	0	2	98	f	none	simulated	system_sim
4575	2026-07-23	WH-DEL-01	ITM-SSD-01	0	1	82	f	none	simulated	system_sim
4576	2026-07-23	WH-DEL-01	ITM-HDD-01	0	2	46	f	none	simulated	system_sim
4577	2026-07-23	WH-DEL-01	ITM-CHG-01	0	3	100	f	none	simulated	system_sim
4578	2026-07-23	WH-DEL-01	ITM-CBL-01	0	2	261	f	none	simulated	system_sim
4579	2026-07-23	WH-CCU-01	ITM-CPU-01	0	3	31	f	none	simulated	system_sim
4580	2026-07-23	WH-CCU-01	ITM-GPU-01	0	2	17	f	none	simulated	system_sim
4581	2026-07-23	WH-CCU-01	ITM-RAM-01	0	7	70	f	none	simulated	system_sim
4582	2026-07-23	WH-CCU-01	ITM-SSD-01	0	0	86	f	none	simulated	system_sim
4583	2026-07-23	WH-CCU-01	ITM-HDD-01	0	0	51	f	none	simulated	system_sim
4584	2026-07-23	WH-CCU-01	ITM-CHG-01	0	9	88	f	none	simulated	system_sim
4585	2026-07-23	WH-CCU-01	ITM-CBL-01	0	6	245	f	none	simulated	system_sim
4586	2026-07-24	WH-BLR-01	ITM-CPU-01	0	0	31	f	none	simulated	system_sim
4587	2026-07-24	WH-BLR-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
4588	2026-07-24	WH-BLR-01	ITM-RAM-01	0	6	76	f	none	simulated	system_sim
4589	2026-07-24	WH-BLR-01	ITM-SSD-01	0	0	80	f	none	simulated	system_sim
4590	2026-07-24	WH-BLR-01	ITM-HDD-01	0	3	44	f	none	simulated	system_sim
4591	2026-07-24	WH-BLR-01	ITM-CHG-01	0	7	80	f	none	simulated	system_sim
4592	2026-07-24	WH-BLR-01	ITM-CBL-01	0	6	245	f	none	simulated	system_sim
4593	2026-07-24	WH-CHN-01	ITM-CPU-01	0	2	22	f	none	simulated	system_sim
4594	2026-07-24	WH-CHN-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
4595	2026-07-24	WH-CHN-01	ITM-RAM-01	0	4	82	f	none	simulated	system_sim
4596	2026-07-24	WH-CHN-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
4597	2026-07-24	WH-CHN-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
4598	2026-07-24	WH-CHN-01	ITM-CHG-01	0	5	81	f	none	simulated	system_sim
4599	2026-07-24	WH-CHN-01	ITM-CBL-01	0	2	238	f	none	simulated	system_sim
4600	2026-07-24	WH-BOM-01	ITM-CPU-01	0	3	30	f	none	simulated	system_sim
4601	2026-07-24	WH-BOM-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
4602	2026-07-24	WH-BOM-01	ITM-RAM-01	0	7	74	f	none	simulated	system_sim
4603	2026-07-24	WH-BOM-01	ITM-SSD-01	0	0	81	f	none	simulated	system_sim
4604	2026-07-24	WH-BOM-01	ITM-HDD-01	0	2	43	f	none	simulated	system_sim
4605	2026-07-24	WH-BOM-01	ITM-CHG-01	0	4	78	f	none	simulated	system_sim
4606	2026-07-24	WH-BOM-01	ITM-CBL-01	0	6	218	f	none	simulated	system_sim
4607	2026-07-24	WH-DEL-01	ITM-CPU-01	0	3	31	f	none	simulated	system_sim
4608	2026-07-24	WH-DEL-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
4609	2026-07-24	WH-DEL-01	ITM-RAM-01	0	2	96	f	none	simulated	system_sim
4610	2026-07-24	WH-DEL-01	ITM-SSD-01	0	1	81	f	none	simulated	system_sim
4611	2026-07-24	WH-DEL-01	ITM-HDD-01	0	2	44	f	none	simulated	system_sim
4612	2026-07-24	WH-DEL-01	ITM-CHG-01	0	7	93	f	none	simulated	system_sim
4613	2026-07-24	WH-DEL-01	ITM-CBL-01	0	7	254	f	none	simulated	system_sim
4614	2026-07-24	WH-CCU-01	ITM-CPU-01	0	2	29	f	none	simulated	system_sim
4615	2026-07-24	WH-CCU-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
4616	2026-07-24	WH-CCU-01	ITM-RAM-01	0	2	68	f	none	simulated	system_sim
4617	2026-07-24	WH-CCU-01	ITM-SSD-01	0	3	83	f	none	simulated	system_sim
4618	2026-07-24	WH-CCU-01	ITM-HDD-01	0	0	51	f	none	simulated	system_sim
4619	2026-07-24	WH-CCU-01	ITM-CHG-01	0	2	86	f	none	simulated	system_sim
4620	2026-07-24	WH-CCU-01	ITM-CBL-01	0	6	239	f	none	simulated	system_sim
4621	2026-07-25	WH-BLR-01	ITM-CPU-01	0	2	29	f	none	simulated	system_sim
4622	2026-07-25	WH-BLR-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
4623	2026-07-25	WH-BLR-01	ITM-RAM-01	0	2	74	f	none	simulated	system_sim
4624	2026-07-25	WH-BLR-01	ITM-SSD-01	0	1	79	f	none	simulated	system_sim
4625	2026-07-25	WH-BLR-01	ITM-HDD-01	0	0	44	f	none	simulated	system_sim
4626	2026-07-25	WH-BLR-01	ITM-CHG-01	0	7	73	f	none	simulated	system_sim
4627	2026-07-25	WH-BLR-01	ITM-CBL-01	0	4	241	f	none	simulated	system_sim
4628	2026-07-25	WH-CHN-01	ITM-CPU-01	45	0	52	t	shrinkage	simulated	system_sim
4629	2026-07-25	WH-CHN-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
4630	2026-07-25	WH-CHN-01	ITM-RAM-01	0	2	80	f	none	simulated	system_sim
4631	2026-07-25	WH-CHN-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
4632	2026-07-25	WH-CHN-01	ITM-HDD-01	0	3	46	f	none	simulated	system_sim
4633	2026-07-25	WH-CHN-01	ITM-CHG-01	0	7	74	f	none	simulated	system_sim
4634	2026-07-25	WH-CHN-01	ITM-CBL-01	0	7	231	f	none	simulated	system_sim
4635	2026-07-25	WH-BOM-01	ITM-CPU-01	0	1	29	f	none	simulated	system_sim
4636	2026-07-25	WH-BOM-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
4637	2026-07-25	WH-BOM-01	ITM-RAM-01	0	7	67	f	none	simulated	system_sim
4638	2026-07-25	WH-BOM-01	ITM-SSD-01	0	0	81	f	none	simulated	system_sim
4639	2026-07-25	WH-BOM-01	ITM-HDD-01	0	3	40	f	none	simulated	system_sim
4640	2026-07-25	WH-BOM-01	ITM-CHG-01	0	1	77	f	none	simulated	system_sim
4641	2026-07-25	WH-BOM-01	ITM-CBL-01	0	2	216	f	none	simulated	system_sim
4642	2026-07-25	WH-DEL-01	ITM-CPU-01	0	0	31	f	none	simulated	system_sim
4643	2026-07-25	WH-DEL-01	ITM-GPU-01	0	1	22	f	none	simulated	system_sim
4644	2026-07-25	WH-DEL-01	ITM-RAM-01	0	4	92	f	none	simulated	system_sim
4645	2026-07-25	WH-DEL-01	ITM-SSD-01	0	1	80	f	none	simulated	system_sim
4646	2026-07-25	WH-DEL-01	ITM-HDD-01	0	3	41	f	none	simulated	system_sim
4647	2026-07-25	WH-DEL-01	ITM-CHG-01	0	7	86	f	none	simulated	system_sim
4648	2026-07-25	WH-DEL-01	ITM-CBL-01	0	10	244	f	none	simulated	system_sim
4649	2026-07-25	WH-CCU-01	ITM-CPU-01	0	3	26	f	none	simulated	system_sim
4650	2026-07-25	WH-CCU-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
4651	2026-07-25	WH-CCU-01	ITM-RAM-01	0	4	64	f	none	simulated	system_sim
4652	2026-07-25	WH-CCU-01	ITM-SSD-01	0	1	82	f	none	simulated	system_sim
4653	2026-07-25	WH-CCU-01	ITM-HDD-01	0	0	51	f	none	simulated	system_sim
4654	2026-07-25	WH-CCU-01	ITM-CHG-01	0	9	77	f	none	simulated	system_sim
4655	2026-07-25	WH-CCU-01	ITM-CBL-01	0	10	229	f	none	simulated	system_sim
4656	2026-07-26	WH-BLR-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
4657	2026-07-26	WH-BLR-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
4658	2026-07-26	WH-BLR-01	ITM-RAM-01	0	7	67	f	none	simulated	system_sim
4659	2026-07-26	WH-BLR-01	ITM-SSD-01	0	0	79	f	none	simulated	system_sim
4660	2026-07-26	WH-BLR-01	ITM-HDD-01	0	0	44	f	none	simulated	system_sim
4661	2026-07-26	WH-BLR-01	ITM-CHG-01	150	5	218	f	none	simulated	system_sim
4662	2026-07-26	WH-BLR-01	ITM-CBL-01	0	5	236	f	none	simulated	system_sim
4663	2026-07-26	WH-CHN-01	ITM-CPU-01	0	2	50	f	none	simulated	system_sim
4664	2026-07-26	WH-CHN-01	ITM-GPU-01	0	1	24	f	none	simulated	system_sim
4665	2026-07-26	WH-CHN-01	ITM-RAM-01	0	7	73	f	none	simulated	system_sim
4666	2026-07-26	WH-CHN-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
4667	2026-07-26	WH-CHN-01	ITM-HDD-01	0	3	43	f	none	simulated	system_sim
4668	2026-07-26	WH-CHN-01	ITM-CHG-01	150	3	221	f	none	simulated	system_sim
4669	2026-07-26	WH-CHN-01	ITM-CBL-01	0	1	230	f	none	simulated	system_sim
4670	2026-07-26	WH-BOM-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
4671	2026-07-26	WH-BOM-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
4672	2026-07-26	WH-BOM-01	ITM-RAM-01	0	7	60	f	none	simulated	system_sim
4673	2026-07-26	WH-BOM-01	ITM-SSD-01	0	1	80	f	none	simulated	system_sim
4674	2026-07-26	WH-BOM-01	ITM-HDD-01	0	2	38	f	none	simulated	system_sim
4675	2026-07-26	WH-BOM-01	ITM-CHG-01	0	10	67	f	none	simulated	system_sim
4676	2026-07-26	WH-BOM-01	ITM-CBL-01	0	4	212	f	none	simulated	system_sim
4677	2026-07-26	WH-DEL-01	ITM-CPU-01	0	2	29	f	none	simulated	system_sim
4678	2026-07-26	WH-DEL-01	ITM-GPU-01	0	2	20	f	none	simulated	system_sim
4679	2026-07-26	WH-DEL-01	ITM-RAM-01	0	7	85	f	none	simulated	system_sim
4680	2026-07-26	WH-DEL-01	ITM-SSD-01	0	1	79	f	none	simulated	system_sim
4681	2026-07-26	WH-DEL-01	ITM-HDD-01	0	0	41	f	none	simulated	system_sim
4682	2026-07-26	WH-DEL-01	ITM-CHG-01	0	9	77	f	none	simulated	system_sim
4683	2026-07-26	WH-DEL-01	ITM-CBL-01	0	2	242	f	none	simulated	system_sim
4684	2026-07-26	WH-CCU-01	ITM-CPU-01	0	1	25	f	none	simulated	system_sim
4685	2026-07-26	WH-CCU-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
4686	2026-07-26	WH-CCU-01	ITM-RAM-01	0	4	60	f	none	simulated	system_sim
4687	2026-07-26	WH-CCU-01	ITM-SSD-01	0	0	82	f	none	simulated	system_sim
4688	2026-07-26	WH-CCU-01	ITM-HDD-01	0	0	51	f	none	simulated	system_sim
4689	2026-07-26	WH-CCU-01	ITM-CHG-01	0	5	72	f	none	simulated	system_sim
4690	2026-07-26	WH-CCU-01	ITM-CBL-01	0	6	223	f	none	simulated	system_sim
4691	2026-07-27	WH-BLR-01	ITM-CPU-01	0	2	27	f	none	simulated	system_sim
4692	2026-07-27	WH-BLR-01	ITM-GPU-01	0	2	18	f	none	simulated	system_sim
4693	2026-07-27	WH-BLR-01	ITM-RAM-01	0	4	63	f	none	simulated	system_sim
4694	2026-07-27	WH-BLR-01	ITM-SSD-01	0	1	78	f	none	simulated	system_sim
4695	2026-07-27	WH-BLR-01	ITM-HDD-01	0	2	42	f	none	simulated	system_sim
4696	2026-07-27	WH-BLR-01	ITM-CHG-01	0	2	216	f	none	simulated	system_sim
4697	2026-07-27	WH-BLR-01	ITM-CBL-01	0	5	231	f	none	simulated	system_sim
4698	2026-07-27	WH-CHN-01	ITM-CPU-01	0	3	47	f	none	simulated	system_sim
4699	2026-07-27	WH-CHN-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
4700	2026-07-27	WH-CHN-01	ITM-RAM-01	0	8	65	f	none	simulated	system_sim
4701	2026-07-27	WH-CHN-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
4702	2026-07-27	WH-CHN-01	ITM-HDD-01	0	2	41	f	none	simulated	system_sim
4703	2026-07-27	WH-CHN-01	ITM-CHG-01	0	8	213	f	none	simulated	system_sim
4704	2026-07-27	WH-CHN-01	ITM-CBL-01	0	7	223	f	none	simulated	system_sim
4705	2026-07-27	WH-BOM-01	ITM-CPU-01	0	2	27	f	none	simulated	system_sim
4706	2026-07-27	WH-BOM-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
4707	2026-07-27	WH-BOM-01	ITM-RAM-01	0	6	54	f	none	simulated	system_sim
4708	2026-07-27	WH-BOM-01	ITM-SSD-01	0	2	78	f	none	simulated	system_sim
4709	2026-07-27	WH-BOM-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
4710	2026-07-27	WH-BOM-01	ITM-CHG-01	150	4	213	f	none	simulated	system_sim
4711	2026-07-27	WH-BOM-01	ITM-CBL-01	0	10	202	f	none	simulated	system_sim
4712	2026-07-27	WH-DEL-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
4713	2026-07-27	WH-DEL-01	ITM-GPU-01	0	2	18	f	none	simulated	system_sim
4714	2026-07-27	WH-DEL-01	ITM-RAM-01	0	6	79	f	none	simulated	system_sim
4715	2026-07-27	WH-DEL-01	ITM-SSD-01	0	1	78	f	none	simulated	system_sim
4716	2026-07-27	WH-DEL-01	ITM-HDD-01	0	2	39	f	none	simulated	system_sim
4717	2026-07-27	WH-DEL-01	ITM-CHG-01	0	10	67	f	none	simulated	system_sim
4718	2026-07-27	WH-DEL-01	ITM-CBL-01	0	10	232	f	none	simulated	system_sim
4719	2026-07-27	WH-CCU-01	ITM-CPU-01	0	1	24	f	none	simulated	system_sim
4720	2026-07-27	WH-CCU-01	ITM-GPU-01	0	1	16	f	none	simulated	system_sim
4721	2026-07-27	WH-CCU-01	ITM-RAM-01	0	5	55	f	none	simulated	system_sim
4722	2026-07-27	WH-CCU-01	ITM-SSD-01	0	3	79	f	none	simulated	system_sim
4723	2026-07-27	WH-CCU-01	ITM-HDD-01	0	1	50	f	none	simulated	system_sim
4724	2026-07-27	WH-CCU-01	ITM-CHG-01	150	6	216	f	none	simulated	system_sim
4725	2026-07-27	WH-CCU-01	ITM-CBL-01	0	8	215	f	none	simulated	system_sim
4726	2026-07-28	WH-BLR-01	ITM-CPU-01	0	1	26	f	none	simulated	system_sim
4727	2026-07-28	WH-BLR-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
4728	2026-07-28	WH-BLR-01	ITM-RAM-01	0	10	53	f	none	simulated	system_sim
4729	2026-07-28	WH-BLR-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
4730	2026-07-28	WH-BLR-01	ITM-HDD-01	0	1	41	f	none	simulated	system_sim
4731	2026-07-28	WH-BLR-01	ITM-CHG-01	0	5	211	f	none	simulated	system_sim
4732	2026-07-28	WH-BLR-01	ITM-CBL-01	0	5	226	f	none	simulated	system_sim
4733	2026-07-28	WH-CHN-01	ITM-CPU-01	0	3	44	f	none	simulated	system_sim
4734	2026-07-28	WH-CHN-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
4735	2026-07-28	WH-CHN-01	ITM-RAM-01	0	3	62	f	none	simulated	system_sim
4736	2026-07-28	WH-CHN-01	ITM-SSD-01	0	3	75	f	none	simulated	system_sim
4737	2026-07-28	WH-CHN-01	ITM-HDD-01	0	2	39	f	none	simulated	system_sim
4738	2026-07-28	WH-CHN-01	ITM-CHG-01	0	6	207	f	none	simulated	system_sim
4739	2026-07-28	WH-CHN-01	ITM-CBL-01	0	3	220	f	none	simulated	system_sim
4740	2026-07-28	WH-BOM-01	ITM-CPU-01	0	1	26	f	none	simulated	system_sim
4741	2026-07-28	WH-BOM-01	ITM-GPU-01	0	1	18	f	none	simulated	system_sim
4742	2026-07-28	WH-BOM-01	ITM-RAM-01	0	10	44	f	none	simulated	system_sim
4743	2026-07-28	WH-BOM-01	ITM-SSD-01	0	3	75	f	none	simulated	system_sim
4744	2026-07-28	WH-BOM-01	ITM-HDD-01	0	1	37	f	none	simulated	system_sim
4745	2026-07-28	WH-BOM-01	ITM-CHG-01	0	6	207	f	none	simulated	system_sim
4746	2026-07-28	WH-BOM-01	ITM-CBL-01	0	7	195	f	none	simulated	system_sim
4747	2026-07-28	WH-DEL-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
4748	2026-07-28	WH-DEL-01	ITM-GPU-01	0	2	16	f	none	simulated	system_sim
4749	2026-07-28	WH-DEL-01	ITM-RAM-01	0	3	76	f	none	simulated	system_sim
4750	2026-07-28	WH-DEL-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
4751	2026-07-28	WH-DEL-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
4752	2026-07-28	WH-DEL-01	ITM-CHG-01	150	1	216	f	none	simulated	system_sim
4753	2026-07-28	WH-DEL-01	ITM-CBL-01	0	4	228	f	none	simulated	system_sim
4754	2026-07-28	WH-CCU-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
4755	2026-07-28	WH-CCU-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
4756	2026-07-28	WH-CCU-01	ITM-RAM-01	0	10	45	f	none	simulated	system_sim
4757	2026-07-28	WH-CCU-01	ITM-SSD-01	0	3	76	f	none	simulated	system_sim
4758	2026-07-28	WH-CCU-01	ITM-HDD-01	0	1	49	f	none	simulated	system_sim
4759	2026-07-28	WH-CCU-01	ITM-CHG-01	0	7	209	f	none	simulated	system_sim
4760	2026-07-28	WH-CCU-01	ITM-CBL-01	0	8	207	f	none	simulated	system_sim
4761	2026-07-29	WH-BLR-01	ITM-CPU-01	0	0	26	f	none	simulated	system_sim
4762	2026-07-29	WH-BLR-01	ITM-GPU-01	0	1	16	f	none	simulated	system_sim
4763	2026-07-29	WH-BLR-01	ITM-RAM-01	0	6	47	f	none	simulated	system_sim
4764	2026-07-29	WH-BLR-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
4765	2026-07-29	WH-BLR-01	ITM-HDD-01	0	0	41	f	none	simulated	system_sim
4766	2026-07-29	WH-BLR-01	ITM-CHG-01	0	1	210	f	none	simulated	system_sim
4767	2026-07-29	WH-BLR-01	ITM-CBL-01	0	10	216	f	none	simulated	system_sim
4768	2026-07-29	WH-CHN-01	ITM-CPU-01	0	2	42	f	none	simulated	system_sim
4769	2026-07-29	WH-CHN-01	ITM-GPU-01	0	1	23	f	none	simulated	system_sim
4770	2026-07-29	WH-CHN-01	ITM-RAM-01	0	6	56	f	none	simulated	system_sim
4771	2026-07-29	WH-CHN-01	ITM-SSD-01	0	0	75	f	none	simulated	system_sim
4772	2026-07-29	WH-CHN-01	ITM-HDD-01	0	2	37	f	none	simulated	system_sim
4773	2026-07-29	WH-CHN-01	ITM-CHG-01	0	3	204	f	none	simulated	system_sim
4774	2026-07-29	WH-CHN-01	ITM-CBL-01	0	8	212	f	none	simulated	system_sim
4775	2026-07-29	WH-BOM-01	ITM-CPU-01	0	1	25	f	none	simulated	system_sim
4776	2026-07-29	WH-BOM-01	ITM-GPU-01	0	2	16	f	none	simulated	system_sim
4777	2026-07-29	WH-BOM-01	ITM-RAM-01	0	3	41	f	none	simulated	system_sim
4778	2026-07-29	WH-BOM-01	ITM-SSD-01	0	0	75	f	none	simulated	system_sim
4779	2026-07-29	WH-BOM-01	ITM-HDD-01	0	1	36	f	none	simulated	system_sim
4780	2026-07-29	WH-BOM-01	ITM-CHG-01	0	3	204	f	none	simulated	system_sim
4781	2026-07-29	WH-BOM-01	ITM-CBL-01	0	6	189	f	none	simulated	system_sim
4782	2026-07-29	WH-DEL-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
4783	2026-07-29	WH-DEL-01	ITM-GPU-01	0	1	15	f	none	simulated	system_sim
4784	2026-07-29	WH-DEL-01	ITM-RAM-01	0	7	69	f	none	simulated	system_sim
4785	2026-07-29	WH-DEL-01	ITM-SSD-01	0	3	75	f	none	simulated	system_sim
4786	2026-07-29	WH-DEL-01	ITM-HDD-01	0	2	37	f	none	simulated	system_sim
4787	2026-07-29	WH-DEL-01	ITM-CHG-01	0	3	213	f	none	simulated	system_sim
4788	2026-07-29	WH-DEL-01	ITM-CBL-01	0	7	221	f	none	simulated	system_sim
4789	2026-07-29	WH-CCU-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
4790	2026-07-29	WH-CCU-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
4791	2026-07-29	WH-CCU-01	ITM-RAM-01	0	4	41	f	none	simulated	system_sim
4792	2026-07-29	WH-CCU-01	ITM-SSD-01	0	0	76	f	none	simulated	system_sim
4793	2026-07-29	WH-CCU-01	ITM-HDD-01	0	1	48	f	none	simulated	system_sim
4794	2026-07-29	WH-CCU-01	ITM-CHG-01	0	2	207	f	none	simulated	system_sim
4795	2026-07-29	WH-CCU-01	ITM-CBL-01	0	9	198	f	none	simulated	system_sim
4796	2026-07-30	WH-BLR-01	ITM-CPU-01	0	3	23	f	none	simulated	system_sim
4797	2026-07-30	WH-BLR-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
4798	2026-07-30	WH-BLR-01	ITM-RAM-01	0	7	40	f	none	simulated	system_sim
4799	2026-07-30	WH-BLR-01	ITM-SSD-01	0	3	75	f	none	simulated	system_sim
4800	2026-07-30	WH-BLR-01	ITM-HDD-01	0	0	41	f	none	simulated	system_sim
4801	2026-07-30	WH-BLR-01	ITM-CHG-01	0	7	203	f	none	simulated	system_sim
4802	2026-07-30	WH-BLR-01	ITM-CBL-01	0	3	213	f	none	simulated	system_sim
4803	2026-07-30	WH-CHN-01	ITM-CPU-01	0	3	39	f	none	simulated	system_sim
4804	2026-07-30	WH-CHN-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
4805	2026-07-30	WH-CHN-01	ITM-RAM-01	0	10	46	f	none	simulated	system_sim
4806	2026-07-30	WH-CHN-01	ITM-SSD-01	0	0	75	f	none	simulated	system_sim
4807	2026-07-30	WH-CHN-01	ITM-HDD-01	0	3	34	f	none	simulated	system_sim
4808	2026-07-30	WH-CHN-01	ITM-CHG-01	0	2	202	f	none	simulated	system_sim
4809	2026-07-30	WH-CHN-01	ITM-CBL-01	0	2	210	f	none	simulated	system_sim
4810	2026-07-30	WH-BOM-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
4811	2026-07-30	WH-BOM-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
4812	2026-07-30	WH-BOM-01	ITM-RAM-01	0	9	32	f	none	simulated	system_sim
4813	2026-07-30	WH-BOM-01	ITM-SSD-01	0	1	74	f	none	simulated	system_sim
4814	2026-07-30	WH-BOM-01	ITM-HDD-01	0	1	35	f	none	simulated	system_sim
4815	2026-07-30	WH-BOM-01	ITM-CHG-01	0	7	197	f	none	simulated	system_sim
4816	2026-07-30	WH-BOM-01	ITM-CBL-01	0	1	188	f	none	simulated	system_sim
4817	2026-07-30	WH-DEL-01	ITM-CPU-01	0	1	28	f	none	simulated	system_sim
4818	2026-07-30	WH-DEL-01	ITM-GPU-01	0	2	13	f	none	simulated	system_sim
4819	2026-07-30	WH-DEL-01	ITM-RAM-01	0	3	66	f	none	simulated	system_sim
4820	2026-07-30	WH-DEL-01	ITM-SSD-01	0	0	75	f	none	simulated	system_sim
4821	2026-07-30	WH-DEL-01	ITM-HDD-01	0	0	37	f	none	simulated	system_sim
4822	2026-07-30	WH-DEL-01	ITM-CHG-01	0	7	206	f	none	simulated	system_sim
4823	2026-07-30	WH-DEL-01	ITM-CBL-01	0	9	212	f	none	simulated	system_sim
4824	2026-07-30	WH-CCU-01	ITM-CPU-01	0	3	21	f	none	simulated	system_sim
4825	2026-07-30	WH-CCU-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
4826	2026-07-30	WH-CCU-01	ITM-RAM-01	0	1	40	f	none	simulated	system_sim
4827	2026-07-30	WH-CCU-01	ITM-SSD-01	0	3	73	f	none	simulated	system_sim
4828	2026-07-30	WH-CCU-01	ITM-HDD-01	0	2	46	f	none	simulated	system_sim
4829	2026-07-30	WH-CCU-01	ITM-CHG-01	0	2	205	f	none	simulated	system_sim
4830	2026-07-30	WH-CCU-01	ITM-CBL-01	0	6	192	f	none	simulated	system_sim
4831	2026-07-31	WH-BLR-01	ITM-CPU-01	0	0	23	f	none	simulated	system_sim
4832	2026-07-31	WH-BLR-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
4833	2026-07-31	WH-BLR-01	ITM-RAM-01	0	7	33	f	none	simulated	system_sim
4834	2026-07-31	WH-BLR-01	ITM-SSD-01	0	3	72	f	none	simulated	system_sim
4835	2026-07-31	WH-BLR-01	ITM-HDD-01	0	2	39	f	none	simulated	system_sim
4836	2026-07-31	WH-BLR-01	ITM-CHG-01	0	7	196	f	none	simulated	system_sim
4837	2026-07-31	WH-BLR-01	ITM-CBL-01	0	2	211	f	none	simulated	system_sim
4838	2026-07-31	WH-CHN-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
4839	2026-07-31	WH-CHN-01	ITM-GPU-01	0	1	22	f	none	simulated	system_sim
4840	2026-07-31	WH-CHN-01	ITM-RAM-01	0	3	43	f	none	simulated	system_sim
4841	2026-07-31	WH-CHN-01	ITM-SSD-01	0	3	72	f	none	simulated	system_sim
4842	2026-07-31	WH-CHN-01	ITM-HDD-01	0	2	32	f	none	simulated	system_sim
4843	2026-07-31	WH-CHN-01	ITM-CHG-01	0	8	194	f	none	simulated	system_sim
4844	2026-07-31	WH-CHN-01	ITM-CBL-01	0	5	205	f	none	simulated	system_sim
4845	2026-07-31	WH-BOM-01	ITM-CPU-01	0	1	24	f	none	simulated	system_sim
4846	2026-07-31	WH-BOM-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
4847	2026-07-31	WH-BOM-01	ITM-RAM-01	75	1	106	f	none	simulated	system_sim
4848	2026-07-31	WH-BOM-01	ITM-SSD-01	0	1	73	f	none	simulated	system_sim
4849	2026-07-31	WH-BOM-01	ITM-HDD-01	0	0	35	f	none	simulated	system_sim
4850	2026-07-31	WH-BOM-01	ITM-CHG-01	0	6	191	f	none	simulated	system_sim
4851	2026-07-31	WH-BOM-01	ITM-CBL-01	0	1	187	f	none	simulated	system_sim
4852	2026-07-31	WH-DEL-01	ITM-CPU-01	0	0	28	f	none	simulated	system_sim
4853	2026-07-31	WH-DEL-01	ITM-GPU-01	30	0	43	f	none	simulated	system_sim
4854	2026-07-31	WH-DEL-01	ITM-RAM-01	0	5	61	f	none	simulated	system_sim
4855	2026-07-31	WH-DEL-01	ITM-SSD-01	0	1	74	f	none	simulated	system_sim
4856	2026-07-31	WH-DEL-01	ITM-HDD-01	0	3	34	f	none	simulated	system_sim
4857	2026-07-31	WH-DEL-01	ITM-CHG-01	0	7	199	f	none	simulated	system_sim
4858	2026-07-31	WH-DEL-01	ITM-CBL-01	0	7	205	f	none	simulated	system_sim
4859	2026-07-31	WH-CCU-01	ITM-CPU-01	45	0	66	f	none	simulated	system_sim
4860	2026-07-31	WH-CCU-01	ITM-GPU-01	0	2	14	f	none	simulated	system_sim
4861	2026-07-31	WH-CCU-01	ITM-RAM-01	0	9	31	f	none	simulated	system_sim
4862	2026-07-31	WH-CCU-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
4863	2026-07-31	WH-CCU-01	ITM-HDD-01	0	1	45	f	none	simulated	system_sim
4864	2026-07-31	WH-CCU-01	ITM-CHG-01	0	4	201	f	none	simulated	system_sim
4865	2026-07-31	WH-CCU-01	ITM-CBL-01	0	9	183	f	none	simulated	system_sim
4866	2026-08-01	WH-BLR-01	ITM-CPU-01	0	1	22	f	none	simulated	system_sim
4867	2026-08-01	WH-BLR-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
4868	2026-08-01	WH-BLR-01	ITM-RAM-01	75	2	106	f	none	simulated	system_sim
4869	2026-08-01	WH-BLR-01	ITM-SSD-01	0	0	72	f	none	simulated	system_sim
4870	2026-08-01	WH-BLR-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
4871	2026-08-01	WH-BLR-01	ITM-CHG-01	0	10	186	f	none	simulated	system_sim
4872	2026-08-01	WH-BLR-01	ITM-CBL-01	0	6	205	f	none	simulated	system_sim
4873	2026-08-01	WH-CHN-01	ITM-CPU-01	0	3	36	f	none	simulated	system_sim
4874	2026-08-01	WH-CHN-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
4875	2026-08-01	WH-CHN-01	ITM-RAM-01	0	9	34	f	none	simulated	system_sim
4876	2026-08-01	WH-CHN-01	ITM-SSD-01	0	2	70	f	none	simulated	system_sim
4877	2026-08-01	WH-CHN-01	ITM-HDD-01	0	0	32	f	none	simulated	system_sim
4878	2026-08-01	WH-CHN-01	ITM-CHG-01	0	8	186	f	none	simulated	system_sim
4879	2026-08-01	WH-CHN-01	ITM-CBL-01	0	10	195	f	none	simulated	system_sim
4880	2026-08-01	WH-BOM-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
4881	2026-08-01	WH-BOM-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
4882	2026-08-01	WH-BOM-01	ITM-RAM-01	0	8	98	f	none	simulated	system_sim
4883	2026-08-01	WH-BOM-01	ITM-SSD-01	0	2	71	f	none	simulated	system_sim
4884	2026-08-01	WH-BOM-01	ITM-HDD-01	0	1	34	f	none	simulated	system_sim
4885	2026-08-01	WH-BOM-01	ITM-CHG-01	0	1	190	f	none	simulated	system_sim
4886	2026-08-01	WH-BOM-01	ITM-CBL-01	0	7	180	f	none	simulated	system_sim
4887	2026-08-01	WH-DEL-01	ITM-CPU-01	0	1	27	f	none	simulated	system_sim
4888	2026-08-01	WH-DEL-01	ITM-GPU-01	0	0	43	f	none	simulated	system_sim
4889	2026-08-01	WH-DEL-01	ITM-RAM-01	0	1	60	f	none	simulated	system_sim
4890	2026-08-01	WH-DEL-01	ITM-SSD-01	0	0	74	f	none	simulated	system_sim
4891	2026-08-01	WH-DEL-01	ITM-HDD-01	0	0	34	f	none	simulated	system_sim
4892	2026-08-01	WH-DEL-01	ITM-CHG-01	0	6	193	f	none	simulated	system_sim
4893	2026-08-01	WH-DEL-01	ITM-CBL-01	0	8	197	f	none	simulated	system_sim
4894	2026-08-01	WH-CCU-01	ITM-CPU-01	0	0	66	f	none	simulated	system_sim
4895	2026-08-01	WH-CCU-01	ITM-GPU-01	30	0	44	f	none	simulated	system_sim
4896	2026-08-01	WH-CCU-01	ITM-RAM-01	75	10	96	f	none	simulated	system_sim
4897	2026-08-01	WH-CCU-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
4898	2026-08-01	WH-CCU-01	ITM-HDD-01	0	0	45	f	none	simulated	system_sim
4899	2026-08-01	WH-CCU-01	ITM-CHG-01	0	2	199	f	none	simulated	system_sim
4900	2026-08-01	WH-CCU-01	ITM-CBL-01	0	9	174	f	none	simulated	system_sim
4901	2026-08-02	WH-BLR-01	ITM-CPU-01	45	3	64	f	none	simulated	system_sim
4902	2026-08-02	WH-BLR-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
4903	2026-08-02	WH-BLR-01	ITM-RAM-01	0	4	102	f	none	simulated	system_sim
4904	2026-08-02	WH-BLR-01	ITM-SSD-01	0	0	72	f	none	simulated	system_sim
4905	2026-08-02	WH-BLR-01	ITM-HDD-01	0	3	36	f	none	simulated	system_sim
4906	2026-08-02	WH-BLR-01	ITM-CHG-01	0	3	183	f	none	simulated	system_sim
4907	2026-08-02	WH-BLR-01	ITM-CBL-01	0	6	199	f	none	simulated	system_sim
4908	2026-08-02	WH-CHN-01	ITM-CPU-01	0	2	34	f	none	simulated	system_sim
4909	2026-08-02	WH-CHN-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
4910	2026-08-02	WH-CHN-01	ITM-RAM-01	75	5	104	f	none	simulated	system_sim
4911	2026-08-02	WH-CHN-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
4912	2026-08-02	WH-CHN-01	ITM-HDD-01	0	1	31	f	none	simulated	system_sim
4913	2026-08-02	WH-CHN-01	ITM-CHG-01	0	10	176	f	none	simulated	system_sim
4914	2026-08-02	WH-CHN-01	ITM-CBL-01	0	9	186	f	none	simulated	system_sim
4915	2026-08-02	WH-BOM-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
4916	2026-08-02	WH-BOM-01	ITM-GPU-01	0	1	15	f	none	simulated	system_sim
4917	2026-08-02	WH-BOM-01	ITM-RAM-01	0	8	90	f	none	simulated	system_sim
4918	2026-08-02	WH-BOM-01	ITM-SSD-01	0	2	69	f	none	simulated	system_sim
4919	2026-08-02	WH-BOM-01	ITM-HDD-01	0	0	34	f	none	simulated	system_sim
4920	2026-08-02	WH-BOM-01	ITM-CHG-01	0	2	188	f	none	simulated	system_sim
4921	2026-08-02	WH-BOM-01	ITM-CBL-01	0	1	179	f	none	simulated	system_sim
4922	2026-08-02	WH-DEL-01	ITM-CPU-01	0	2	25	f	none	simulated	system_sim
4923	2026-08-02	WH-DEL-01	ITM-GPU-01	0	2	41	f	none	simulated	system_sim
4924	2026-08-02	WH-DEL-01	ITM-RAM-01	0	7	53	f	none	simulated	system_sim
4925	2026-08-02	WH-DEL-01	ITM-SSD-01	0	0	74	f	none	simulated	system_sim
4926	2026-08-02	WH-DEL-01	ITM-HDD-01	0	3	31	f	none	simulated	system_sim
4927	2026-08-02	WH-DEL-01	ITM-CHG-01	0	1	192	f	none	simulated	system_sim
4928	2026-08-02	WH-DEL-01	ITM-CBL-01	0	7	190	f	none	simulated	system_sim
4929	2026-08-02	WH-CCU-01	ITM-CPU-01	0	1	65	f	none	simulated	system_sim
4930	2026-08-02	WH-CCU-01	ITM-GPU-01	0	0	44	f	none	simulated	system_sim
4931	2026-08-02	WH-CCU-01	ITM-RAM-01	0	7	89	f	none	simulated	system_sim
4932	2026-08-02	WH-CCU-01	ITM-SSD-01	0	3	70	f	none	simulated	system_sim
4933	2026-08-02	WH-CCU-01	ITM-HDD-01	0	3	42	f	none	simulated	system_sim
4934	2026-08-02	WH-CCU-01	ITM-CHG-01	0	5	194	f	none	simulated	system_sim
4935	2026-08-02	WH-CCU-01	ITM-CBL-01	0	6	168	f	none	simulated	system_sim
4936	2026-08-03	WH-BLR-01	ITM-CPU-01	0	0	64	f	none	simulated	system_sim
4937	2026-08-03	WH-BLR-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
4938	2026-08-03	WH-BLR-01	ITM-RAM-01	0	6	96	f	none	simulated	system_sim
4939	2026-08-03	WH-BLR-01	ITM-SSD-01	0	0	72	f	none	simulated	system_sim
4940	2026-08-03	WH-BLR-01	ITM-HDD-01	0	3	33	f	none	simulated	system_sim
4941	2026-08-03	WH-BLR-01	ITM-CHG-01	0	6	177	f	none	simulated	system_sim
4942	2026-08-03	WH-BLR-01	ITM-CBL-01	0	7	192	f	none	simulated	system_sim
4943	2026-08-03	WH-CHN-01	ITM-CPU-01	0	3	31	f	none	simulated	system_sim
4944	2026-08-03	WH-CHN-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
4945	2026-08-03	WH-CHN-01	ITM-RAM-01	0	5	99	f	none	simulated	system_sim
4946	2026-08-03	WH-CHN-01	ITM-SSD-01	0	3	67	f	none	simulated	system_sim
4947	2026-08-03	WH-CHN-01	ITM-HDD-01	0	2	29	f	none	simulated	system_sim
4948	2026-08-03	WH-CHN-01	ITM-CHG-01	0	1	175	f	none	simulated	system_sim
4949	2026-08-03	WH-CHN-01	ITM-CBL-01	0	7	179	f	none	simulated	system_sim
4950	2026-08-03	WH-BOM-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
4951	2026-08-03	WH-BOM-01	ITM-GPU-01	0	1	14	f	none	simulated	system_sim
4952	2026-08-03	WH-BOM-01	ITM-RAM-01	0	2	88	f	none	simulated	system_sim
4953	2026-08-03	WH-BOM-01	ITM-SSD-01	0	1	68	f	none	simulated	system_sim
4954	2026-08-03	WH-BOM-01	ITM-HDD-01	0	1	33	f	none	simulated	system_sim
4955	2026-08-03	WH-BOM-01	ITM-CHG-01	0	5	183	f	none	simulated	system_sim
4956	2026-08-03	WH-BOM-01	ITM-CBL-01	0	1	178	f	none	simulated	system_sim
4957	2026-08-03	WH-DEL-01	ITM-CPU-01	0	2	23	f	none	simulated	system_sim
4958	2026-08-03	WH-DEL-01	ITM-GPU-01	0	2	39	f	none	simulated	system_sim
4959	2026-08-03	WH-DEL-01	ITM-RAM-01	0	2	51	f	none	simulated	system_sim
4960	2026-08-03	WH-DEL-01	ITM-SSD-01	0	0	74	f	none	simulated	system_sim
4961	2026-08-03	WH-DEL-01	ITM-HDD-01	0	2	29	f	none	simulated	system_sim
4962	2026-08-03	WH-DEL-01	ITM-CHG-01	0	10	182	f	none	simulated	system_sim
4963	2026-08-03	WH-DEL-01	ITM-CBL-01	0	4	186	f	none	simulated	system_sim
4964	2026-08-03	WH-CCU-01	ITM-CPU-01	0	3	62	f	none	simulated	system_sim
4965	2026-08-03	WH-CCU-01	ITM-GPU-01	0	0	44	f	none	simulated	system_sim
4966	2026-08-03	WH-CCU-01	ITM-RAM-01	0	5	84	f	none	simulated	system_sim
4967	2026-08-03	WH-CCU-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
4968	2026-08-03	WH-CCU-01	ITM-HDD-01	0	1	41	f	none	simulated	system_sim
4969	2026-08-03	WH-CCU-01	ITM-CHG-01	0	4	190	f	none	simulated	system_sim
4970	2026-08-03	WH-CCU-01	ITM-CBL-01	0	7	161	f	none	simulated	system_sim
4971	2026-08-04	WH-BLR-01	ITM-CPU-01	0	0	64	f	none	simulated	system_sim
4972	2026-08-04	WH-BLR-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
4973	2026-08-04	WH-BLR-01	ITM-RAM-01	0	1	95	f	none	simulated	system_sim
4974	2026-08-04	WH-BLR-01	ITM-SSD-01	0	2	70	f	none	simulated	system_sim
4975	2026-08-04	WH-BLR-01	ITM-HDD-01	0	3	30	f	none	simulated	system_sim
4976	2026-08-04	WH-BLR-01	ITM-CHG-01	0	9	168	f	none	simulated	system_sim
4977	2026-08-04	WH-BLR-01	ITM-CBL-01	0	1	191	f	none	simulated	system_sim
4978	2026-08-04	WH-CHN-01	ITM-CPU-01	0	1	30	f	none	simulated	system_sim
4979	2026-08-04	WH-CHN-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
4980	2026-08-04	WH-CHN-01	ITM-RAM-01	0	3	96	f	none	simulated	system_sim
4981	2026-08-04	WH-CHN-01	ITM-SSD-01	0	0	67	f	none	simulated	system_sim
4982	2026-08-04	WH-CHN-01	ITM-HDD-01	60	0	89	f	none	simulated	system_sim
4983	2026-08-04	WH-CHN-01	ITM-CHG-01	0	7	168	f	none	simulated	system_sim
4984	2026-08-04	WH-CHN-01	ITM-CBL-01	0	5	174	f	none	simulated	system_sim
4985	2026-08-04	WH-BOM-01	ITM-CPU-01	0	2	22	f	none	simulated	system_sim
4986	2026-08-04	WH-BOM-01	ITM-GPU-01	30	0	44	f	none	simulated	system_sim
4987	2026-08-04	WH-BOM-01	ITM-RAM-01	0	7	81	f	none	simulated	system_sim
4988	2026-08-04	WH-BOM-01	ITM-SSD-01	0	3	65	f	none	simulated	system_sim
4989	2026-08-04	WH-BOM-01	ITM-HDD-01	0	0	33	f	none	simulated	system_sim
4990	2026-08-04	WH-BOM-01	ITM-CHG-01	0	7	176	f	none	simulated	system_sim
4991	2026-08-04	WH-BOM-01	ITM-CBL-01	0	4	174	f	none	simulated	system_sim
4992	2026-08-04	WH-DEL-01	ITM-CPU-01	0	0	23	f	none	simulated	system_sim
4993	2026-08-04	WH-DEL-01	ITM-GPU-01	0	0	39	f	none	simulated	system_sim
4994	2026-08-04	WH-DEL-01	ITM-RAM-01	0	6	45	f	none	simulated	system_sim
4995	2026-08-04	WH-DEL-01	ITM-SSD-01	0	2	72	f	none	simulated	system_sim
4996	2026-08-04	WH-DEL-01	ITM-HDD-01	60	3	86	f	none	simulated	system_sim
4997	2026-08-04	WH-DEL-01	ITM-CHG-01	0	4	178	f	none	simulated	system_sim
4998	2026-08-04	WH-DEL-01	ITM-CBL-01	0	5	181	f	none	simulated	system_sim
4999	2026-08-04	WH-CCU-01	ITM-CPU-01	0	2	60	f	none	simulated	system_sim
5000	2026-08-04	WH-CCU-01	ITM-GPU-01	0	1	43	f	none	simulated	system_sim
5001	2026-08-04	WH-CCU-01	ITM-RAM-01	0	8	76	f	none	simulated	system_sim
5002	2026-08-04	WH-CCU-01	ITM-SSD-01	0	2	68	f	none	simulated	system_sim
5003	2026-08-04	WH-CCU-01	ITM-HDD-01	0	3	38	f	none	simulated	system_sim
5004	2026-08-04	WH-CCU-01	ITM-CHG-01	0	1	189	f	none	simulated	system_sim
5005	2026-08-04	WH-CCU-01	ITM-CBL-01	0	4	157	f	none	simulated	system_sim
5006	2026-08-05	WH-BLR-01	ITM-CPU-01	0	1	63	f	none	simulated	system_sim
5007	2026-08-05	WH-BLR-01	ITM-GPU-01	0	0	6	t	shrinkage	simulated	system_sim
5008	2026-08-05	WH-BLR-01	ITM-RAM-01	0	6	89	f	none	simulated	system_sim
5009	2026-08-05	WH-BLR-01	ITM-SSD-01	0	1	69	f	none	simulated	system_sim
5010	2026-08-05	WH-BLR-01	ITM-HDD-01	0	1	29	f	none	simulated	system_sim
5011	2026-08-05	WH-BLR-01	ITM-CHG-01	0	9	159	f	none	simulated	system_sim
5012	2026-08-05	WH-BLR-01	ITM-CBL-01	0	10	181	f	none	simulated	system_sim
5013	2026-08-05	WH-CHN-01	ITM-CPU-01	0	0	30	f	none	simulated	system_sim
5014	2026-08-05	WH-CHN-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
5015	2026-08-05	WH-CHN-01	ITM-RAM-01	0	6	90	f	none	simulated	system_sim
5016	2026-08-05	WH-CHN-01	ITM-SSD-01	0	1	66	f	none	simulated	system_sim
5017	2026-08-05	WH-CHN-01	ITM-HDD-01	0	3	86	f	none	simulated	system_sim
5018	2026-08-05	WH-CHN-01	ITM-CHG-01	0	10	158	f	none	simulated	system_sim
5019	2026-08-05	WH-CHN-01	ITM-CBL-01	0	5	169	f	none	simulated	system_sim
5020	2026-08-05	WH-BOM-01	ITM-CPU-01	45	2	65	f	none	simulated	system_sim
5021	2026-08-05	WH-BOM-01	ITM-GPU-01	0	2	42	f	none	simulated	system_sim
5022	2026-08-05	WH-BOM-01	ITM-RAM-01	0	8	73	f	none	simulated	system_sim
5023	2026-08-05	WH-BOM-01	ITM-SSD-01	0	0	65	f	none	simulated	system_sim
5024	2026-08-05	WH-BOM-01	ITM-HDD-01	0	2	31	f	none	simulated	system_sim
5025	2026-08-05	WH-BOM-01	ITM-CHG-01	0	6	170	f	none	simulated	system_sim
5026	2026-08-05	WH-BOM-01	ITM-CBL-01	0	7	167	f	none	simulated	system_sim
5027	2026-08-05	WH-DEL-01	ITM-CPU-01	0	3	20	f	none	simulated	system_sim
5028	2026-08-05	WH-DEL-01	ITM-GPU-01	0	0	39	f	none	simulated	system_sim
5029	2026-08-05	WH-DEL-01	ITM-RAM-01	0	1	44	f	none	simulated	system_sim
5030	2026-08-05	WH-DEL-01	ITM-SSD-01	0	0	72	f	none	simulated	system_sim
5031	2026-08-05	WH-DEL-01	ITM-HDD-01	0	2	84	f	none	simulated	system_sim
5032	2026-08-05	WH-DEL-01	ITM-CHG-01	0	9	169	f	none	simulated	system_sim
5033	2026-08-05	WH-DEL-01	ITM-CBL-01	0	10	171	f	none	simulated	system_sim
5034	2026-08-05	WH-CCU-01	ITM-CPU-01	0	0	60	f	none	simulated	system_sim
5035	2026-08-05	WH-CCU-01	ITM-GPU-01	0	2	41	f	none	simulated	system_sim
5036	2026-08-05	WH-CCU-01	ITM-RAM-01	0	7	69	f	none	simulated	system_sim
5037	2026-08-05	WH-CCU-01	ITM-SSD-01	0	0	68	f	none	simulated	system_sim
5038	2026-08-05	WH-CCU-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
5039	2026-08-05	WH-CCU-01	ITM-CHG-01	0	1	188	f	none	simulated	system_sim
5040	2026-08-05	WH-CCU-01	ITM-CBL-01	0	3	154	f	none	simulated	system_sim
5041	2026-08-06	WH-BLR-01	ITM-CPU-01	0	0	63	f	none	simulated	system_sim
5042	2026-08-06	WH-BLR-01	ITM-GPU-01	30	2	34	f	none	simulated	system_sim
5043	2026-08-06	WH-BLR-01	ITM-RAM-01	0	3	86	f	none	simulated	system_sim
5044	2026-08-06	WH-BLR-01	ITM-SSD-01	0	3	66	f	none	simulated	system_sim
5045	2026-08-06	WH-BLR-01	ITM-HDD-01	60	1	88	f	none	simulated	system_sim
5046	2026-08-06	WH-BLR-01	ITM-CHG-01	0	5	154	f	none	simulated	system_sim
5047	2026-08-06	WH-BLR-01	ITM-CBL-01	0	2	179	f	none	simulated	system_sim
5048	2026-08-06	WH-CHN-01	ITM-CPU-01	0	2	28	f	none	simulated	system_sim
5049	2026-08-06	WH-CHN-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
5050	2026-08-06	WH-CHN-01	ITM-RAM-01	0	10	80	f	none	simulated	system_sim
5051	2026-08-06	WH-CHN-01	ITM-SSD-01	0	1	65	f	none	simulated	system_sim
5052	2026-08-06	WH-CHN-01	ITM-HDD-01	0	3	83	f	none	simulated	system_sim
5053	2026-08-06	WH-CHN-01	ITM-CHG-01	0	8	150	f	none	simulated	system_sim
5054	2026-08-06	WH-CHN-01	ITM-CBL-01	0	5	164	f	none	simulated	system_sim
5055	2026-08-06	WH-BOM-01	ITM-CPU-01	0	2	63	f	none	simulated	system_sim
5056	2026-08-06	WH-BOM-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
5057	2026-08-06	WH-BOM-01	ITM-RAM-01	0	3	70	f	none	simulated	system_sim
5058	2026-08-06	WH-BOM-01	ITM-SSD-01	0	2	63	f	none	simulated	system_sim
5059	2026-08-06	WH-BOM-01	ITM-HDD-01	0	3	28	f	none	simulated	system_sim
5060	2026-08-06	WH-BOM-01	ITM-CHG-01	0	2	168	f	none	simulated	system_sim
5061	2026-08-06	WH-BOM-01	ITM-CBL-01	0	7	160	f	none	simulated	system_sim
5062	2026-08-06	WH-DEL-01	ITM-CPU-01	45	1	64	f	none	simulated	system_sim
5063	2026-08-06	WH-DEL-01	ITM-GPU-01	0	2	37	f	none	simulated	system_sim
5064	2026-08-06	WH-DEL-01	ITM-RAM-01	0	4	40	f	none	simulated	system_sim
5065	2026-08-06	WH-DEL-01	ITM-SSD-01	0	1	71	f	none	simulated	system_sim
5066	2026-08-06	WH-DEL-01	ITM-HDD-01	0	2	82	f	none	simulated	system_sim
5067	2026-08-06	WH-DEL-01	ITM-CHG-01	0	10	159	f	none	simulated	system_sim
5068	2026-08-06	WH-DEL-01	ITM-CBL-01	0	1	170	f	none	simulated	system_sim
5069	2026-08-06	WH-CCU-01	ITM-CPU-01	0	1	59	f	none	simulated	system_sim
5070	2026-08-06	WH-CCU-01	ITM-GPU-01	0	2	39	f	none	simulated	system_sim
5071	2026-08-06	WH-CCU-01	ITM-RAM-01	0	2	67	f	none	simulated	system_sim
5072	2026-08-06	WH-CCU-01	ITM-SSD-01	0	1	67	f	none	simulated	system_sim
5073	2026-08-06	WH-CCU-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
5074	2026-08-06	WH-CCU-01	ITM-CHG-01	0	2	186	f	none	simulated	system_sim
5075	2026-08-06	WH-CCU-01	ITM-CBL-01	0	3	151	f	none	simulated	system_sim
5076	2026-08-07	WH-BLR-01	ITM-CPU-01	0	0	63	f	none	simulated	system_sim
5077	2026-08-07	WH-BLR-01	ITM-GPU-01	0	2	32	f	none	simulated	system_sim
5078	2026-08-07	WH-BLR-01	ITM-RAM-01	0	8	78	f	none	simulated	system_sim
5079	2026-08-07	WH-BLR-01	ITM-SSD-01	0	0	66	f	none	simulated	system_sim
5080	2026-08-07	WH-BLR-01	ITM-HDD-01	0	0	88	f	none	simulated	system_sim
5081	2026-08-07	WH-BLR-01	ITM-CHG-01	0	5	149	f	none	simulated	system_sim
5082	2026-08-07	WH-BLR-01	ITM-CBL-01	0	9	170	f	none	simulated	system_sim
5083	2026-08-07	WH-CHN-01	ITM-CPU-01	0	3	25	f	none	simulated	system_sim
5084	2026-08-07	WH-CHN-01	ITM-GPU-01	0	2	20	f	none	simulated	system_sim
5085	2026-08-07	WH-CHN-01	ITM-RAM-01	0	6	74	f	none	simulated	system_sim
5086	2026-08-07	WH-CHN-01	ITM-SSD-01	0	0	65	f	none	simulated	system_sim
5087	2026-08-07	WH-CHN-01	ITM-HDD-01	0	0	83	f	none	simulated	system_sim
5088	2026-08-07	WH-CHN-01	ITM-CHG-01	0	2	148	f	none	simulated	system_sim
5089	2026-08-07	WH-CHN-01	ITM-CBL-01	0	1	163	f	none	simulated	system_sim
5090	2026-08-07	WH-BOM-01	ITM-CPU-01	0	3	60	f	none	simulated	system_sim
5091	2026-08-07	WH-BOM-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
5092	2026-08-07	WH-BOM-01	ITM-RAM-01	0	9	61	f	none	simulated	system_sim
5093	2026-08-07	WH-BOM-01	ITM-SSD-01	0	0	63	f	none	simulated	system_sim
5094	2026-08-07	WH-BOM-01	ITM-HDD-01	60	1	87	f	none	simulated	system_sim
5095	2026-08-07	WH-BOM-01	ITM-CHG-01	0	9	159	f	none	simulated	system_sim
5096	2026-08-07	WH-BOM-01	ITM-CBL-01	0	2	158	f	none	simulated	system_sim
5097	2026-08-07	WH-DEL-01	ITM-CPU-01	0	2	62	f	none	simulated	system_sim
5098	2026-08-07	WH-DEL-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
5099	2026-08-07	WH-DEL-01	ITM-RAM-01	0	5	35	f	none	simulated	system_sim
5100	2026-08-07	WH-DEL-01	ITM-SSD-01	0	0	71	f	none	simulated	system_sim
5101	2026-08-07	WH-DEL-01	ITM-HDD-01	0	2	80	f	none	simulated	system_sim
5102	2026-08-07	WH-DEL-01	ITM-CHG-01	0	7	152	f	none	simulated	system_sim
5103	2026-08-07	WH-DEL-01	ITM-CBL-01	0	10	160	f	none	simulated	system_sim
5104	2026-08-07	WH-CCU-01	ITM-CPU-01	0	0	59	f	none	simulated	system_sim
5105	2026-08-07	WH-CCU-01	ITM-GPU-01	0	2	37	f	none	simulated	system_sim
5106	2026-08-07	WH-CCU-01	ITM-RAM-01	0	5	62	f	none	simulated	system_sim
5107	2026-08-07	WH-CCU-01	ITM-SSD-01	0	0	67	f	none	simulated	system_sim
5108	2026-08-07	WH-CCU-01	ITM-HDD-01	0	3	35	f	none	simulated	system_sim
5109	2026-08-07	WH-CCU-01	ITM-CHG-01	0	10	176	f	none	simulated	system_sim
5110	2026-08-07	WH-CCU-01	ITM-CBL-01	0	8	143	f	none	simulated	system_sim
5111	2026-08-08	WH-BLR-01	ITM-CPU-01	0	1	62	f	none	simulated	system_sim
5112	2026-08-08	WH-BLR-01	ITM-GPU-01	0	0	32	f	none	simulated	system_sim
5113	2026-08-08	WH-BLR-01	ITM-RAM-01	0	1	77	f	none	simulated	system_sim
5114	2026-08-08	WH-BLR-01	ITM-SSD-01	0	0	66	f	none	simulated	system_sim
5115	2026-08-08	WH-BLR-01	ITM-HDD-01	0	0	88	f	none	simulated	system_sim
5116	2026-08-08	WH-BLR-01	ITM-CHG-01	0	1	148	f	none	simulated	system_sim
5117	2026-08-08	WH-BLR-01	ITM-CBL-01	0	7	163	f	none	simulated	system_sim
5118	2026-08-08	WH-CHN-01	ITM-CPU-01	0	3	22	f	none	simulated	system_sim
5119	2026-08-08	WH-CHN-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
5120	2026-08-08	WH-CHN-01	ITM-RAM-01	0	5	69	f	none	simulated	system_sim
5121	2026-08-08	WH-CHN-01	ITM-SSD-01	0	1	64	f	none	simulated	system_sim
5122	2026-08-08	WH-CHN-01	ITM-HDD-01	0	0	83	f	none	simulated	system_sim
5123	2026-08-08	WH-CHN-01	ITM-CHG-01	0	5	143	f	none	simulated	system_sim
5124	2026-08-08	WH-CHN-01	ITM-CBL-01	0	7	156	f	none	simulated	system_sim
5125	2026-08-08	WH-BOM-01	ITM-CPU-01	0	1	59	f	none	simulated	system_sim
5126	2026-08-08	WH-BOM-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
5127	2026-08-08	WH-BOM-01	ITM-RAM-01	0	6	55	f	none	simulated	system_sim
5128	2026-08-08	WH-BOM-01	ITM-SSD-01	0	0	63	f	none	simulated	system_sim
5129	2026-08-08	WH-BOM-01	ITM-HDD-01	0	3	84	f	none	simulated	system_sim
5130	2026-08-08	WH-BOM-01	ITM-CHG-01	0	6	153	f	none	simulated	system_sim
5131	2026-08-08	WH-BOM-01	ITM-CBL-01	0	10	148	f	none	simulated	system_sim
5132	2026-08-08	WH-DEL-01	ITM-CPU-01	0	0	62	f	none	simulated	system_sim
5133	2026-08-08	WH-DEL-01	ITM-GPU-01	0	2	35	f	none	simulated	system_sim
5134	2026-08-08	WH-DEL-01	ITM-RAM-01	75	10	100	f	none	simulated	system_sim
5135	2026-08-08	WH-DEL-01	ITM-SSD-01	0	0	71	f	none	simulated	system_sim
5136	2026-08-08	WH-DEL-01	ITM-HDD-01	0	3	77	f	none	simulated	system_sim
5137	2026-08-08	WH-DEL-01	ITM-CHG-01	0	5	147	f	none	simulated	system_sim
5138	2026-08-08	WH-DEL-01	ITM-CBL-01	0	7	153	f	none	simulated	system_sim
5139	2026-08-08	WH-CCU-01	ITM-CPU-01	0	3	56	f	none	simulated	system_sim
5140	2026-08-08	WH-CCU-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
5141	2026-08-08	WH-CCU-01	ITM-RAM-01	0	3	59	f	none	simulated	system_sim
5142	2026-08-08	WH-CCU-01	ITM-SSD-01	0	1	66	f	none	simulated	system_sim
5143	2026-08-08	WH-CCU-01	ITM-HDD-01	0	3	32	f	none	simulated	system_sim
5144	2026-08-08	WH-CCU-01	ITM-CHG-01	0	9	167	f	none	simulated	system_sim
5145	2026-08-08	WH-CCU-01	ITM-CBL-01	300	8	435	f	none	simulated	system_sim
5146	2026-08-09	WH-BLR-01	ITM-CPU-01	0	1	61	f	none	simulated	system_sim
5147	2026-08-09	WH-BLR-01	ITM-GPU-01	0	0	32	f	none	simulated	system_sim
5148	2026-08-09	WH-BLR-01	ITM-RAM-01	0	9	68	f	none	simulated	system_sim
5149	2026-08-09	WH-BLR-01	ITM-SSD-01	0	0	66	f	none	simulated	system_sim
5150	2026-08-09	WH-BLR-01	ITM-HDD-01	0	1	87	f	none	simulated	system_sim
5151	2026-08-09	WH-BLR-01	ITM-CHG-01	0	4	144	f	none	simulated	system_sim
5152	2026-08-09	WH-BLR-01	ITM-CBL-01	0	9	154	f	none	simulated	system_sim
5153	2026-08-09	WH-CHN-01	ITM-CPU-01	45	3	64	f	none	simulated	system_sim
5154	2026-08-09	WH-CHN-01	ITM-GPU-01	0	2	18	f	none	simulated	system_sim
5155	2026-08-09	WH-CHN-01	ITM-RAM-01	0	1	68	f	none	simulated	system_sim
5156	2026-08-09	WH-CHN-01	ITM-SSD-01	0	3	61	f	none	simulated	system_sim
5157	2026-08-09	WH-CHN-01	ITM-HDD-01	0	0	83	f	none	simulated	system_sim
5158	2026-08-09	WH-CHN-01	ITM-CHG-01	0	5	138	f	none	simulated	system_sim
5159	2026-08-09	WH-CHN-01	ITM-CBL-01	0	3	153	f	none	simulated	system_sim
5160	2026-08-09	WH-BOM-01	ITM-CPU-01	0	1	58	f	none	simulated	system_sim
5161	2026-08-09	WH-BOM-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
5162	2026-08-09	WH-BOM-01	ITM-RAM-01	0	9	46	f	none	simulated	system_sim
5163	2026-08-09	WH-BOM-01	ITM-SSD-01	0	0	63	f	none	simulated	system_sim
5164	2026-08-09	WH-BOM-01	ITM-HDD-01	0	0	84	f	none	simulated	system_sim
5165	2026-08-09	WH-BOM-01	ITM-CHG-01	0	2	151	f	none	simulated	system_sim
5166	2026-08-09	WH-BOM-01	ITM-CBL-01	300	10	438	f	none	simulated	system_sim
5167	2026-08-09	WH-DEL-01	ITM-CPU-01	0	2	60	f	none	simulated	system_sim
5168	2026-08-09	WH-DEL-01	ITM-GPU-01	0	0	35	f	none	simulated	system_sim
5169	2026-08-09	WH-DEL-01	ITM-RAM-01	0	1	99	f	none	simulated	system_sim
5170	2026-08-09	WH-DEL-01	ITM-SSD-01	0	2	69	f	none	simulated	system_sim
5171	2026-08-09	WH-DEL-01	ITM-HDD-01	0	2	75	f	none	simulated	system_sim
5172	2026-08-09	WH-DEL-01	ITM-CHG-01	0	4	143	f	none	simulated	system_sim
5173	2026-08-09	WH-DEL-01	ITM-CBL-01	0	3	150	f	none	simulated	system_sim
5174	2026-08-09	WH-CCU-01	ITM-CPU-01	0	2	54	f	none	simulated	system_sim
5175	2026-08-09	WH-CCU-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
5176	2026-08-09	WH-CCU-01	ITM-RAM-01	0	1	58	f	none	simulated	system_sim
5177	2026-08-09	WH-CCU-01	ITM-SSD-01	0	0	66	f	none	simulated	system_sim
5178	2026-08-09	WH-CCU-01	ITM-HDD-01	0	3	29	f	none	simulated	system_sim
5179	2026-08-09	WH-CCU-01	ITM-CHG-01	0	5	162	f	none	simulated	system_sim
5180	2026-08-09	WH-CCU-01	ITM-CBL-01	0	10	425	f	none	simulated	system_sim
5181	2026-08-10	WH-BLR-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
5182	2026-08-10	WH-BLR-01	ITM-GPU-01	0	2	30	f	none	simulated	system_sim
5183	2026-08-10	WH-BLR-01	ITM-RAM-01	0	2	66	f	none	simulated	system_sim
5184	2026-08-10	WH-BLR-01	ITM-SSD-01	0	2	64	f	none	simulated	system_sim
5185	2026-08-10	WH-BLR-01	ITM-HDD-01	0	0	87	f	none	simulated	system_sim
5186	2026-08-10	WH-BLR-01	ITM-CHG-01	0	7	137	f	none	simulated	system_sim
5187	2026-08-10	WH-BLR-01	ITM-CBL-01	0	6	148	f	none	simulated	system_sim
5188	2026-08-10	WH-CHN-01	ITM-CPU-01	0	0	64	f	none	simulated	system_sim
5189	2026-08-10	WH-CHN-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
5190	2026-08-10	WH-CHN-01	ITM-RAM-01	0	3	65	f	none	simulated	system_sim
5191	2026-08-10	WH-CHN-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
5192	2026-08-10	WH-CHN-01	ITM-HDD-01	0	0	83	f	none	simulated	system_sim
5193	2026-08-10	WH-CHN-01	ITM-CHG-01	0	8	130	f	none	simulated	system_sim
5194	2026-08-10	WH-CHN-01	ITM-CBL-01	0	7	146	f	none	simulated	system_sim
5195	2026-08-10	WH-BOM-01	ITM-CPU-01	0	0	58	f	none	simulated	system_sim
5196	2026-08-10	WH-BOM-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
5197	2026-08-10	WH-BOM-01	ITM-RAM-01	0	8	38	f	none	simulated	system_sim
5198	2026-08-10	WH-BOM-01	ITM-SSD-01	0	2	61	f	none	simulated	system_sim
5199	2026-08-10	WH-BOM-01	ITM-HDD-01	0	2	82	f	none	simulated	system_sim
5200	2026-08-10	WH-BOM-01	ITM-CHG-01	0	5	146	f	none	simulated	system_sim
5201	2026-08-10	WH-BOM-01	ITM-CBL-01	0	5	433	f	none	simulated	system_sim
5202	2026-08-10	WH-DEL-01	ITM-CPU-01	0	1	59	f	none	simulated	system_sim
5203	2026-08-10	WH-DEL-01	ITM-GPU-01	0	0	35	f	none	simulated	system_sim
5204	2026-08-10	WH-DEL-01	ITM-RAM-01	0	1	98	f	none	simulated	system_sim
5205	2026-08-10	WH-DEL-01	ITM-SSD-01	0	0	69	f	none	simulated	system_sim
5206	2026-08-10	WH-DEL-01	ITM-HDD-01	0	2	73	f	none	simulated	system_sim
5207	2026-08-10	WH-DEL-01	ITM-CHG-01	0	2	141	f	none	simulated	system_sim
5208	2026-08-10	WH-DEL-01	ITM-CBL-01	0	1	149	f	none	simulated	system_sim
5209	2026-08-10	WH-CCU-01	ITM-CPU-01	0	0	54	f	none	simulated	system_sim
5210	2026-08-10	WH-CCU-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
5211	2026-08-10	WH-CCU-01	ITM-RAM-01	0	8	50	f	none	simulated	system_sim
5212	2026-08-10	WH-CCU-01	ITM-SSD-01	0	3	63	f	none	simulated	system_sim
5213	2026-08-10	WH-CCU-01	ITM-HDD-01	60	0	89	f	none	simulated	system_sim
5214	2026-08-10	WH-CCU-01	ITM-CHG-01	0	1	161	f	none	simulated	system_sim
5215	2026-08-10	WH-CCU-01	ITM-CBL-01	0	4	421	f	none	simulated	system_sim
5216	2026-08-11	WH-BLR-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
5217	2026-08-11	WH-BLR-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
5218	2026-08-11	WH-BLR-01	ITM-RAM-01	0	6	60	f	none	simulated	system_sim
5219	2026-08-11	WH-BLR-01	ITM-SSD-01	0	0	64	f	none	simulated	system_sim
5220	2026-08-11	WH-BLR-01	ITM-HDD-01	0	1	86	f	none	simulated	system_sim
5221	2026-08-11	WH-BLR-01	ITM-CHG-01	0	2	135	f	none	simulated	system_sim
5222	2026-08-11	WH-BLR-01	ITM-CBL-01	300	9	439	f	none	simulated	system_sim
5223	2026-08-11	WH-CHN-01	ITM-CPU-01	0	2	62	f	none	simulated	system_sim
5224	2026-08-11	WH-CHN-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
5225	2026-08-11	WH-CHN-01	ITM-RAM-01	0	3	62	f	none	simulated	system_sim
5226	2026-08-11	WH-CHN-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
5227	2026-08-11	WH-CHN-01	ITM-HDD-01	0	3	80	f	none	simulated	system_sim
5228	2026-08-11	WH-CHN-01	ITM-CHG-01	0	6	124	f	none	simulated	system_sim
5229	2026-08-11	WH-CHN-01	ITM-CBL-01	300	7	439	f	none	simulated	system_sim
5230	2026-08-11	WH-BOM-01	ITM-CPU-01	0	3	55	f	none	simulated	system_sim
5231	2026-08-11	WH-BOM-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
5232	2026-08-11	WH-BOM-01	ITM-RAM-01	0	2	36	f	none	simulated	system_sim
5233	2026-08-11	WH-BOM-01	ITM-SSD-01	0	1	60	f	none	simulated	system_sim
5234	2026-08-11	WH-BOM-01	ITM-HDD-01	0	0	82	f	none	simulated	system_sim
5235	2026-08-11	WH-BOM-01	ITM-CHG-01	0	9	137	f	none	simulated	system_sim
5236	2026-08-11	WH-BOM-01	ITM-CBL-01	0	9	424	f	none	simulated	system_sim
5237	2026-08-11	WH-DEL-01	ITM-CPU-01	0	1	58	f	none	simulated	system_sim
5238	2026-08-11	WH-DEL-01	ITM-GPU-01	0	2	33	f	none	simulated	system_sim
5239	2026-08-11	WH-DEL-01	ITM-RAM-01	0	9	89	f	none	simulated	system_sim
5240	2026-08-11	WH-DEL-01	ITM-SSD-01	0	0	69	f	none	simulated	system_sim
5241	2026-08-11	WH-DEL-01	ITM-HDD-01	0	0	73	f	none	simulated	system_sim
5242	2026-08-11	WH-DEL-01	ITM-CHG-01	0	5	136	f	none	simulated	system_sim
5243	2026-08-11	WH-DEL-01	ITM-CBL-01	300	5	444	f	none	simulated	system_sim
5244	2026-08-11	WH-CCU-01	ITM-CPU-01	0	1	53	f	none	simulated	system_sim
5245	2026-08-11	WH-CCU-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
5246	2026-08-11	WH-CCU-01	ITM-RAM-01	0	9	41	f	none	simulated	system_sim
5247	2026-08-11	WH-CCU-01	ITM-SSD-01	0	1	62	f	none	simulated	system_sim
5248	2026-08-11	WH-CCU-01	ITM-HDD-01	0	2	87	f	none	simulated	system_sim
5249	2026-08-11	WH-CCU-01	ITM-CHG-01	0	9	152	f	none	simulated	system_sim
5250	2026-08-11	WH-CCU-01	ITM-CBL-01	0	9	412	f	none	simulated	system_sim
\.


--
-- Data for Name: system_health_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_health_snapshots (id, service, status, latency_ms, "timestamp") FROM stdin;
1	database	HEALTHY	0	2026-08-19 15:43:16.958992
2	redis	NOT_CONFIGURED	\N	2026-08-19 15:43:16.958992
3	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:43:16.958992
4	celery	NOT_CONFIGURED	\N	2026-08-19 15:43:16.958992
5	email	HEALTHY	\N	2026-08-19 15:43:16.958992
6	backup	DEGRADED	\N	2026-08-19 15:43:16.960009
7	sentry	NOT_CONFIGURED	\N	2026-08-19 15:43:16.960009
8	openai	NOT_CONFIGURED	\N	2026-08-19 15:43:16.960009
9	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:43:16.960009
10	simulation	HEALTHY	\N	2026-08-19 15:43:16.960009
11	application	HEALTHY	4.5	2026-08-19 15:43:16.960009
12	database	HEALTHY	5.94	2026-08-19 15:43:47.085618
13	redis	NOT_CONFIGURED	\N	2026-08-19 15:43:47.085618
14	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:43:47.086299
15	celery	NOT_CONFIGURED	\N	2026-08-19 15:43:47.086299
16	email	HEALTHY	\N	2026-08-19 15:43:47.086299
17	backup	DEGRADED	\N	2026-08-19 15:43:47.086299
18	sentry	NOT_CONFIGURED	\N	2026-08-19 15:43:47.086299
19	openai	NOT_CONFIGURED	\N	2026-08-19 15:43:47.086299
20	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:43:47.086299
21	simulation	HEALTHY	\N	2026-08-19 15:43:47.086299
22	application	HEALTHY	4.5	2026-08-19 15:43:47.086299
23	database	HEALTHY	3.02	2026-08-19 15:44:17.211859
24	redis	NOT_CONFIGURED	\N	2026-08-19 15:44:17.211859
25	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:44:17.211859
26	celery	NOT_CONFIGURED	\N	2026-08-19 15:44:17.211859
27	email	HEALTHY	\N	2026-08-19 15:44:17.211859
28	backup	DEGRADED	\N	2026-08-19 15:44:17.211859
29	sentry	NOT_CONFIGURED	\N	2026-08-19 15:44:17.211859
30	openai	NOT_CONFIGURED	\N	2026-08-19 15:44:17.212864
31	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:44:17.212864
32	simulation	HEALTHY	\N	2026-08-19 15:44:17.212864
33	application	HEALTHY	4.5	2026-08-19 15:44:17.212864
34	database	HEALTHY	5.99	2026-08-19 15:44:47.457941
35	redis	NOT_CONFIGURED	\N	2026-08-19 15:44:47.457941
36	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:44:47.458945
37	celery	NOT_CONFIGURED	\N	2026-08-19 15:44:47.458945
38	email	HEALTHY	\N	2026-08-19 15:44:47.458945
39	backup	DEGRADED	\N	2026-08-19 15:44:47.458945
40	sentry	NOT_CONFIGURED	\N	2026-08-19 15:44:47.458945
41	openai	NOT_CONFIGURED	\N	2026-08-19 15:44:47.458945
42	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:44:47.458945
43	simulation	HEALTHY	\N	2026-08-19 15:44:47.458945
44	application	HEALTHY	4.5	2026-08-19 15:44:47.458945
45	database	HEALTHY	3.71	2026-08-19 15:45:17.632382
46	redis	NOT_CONFIGURED	\N	2026-08-19 15:45:17.632382
47	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:45:17.632382
48	celery	NOT_CONFIGURED	\N	2026-08-19 15:45:17.632382
49	email	HEALTHY	\N	2026-08-19 15:45:17.632382
50	backup	DEGRADED	\N	2026-08-19 15:45:17.632382
51	sentry	NOT_CONFIGURED	\N	2026-08-19 15:45:17.632382
52	openai	NOT_CONFIGURED	\N	2026-08-19 15:45:17.632382
53	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:45:17.632382
54	simulation	HEALTHY	\N	2026-08-19 15:45:17.632382
55	application	HEALTHY	4.5	2026-08-19 15:45:17.632382
56	database	HEALTHY	1	2026-08-19 15:45:47.689904
57	redis	NOT_CONFIGURED	\N	2026-08-19 15:45:47.689904
58	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:45:47.689904
59	celery	NOT_CONFIGURED	\N	2026-08-19 15:45:47.689904
60	email	HEALTHY	\N	2026-08-19 15:45:47.689904
61	backup	DEGRADED	\N	2026-08-19 15:45:47.689904
62	sentry	NOT_CONFIGURED	\N	2026-08-19 15:45:47.689904
63	openai	NOT_CONFIGURED	\N	2026-08-19 15:45:47.689904
64	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:45:47.689904
65	simulation	HEALTHY	\N	2026-08-19 15:45:47.689904
66	application	HEALTHY	4.5	2026-08-19 15:45:47.689904
67	database	HEALTHY	1	2026-08-19 15:46:17.753805
68	redis	NOT_CONFIGURED	\N	2026-08-19 15:46:17.753805
69	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:46:17.753805
70	celery	NOT_CONFIGURED	\N	2026-08-19 15:46:17.753805
71	email	HEALTHY	\N	2026-08-19 15:46:17.753805
72	backup	DEGRADED	\N	2026-08-19 15:46:17.753805
73	sentry	NOT_CONFIGURED	\N	2026-08-19 15:46:17.753805
74	openai	NOT_CONFIGURED	\N	2026-08-19 15:46:17.753805
75	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:46:17.753805
76	simulation	HEALTHY	\N	2026-08-19 15:46:17.753805
77	application	HEALTHY	4.5	2026-08-19 15:46:17.753805
78	database	HEALTHY	1	2026-08-19 15:46:47.800965
79	redis	NOT_CONFIGURED	\N	2026-08-19 15:46:47.800965
80	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:46:47.800965
81	celery	NOT_CONFIGURED	\N	2026-08-19 15:46:47.800965
82	email	HEALTHY	\N	2026-08-19 15:46:47.80197
83	backup	DEGRADED	\N	2026-08-19 15:46:47.80197
84	sentry	NOT_CONFIGURED	\N	2026-08-19 15:46:47.80197
85	openai	NOT_CONFIGURED	\N	2026-08-19 15:46:47.80197
86	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:46:47.80197
87	simulation	HEALTHY	\N	2026-08-19 15:46:47.80197
88	application	HEALTHY	4.5	2026-08-19 15:46:47.80197
89	database	HEALTHY	0	2026-08-19 15:47:17.84018
90	redis	NOT_CONFIGURED	\N	2026-08-19 15:47:17.84018
91	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:47:17.84018
92	celery	NOT_CONFIGURED	\N	2026-08-19 15:47:17.84018
93	email	HEALTHY	\N	2026-08-19 15:47:17.84018
94	backup	DEGRADED	\N	2026-08-19 15:47:17.84018
95	sentry	NOT_CONFIGURED	\N	2026-08-19 15:47:17.84018
96	openai	NOT_CONFIGURED	\N	2026-08-19 15:47:17.84018
97	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:47:17.84018
98	simulation	HEALTHY	\N	2026-08-19 15:47:17.84018
99	application	HEALTHY	4.5	2026-08-19 15:47:17.84018
100	database	HEALTHY	0	2026-08-19 15:47:47.878138
101	redis	NOT_CONFIGURED	\N	2026-08-19 15:47:47.878138
102	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:47:47.878138
103	celery	NOT_CONFIGURED	\N	2026-08-19 15:47:47.878138
104	email	HEALTHY	\N	2026-08-19 15:47:47.878138
105	backup	DEGRADED	\N	2026-08-19 15:47:47.878138
106	sentry	NOT_CONFIGURED	\N	2026-08-19 15:47:47.878138
107	openai	NOT_CONFIGURED	\N	2026-08-19 15:47:47.879137
108	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:47:47.879137
109	simulation	HEALTHY	\N	2026-08-19 15:47:47.879137
110	application	HEALTHY	4.5	2026-08-19 15:47:47.879137
111	database	HEALTHY	0	2026-08-19 15:48:17.938924
112	redis	NOT_CONFIGURED	\N	2026-08-19 15:48:17.938924
113	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:48:17.938924
114	celery	NOT_CONFIGURED	\N	2026-08-19 15:48:17.938924
115	email	HEALTHY	\N	2026-08-19 15:48:17.938924
116	backup	DEGRADED	\N	2026-08-19 15:48:17.938924
117	sentry	NOT_CONFIGURED	\N	2026-08-19 15:48:17.938924
118	openai	NOT_CONFIGURED	\N	2026-08-19 15:48:17.938924
119	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:48:17.938924
120	simulation	HEALTHY	\N	2026-08-19 15:48:17.938924
121	application	HEALTHY	4.5	2026-08-19 15:48:17.938924
122	database	HEALTHY	0	2026-08-19 15:48:47.970409
123	redis	NOT_CONFIGURED	\N	2026-08-19 15:48:47.970409
124	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:48:47.970409
125	celery	NOT_CONFIGURED	\N	2026-08-19 15:48:47.970409
126	email	HEALTHY	\N	2026-08-19 15:48:47.970409
127	backup	DEGRADED	\N	2026-08-19 15:48:47.970409
128	sentry	NOT_CONFIGURED	\N	2026-08-19 15:48:47.970409
129	openai	NOT_CONFIGURED	\N	2026-08-19 15:48:47.970409
130	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:48:47.970409
131	simulation	HEALTHY	\N	2026-08-19 15:48:47.970409
132	application	HEALTHY	4.5	2026-08-19 15:48:47.970409
133	database	HEALTHY	0	2026-08-19 15:49:18.017824
134	redis	NOT_CONFIGURED	\N	2026-08-19 15:49:18.017824
135	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:49:18.017824
136	celery	NOT_CONFIGURED	\N	2026-08-19 15:49:18.017824
137	email	HEALTHY	\N	2026-08-19 15:49:18.017824
138	backup	DEGRADED	\N	2026-08-19 15:49:18.017824
139	sentry	NOT_CONFIGURED	\N	2026-08-19 15:49:18.017824
140	openai	NOT_CONFIGURED	\N	2026-08-19 15:49:18.017824
141	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:49:18.017824
142	simulation	HEALTHY	\N	2026-08-19 15:49:18.017824
143	application	HEALTHY	4.5	2026-08-19 15:49:18.017824
144	database	HEALTHY	0	2026-08-19 15:49:48.067227
145	redis	NOT_CONFIGURED	\N	2026-08-19 15:49:48.067227
146	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:49:48.067227
147	celery	NOT_CONFIGURED	\N	2026-08-19 15:49:48.067227
148	email	HEALTHY	\N	2026-08-19 15:49:48.067227
149	backup	DEGRADED	\N	2026-08-19 15:49:48.068228
150	sentry	NOT_CONFIGURED	\N	2026-08-19 15:49:48.068228
151	openai	NOT_CONFIGURED	\N	2026-08-19 15:49:48.068228
152	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:49:48.068228
153	simulation	HEALTHY	\N	2026-08-19 15:49:48.068228
154	application	HEALTHY	4.5	2026-08-19 15:49:48.068228
155	database	HEALTHY	0	2026-08-19 15:50:18.108276
156	redis	NOT_CONFIGURED	\N	2026-08-19 15:50:18.109288
157	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:50:18.109288
158	celery	NOT_CONFIGURED	\N	2026-08-19 15:50:18.109288
159	email	HEALTHY	\N	2026-08-19 15:50:18.109288
160	backup	DEGRADED	\N	2026-08-19 15:50:18.109288
161	sentry	NOT_CONFIGURED	\N	2026-08-19 15:50:18.109288
162	openai	NOT_CONFIGURED	\N	2026-08-19 15:50:18.109288
163	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:50:18.109288
164	simulation	HEALTHY	\N	2026-08-19 15:50:18.109288
165	application	HEALTHY	4.5	2026-08-19 15:50:18.109288
166	database	HEALTHY	0	2026-08-19 15:50:48.141889
167	redis	NOT_CONFIGURED	\N	2026-08-19 15:50:48.141889
168	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:50:48.141889
169	celery	NOT_CONFIGURED	\N	2026-08-19 15:50:48.141889
170	email	HEALTHY	\N	2026-08-19 15:50:48.141889
171	backup	DEGRADED	\N	2026-08-19 15:50:48.141889
172	sentry	NOT_CONFIGURED	\N	2026-08-19 15:50:48.143248
173	openai	NOT_CONFIGURED	\N	2026-08-19 15:50:48.143248
174	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:50:48.143248
175	simulation	HEALTHY	\N	2026-08-19 15:50:48.143248
176	application	HEALTHY	4.5	2026-08-19 15:50:48.143248
177	database	HEALTHY	0	2026-08-19 15:51:18.179254
178	redis	NOT_CONFIGURED	\N	2026-08-19 15:51:18.179254
179	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:51:18.179254
180	celery	NOT_CONFIGURED	\N	2026-08-19 15:51:18.180254
181	email	HEALTHY	\N	2026-08-19 15:51:18.180254
182	backup	DEGRADED	\N	2026-08-19 15:51:18.180254
183	sentry	NOT_CONFIGURED	\N	2026-08-19 15:51:18.180254
184	openai	NOT_CONFIGURED	\N	2026-08-19 15:51:18.180254
185	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:51:18.180254
186	simulation	HEALTHY	\N	2026-08-19 15:51:18.180254
187	application	HEALTHY	4.5	2026-08-19 15:51:18.180254
188	database	HEALTHY	0.69	2026-08-19 15:51:48.208362
189	redis	NOT_CONFIGURED	\N	2026-08-19 15:51:48.208362
190	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:51:48.208362
191	celery	NOT_CONFIGURED	\N	2026-08-19 15:51:48.208362
192	email	HEALTHY	\N	2026-08-19 15:51:48.208362
193	backup	DEGRADED	\N	2026-08-19 15:51:48.208362
194	sentry	NOT_CONFIGURED	\N	2026-08-19 15:51:48.208362
195	openai	NOT_CONFIGURED	\N	2026-08-19 15:51:48.208362
196	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:51:48.208362
197	simulation	HEALTHY	\N	2026-08-19 15:51:48.208362
198	application	HEALTHY	4.5	2026-08-19 15:51:48.208362
199	database	HEALTHY	1.02	2026-08-19 15:52:18.241292
200	redis	NOT_CONFIGURED	\N	2026-08-19 15:52:18.242297
201	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:52:18.242297
202	celery	NOT_CONFIGURED	\N	2026-08-19 15:52:18.242297
203	email	HEALTHY	\N	2026-08-19 15:52:18.242297
204	backup	DEGRADED	\N	2026-08-19 15:52:18.242297
205	sentry	NOT_CONFIGURED	\N	2026-08-19 15:52:18.242297
206	openai	NOT_CONFIGURED	\N	2026-08-19 15:52:18.242297
207	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:52:18.242297
208	simulation	HEALTHY	\N	2026-08-19 15:52:18.242297
209	application	HEALTHY	4.5	2026-08-19 15:52:18.242297
210	database	HEALTHY	1	2026-08-19 15:52:48.278019
211	redis	NOT_CONFIGURED	\N	2026-08-19 15:52:48.279014
212	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:52:48.279014
213	celery	NOT_CONFIGURED	\N	2026-08-19 15:52:48.279014
214	email	HEALTHY	\N	2026-08-19 15:52:48.279014
215	backup	DEGRADED	\N	2026-08-19 15:52:48.279014
216	sentry	NOT_CONFIGURED	\N	2026-08-19 15:52:48.279014
217	openai	NOT_CONFIGURED	\N	2026-08-19 15:52:48.279014
218	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:52:48.279014
219	simulation	HEALTHY	\N	2026-08-19 15:52:48.279014
220	application	HEALTHY	4.5	2026-08-19 15:52:48.279014
221	database	HEALTHY	1	2026-08-19 15:53:18.310184
222	redis	NOT_CONFIGURED	\N	2026-08-19 15:53:18.310184
223	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:53:18.310184
224	celery	NOT_CONFIGURED	\N	2026-08-19 15:53:18.310184
225	email	HEALTHY	\N	2026-08-19 15:53:18.310184
226	backup	DEGRADED	\N	2026-08-19 15:53:18.310184
227	sentry	NOT_CONFIGURED	\N	2026-08-19 15:53:18.310184
228	openai	NOT_CONFIGURED	\N	2026-08-19 15:53:18.310184
229	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:53:18.311185
230	simulation	HEALTHY	\N	2026-08-19 15:53:18.311185
231	application	HEALTHY	4.5	2026-08-19 15:53:18.311185
232	database	HEALTHY	1.05	2026-08-19 15:53:48.350893
233	redis	NOT_CONFIGURED	\N	2026-08-19 15:53:48.350893
234	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:53:48.350893
235	celery	NOT_CONFIGURED	\N	2026-08-19 15:53:48.350893
236	email	HEALTHY	\N	2026-08-19 15:53:48.350893
237	backup	DEGRADED	\N	2026-08-19 15:53:48.350893
238	sentry	NOT_CONFIGURED	\N	2026-08-19 15:53:48.350893
239	openai	NOT_CONFIGURED	\N	2026-08-19 15:53:48.350893
240	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:53:48.350893
241	simulation	HEALTHY	\N	2026-08-19 15:53:48.350893
242	application	HEALTHY	4.5	2026-08-19 15:53:48.350893
243	database	HEALTHY	0	2026-08-19 15:54:18.38665
244	redis	NOT_CONFIGURED	\N	2026-08-19 15:54:18.38665
245	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:54:18.38665
246	celery	NOT_CONFIGURED	\N	2026-08-19 15:54:18.38665
247	email	HEALTHY	\N	2026-08-19 15:54:18.38665
248	backup	DEGRADED	\N	2026-08-19 15:54:18.38665
249	sentry	NOT_CONFIGURED	\N	2026-08-19 15:54:18.38665
250	openai	NOT_CONFIGURED	\N	2026-08-19 15:54:18.38665
251	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:54:18.38665
252	simulation	HEALTHY	\N	2026-08-19 15:54:18.38665
253	application	HEALTHY	4.5	2026-08-19 15:54:18.38665
254	database	HEALTHY	0	2026-08-19 15:54:48.415246
255	redis	NOT_CONFIGURED	\N	2026-08-19 15:54:48.415246
256	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:54:48.415246
257	celery	NOT_CONFIGURED	\N	2026-08-19 15:54:48.415246
258	email	HEALTHY	\N	2026-08-19 15:54:48.415246
259	backup	DEGRADED	\N	2026-08-19 15:54:48.415246
260	sentry	NOT_CONFIGURED	\N	2026-08-19 15:54:48.415246
261	openai	NOT_CONFIGURED	\N	2026-08-19 15:54:48.415246
262	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:54:48.415246
263	simulation	HEALTHY	\N	2026-08-19 15:54:48.415246
264	application	HEALTHY	4.5	2026-08-19 15:54:48.415246
265	database	HEALTHY	1	2026-08-19 15:55:18.447024
266	redis	NOT_CONFIGURED	\N	2026-08-19 15:55:18.448023
267	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:55:18.448023
268	celery	NOT_CONFIGURED	\N	2026-08-19 15:55:18.448023
269	email	HEALTHY	\N	2026-08-19 15:55:18.448023
270	backup	DEGRADED	\N	2026-08-19 15:55:18.448023
271	sentry	NOT_CONFIGURED	\N	2026-08-19 15:55:18.448023
272	openai	NOT_CONFIGURED	\N	2026-08-19 15:55:18.448023
273	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:55:18.448023
274	simulation	HEALTHY	\N	2026-08-19 15:55:18.448023
275	application	HEALTHY	4.5	2026-08-19 15:55:18.448023
276	database	HEALTHY	0	2026-08-19 15:55:48.482337
277	redis	NOT_CONFIGURED	\N	2026-08-19 15:55:48.482337
278	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:55:48.482337
279	celery	NOT_CONFIGURED	\N	2026-08-19 15:55:48.482337
280	email	HEALTHY	\N	2026-08-19 15:55:48.482337
281	backup	DEGRADED	\N	2026-08-19 15:55:48.482337
282	sentry	NOT_CONFIGURED	\N	2026-08-19 15:55:48.482337
283	openai	NOT_CONFIGURED	\N	2026-08-19 15:55:48.482337
284	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:55:48.482337
285	simulation	HEALTHY	\N	2026-08-19 15:55:48.482337
286	application	HEALTHY	4.5	2026-08-19 15:55:48.482337
287	database	HEALTHY	1.66	2026-08-19 15:56:18.648095
288	redis	NOT_CONFIGURED	\N	2026-08-19 15:56:18.648095
289	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:56:18.648095
290	celery	NOT_CONFIGURED	\N	2026-08-19 15:56:18.648095
291	email	HEALTHY	\N	2026-08-19 15:56:18.648095
292	backup	DEGRADED	\N	2026-08-19 15:56:18.648095
293	sentry	NOT_CONFIGURED	\N	2026-08-19 15:56:18.648095
294	openai	NOT_CONFIGURED	\N	2026-08-19 15:56:18.648095
295	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:56:18.648095
296	simulation	HEALTHY	\N	2026-08-19 15:56:18.648095
297	application	HEALTHY	4.5	2026-08-19 15:56:18.648095
298	database	HEALTHY	0	2026-08-19 15:56:48.675899
299	redis	NOT_CONFIGURED	\N	2026-08-19 15:56:48.675899
300	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:56:48.675899
301	celery	NOT_CONFIGURED	\N	2026-08-19 15:56:48.675899
302	email	HEALTHY	\N	2026-08-19 15:56:48.675899
303	backup	DEGRADED	\N	2026-08-19 15:56:48.675899
304	sentry	NOT_CONFIGURED	\N	2026-08-19 15:56:48.675899
305	openai	NOT_CONFIGURED	\N	2026-08-19 15:56:48.675899
306	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:56:48.675899
307	simulation	HEALTHY	\N	2026-08-19 15:56:48.675899
308	application	HEALTHY	4.5	2026-08-19 15:56:48.675899
309	database	HEALTHY	0	2026-08-19 15:57:18.709025
310	redis	NOT_CONFIGURED	\N	2026-08-19 15:57:18.710392
311	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:57:18.710392
312	celery	NOT_CONFIGURED	\N	2026-08-19 15:57:18.710392
313	email	HEALTHY	\N	2026-08-19 15:57:18.710392
314	backup	DEGRADED	\N	2026-08-19 15:57:18.710392
315	sentry	NOT_CONFIGURED	\N	2026-08-19 15:57:18.710392
316	openai	NOT_CONFIGURED	\N	2026-08-19 15:57:18.710392
317	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:57:18.710392
318	simulation	HEALTHY	\N	2026-08-19 15:57:18.710392
319	application	HEALTHY	4.5	2026-08-19 15:57:18.710392
320	database	HEALTHY	0.51	2026-08-19 15:57:48.749251
321	redis	NOT_CONFIGURED	\N	2026-08-19 15:57:48.750811
322	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:57:48.750811
323	celery	NOT_CONFIGURED	\N	2026-08-19 15:57:48.750811
324	email	HEALTHY	\N	2026-08-19 15:57:48.750811
325	backup	DEGRADED	\N	2026-08-19 15:57:48.750811
326	sentry	NOT_CONFIGURED	\N	2026-08-19 15:57:48.750811
327	openai	NOT_CONFIGURED	\N	2026-08-19 15:57:48.750811
328	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:57:48.750811
329	simulation	HEALTHY	\N	2026-08-19 15:57:48.750811
330	application	HEALTHY	4.5	2026-08-19 15:57:48.750811
331	database	HEALTHY	0	2026-08-19 15:58:18.775742
332	redis	NOT_CONFIGURED	\N	2026-08-19 15:58:18.775742
333	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:58:18.775742
334	celery	NOT_CONFIGURED	\N	2026-08-19 15:58:18.775742
335	email	HEALTHY	\N	2026-08-19 15:58:18.775742
336	backup	DEGRADED	\N	2026-08-19 15:58:18.775742
337	sentry	NOT_CONFIGURED	\N	2026-08-19 15:58:18.775742
338	openai	NOT_CONFIGURED	\N	2026-08-19 15:58:18.775742
339	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:58:18.775742
340	simulation	HEALTHY	\N	2026-08-19 15:58:18.775742
341	application	HEALTHY	4.5	2026-08-19 15:58:18.776745
342	database	HEALTHY	1	2026-08-19 15:58:48.839837
343	redis	NOT_CONFIGURED	\N	2026-08-19 15:58:48.839837
344	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:58:48.839837
345	celery	NOT_CONFIGURED	\N	2026-08-19 15:58:48.839837
346	email	HEALTHY	\N	2026-08-19 15:58:48.839837
347	backup	DEGRADED	\N	2026-08-19 15:58:48.839837
348	sentry	NOT_CONFIGURED	\N	2026-08-19 15:58:48.840835
349	openai	NOT_CONFIGURED	\N	2026-08-19 15:58:48.840835
350	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:58:48.840835
351	simulation	HEALTHY	\N	2026-08-19 15:58:48.840835
352	application	HEALTHY	4.5	2026-08-19 15:58:48.840835
353	database	HEALTHY	0	2026-08-19 15:59:18.887093
354	redis	NOT_CONFIGURED	\N	2026-08-19 15:59:18.887093
355	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:59:18.887093
356	celery	NOT_CONFIGURED	\N	2026-08-19 15:59:18.887093
357	email	HEALTHY	\N	2026-08-19 15:59:18.887093
358	backup	DEGRADED	\N	2026-08-19 15:59:18.887093
359	sentry	NOT_CONFIGURED	\N	2026-08-19 15:59:18.887093
360	openai	NOT_CONFIGURED	\N	2026-08-19 15:59:18.887093
361	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:59:18.887093
362	simulation	HEALTHY	\N	2026-08-19 15:59:18.887093
363	application	HEALTHY	4.5	2026-08-19 15:59:18.887093
364	database	HEALTHY	2	2026-08-19 15:59:48.921252
365	redis	NOT_CONFIGURED	\N	2026-08-19 15:59:48.922252
366	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:59:48.922252
367	celery	NOT_CONFIGURED	\N	2026-08-19 15:59:48.922252
368	email	HEALTHY	\N	2026-08-19 15:59:48.922252
369	backup	DEGRADED	\N	2026-08-19 15:59:48.922252
370	sentry	NOT_CONFIGURED	\N	2026-08-19 15:59:48.922252
371	openai	NOT_CONFIGURED	\N	2026-08-19 15:59:48.922252
372	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:59:48.922252
373	simulation	HEALTHY	\N	2026-08-19 15:59:48.922252
374	application	HEALTHY	4.5	2026-08-19 15:59:48.922252
375	database	HEALTHY	0.72	2026-08-19 16:00:18.986965
376	redis	NOT_CONFIGURED	\N	2026-08-19 16:00:18.986965
377	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:00:18.986965
378	celery	NOT_CONFIGURED	\N	2026-08-19 16:00:18.986965
379	email	HEALTHY	\N	2026-08-19 16:00:18.986965
380	backup	DEGRADED	\N	2026-08-19 16:00:18.986965
381	sentry	NOT_CONFIGURED	\N	2026-08-19 16:00:18.986965
382	openai	NOT_CONFIGURED	\N	2026-08-19 16:00:18.986965
383	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:00:18.986965
384	simulation	HEALTHY	\N	2026-08-19 16:00:18.986965
385	application	HEALTHY	4.5	2026-08-19 16:00:18.986965
386	database	HEALTHY	0	2026-08-19 16:00:49.058315
387	redis	NOT_CONFIGURED	\N	2026-08-19 16:00:49.058315
388	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:00:49.059309
389	celery	NOT_CONFIGURED	\N	2026-08-19 16:00:49.059309
390	email	HEALTHY	\N	2026-08-19 16:00:49.059309
391	backup	DEGRADED	\N	2026-08-19 16:00:49.059309
392	sentry	NOT_CONFIGURED	\N	2026-08-19 16:00:49.059309
393	openai	NOT_CONFIGURED	\N	2026-08-19 16:00:49.059309
394	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:00:49.059309
395	simulation	HEALTHY	\N	2026-08-19 16:00:49.059309
396	application	HEALTHY	4.5	2026-08-19 16:00:49.059309
397	database	HEALTHY	0.99	2026-08-19 16:01:19.090784
398	redis	NOT_CONFIGURED	\N	2026-08-19 16:01:19.090784
399	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:01:19.090784
400	celery	NOT_CONFIGURED	\N	2026-08-19 16:01:19.090784
401	email	HEALTHY	\N	2026-08-19 16:01:19.090784
402	backup	DEGRADED	\N	2026-08-19 16:01:19.090784
403	sentry	NOT_CONFIGURED	\N	2026-08-19 16:01:19.090784
404	openai	NOT_CONFIGURED	\N	2026-08-19 16:01:19.090784
405	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:01:19.090784
406	simulation	HEALTHY	\N	2026-08-19 16:01:19.090784
407	application	HEALTHY	4.5	2026-08-19 16:01:19.090784
408	database	HEALTHY	1	2026-08-19 16:01:49.238816
409	redis	NOT_CONFIGURED	\N	2026-08-19 16:01:49.238816
410	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:01:49.238816
411	celery	NOT_CONFIGURED	\N	2026-08-19 16:01:49.238816
412	email	HEALTHY	\N	2026-08-19 16:01:49.238816
413	backup	DEGRADED	\N	2026-08-19 16:01:49.238816
414	sentry	NOT_CONFIGURED	\N	2026-08-19 16:01:49.238816
415	openai	NOT_CONFIGURED	\N	2026-08-19 16:01:49.239799
416	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:01:49.239799
417	simulation	HEALTHY	\N	2026-08-19 16:01:49.239799
418	application	HEALTHY	4.5	2026-08-19 16:01:49.239799
419	database	HEALTHY	1	2026-08-19 16:02:19.277167
420	redis	NOT_CONFIGURED	\N	2026-08-19 16:02:19.277167
421	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:02:19.277167
422	celery	NOT_CONFIGURED	\N	2026-08-19 16:02:19.278171
423	email	HEALTHY	\N	2026-08-19 16:02:19.278171
424	backup	DEGRADED	\N	2026-08-19 16:02:19.278171
425	sentry	NOT_CONFIGURED	\N	2026-08-19 16:02:19.278171
426	openai	NOT_CONFIGURED	\N	2026-08-19 16:02:19.278171
427	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:02:19.278171
428	simulation	HEALTHY	\N	2026-08-19 16:02:19.278171
429	application	HEALTHY	4.5	2026-08-19 16:02:19.278171
430	database	HEALTHY	0	2026-08-19 16:02:49.309146
431	redis	NOT_CONFIGURED	\N	2026-08-19 16:02:49.309146
432	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:02:49.309146
433	celery	NOT_CONFIGURED	\N	2026-08-19 16:02:49.309146
434	email	HEALTHY	\N	2026-08-19 16:02:49.309146
435	backup	DEGRADED	\N	2026-08-19 16:02:49.309146
436	sentry	NOT_CONFIGURED	\N	2026-08-19 16:02:49.309146
437	openai	NOT_CONFIGURED	\N	2026-08-19 16:02:49.309146
438	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:02:49.309146
439	simulation	HEALTHY	\N	2026-08-19 16:02:49.309146
440	application	HEALTHY	4.5	2026-08-19 16:02:49.309146
441	database	HEALTHY	0	2026-08-19 16:03:19.347408
442	redis	NOT_CONFIGURED	\N	2026-08-19 16:03:19.348405
443	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:03:19.348405
444	celery	NOT_CONFIGURED	\N	2026-08-19 16:03:19.348405
445	email	HEALTHY	\N	2026-08-19 16:03:19.348405
446	backup	DEGRADED	\N	2026-08-19 16:03:19.348405
447	sentry	NOT_CONFIGURED	\N	2026-08-19 16:03:19.348405
448	openai	NOT_CONFIGURED	\N	2026-08-19 16:03:19.348405
449	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:03:19.348405
450	simulation	HEALTHY	\N	2026-08-19 16:03:19.348405
451	application	HEALTHY	4.5	2026-08-19 16:03:19.348405
452	database	HEALTHY	0	2026-08-19 16:03:49.394343
453	redis	NOT_CONFIGURED	\N	2026-08-19 16:03:49.394343
454	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:03:49.394343
455	celery	NOT_CONFIGURED	\N	2026-08-19 16:03:49.394343
456	email	HEALTHY	\N	2026-08-19 16:03:49.394343
457	backup	DEGRADED	\N	2026-08-19 16:03:49.394343
458	sentry	NOT_CONFIGURED	\N	2026-08-19 16:03:49.394343
459	openai	NOT_CONFIGURED	\N	2026-08-19 16:03:49.394343
460	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:03:49.394343
461	simulation	HEALTHY	\N	2026-08-19 16:03:49.394343
462	application	HEALTHY	4.5	2026-08-19 16:03:49.394343
463	database	HEALTHY	1	2026-08-19 16:04:19.434344
464	redis	NOT_CONFIGURED	\N	2026-08-19 16:04:19.43532
465	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:04:19.43532
466	celery	NOT_CONFIGURED	\N	2026-08-19 16:04:19.43532
467	email	HEALTHY	\N	2026-08-19 16:04:19.43532
468	backup	DEGRADED	\N	2026-08-19 16:04:19.43532
469	sentry	NOT_CONFIGURED	\N	2026-08-19 16:04:19.43532
470	openai	NOT_CONFIGURED	\N	2026-08-19 16:04:19.43532
471	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:04:19.43532
472	simulation	HEALTHY	\N	2026-08-19 16:04:19.43532
473	application	HEALTHY	4.5	2026-08-19 16:04:19.43532
474	database	HEALTHY	0	2026-08-19 16:04:49.498861
475	redis	NOT_CONFIGURED	\N	2026-08-19 16:04:49.498861
476	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:04:49.498861
477	celery	NOT_CONFIGURED	\N	2026-08-19 16:04:49.498861
478	email	HEALTHY	\N	2026-08-19 16:04:49.499858
479	backup	DEGRADED	\N	2026-08-19 16:04:49.499858
480	sentry	NOT_CONFIGURED	\N	2026-08-19 16:04:49.499858
481	openai	NOT_CONFIGURED	\N	2026-08-19 16:04:49.499858
482	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:04:49.499858
483	simulation	HEALTHY	\N	2026-08-19 16:04:49.499858
484	application	HEALTHY	4.5	2026-08-19 16:04:49.499858
485	database	HEALTHY	0	2026-08-19 16:05:19.529283
486	redis	NOT_CONFIGURED	\N	2026-08-19 16:05:19.529283
487	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:05:19.529283
488	celery	NOT_CONFIGURED	\N	2026-08-19 16:05:19.529283
489	email	HEALTHY	\N	2026-08-19 16:05:19.529283
490	backup	DEGRADED	\N	2026-08-19 16:05:19.529283
491	sentry	NOT_CONFIGURED	\N	2026-08-19 16:05:19.529283
492	openai	NOT_CONFIGURED	\N	2026-08-19 16:05:19.529283
493	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:05:19.529283
494	simulation	HEALTHY	\N	2026-08-19 16:05:19.529283
495	application	HEALTHY	4.5	2026-08-19 16:05:19.529283
496	database	HEALTHY	1	2026-08-19 16:05:49.581173
497	redis	NOT_CONFIGURED	\N	2026-08-19 16:05:49.581173
498	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:05:49.581173
499	celery	NOT_CONFIGURED	\N	2026-08-19 16:05:49.581173
500	email	HEALTHY	\N	2026-08-19 16:05:49.581173
501	backup	DEGRADED	\N	2026-08-19 16:05:49.581173
502	sentry	NOT_CONFIGURED	\N	2026-08-19 16:05:49.581173
503	openai	NOT_CONFIGURED	\N	2026-08-19 16:05:49.581173
504	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:05:49.581173
505	simulation	HEALTHY	\N	2026-08-19 16:05:49.581173
506	application	HEALTHY	4.5	2026-08-19 16:05:49.581173
507	database	HEALTHY	1	2026-08-19 16:06:19.623269
508	redis	NOT_CONFIGURED	\N	2026-08-19 16:06:19.623269
509	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:06:19.623269
510	celery	NOT_CONFIGURED	\N	2026-08-19 16:06:19.623269
511	email	HEALTHY	\N	2026-08-19 16:06:19.623269
512	backup	DEGRADED	\N	2026-08-19 16:06:19.623269
513	sentry	NOT_CONFIGURED	\N	2026-08-19 16:06:19.623269
514	openai	NOT_CONFIGURED	\N	2026-08-19 16:06:19.623269
515	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:06:19.623269
516	simulation	HEALTHY	\N	2026-08-19 16:06:19.623269
517	application	HEALTHY	4.5	2026-08-19 16:06:19.623269
518	database	HEALTHY	0	2026-08-19 16:06:49.655565
519	redis	NOT_CONFIGURED	\N	2026-08-19 16:06:49.656561
520	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:06:49.656561
521	celery	NOT_CONFIGURED	\N	2026-08-19 16:06:49.656561
522	email	HEALTHY	\N	2026-08-19 16:06:49.656561
523	backup	DEGRADED	\N	2026-08-19 16:06:49.656561
524	sentry	NOT_CONFIGURED	\N	2026-08-19 16:06:49.656561
525	openai	NOT_CONFIGURED	\N	2026-08-19 16:06:49.656561
526	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:06:49.656561
527	simulation	HEALTHY	\N	2026-08-19 16:06:49.656561
528	application	HEALTHY	4.5	2026-08-19 16:06:49.656561
529	database	HEALTHY	0	2026-08-19 16:07:19.686925
530	redis	NOT_CONFIGURED	\N	2026-08-19 16:07:19.687925
531	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:07:19.687925
532	celery	NOT_CONFIGURED	\N	2026-08-19 16:07:19.687925
533	email	HEALTHY	\N	2026-08-19 16:07:19.687925
534	backup	DEGRADED	\N	2026-08-19 16:07:19.687925
535	sentry	NOT_CONFIGURED	\N	2026-08-19 16:07:19.687925
536	openai	NOT_CONFIGURED	\N	2026-08-19 16:07:19.687925
537	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:07:19.687925
538	simulation	HEALTHY	\N	2026-08-19 16:07:19.687925
539	application	HEALTHY	4.5	2026-08-19 16:07:19.687925
540	database	HEALTHY	1	2026-08-19 16:07:49.742458
541	redis	NOT_CONFIGURED	\N	2026-08-19 16:07:49.743901
542	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:07:49.743901
543	celery	NOT_CONFIGURED	\N	2026-08-19 16:07:49.743901
544	email	HEALTHY	\N	2026-08-19 16:07:49.743901
545	backup	DEGRADED	\N	2026-08-19 16:07:49.743901
546	sentry	NOT_CONFIGURED	\N	2026-08-19 16:07:49.743901
547	openai	NOT_CONFIGURED	\N	2026-08-19 16:07:49.743901
548	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:07:49.743901
549	simulation	HEALTHY	\N	2026-08-19 16:07:49.743901
550	application	HEALTHY	4.5	2026-08-19 16:07:49.743901
551	database	HEALTHY	0	2026-08-19 16:08:19.773555
552	redis	NOT_CONFIGURED	\N	2026-08-19 16:08:19.773555
553	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:08:19.773555
554	celery	NOT_CONFIGURED	\N	2026-08-19 16:08:19.773555
555	email	HEALTHY	\N	2026-08-19 16:08:19.773555
556	backup	DEGRADED	\N	2026-08-19 16:08:19.773555
557	sentry	NOT_CONFIGURED	\N	2026-08-19 16:08:19.773555
558	openai	NOT_CONFIGURED	\N	2026-08-19 16:08:19.773555
559	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:08:19.773555
560	simulation	HEALTHY	\N	2026-08-19 16:08:19.773555
561	application	HEALTHY	4.5	2026-08-19 16:08:19.773555
562	database	HEALTHY	0	2026-08-19 16:08:49.807318
563	redis	NOT_CONFIGURED	\N	2026-08-19 16:08:49.807318
564	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:08:49.807318
565	celery	NOT_CONFIGURED	\N	2026-08-19 16:08:49.807318
566	email	HEALTHY	\N	2026-08-19 16:08:49.807318
567	backup	DEGRADED	\N	2026-08-19 16:08:49.807318
568	sentry	NOT_CONFIGURED	\N	2026-08-19 16:08:49.807318
569	openai	NOT_CONFIGURED	\N	2026-08-19 16:08:49.807318
570	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:08:49.807318
571	simulation	HEALTHY	\N	2026-08-19 16:08:49.807318
572	application	HEALTHY	4.5	2026-08-19 16:08:49.807318
573	database	HEALTHY	0.97	2026-08-19 16:09:19.84777
574	redis	NOT_CONFIGURED	\N	2026-08-19 16:09:19.84777
575	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:09:19.84777
576	celery	NOT_CONFIGURED	\N	2026-08-19 16:09:19.84777
577	email	HEALTHY	\N	2026-08-19 16:09:19.84777
578	backup	DEGRADED	\N	2026-08-19 16:09:19.84777
579	sentry	NOT_CONFIGURED	\N	2026-08-19 16:09:19.84777
580	openai	NOT_CONFIGURED	\N	2026-08-19 16:09:19.84777
581	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:09:19.84777
582	simulation	HEALTHY	\N	2026-08-19 16:09:19.84777
583	application	HEALTHY	4.5	2026-08-19 16:09:19.84777
584	database	HEALTHY	1	2026-08-19 16:09:49.883057
585	redis	NOT_CONFIGURED	\N	2026-08-19 16:09:49.883057
586	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:09:49.883057
587	celery	NOT_CONFIGURED	\N	2026-08-19 16:09:49.883057
588	email	HEALTHY	\N	2026-08-19 16:09:49.883057
589	backup	DEGRADED	\N	2026-08-19 16:09:49.883057
590	sentry	NOT_CONFIGURED	\N	2026-08-19 16:09:49.883057
591	openai	NOT_CONFIGURED	\N	2026-08-19 16:09:49.883057
592	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:09:49.883057
593	simulation	HEALTHY	\N	2026-08-19 16:09:49.883057
594	application	HEALTHY	4.5	2026-08-19 16:09:49.883057
595	database	HEALTHY	1	2026-08-19 16:10:19.927704
596	redis	NOT_CONFIGURED	\N	2026-08-19 16:10:19.927704
597	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:10:19.927704
598	celery	NOT_CONFIGURED	\N	2026-08-19 16:10:19.927704
599	email	HEALTHY	\N	2026-08-19 16:10:19.927704
600	backup	DEGRADED	\N	2026-08-19 16:10:19.927704
601	sentry	NOT_CONFIGURED	\N	2026-08-19 16:10:19.927704
602	openai	NOT_CONFIGURED	\N	2026-08-19 16:10:19.927704
603	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:10:19.927704
604	simulation	HEALTHY	\N	2026-08-19 16:10:19.927704
605	application	HEALTHY	4.5	2026-08-19 16:10:19.927704
606	database	HEALTHY	0	2026-08-19 16:10:49.9668
607	redis	NOT_CONFIGURED	\N	2026-08-19 16:10:49.9668
608	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:10:49.9668
609	celery	NOT_CONFIGURED	\N	2026-08-19 16:10:49.9668
610	email	HEALTHY	\N	2026-08-19 16:10:49.9668
611	backup	DEGRADED	\N	2026-08-19 16:10:49.9668
612	sentry	NOT_CONFIGURED	\N	2026-08-19 16:10:49.9668
613	openai	NOT_CONFIGURED	\N	2026-08-19 16:10:49.9668
614	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:10:49.9668
615	simulation	HEALTHY	\N	2026-08-19 16:10:49.9668
616	application	HEALTHY	4.5	2026-08-19 16:10:49.9668
617	database	HEALTHY	0	2026-08-19 16:11:20.002192
618	redis	NOT_CONFIGURED	\N	2026-08-19 16:11:20.002192
619	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:11:20.002192
620	celery	NOT_CONFIGURED	\N	2026-08-19 16:11:20.002192
621	email	HEALTHY	\N	2026-08-19 16:11:20.002192
622	backup	DEGRADED	\N	2026-08-19 16:11:20.002192
623	sentry	NOT_CONFIGURED	\N	2026-08-19 16:11:20.002192
624	openai	NOT_CONFIGURED	\N	2026-08-19 16:11:20.002192
625	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:11:20.002192
626	simulation	HEALTHY	\N	2026-08-19 16:11:20.002192
627	application	HEALTHY	4.5	2026-08-19 16:11:20.002192
628	database	HEALTHY	0	2026-08-19 16:11:50.04983
629	redis	NOT_CONFIGURED	\N	2026-08-19 16:11:50.04983
630	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:11:50.04983
631	celery	NOT_CONFIGURED	\N	2026-08-19 16:11:50.050895
632	email	HEALTHY	\N	2026-08-19 16:11:50.050895
633	backup	DEGRADED	\N	2026-08-19 16:11:50.050895
634	sentry	NOT_CONFIGURED	\N	2026-08-19 16:11:50.050895
635	openai	NOT_CONFIGURED	\N	2026-08-19 16:11:50.050895
636	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:11:50.050895
637	simulation	HEALTHY	\N	2026-08-19 16:11:50.050895
638	application	HEALTHY	4.5	2026-08-19 16:11:50.050895
639	database	HEALTHY	1	2026-08-19 16:12:20.079732
640	redis	NOT_CONFIGURED	\N	2026-08-19 16:12:20.079732
641	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:12:20.079732
642	celery	NOT_CONFIGURED	\N	2026-08-19 16:12:20.079732
643	email	HEALTHY	\N	2026-08-19 16:12:20.079732
644	backup	DEGRADED	\N	2026-08-19 16:12:20.079732
645	sentry	NOT_CONFIGURED	\N	2026-08-19 16:12:20.079732
646	openai	NOT_CONFIGURED	\N	2026-08-19 16:12:20.079732
647	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:12:20.079732
648	simulation	HEALTHY	\N	2026-08-19 16:12:20.079732
649	application	HEALTHY	4.5	2026-08-19 16:12:20.079732
650	database	HEALTHY	0	2026-08-19 16:12:50.133789
651	redis	NOT_CONFIGURED	\N	2026-08-19 16:12:50.133789
652	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:12:50.135114
653	celery	NOT_CONFIGURED	\N	2026-08-19 16:12:50.135114
654	email	HEALTHY	\N	2026-08-19 16:12:50.135114
655	backup	DEGRADED	\N	2026-08-19 16:12:50.135114
656	sentry	NOT_CONFIGURED	\N	2026-08-19 16:12:50.135114
657	openai	NOT_CONFIGURED	\N	2026-08-19 16:12:50.135114
658	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:12:50.135114
659	simulation	HEALTHY	\N	2026-08-19 16:12:50.135114
660	application	HEALTHY	4.5	2026-08-19 16:12:50.135114
661	database	HEALTHY	3	2026-08-19 16:13:20.207174
662	redis	NOT_CONFIGURED	\N	2026-08-19 16:13:20.207174
663	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:13:20.207174
664	celery	NOT_CONFIGURED	\N	2026-08-19 16:13:20.207174
665	email	HEALTHY	\N	2026-08-19 16:13:20.207174
666	backup	DEGRADED	\N	2026-08-19 16:13:20.207174
667	sentry	NOT_CONFIGURED	\N	2026-08-19 16:13:20.207174
668	openai	NOT_CONFIGURED	\N	2026-08-19 16:13:20.207174
669	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:13:20.207174
670	simulation	HEALTHY	\N	2026-08-19 16:13:20.208717
671	application	HEALTHY	4.5	2026-08-19 16:13:20.208717
672	database	HEALTHY	3.99	2026-08-19 16:13:50.405009
673	redis	NOT_CONFIGURED	\N	2026-08-19 16:13:50.40601
674	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:13:50.40601
675	celery	NOT_CONFIGURED	\N	2026-08-19 16:13:50.40601
676	email	HEALTHY	\N	2026-08-19 16:13:50.40601
677	backup	DEGRADED	\N	2026-08-19 16:13:50.40601
678	sentry	NOT_CONFIGURED	\N	2026-08-19 16:13:50.40601
679	openai	NOT_CONFIGURED	\N	2026-08-19 16:13:50.40601
680	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:13:50.40601
681	simulation	HEALTHY	\N	2026-08-19 16:13:50.40601
682	application	HEALTHY	4.5	2026-08-19 16:13:50.40601
683	database	HEALTHY	0	2026-08-19 16:14:20.625927
684	redis	NOT_CONFIGURED	\N	2026-08-19 16:14:20.625927
685	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:14:20.625927
686	celery	NOT_CONFIGURED	\N	2026-08-19 16:14:20.625927
687	email	HEALTHY	\N	2026-08-19 16:14:20.626928
688	backup	DEGRADED	\N	2026-08-19 16:14:20.626928
689	sentry	NOT_CONFIGURED	\N	2026-08-19 16:14:20.626928
690	openai	NOT_CONFIGURED	\N	2026-08-19 16:14:20.626928
691	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:14:20.626928
692	simulation	HEALTHY	\N	2026-08-19 16:14:20.626928
693	application	HEALTHY	4.5	2026-08-19 16:14:20.626928
694	database	HEALTHY	0.99	2026-08-19 16:14:50.668735
695	redis	NOT_CONFIGURED	\N	2026-08-19 16:14:50.668735
696	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:14:50.668735
697	celery	NOT_CONFIGURED	\N	2026-08-19 16:14:50.668735
698	email	HEALTHY	\N	2026-08-19 16:14:50.668735
699	backup	DEGRADED	\N	2026-08-19 16:14:50.668735
700	sentry	NOT_CONFIGURED	\N	2026-08-19 16:14:50.668735
701	openai	NOT_CONFIGURED	\N	2026-08-19 16:14:50.669736
702	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:14:50.669736
703	simulation	HEALTHY	\N	2026-08-19 16:14:50.669736
704	application	HEALTHY	4.5	2026-08-19 16:14:50.669736
705	database	HEALTHY	1.01	2026-08-19 16:15:20.70198
706	redis	NOT_CONFIGURED	\N	2026-08-19 16:15:20.70198
707	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:15:20.70198
708	celery	NOT_CONFIGURED	\N	2026-08-19 16:15:20.70198
709	email	HEALTHY	\N	2026-08-19 16:15:20.70198
710	backup	DEGRADED	\N	2026-08-19 16:15:20.702983
711	sentry	NOT_CONFIGURED	\N	2026-08-19 16:15:20.702983
712	openai	NOT_CONFIGURED	\N	2026-08-19 16:15:20.702983
713	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:15:20.702983
714	simulation	HEALTHY	\N	2026-08-19 16:15:20.702983
715	application	HEALTHY	4.5	2026-08-19 16:15:20.702983
716	database	HEALTHY	1.02	2026-08-19 16:15:50.762278
717	redis	NOT_CONFIGURED	\N	2026-08-19 16:15:50.762278
718	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:15:50.762278
719	celery	NOT_CONFIGURED	\N	2026-08-19 16:15:50.762278
720	email	HEALTHY	\N	2026-08-19 16:15:50.762278
721	backup	DEGRADED	\N	2026-08-19 16:15:50.762278
722	sentry	NOT_CONFIGURED	\N	2026-08-19 16:15:50.762278
723	openai	NOT_CONFIGURED	\N	2026-08-19 16:15:50.762278
724	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:15:50.762278
725	simulation	HEALTHY	\N	2026-08-19 16:15:50.762278
726	application	HEALTHY	4.5	2026-08-19 16:15:50.762278
727	database	HEALTHY	0	2026-08-19 16:16:20.807288
728	redis	NOT_CONFIGURED	\N	2026-08-19 16:16:20.807288
729	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:16:20.807288
730	celery	NOT_CONFIGURED	\N	2026-08-19 16:16:20.807288
731	email	HEALTHY	\N	2026-08-19 16:16:20.808291
732	backup	DEGRADED	\N	2026-08-19 16:16:20.808291
733	sentry	NOT_CONFIGURED	\N	2026-08-19 16:16:20.808291
734	openai	NOT_CONFIGURED	\N	2026-08-19 16:16:20.808291
735	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:16:20.808291
736	simulation	HEALTHY	\N	2026-08-19 16:16:20.808291
737	application	HEALTHY	4.5	2026-08-19 16:16:20.808291
738	database	HEALTHY	1	2026-08-19 16:16:50.86567
739	redis	NOT_CONFIGURED	\N	2026-08-19 16:16:50.86567
740	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:16:50.86567
741	celery	NOT_CONFIGURED	\N	2026-08-19 16:16:50.86567
742	email	HEALTHY	\N	2026-08-19 16:16:50.86567
743	backup	DEGRADED	\N	2026-08-19 16:16:50.86567
744	sentry	NOT_CONFIGURED	\N	2026-08-19 16:16:50.86567
745	openai	NOT_CONFIGURED	\N	2026-08-19 16:16:50.86567
746	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:16:50.86567
747	simulation	HEALTHY	\N	2026-08-19 16:16:50.86567
748	application	HEALTHY	4.5	2026-08-19 16:16:50.86567
749	database	HEALTHY	0	2026-08-19 16:17:20.900338
750	redis	NOT_CONFIGURED	\N	2026-08-19 16:17:20.900338
751	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:17:20.901367
752	celery	NOT_CONFIGURED	\N	2026-08-19 16:17:20.901367
753	email	HEALTHY	\N	2026-08-19 16:17:20.901367
754	backup	DEGRADED	\N	2026-08-19 16:17:20.901367
755	sentry	NOT_CONFIGURED	\N	2026-08-19 16:17:20.901367
756	openai	NOT_CONFIGURED	\N	2026-08-19 16:17:20.901367
757	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:17:20.901367
758	simulation	HEALTHY	\N	2026-08-19 16:17:20.901367
759	application	HEALTHY	4.5	2026-08-19 16:17:20.901367
760	database	HEALTHY	0.99	2026-08-19 16:17:50.958135
761	redis	NOT_CONFIGURED	\N	2026-08-19 16:17:50.958135
762	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:17:50.958135
763	celery	NOT_CONFIGURED	\N	2026-08-19 16:17:50.958135
764	email	HEALTHY	\N	2026-08-19 16:17:50.958135
765	backup	DEGRADED	\N	2026-08-19 16:17:50.958135
766	sentry	NOT_CONFIGURED	\N	2026-08-19 16:17:50.958135
767	openai	NOT_CONFIGURED	\N	2026-08-19 16:17:50.959133
768	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:17:50.959133
769	simulation	HEALTHY	\N	2026-08-19 16:17:50.959133
770	application	HEALTHY	4.5	2026-08-19 16:17:50.959133
771	database	HEALTHY	0	2026-08-19 16:18:20.992804
772	redis	NOT_CONFIGURED	\N	2026-08-19 16:18:20.993803
773	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:18:20.993803
774	celery	NOT_CONFIGURED	\N	2026-08-19 16:18:20.993803
775	email	HEALTHY	\N	2026-08-19 16:18:20.993803
776	backup	DEGRADED	\N	2026-08-19 16:18:20.993803
777	sentry	NOT_CONFIGURED	\N	2026-08-19 16:18:20.993803
778	openai	NOT_CONFIGURED	\N	2026-08-19 16:18:20.993803
779	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:18:20.993803
780	simulation	HEALTHY	\N	2026-08-19 16:18:20.993803
781	application	HEALTHY	4.5	2026-08-19 16:18:20.993803
782	database	HEALTHY	0	2026-08-19 16:18:51.042369
783	redis	NOT_CONFIGURED	\N	2026-08-19 16:18:51.042369
784	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:18:51.043367
785	celery	NOT_CONFIGURED	\N	2026-08-19 16:18:51.043367
786	email	HEALTHY	\N	2026-08-19 16:18:51.043367
787	backup	DEGRADED	\N	2026-08-19 16:18:51.043367
788	sentry	NOT_CONFIGURED	\N	2026-08-19 16:18:51.043367
789	openai	NOT_CONFIGURED	\N	2026-08-19 16:18:51.043367
790	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:18:51.043367
791	simulation	HEALTHY	\N	2026-08-19 16:18:51.043367
792	application	HEALTHY	4.5	2026-08-19 16:18:51.043367
793	database	HEALTHY	0	2026-08-19 16:19:21.075709
794	redis	NOT_CONFIGURED	\N	2026-08-19 16:19:21.075709
795	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:19:21.075709
796	celery	NOT_CONFIGURED	\N	2026-08-19 16:19:21.075709
797	email	HEALTHY	\N	2026-08-19 16:19:21.075709
798	backup	DEGRADED	\N	2026-08-19 16:19:21.075709
799	sentry	NOT_CONFIGURED	\N	2026-08-19 16:19:21.075709
800	openai	NOT_CONFIGURED	\N	2026-08-19 16:19:21.075709
801	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:19:21.075709
802	simulation	HEALTHY	\N	2026-08-19 16:19:21.075709
803	application	HEALTHY	4.5	2026-08-19 16:19:21.075709
804	database	HEALTHY	0	2026-08-19 16:19:51.108704
805	redis	NOT_CONFIGURED	\N	2026-08-19 16:19:51.108704
806	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:19:51.108704
807	celery	NOT_CONFIGURED	\N	2026-08-19 16:19:51.108704
808	email	HEALTHY	\N	2026-08-19 16:19:51.108704
809	backup	DEGRADED	\N	2026-08-19 16:19:51.108704
810	sentry	NOT_CONFIGURED	\N	2026-08-19 16:19:51.108704
811	openai	NOT_CONFIGURED	\N	2026-08-19 16:19:51.108704
812	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:19:51.109691
813	simulation	HEALTHY	\N	2026-08-19 16:19:51.109691
814	application	HEALTHY	4.5	2026-08-19 16:19:51.109691
815	database	HEALTHY	1	2026-08-19 16:20:21.135138
816	redis	NOT_CONFIGURED	\N	2026-08-19 16:20:21.135138
817	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:20:21.136481
818	celery	NOT_CONFIGURED	\N	2026-08-19 16:20:21.136481
819	email	HEALTHY	\N	2026-08-19 16:20:21.136481
820	backup	DEGRADED	\N	2026-08-19 16:20:21.136481
821	sentry	NOT_CONFIGURED	\N	2026-08-19 16:20:21.136481
822	openai	NOT_CONFIGURED	\N	2026-08-19 16:20:21.136481
823	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:20:21.136481
824	simulation	HEALTHY	\N	2026-08-19 16:20:21.136481
825	application	HEALTHY	4.5	2026-08-19 16:20:21.136481
826	database	HEALTHY	0.99	2026-08-19 16:20:51.174426
827	redis	NOT_CONFIGURED	\N	2026-08-19 16:20:51.174426
828	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:20:51.174426
829	celery	NOT_CONFIGURED	\N	2026-08-19 16:20:51.174426
830	email	HEALTHY	\N	2026-08-19 16:20:51.174426
831	backup	DEGRADED	\N	2026-08-19 16:20:51.174426
832	sentry	NOT_CONFIGURED	\N	2026-08-19 16:20:51.174426
833	openai	NOT_CONFIGURED	\N	2026-08-19 16:20:51.175438
834	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:20:51.175438
835	simulation	HEALTHY	\N	2026-08-19 16:20:51.175438
836	application	HEALTHY	4.5	2026-08-19 16:20:51.175438
837	database	HEALTHY	1	2026-08-19 16:21:21.215392
838	redis	NOT_CONFIGURED	\N	2026-08-19 16:21:21.216392
839	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:21:21.216392
840	celery	NOT_CONFIGURED	\N	2026-08-19 16:21:21.216392
841	email	HEALTHY	\N	2026-08-19 16:21:21.216392
842	backup	DEGRADED	\N	2026-08-19 16:21:21.216392
843	sentry	NOT_CONFIGURED	\N	2026-08-19 16:21:21.216392
844	openai	NOT_CONFIGURED	\N	2026-08-19 16:21:21.216392
845	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:21:21.216392
846	simulation	HEALTHY	\N	2026-08-19 16:21:21.216392
847	application	HEALTHY	4.5	2026-08-19 16:21:21.216392
848	database	HEALTHY	0	2026-08-19 16:21:51.250566
849	redis	NOT_CONFIGURED	\N	2026-08-19 16:21:51.250566
850	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:21:51.250566
851	celery	NOT_CONFIGURED	\N	2026-08-19 16:21:51.250566
852	email	HEALTHY	\N	2026-08-19 16:21:51.250566
853	backup	DEGRADED	\N	2026-08-19 16:21:51.252337
854	sentry	NOT_CONFIGURED	\N	2026-08-19 16:21:51.252337
855	openai	NOT_CONFIGURED	\N	2026-08-19 16:21:51.252337
856	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:21:51.252337
857	simulation	HEALTHY	\N	2026-08-19 16:21:51.252337
858	application	HEALTHY	4.5	2026-08-19 16:21:51.252337
859	database	HEALTHY	0.99	2026-08-19 16:22:21.278654
860	redis	NOT_CONFIGURED	\N	2026-08-19 16:22:21.278654
861	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:22:21.278654
862	celery	NOT_CONFIGURED	\N	2026-08-19 16:22:21.279694
863	email	HEALTHY	\N	2026-08-19 16:22:21.279694
864	backup	DEGRADED	\N	2026-08-19 16:22:21.279694
865	sentry	NOT_CONFIGURED	\N	2026-08-19 16:22:21.279694
866	openai	NOT_CONFIGURED	\N	2026-08-19 16:22:21.279694
867	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:22:21.279694
868	simulation	HEALTHY	\N	2026-08-19 16:22:21.279694
869	application	HEALTHY	4.5	2026-08-19 16:22:21.279694
870	database	HEALTHY	1	2026-08-19 16:22:51.337485
871	redis	NOT_CONFIGURED	\N	2026-08-19 16:22:51.337485
872	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:22:51.337485
873	celery	NOT_CONFIGURED	\N	2026-08-19 16:22:51.337485
874	email	HEALTHY	\N	2026-08-19 16:22:51.337485
875	backup	DEGRADED	\N	2026-08-19 16:22:51.337485
876	sentry	NOT_CONFIGURED	\N	2026-08-19 16:22:51.337485
877	openai	NOT_CONFIGURED	\N	2026-08-19 16:22:51.337485
878	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:22:51.337485
879	simulation	HEALTHY	\N	2026-08-19 16:22:51.337485
880	application	HEALTHY	4.5	2026-08-19 16:22:51.337485
881	database	HEALTHY	0	2026-08-19 16:23:21.363007
882	redis	NOT_CONFIGURED	\N	2026-08-19 16:23:21.363007
883	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:23:21.363007
884	celery	NOT_CONFIGURED	\N	2026-08-19 16:23:21.363007
885	email	HEALTHY	\N	2026-08-19 16:23:21.363007
886	backup	DEGRADED	\N	2026-08-19 16:23:21.363007
887	sentry	NOT_CONFIGURED	\N	2026-08-19 16:23:21.363007
888	openai	NOT_CONFIGURED	\N	2026-08-19 16:23:21.363007
889	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:23:21.364007
890	simulation	HEALTHY	\N	2026-08-19 16:23:21.364007
891	application	HEALTHY	4.5	2026-08-19 16:23:21.364007
\.


--
-- Data for Name: system_incidents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_incidents (id, category, severity, title, description, source, status, fingerprint, started_at, resolved_at, acknowledged_by, created_at) FROM stdin;
1	BACKUP	HIGH	Backups failing age / verification rules	No backups exist in database records	health_check	OPEN	BACKUP_VERIFICATION_FAILED	2026-08-19 15:43:44.595011	\N	\N	2026-08-19 15:43:44.60599
\.


--
-- Data for Name: task_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_events (id, task_id, event_type, previous_status, new_status, user_id, created_at, reason, metadata) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, task_number, warehouse_id, task_type, priority, priority_score, status, source_type, source_id, order_id, order_item_id, product_id, source_location_id, destination_location_id, requested_quantity, completed_quantity, assigned_user_id, assigned_robot_id, created_at, prioritized_at, assigned_at, started_at, paused_at, completed_at, failed_at, cancelled_at, due_at, retry_count, failure_reason, notes, metadata, depends_on_task_id) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (id, user_id, session_token_hash, created_at, last_seen_at, expires_at, revoked_at, revoke_reason, login_method, ip_address, login_location, user_agent) FROM stdin;
\.


--
-- Data for Name: user_warehouse_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_warehouse_access (id, user_id, warehouse_id, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, password_hash, role, full_name, google_subject_id, created_at, updated_at, is_active, is_verified, last_login_at, last_logout_at, last_login_ip, login_location, login_method, failed_login_count, locked_until, email_verified_at, password_changed_at) FROM stdin;
2	test_admin	\N	$2b$12$YnltEE/2/PB4DM./KCArPOilz4NYQuH19u9DMAPBPfZ2r0r6TlmmO	admin		\N	2026-08-19 15:43:35.82341	2026-08-19 15:43:35.82341	t	f	\N	\N	\N	\N	\N	0	\N	\N	\N
3	test_manager	\N	$2b$12$GFo8sE.n54/fIADXyKInkucviTcgbabSwv8GzwGEvt397RMAB5bmO	manager		\N	2026-08-19 15:43:35.82341	2026-08-19 15:43:35.82341	t	f	\N	\N	\N	\N	\N	0	\N	\N	\N
5	test_admin_hardened	\N	$2b$12$84cr.UVx0AzxuMsHIMGm7.rRHF2IndskJ7.2ytRfZF/BWKznDLGvq	admin		\N	2026-08-19 15:43:35.82341	2026-08-19 15:43:35.82341	t	f	\N	\N	\N	\N	\N	0	\N	\N	\N
4	test_viewer	\N	$2b$12$nQPG2Um5UqZfI6jK3B6.WetOxegfqLhd6Pce1RI9tUCKHBMph6XAy	viewer		\N	2026-08-19 15:43:35.82341	2026-08-19 15:44:20.675787	t	t	2026-08-19 15:44:20.667694	\N	127.0.0.1	\N	password	0	\N	\N	\N
1	admin	\N	$2b$12$ZBDm0khkDRbz0JCeYWHKweMqEuIQNPH4U39P4IhVqCAKD5RILGQrK	admin	System Administrator	\N	2026-08-19 15:43:01.098298	2026-08-19 16:19:21.702607	t	t	2026-08-19 16:19:21.697079	\N	127.0.0.1	\N	password	0	\N	\N	\N
\.


--
-- Data for Name: warehouse_grid_cells; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_grid_cells (id, warehouse_id, x, y, cell_type, traversable, occupied, restricted, cost, metadata) FROM stdin;
\.


--
-- Data for Name: warehouse_locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_locations (id, warehouse_id, zone, aisle, rack, shelf, x, y, capacity, current_utilization, location_type, status, created_at) FROM stdin;
WH-WH-BLR-01-RECEIVING	WH-BLR-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-SHIPPING	WH-BLR-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-STAGING	WH-BLR-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-CHARGING-1	WH-BLR-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-CHARGING-2	WH-BLR-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-CPU-01-STORAGE	WH-BLR-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-GPU-01-STORAGE	WH-BLR-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-RAM-01-STORAGE	WH-BLR-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-SSD-01-STORAGE	WH-BLR-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-HDD-01-STORAGE	WH-BLR-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-CHG-01-STORAGE	WH-BLR-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-CBL-01-STORAGE	WH-BLR-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-CPU-01-PICKING	WH-BLR-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-GPU-01-PICKING	WH-BLR-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-RAM-01-PICKING	WH-BLR-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-SSD-01-PICKING	WH-BLR-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-HDD-01-PICKING	WH-BLR-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-CHG-01-PICKING	WH-BLR-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-LOC-ITM-CBL-01-PICKING	WH-BLR-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-1-1	WH-BLR-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-12-1	WH-BLR-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-1-2	WH-BLR-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-2-2	WH-BLR-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-3-2	WH-BLR-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-4-2	WH-BLR-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-5-2	WH-BLR-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-6-2	WH-BLR-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-7-2	WH-BLR-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-8-2	WH-BLR-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-9-2	WH-BLR-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-10-2	WH-BLR-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-11-2	WH-BLR-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-12-2	WH-BLR-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-1-3	WH-BLR-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-12-3	WH-BLR-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-1-4	WH-BLR-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-2-4	WH-BLR-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-3-4	WH-BLR-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-4-4	WH-BLR-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-5-4	WH-BLR-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-6-4	WH-BLR-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.234148
WH-WH-BLR-01-AISLE-7-4	WH-BLR-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-8-4	WH-BLR-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-9-4	WH-BLR-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-10-4	WH-BLR-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-11-4	WH-BLR-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-12-4	WH-BLR-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-3-5	WH-BLR-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-4-5	WH-BLR-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-5-5	WH-BLR-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-6-5	WH-BLR-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-7-5	WH-BLR-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-8-5	WH-BLR-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-9-5	WH-BLR-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BLR-01-AISLE-10-5	WH-BLR-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-RECEIVING	WH-CHN-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-SHIPPING	WH-CHN-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-STAGING	WH-CHN-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-CHARGING-1	WH-CHN-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-CHARGING-2	WH-CHN-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-CPU-01-STORAGE	WH-CHN-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-GPU-01-STORAGE	WH-CHN-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-RAM-01-STORAGE	WH-CHN-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-SSD-01-STORAGE	WH-CHN-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-HDD-01-STORAGE	WH-CHN-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-CHG-01-STORAGE	WH-CHN-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-CBL-01-STORAGE	WH-CHN-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-CPU-01-PICKING	WH-CHN-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-GPU-01-PICKING	WH-CHN-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-RAM-01-PICKING	WH-CHN-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-SSD-01-PICKING	WH-CHN-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-HDD-01-PICKING	WH-CHN-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-CHG-01-PICKING	WH-CHN-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-LOC-ITM-CBL-01-PICKING	WH-CHN-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-1-1	WH-CHN-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-12-1	WH-CHN-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-1-2	WH-CHN-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-2-2	WH-CHN-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-3-2	WH-CHN-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-4-2	WH-CHN-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-5-2	WH-CHN-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-6-2	WH-CHN-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-7-2	WH-CHN-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-8-2	WH-CHN-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-9-2	WH-CHN-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-10-2	WH-CHN-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-11-2	WH-CHN-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-12-2	WH-CHN-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-1-3	WH-CHN-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-12-3	WH-CHN-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-1-4	WH-CHN-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-2-4	WH-CHN-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-3-4	WH-CHN-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-4-4	WH-CHN-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-5-4	WH-CHN-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-6-4	WH-CHN-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-7-4	WH-CHN-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-8-4	WH-CHN-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-9-4	WH-CHN-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-10-4	WH-CHN-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-11-4	WH-CHN-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-12-4	WH-CHN-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-3-5	WH-CHN-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-4-5	WH-CHN-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-5-5	WH-CHN-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-6-5	WH-CHN-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-7-5	WH-CHN-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-8-5	WH-CHN-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-9-5	WH-CHN-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-CHN-01-AISLE-10-5	WH-CHN-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-RECEIVING	WH-BOM-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-SHIPPING	WH-BOM-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-STAGING	WH-BOM-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-CHARGING-1	WH-BOM-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-CHARGING-2	WH-BOM-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-CPU-01-STORAGE	WH-BOM-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-GPU-01-STORAGE	WH-BOM-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-RAM-01-STORAGE	WH-BOM-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-SSD-01-STORAGE	WH-BOM-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-HDD-01-STORAGE	WH-BOM-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-CHG-01-STORAGE	WH-BOM-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-CBL-01-STORAGE	WH-BOM-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-CPU-01-PICKING	WH-BOM-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-GPU-01-PICKING	WH-BOM-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-RAM-01-PICKING	WH-BOM-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-SSD-01-PICKING	WH-BOM-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-HDD-01-PICKING	WH-BOM-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-CHG-01-PICKING	WH-BOM-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-LOC-ITM-CBL-01-PICKING	WH-BOM-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-AISLE-1-1	WH-BOM-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-AISLE-12-1	WH-BOM-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.235151
WH-WH-BOM-01-AISLE-1-2	WH-BOM-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-2-2	WH-BOM-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-3-2	WH-BOM-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-4-2	WH-BOM-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-5-2	WH-BOM-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-6-2	WH-BOM-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-7-2	WH-BOM-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-8-2	WH-BOM-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-9-2	WH-BOM-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-10-2	WH-BOM-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-11-2	WH-BOM-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-12-2	WH-BOM-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-1-3	WH-BOM-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-12-3	WH-BOM-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-1-4	WH-BOM-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-2-4	WH-BOM-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-3-4	WH-BOM-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-4-4	WH-BOM-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-5-4	WH-BOM-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-6-4	WH-BOM-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-7-4	WH-BOM-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-8-4	WH-BOM-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-9-4	WH-BOM-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-10-4	WH-BOM-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-11-4	WH-BOM-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-12-4	WH-BOM-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-3-5	WH-BOM-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-4-5	WH-BOM-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-5-5	WH-BOM-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-6-5	WH-BOM-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-7-5	WH-BOM-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-8-5	WH-BOM-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-9-5	WH-BOM-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-BOM-01-AISLE-10-5	WH-BOM-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-RECEIVING	WH-DEL-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-SHIPPING	WH-DEL-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-STAGING	WH-DEL-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-CHARGING-1	WH-DEL-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-CHARGING-2	WH-DEL-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-CPU-01-STORAGE	WH-DEL-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-GPU-01-STORAGE	WH-DEL-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-RAM-01-STORAGE	WH-DEL-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-SSD-01-STORAGE	WH-DEL-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-HDD-01-STORAGE	WH-DEL-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-CHG-01-STORAGE	WH-DEL-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-CBL-01-STORAGE	WH-DEL-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-CPU-01-PICKING	WH-DEL-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-GPU-01-PICKING	WH-DEL-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-RAM-01-PICKING	WH-DEL-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-SSD-01-PICKING	WH-DEL-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-HDD-01-PICKING	WH-DEL-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-CHG-01-PICKING	WH-DEL-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-LOC-ITM-CBL-01-PICKING	WH-DEL-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-1-1	WH-DEL-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-12-1	WH-DEL-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-1-2	WH-DEL-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-2-2	WH-DEL-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-3-2	WH-DEL-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-4-2	WH-DEL-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-5-2	WH-DEL-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-6-2	WH-DEL-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-7-2	WH-DEL-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-8-2	WH-DEL-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-9-2	WH-DEL-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-10-2	WH-DEL-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-11-2	WH-DEL-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-12-2	WH-DEL-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-1-3	WH-DEL-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-12-3	WH-DEL-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-1-4	WH-DEL-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-2-4	WH-DEL-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-3-4	WH-DEL-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-4-4	WH-DEL-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-5-4	WH-DEL-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-6-4	WH-DEL-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-7-4	WH-DEL-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-8-4	WH-DEL-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-9-4	WH-DEL-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-10-4	WH-DEL-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-11-4	WH-DEL-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-12-4	WH-DEL-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-3-5	WH-DEL-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-4-5	WH-DEL-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-5-5	WH-DEL-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-6-5	WH-DEL-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-7-5	WH-DEL-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-8-5	WH-DEL-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-9-5	WH-DEL-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-DEL-01-AISLE-10-5	WH-DEL-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-RECEIVING	WH-CCU-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-SHIPPING	WH-CCU-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-STAGING	WH-CCU-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-CHARGING-1	WH-CCU-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-CHARGING-2	WH-CCU-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-CPU-01-STORAGE	WH-CCU-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-GPU-01-STORAGE	WH-CCU-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-RAM-01-STORAGE	WH-CCU-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-SSD-01-STORAGE	WH-CCU-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-HDD-01-STORAGE	WH-CCU-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-CHG-01-STORAGE	WH-CCU-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-CBL-01-STORAGE	WH-CCU-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-CPU-01-PICKING	WH-CCU-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-GPU-01-PICKING	WH-CCU-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-RAM-01-PICKING	WH-CCU-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-SSD-01-PICKING	WH-CCU-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-HDD-01-PICKING	WH-CCU-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-CHG-01-PICKING	WH-CCU-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-LOC-ITM-CBL-01-PICKING	WH-CCU-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-1-1	WH-CCU-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-12-1	WH-CCU-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-1-2	WH-CCU-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-2-2	WH-CCU-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-3-2	WH-CCU-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-4-2	WH-CCU-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-5-2	WH-CCU-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-6-2	WH-CCU-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-7-2	WH-CCU-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-8-2	WH-CCU-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-9-2	WH-CCU-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-10-2	WH-CCU-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-11-2	WH-CCU-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-12-2	WH-CCU-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-1-3	WH-CCU-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-12-3	WH-CCU-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-1-4	WH-CCU-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-2-4	WH-CCU-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-3-4	WH-CCU-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.23615
WH-WH-CCU-01-AISLE-4-4	WH-CCU-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-5-4	WH-CCU-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-6-4	WH-CCU-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-7-4	WH-CCU-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-8-4	WH-CCU-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-9-4	WH-CCU-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-10-4	WH-CCU-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-11-4	WH-CCU-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-12-4	WH-CCU-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-3-5	WH-CCU-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-4-5	WH-CCU-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-5-5	WH-CCU-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-6-5	WH-CCU-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-7-5	WH-CCU-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-8-5	WH-CCU-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-9-5	WH-CCU-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
WH-WH-CCU-01-AISLE-10-5	WH-CCU-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 16:19:14.237149
\.


--
-- Data for Name: warehouse_obstacles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_obstacles (id, warehouse_id, obstacle_type, x, y, width, height, active, severity, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouses (id, name, location, latitude, longitude, created_at) FROM stdin;
WH-BLR-01	Bangalore Fulfillment Center	Bangalore, Karnataka	12.971598	77.594566	2026-08-19 16:19:14.168908
WH-CHN-01	Chennai Port Logistics Hub	Chennai, Tamil Nadu	13.08268	80.270718	2026-08-19 16:19:14.180905
WH-BOM-01	Mumbai Container Terminal	Mumbai, Maharashtra	19.07609	72.877701	2026-08-19 16:19:14.186992
WH-DEL-01	Delhi NCR Logistics Park	Noida, Uttar Pradesh	28.535517	77.391029	2026-08-19 16:19:14.192911
WH-CCU-01	Kolkata Gateway Depot	Kolkata, West Bengal	22.572646	88.363895	2026-08-19 16:19:14.199153
\.


--
-- Name: access_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_log_id_seq', 262, true);


--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_recommendations_id_seq', 1, false);


--
-- Name: audit_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_ledger_id_seq', 255, true);


--
-- Name: backup_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.backup_records_id_seq', 1, true);


--
-- Name: digital_twin_simulations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.digital_twin_simulations_id_seq', 1, false);


--
-- Name: experiment_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.experiment_runs_id_seq', 1, false);


--
-- Name: experiments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.experiments_id_seq', 1, false);


--
-- Name: health_thresholds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.health_thresholds_id_seq', 1, false);


--
-- Name: inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_id_seq', 175, true);


--
-- Name: inventory_reservations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_reservations_id_seq', 1, false);


--
-- Name: notification_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_preferences_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 15, true);


--
-- Name: order_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_events_id_seq', 1, false);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- Name: otp_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.otp_records_id_seq', 1, false);


--
-- Name: packing_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.packing_records_id_seq', 1, false);


--
-- Name: recovery_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recovery_codes_id_seq', 1, false);


--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recovery_credentials_id_seq', 1, false);


--
-- Name: robot_reservations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robot_reservations_id_seq', 1, false);


--
-- Name: robot_routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robot_routes_id_seq', 1, false);


--
-- Name: robot_telemetry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robot_telemetry_id_seq', 1, false);


--
-- Name: robots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robots_id_seq', 35, true);


--
-- Name: scenarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scenarios_id_seq', 1, false);


--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shrinkage_flags_id_seq', 10, true);


--
-- Name: simulation_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.simulation_events_id_seq', 1, false);


--
-- Name: simulation_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.simulation_snapshots_id_seq', 1, false);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 5250, true);


--
-- Name: system_health_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_health_snapshots_id_seq', 891, true);


--
-- Name: system_incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_incidents_id_seq', 1, true);


--
-- Name: task_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_events_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 1, false);


--
-- Name: user_warehouse_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_warehouse_access_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: warehouse_grid_cells_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.warehouse_grid_cells_id_seq', 120, true);


--
-- Name: warehouse_obstacles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.warehouse_obstacles_id_seq', 1, false);


--
-- Name: access_log access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log
    ADD CONSTRAINT access_log_pkey PRIMARY KEY (id);


--
-- Name: ai_recommendations ai_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_recommendations
    ADD CONSTRAINT ai_recommendations_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_ledger audit_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_ledger
    ADD CONSTRAINT audit_ledger_pkey PRIMARY KEY (id);


--
-- Name: backup_records backup_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_records
    ADD CONSTRAINT backup_records_pkey PRIMARY KEY (id);


--
-- Name: digital_twin_simulations digital_twin_simulations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.digital_twin_simulations
    ADD CONSTRAINT digital_twin_simulations_pkey PRIMARY KEY (id);


--
-- Name: experiment_runs experiment_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_runs
    ADD CONSTRAINT experiment_runs_pkey PRIMARY KEY (id);


--
-- Name: experiments experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT experiments_pkey PRIMARY KEY (id);


--
-- Name: health_thresholds health_thresholds_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_thresholds
    ADD CONSTRAINT health_thresholds_pkey PRIMARY KEY (id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: inventory_reservations inventory_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_events order_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_events
    ADD CONSTRAINT order_events_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: otp_records otp_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_records
    ADD CONSTRAINT otp_records_pkey PRIMARY KEY (id);


--
-- Name: packing_records packing_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packing_records
    ADD CONSTRAINT packing_records_pkey PRIMARY KEY (id);


--
-- Name: recovery_codes recovery_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: recovery_credentials recovery_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials
    ADD CONSTRAINT recovery_credentials_pkey PRIMARY KEY (id);


--
-- Name: robot_reservations robot_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_reservations
    ADD CONSTRAINT robot_reservations_pkey PRIMARY KEY (id);


--
-- Name: robot_routes robot_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes
    ADD CONSTRAINT robot_routes_pkey PRIMARY KEY (id);


--
-- Name: robot_telemetry robot_telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_telemetry
    ADD CONSTRAINT robot_telemetry_pkey PRIMARY KEY (id);


--
-- Name: robots robots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_pkey PRIMARY KEY (id);


--
-- Name: scenarios scenarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scenarios
    ADD CONSTRAINT scenarios_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: shrinkage_flags shrinkage_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shrinkage_flags
    ADD CONSTRAINT shrinkage_flags_pkey PRIMARY KEY (id);


--
-- Name: simulation_events simulation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_events
    ADD CONSTRAINT simulation_events_pkey PRIMARY KEY (id);


--
-- Name: simulation_snapshots simulation_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_snapshots
    ADD CONSTRAINT simulation_snapshots_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: system_health_snapshots system_health_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_health_snapshots
    ADD CONSTRAINT system_health_snapshots_pkey PRIMARY KEY (id);


--
-- Name: system_incidents system_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_incidents
    ADD CONSTRAINT system_incidents_pkey PRIMARY KEY (id);


--
-- Name: task_events task_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: warehouse_grid_cells uq_grid_cell; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_grid_cells
    ADD CONSTRAINT uq_grid_cell UNIQUE (warehouse_id, x, y);


--
-- Name: stock_movements uq_movement; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT uq_movement UNIQUE (date, warehouse_id, item_id);


--
-- Name: otp_records uq_otp_user_purpose; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_records
    ADD CONSTRAINT uq_otp_user_purpose UNIQUE (user_id, purpose);


--
-- Name: notification_preferences uq_user_category_preference; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT uq_user_category_preference UNIQUE (user_id, category);


--
-- Name: user_warehouse_access uq_user_warehouse; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access
    ADD CONSTRAINT uq_user_warehouse UNIQUE (user_id, warehouse_id);


--
-- Name: inventory uq_warehouse_item_location; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT uq_warehouse_item_location UNIQUE (warehouse_id, item_id, location_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_token_hash_key UNIQUE (session_token_hash);


--
-- Name: user_warehouse_access user_warehouse_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access
    ADD CONSTRAINT user_warehouse_access_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouse_grid_cells warehouse_grid_cells_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_grid_cells
    ADD CONSTRAINT warehouse_grid_cells_pkey PRIMARY KEY (id);


--
-- Name: warehouse_locations warehouse_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_pkey PRIMARY KEY (id);


--
-- Name: warehouse_obstacles warehouse_obstacles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_obstacles
    ADD CONSTRAINT warehouse_obstacles_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: ix_access_log_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_access_log_timestamp ON public.access_log USING btree ("timestamp");


--
-- Name: ix_ai_recommendations_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_recommendations_created_at ON public.ai_recommendations USING btree (created_at);


--
-- Name: ix_ai_recommendations_recommendation_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_recommendations_recommendation_type ON public.ai_recommendations USING btree (recommendation_type);


--
-- Name: ix_ai_recommendations_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_recommendations_timestamp ON public.ai_recommendations USING btree ("timestamp");


--
-- Name: ix_backup_records_backup_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_backup_records_backup_id ON public.backup_records USING btree (backup_id);


--
-- Name: ix_backup_records_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_backup_records_created_at ON public.backup_records USING btree (created_at);


--
-- Name: ix_digital_twin_simulations_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_digital_twin_simulations_created_at ON public.digital_twin_simulations USING btree (created_at);


--
-- Name: ix_digital_twin_simulations_simulation_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_digital_twin_simulations_simulation_status ON public.digital_twin_simulations USING btree (simulation_status);


--
-- Name: ix_digital_twin_simulations_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_digital_twin_simulations_warehouse_id ON public.digital_twin_simulations USING btree (warehouse_id);


--
-- Name: ix_experiment_runs_experiment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_experiment_runs_experiment_id ON public.experiment_runs USING btree (experiment_id);


--
-- Name: ix_experiments_scenario_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_experiments_scenario_id ON public.experiments USING btree (scenario_id);


--
-- Name: ix_health_thresholds_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_health_thresholds_key ON public.health_thresholds USING btree (key);


--
-- Name: ix_inventory_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_item_id ON public.inventory USING btree (item_id);


--
-- Name: ix_inventory_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_location_id ON public.inventory USING btree (location_id);


--
-- Name: ix_inventory_reservations_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_reservations_created_at ON public.inventory_reservations USING btree (created_at);


--
-- Name: ix_inventory_reservations_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_reservations_item_id ON public.inventory_reservations USING btree (item_id);


--
-- Name: ix_inventory_reservations_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_reservations_location_id ON public.inventory_reservations USING btree (location_id);


--
-- Name: ix_inventory_reservations_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_reservations_order_id ON public.inventory_reservations USING btree (order_id);


--
-- Name: ix_inventory_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_warehouse_id ON public.inventory USING btree (warehouse_id);


--
-- Name: ix_items_sku; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_items_sku ON public.items USING btree (sku);


--
-- Name: ix_notification_preferences_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notification_preferences_category ON public.notification_preferences USING btree (category);


--
-- Name: ix_notification_preferences_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notification_preferences_user_id ON public.notification_preferences USING btree (user_id);


--
-- Name: ix_notifications_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_created_at ON public.notifications USING btree (created_at);


--
-- Name: ix_notifications_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_event_type ON public.notifications USING btree (event_type);


--
-- Name: ix_notifications_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_status ON public.notifications USING btree (status);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_notifications_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_warehouse_id ON public.notifications USING btree (warehouse_id);


--
-- Name: ix_order_events_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_events_order_id ON public.order_events USING btree (order_id);


--
-- Name: ix_order_events_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_events_timestamp ON public.order_events USING btree ("timestamp");


--
-- Name: ix_order_items_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_items_item_id ON public.order_items USING btree (item_id);


--
-- Name: ix_order_items_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_items_order_id ON public.order_items USING btree (order_id);


--
-- Name: ix_orders_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_created_at ON public.orders USING btree (created_at);


--
-- Name: ix_orders_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_status ON public.orders USING btree (status);


--
-- Name: ix_orders_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_warehouse_id ON public.orders USING btree (warehouse_id);


--
-- Name: ix_otp_records_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_otp_records_expires_at ON public.otp_records USING btree (expires_at);


--
-- Name: ix_otp_records_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_otp_records_user_id ON public.otp_records USING btree (user_id);


--
-- Name: ix_packing_records_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_packing_records_order_id ON public.packing_records USING btree (order_id);


--
-- Name: ix_recovery_codes_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_recovery_codes_user_id ON public.recovery_codes USING btree (user_id);


--
-- Name: ix_recovery_credentials_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_recovery_credentials_user_id ON public.recovery_credentials USING btree (user_id);


--
-- Name: ix_robot_reservations_robot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_reservations_robot_id ON public.robot_reservations USING btree (robot_id);


--
-- Name: ix_robot_reservations_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_reservations_warehouse_id ON public.robot_reservations USING btree (warehouse_id);


--
-- Name: ix_robot_routes_robot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_routes_robot_id ON public.robot_routes USING btree (robot_id);


--
-- Name: ix_robot_routes_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_routes_task_id ON public.robot_routes USING btree (task_id);


--
-- Name: ix_robot_routes_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_routes_warehouse_id ON public.robot_routes USING btree (warehouse_id);


--
-- Name: ix_robot_telemetry_robot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_telemetry_robot_id ON public.robot_telemetry USING btree (robot_id);


--
-- Name: ix_robot_telemetry_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_telemetry_timestamp ON public.robot_telemetry USING btree ("timestamp");


--
-- Name: ix_robots_assigned_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_assigned_task_id ON public.robots USING btree (assigned_task_id);


--
-- Name: ix_robots_current_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_current_location_id ON public.robots USING btree (current_location_id);


--
-- Name: ix_robots_robot_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_robots_robot_code ON public.robots USING btree (robot_code);


--
-- Name: ix_robots_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_status ON public.robots USING btree (status);


--
-- Name: ix_robots_target_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_target_location_id ON public.robots USING btree (target_location_id);


--
-- Name: ix_robots_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_warehouse_id ON public.robots USING btree (warehouse_id);


--
-- Name: ix_scenarios_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_scenarios_warehouse_id ON public.scenarios USING btree (warehouse_id);


--
-- Name: ix_shipments_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_shipments_order_id ON public.shipments USING btree (order_id);


--
-- Name: ix_simulation_events_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_event_type ON public.simulation_events USING btree (event_type);


--
-- Name: ix_simulation_events_real_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_real_timestamp ON public.simulation_events USING btree (real_timestamp);


--
-- Name: ix_simulation_events_robot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_robot_id ON public.simulation_events USING btree (robot_id);


--
-- Name: ix_simulation_events_simulation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_simulation_id ON public.simulation_events USING btree (simulation_id);


--
-- Name: ix_simulation_events_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_task_id ON public.simulation_events USING btree (task_id);


--
-- Name: ix_simulation_events_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_warehouse_id ON public.simulation_events USING btree (warehouse_id);


--
-- Name: ix_simulation_snapshots_simulation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_snapshots_simulation_id ON public.simulation_snapshots USING btree (simulation_id);


--
-- Name: ix_simulation_snapshots_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_snapshots_warehouse_id ON public.simulation_snapshots USING btree (warehouse_id);


--
-- Name: ix_stock_movements_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_date ON public.stock_movements USING btree (date);


--
-- Name: ix_stock_movements_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_item_id ON public.stock_movements USING btree (item_id);


--
-- Name: ix_stock_movements_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_warehouse_id ON public.stock_movements USING btree (warehouse_id);


--
-- Name: ix_system_health_snapshots_service; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_system_health_snapshots_service ON public.system_health_snapshots USING btree (service);


--
-- Name: ix_system_health_snapshots_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_system_health_snapshots_timestamp ON public.system_health_snapshots USING btree ("timestamp");


--
-- Name: ix_system_incidents_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_system_incidents_category ON public.system_incidents USING btree (category);


--
-- Name: ix_system_incidents_fingerprint; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_system_incidents_fingerprint ON public.system_incidents USING btree (fingerprint);


--
-- Name: ix_task_events_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_events_task_id ON public.task_events USING btree (task_id);


--
-- Name: ix_tasks_assigned_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_assigned_user_id ON public.tasks USING btree (assigned_user_id);


--
-- Name: ix_tasks_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_created_at ON public.tasks USING btree (created_at);


--
-- Name: ix_tasks_destination_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_destination_location_id ON public.tasks USING btree (destination_location_id);


--
-- Name: ix_tasks_due_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_due_at ON public.tasks USING btree (due_at);


--
-- Name: ix_tasks_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_order_id ON public.tasks USING btree (order_id);


--
-- Name: ix_tasks_order_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_order_item_id ON public.tasks USING btree (order_item_id);


--
-- Name: ix_tasks_priority_score; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_priority_score ON public.tasks USING btree (priority_score);


--
-- Name: ix_tasks_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_product_id ON public.tasks USING btree (product_id);


--
-- Name: ix_tasks_source_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_source_location_id ON public.tasks USING btree (source_location_id);


--
-- Name: ix_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_status ON public.tasks USING btree (status);


--
-- Name: ix_tasks_task_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_tasks_task_number ON public.tasks USING btree (task_number);


--
-- Name: ix_tasks_task_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_task_type ON public.tasks USING btree (task_type);


--
-- Name: ix_tasks_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_warehouse_id ON public.tasks USING btree (warehouse_id);


--
-- Name: ix_user_sessions_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_sessions_expires_at ON public.user_sessions USING btree (expires_at);


--
-- Name: ix_user_sessions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: ix_user_warehouse_access_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_warehouse_access_user_id ON public.user_warehouse_access USING btree (user_id);


--
-- Name: ix_user_warehouse_access_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_warehouse_access_warehouse_id ON public.user_warehouse_access USING btree (warehouse_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_google_subject_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_google_subject_id ON public.users USING btree (google_subject_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_warehouse_grid_cells_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_grid_cells_warehouse_id ON public.warehouse_grid_cells USING btree (warehouse_id);


--
-- Name: ix_warehouse_locations_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_locations_warehouse_id ON public.warehouse_locations USING btree (warehouse_id);


--
-- Name: ix_warehouse_obstacles_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_obstacles_warehouse_id ON public.warehouse_obstacles USING btree (warehouse_id);


--
-- Name: digital_twin_simulations digital_twin_simulations_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.digital_twin_simulations
    ADD CONSTRAINT digital_twin_simulations_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: experiment_runs experiment_runs_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_runs
    ADD CONSTRAINT experiment_runs_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiments(id) ON DELETE CASCADE;


--
-- Name: experiments experiments_scenario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT experiments_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES public.scenarios(id) ON DELETE CASCADE;


--
-- Name: inventory inventory_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: inventory inventory_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: inventory_reservations inventory_reservations_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: inventory_reservations inventory_reservations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: inventory_reservations inventory_reservations_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: inventory inventory_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: order_events order_events_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_events
    ADD CONSTRAINT order_events_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders orders_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: otp_records otp_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_records
    ADD CONSTRAINT otp_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: packing_records packing_records_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packing_records
    ADD CONSTRAINT packing_records_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: recovery_codes recovery_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: recovery_credentials recovery_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials
    ADD CONSTRAINT recovery_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: robot_reservations robot_reservations_robot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_reservations
    ADD CONSTRAINT robot_reservations_robot_id_fkey FOREIGN KEY (robot_id) REFERENCES public.robots(id) ON DELETE CASCADE;


--
-- Name: robot_reservations robot_reservations_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_reservations
    ADD CONSTRAINT robot_reservations_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: robot_routes robot_routes_robot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes
    ADD CONSTRAINT robot_routes_robot_id_fkey FOREIGN KEY (robot_id) REFERENCES public.robots(id) ON DELETE CASCADE;


--
-- Name: robot_routes robot_routes_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes
    ADD CONSTRAINT robot_routes_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: robot_routes robot_routes_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes
    ADD CONSTRAINT robot_routes_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: robot_telemetry robot_telemetry_robot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_telemetry
    ADD CONSTRAINT robot_telemetry_robot_id_fkey FOREIGN KEY (robot_id) REFERENCES public.robots(id) ON DELETE CASCADE;


--
-- Name: robots robots_assigned_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_assigned_task_id_fkey FOREIGN KEY (assigned_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: robots robots_current_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_current_location_id_fkey FOREIGN KEY (current_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: robots robots_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: robots robots_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: scenarios scenarios_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scenarios
    ADD CONSTRAINT scenarios_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: shipments shipments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: simulation_events simulation_events_simulation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_events
    ADD CONSTRAINT simulation_events_simulation_id_fkey FOREIGN KEY (simulation_id) REFERENCES public.digital_twin_simulations(id) ON DELETE CASCADE;


--
-- Name: simulation_events simulation_events_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_events
    ADD CONSTRAINT simulation_events_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: simulation_snapshots simulation_snapshots_simulation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_snapshots
    ADD CONSTRAINT simulation_snapshots_simulation_id_fkey FOREIGN KEY (simulation_id) REFERENCES public.digital_twin_simulations(id) ON DELETE CASCADE;


--
-- Name: simulation_snapshots simulation_snapshots_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_snapshots
    ADD CONSTRAINT simulation_snapshots_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id);


--
-- Name: stock_movements stock_movements_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: task_events task_events_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_events task_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_assigned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assigned_user_id_fkey FOREIGN KEY (assigned_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_depends_on_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_depends_on_task_id_fkey FOREIGN KEY (depends_on_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_destination_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_destination_location_id_fkey FOREIGN KEY (destination_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_order_item_id_fkey FOREIGN KEY (order_item_id) REFERENCES public.order_items(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_warehouse_access user_warehouse_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access
    ADD CONSTRAINT user_warehouse_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_warehouse_access user_warehouse_access_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access
    ADD CONSTRAINT user_warehouse_access_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: warehouse_grid_cells warehouse_grid_cells_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_grid_cells
    ADD CONSTRAINT warehouse_grid_cells_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: warehouse_locations warehouse_locations_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: warehouse_obstacles warehouse_obstacles_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_obstacles
    ADD CONSTRAINT warehouse_obstacles_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict ns98XlkMcLeoxAhHnaeuITzzsTRUhPmaJOaUhfVuFqrwJb78TUWRyqezMdOPrsh

