--
-- PostgreSQL database dump
--

\restrict xoYiS211i2qkwHTRBsT7wmLRIJ2ki80f5DpUaMb6xgtIeS8op2Q98K7FAqMRQ85

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_log (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    username character varying(64) NOT NULL,
    warehouse_id character varying(20),
    action character varying(50) NOT NULL,
    ip_address character varying(45)
);


ALTER TABLE public.access_log OWNER TO postgres;

--
-- Name: access_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.access_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.access_log_id_seq OWNER TO postgres;

--
-- Name: access_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.access_log_id_seq OWNED BY public.access_log.id;


--
-- Name: ai_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_recommendations (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(50),
    title character varying(100) NOT NULL,
    risk_level character varying(20),
    action_recommended character varying(100) NOT NULL,
    confidence_score integer,
    input_factors text,
    status character varying(20),
    decision_by character varying(64),
    decision_time timestamp without time zone,
    notes text,
    recommendation_type character varying(50),
    description text,
    priority character varying(20),
    score integer,
    confidence_or_reliability character varying(50),
    source_model character varying(50),
    source_entity_type character varying(50),
    source_entity_id character varying(50),
    recommended_action character varying(200),
    estimated_impact double precision,
    explanation text,
    supporting_metrics text,
    created_at timestamp without time zone NOT NULL,
    reviewed_at timestamp without time zone,
    reviewed_by character varying(64),
    review_notes text,
    expires_at timestamp without time zone,
    metadata text NOT NULL
);


ALTER TABLE public.ai_recommendations OWNER TO postgres;

--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_recommendations_id_seq OWNER TO postgres;

--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_recommendations_id_seq OWNED BY public.ai_recommendations.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: audit_ledger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_ledger (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    event_type character varying(50) NOT NULL,
    details text,
    prev_hash character varying(64) NOT NULL,
    hash character varying(64) NOT NULL
);


ALTER TABLE public.audit_ledger OWNER TO postgres;

--
-- Name: audit_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_ledger_id_seq OWNER TO postgres;

--
-- Name: audit_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_ledger_id_seq OWNED BY public.audit_ledger.id;


--
-- Name: backup_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_records (
    id integer NOT NULL,
    backup_id character varying(64) NOT NULL,
    filename character varying(255) NOT NULL,
    created_at timestamp without time zone,
    size_bytes integer,
    sha256 character varying(64),
    status character varying(20) NOT NULL,
    storage_key character varying(255),
    error_message text,
    backup_type character varying(50),
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    storage_provider character varying(50),
    bucket character varying(255),
    checksum_algorithm character varying(20),
    verification_status character varying(50),
    verification_at timestamp without time zone,
    restore_test_status character varying(50),
    restore_test_at timestamp without time zone,
    retention_status character varying(50),
    initiated_by character varying(100),
    audit_ref character varying(255)
);


ALTER TABLE public.backup_records OWNER TO postgres;

--
-- Name: backup_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.backup_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_records_id_seq OWNER TO postgres;

--
-- Name: backup_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.backup_records_id_seq OWNED BY public.backup_records.id;


--
-- Name: digital_twin_simulations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.digital_twin_simulations (
    id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    simulation_status character varying(20) NOT NULL,
    simulation_time_seconds double precision NOT NULL,
    speed_multiplier double precision NOT NULL,
    seed integer NOT NULL,
    mode character varying(20) NOT NULL,
    scenario_type character varying(30) NOT NULL,
    tick_count integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    started_at timestamp without time zone,
    paused_at timestamp without time zone,
    stopped_at timestamp without time zone,
    completed_at timestamp without time zone,
    error_message text,
    created_by character varying(64) NOT NULL
);


ALTER TABLE public.digital_twin_simulations OWNER TO postgres;

--
-- Name: digital_twin_simulations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.digital_twin_simulations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.digital_twin_simulations_id_seq OWNER TO postgres;

--
-- Name: digital_twin_simulations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.digital_twin_simulations_id_seq OWNED BY public.digital_twin_simulations.id;


--
-- Name: experiment_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.experiment_runs (
    id integer NOT NULL,
    experiment_id integer NOT NULL,
    repetition_number integer NOT NULL,
    random_seed integer NOT NULL,
    status character varying(20) NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    duration_seconds double precision,
    error_message text,
    metrics json,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.experiment_runs OWNER TO postgres;

--
-- Name: experiment_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.experiment_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.experiment_runs_id_seq OWNER TO postgres;

--
-- Name: experiment_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.experiment_runs_id_seq OWNED BY public.experiment_runs.id;


--
-- Name: experiments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.experiments (
    id integer NOT NULL,
    scenario_id integer NOT NULL,
    experiment_name character varying(150) NOT NULL,
    description text,
    status character varying(20) NOT NULL,
    algorithm_name character varying(50) NOT NULL,
    algorithm_version character varying(20) NOT NULL,
    configuration json NOT NULL,
    random_seed integer NOT NULL,
    repetitions integer NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    duration_seconds double precision,
    created_by character varying(64) NOT NULL,
    error_message text,
    metrics_summary json,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.experiments OWNER TO postgres;

--
-- Name: experiments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.experiments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.experiments_id_seq OWNER TO postgres;

--
-- Name: experiments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.experiments_id_seq OWNED BY public.experiments.id;


--
-- Name: health_thresholds; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health_thresholds (
    id integer NOT NULL,
    key character varying(64) NOT NULL,
    value double precision NOT NULL,
    description character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.health_thresholds OWNER TO postgres;

--
-- Name: health_thresholds_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.health_thresholds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.health_thresholds_id_seq OWNER TO postgres;

--
-- Name: health_thresholds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.health_thresholds_id_seq OWNED BY public.health_thresholds.id;


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    location_id character varying(50),
    on_hand integer NOT NULL,
    reserved integer NOT NULL,
    available integer NOT NULL,
    damaged integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_id_seq OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_id_seq OWNED BY public.inventory.id;


--
-- Name: inventory_reservations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_reservations (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    location_id character varying(50),
    reserved_qty integer NOT NULL,
    released_qty integer NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.inventory_reservations OWNER TO postgres;

--
-- Name: inventory_reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_reservations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_reservations_id_seq OWNER TO postgres;

--
-- Name: inventory_reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_reservations_id_seq OWNED BY public.inventory_reservations.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id character varying(20) NOT NULL,
    name character varying(150) NOT NULL,
    category character varying(80),
    unit_cost double precision,
    lead_time_days integer,
    safety_stock integer,
    sku character varying(64),
    description text,
    unit character varying(20),
    weight_kg double precision,
    dimensions character varying(50),
    barcode character varying(64),
    is_active boolean,
    reorder_threshold integer,
    preferred_storage_type character varying(20),
    created_at timestamp without time zone
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_preferences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    category character varying(50) NOT NULL,
    in_app_enabled boolean NOT NULL,
    email_enabled boolean NOT NULL,
    min_severity character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.notification_preferences OWNER TO postgres;

--
-- Name: notification_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_preferences_id_seq OWNER TO postgres;

--
-- Name: notification_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_preferences_id_seq OWNED BY public.notification_preferences.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    warehouse_id character varying(20),
    event_type character varying(50) NOT NULL,
    notification_type character varying(50) NOT NULL,
    title character varying(150) NOT NULL,
    message text NOT NULL,
    severity character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    channel character varying(20) NOT NULL,
    source_entity_type character varying(50),
    source_entity_id character varying(50),
    created_at timestamp without time zone NOT NULL,
    read_at timestamp without time zone,
    delivered_at timestamp without time zone,
    failed_at timestamp without time zone,
    retry_count integer NOT NULL,
    expires_at timestamp without time zone,
    metadata text NOT NULL,
    idempotency_key character varying(255)
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: order_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_events (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    "timestamp" timestamp without time zone,
    status character varying(30) NOT NULL,
    event_type character varying(50) NOT NULL,
    operator character varying(64),
    notes text
);


ALTER TABLE public.order_events OWNER TO postgres;

--
-- Name: order_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_events_id_seq OWNER TO postgres;

--
-- Name: order_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_events_id_seq OWNED BY public.order_events.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    requested_qty integer NOT NULL,
    reserved_qty integer NOT NULL,
    picked_qty integer NOT NULL,
    packed_qty integer NOT NULL,
    shipped_qty integer NOT NULL,
    status character varying(20) NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id character varying(20) NOT NULL,
    customer_ref character varying(100) NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    status character varying(30) NOT NULL,
    priority character varying(20) NOT NULL,
    total_items integer NOT NULL,
    notes text,
    created_by character varying(64)
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: otp_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otp_records (
    id integer NOT NULL,
    user_id integer NOT NULL,
    purpose character varying(50) NOT NULL,
    code_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    attempts integer NOT NULL,
    max_attempts integer NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    request_ip character varying(45),
    context_data text
);


ALTER TABLE public.otp_records OWNER TO postgres;

--
-- Name: otp_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.otp_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.otp_records_id_seq OWNER TO postgres;

--
-- Name: otp_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.otp_records_id_seq OWNED BY public.otp_records.id;


--
-- Name: packing_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.packing_records (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    operator character varying(64),
    package_count integer NOT NULL,
    weight_kg double precision,
    notes text
);


ALTER TABLE public.packing_records OWNER TO postgres;

--
-- Name: packing_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.packing_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.packing_records_id_seq OWNER TO postgres;

--
-- Name: packing_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.packing_records_id_seq OWNED BY public.packing_records.id;


--
-- Name: recovery_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recovery_codes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code_hash character varying(255) NOT NULL,
    used boolean NOT NULL,
    created_at timestamp without time zone,
    used_at timestamp without time zone
);


ALTER TABLE public.recovery_codes OWNER TO postgres;

--
-- Name: recovery_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recovery_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recovery_codes_id_seq OWNER TO postgres;

--
-- Name: recovery_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recovery_codes_id_seq OWNED BY public.recovery_codes.id;


--
-- Name: recovery_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recovery_credentials (
    id integer NOT NULL,
    user_id integer NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.recovery_credentials OWNER TO postgres;

--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recovery_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recovery_credentials_id_seq OWNER TO postgres;

--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recovery_credentials_id_seq OWNED BY public.recovery_credentials.id;


--
-- Name: robot_reservations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robot_reservations (
    id integer NOT NULL,
    robot_id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    tick integer NOT NULL
);


ALTER TABLE public.robot_reservations OWNER TO postgres;

--
-- Name: robot_reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.robot_reservations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.robot_reservations_id_seq OWNER TO postgres;

--
-- Name: robot_reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.robot_reservations_id_seq OWNED BY public.robot_reservations.id;


--
-- Name: robot_routes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robot_routes (
    id integer NOT NULL,
    robot_id integer NOT NULL,
    task_id integer,
    warehouse_id character varying(20) NOT NULL,
    start_x integer NOT NULL,
    start_y integer NOT NULL,
    goal_x integer NOT NULL,
    goal_y integer NOT NULL,
    algorithm character varying(30) NOT NULL,
    path_data text NOT NULL,
    distance double precision NOT NULL,
    cost double precision NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    completed_at timestamp without time zone
);


ALTER TABLE public.robot_routes OWNER TO postgres;

--
-- Name: robot_routes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.robot_routes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.robot_routes_id_seq OWNER TO postgres;

--
-- Name: robot_routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.robot_routes_id_seq OWNED BY public.robot_routes.id;


--
-- Name: robot_telemetry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robot_telemetry (
    id integer NOT NULL,
    robot_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    x double precision NOT NULL,
    y double precision NOT NULL,
    battery double precision NOT NULL,
    status character varying(30) NOT NULL,
    task_id integer,
    metadata text NOT NULL
);


ALTER TABLE public.robot_telemetry OWNER TO postgres;

--
-- Name: robot_telemetry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.robot_telemetry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.robot_telemetry_id_seq OWNER TO postgres;

--
-- Name: robot_telemetry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.robot_telemetry_id_seq OWNED BY public.robot_telemetry.id;


--
-- Name: robots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robots (
    id integer NOT NULL,
    robot_code character varying(30) NOT NULL,
    name character varying(100) NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    status character varying(30) NOT NULL,
    battery_level double precision NOT NULL,
    current_location_id character varying(50),
    current_x double precision NOT NULL,
    current_y double precision NOT NULL,
    target_location_id character varying(50),
    target_x double precision NOT NULL,
    target_y double precision NOT NULL,
    assigned_task_id integer,
    total_tasks_completed integer NOT NULL,
    total_distance double precision NOT NULL,
    total_operating_time double precision NOT NULL,
    utilization_percent double precision NOT NULL,
    failure_count integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    last_heartbeat_at timestamp without time zone NOT NULL,
    robot_type character varying(30) NOT NULL,
    max_payload double precision NOT NULL,
    max_speed double precision NOT NULL,
    enabled boolean NOT NULL,
    metadata text NOT NULL
);


ALTER TABLE public.robots OWNER TO postgres;

--
-- Name: robots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.robots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.robots_id_seq OWNER TO postgres;

--
-- Name: robots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.robots_id_seq OWNED BY public.robots.id;


--
-- Name: scenarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scenarios (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    warehouse_id character varying(20) NOT NULL,
    scenario_type character varying(30) NOT NULL,
    configuration json NOT NULL,
    random_seed integer NOT NULL,
    status character varying(20) NOT NULL,
    tags text NOT NULL,
    notes text,
    created_by character varying(64) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.scenarios OWNER TO postgres;

--
-- Name: scenarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.scenarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scenarios_id_seq OWNER TO postgres;

--
-- Name: scenarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.scenarios_id_seq OWNED BY public.scenarios.id;


--
-- Name: shipments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipments (
    id character varying(20) NOT NULL,
    order_id character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    tracking_reference character varying(100),
    carrier character varying(50),
    created_at timestamp without time zone,
    shipped_at timestamp without time zone,
    delivered_at timestamp without time zone
);


ALTER TABLE public.shipments OWNER TO postgres;

--
-- Name: shrinkage_flags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shrinkage_flags (
    id integer NOT NULL,
    date date NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    item_name character varying(150),
    deviation_score double precision,
    expected_quantity double precision,
    actual_quantity double precision,
    discrepancy_quantity double precision,
    estimated_exposure double precision,
    severity character varying(20),
    likely_cause character varying(80),
    explanation text
);


ALTER TABLE public.shrinkage_flags OWNER TO postgres;

--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shrinkage_flags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shrinkage_flags_id_seq OWNER TO postgres;

--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shrinkage_flags_id_seq OWNED BY public.shrinkage_flags.id;


--
-- Name: simulation_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.simulation_events (
    id integer NOT NULL,
    simulation_id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    event_type character varying(50) NOT NULL,
    severity character varying(10) NOT NULL,
    sim_time_seconds double precision NOT NULL,
    real_timestamp timestamp without time zone NOT NULL,
    robot_id integer,
    task_id integer,
    location_id character varying(50),
    route_id integer,
    message text NOT NULL,
    metadata text NOT NULL
);


ALTER TABLE public.simulation_events OWNER TO postgres;

--
-- Name: simulation_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.simulation_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.simulation_events_id_seq OWNER TO postgres;

--
-- Name: simulation_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.simulation_events_id_seq OWNED BY public.simulation_events.id;


--
-- Name: simulation_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.simulation_snapshots (
    id integer NOT NULL,
    simulation_id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    snapshot_version integer NOT NULL,
    taken_at timestamp without time zone NOT NULL,
    sim_time_seconds double precision NOT NULL,
    robot_states text NOT NULL,
    task_states text NOT NULL,
    obstacle_states text NOT NULL,
    sim_inventory_delta text NOT NULL,
    metadata text NOT NULL
);


ALTER TABLE public.simulation_snapshots OWNER TO postgres;

--
-- Name: simulation_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.simulation_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.simulation_snapshots_id_seq OWNER TO postgres;

--
-- Name: simulation_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.simulation_snapshots_id_seq OWNED BY public.simulation_snapshots.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    date date NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    stock_in integer,
    stock_out integer,
    closing_stock integer,
    is_anomaly boolean,
    anomaly_type character varying(30),
    entry_source character varying(20),
    entered_by character varying(64)
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_movements_id_seq OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: system_health_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_health_snapshots (
    id integer NOT NULL,
    service character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    latency_ms double precision,
    "timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public.system_health_snapshots OWNER TO postgres;

--
-- Name: system_health_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_health_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_health_snapshots_id_seq OWNER TO postgres;

--
-- Name: system_health_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_health_snapshots_id_seq OWNED BY public.system_health_snapshots.id;


--
-- Name: system_incidents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_incidents (
    id integer NOT NULL,
    category character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(100) NOT NULL,
    description text NOT NULL,
    source character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    fingerprint character varying(128),
    started_at timestamp without time zone NOT NULL,
    resolved_at timestamp without time zone,
    acknowledged_by character varying(64),
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.system_incidents OWNER TO postgres;

--
-- Name: system_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_incidents_id_seq OWNER TO postgres;

--
-- Name: system_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_incidents_id_seq OWNED BY public.system_incidents.id;


--
-- Name: task_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_events (
    id integer NOT NULL,
    task_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    previous_status character varying(30),
    new_status character varying(30),
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    reason text,
    metadata text NOT NULL
);


ALTER TABLE public.task_events OWNER TO postgres;

--
-- Name: task_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_events_id_seq OWNER TO postgres;

--
-- Name: task_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_events_id_seq OWNED BY public.task_events.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    task_number character varying(64) NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    task_type character varying(30) NOT NULL,
    priority character varying(20) NOT NULL,
    priority_score integer NOT NULL,
    status character varying(30) NOT NULL,
    source_type character varying(30),
    source_id character varying(64),
    order_id character varying(20),
    order_item_id integer,
    product_id character varying(20) NOT NULL,
    source_location_id character varying(50),
    destination_location_id character varying(50),
    requested_quantity integer NOT NULL,
    completed_quantity integer NOT NULL,
    assigned_user_id integer,
    assigned_robot_id character varying(50),
    created_at timestamp without time zone,
    prioritized_at timestamp without time zone,
    assigned_at timestamp without time zone,
    started_at timestamp without time zone,
    paused_at timestamp without time zone,
    completed_at timestamp without time zone,
    failed_at timestamp without time zone,
    cancelled_at timestamp without time zone,
    due_at timestamp without time zone,
    retry_count integer NOT NULL,
    failure_reason text,
    notes text,
    metadata text NOT NULL,
    depends_on_task_id integer
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    session_token_hash character varying(64) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    last_seen_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    revoked_at timestamp without time zone,
    revoke_reason character varying(100),
    login_method character varying(30),
    ip_address character varying(45),
    login_location character varying(255),
    user_agent character varying(500)
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_sessions_id_seq OWNER TO postgres;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: user_warehouse_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_warehouse_access (
    id integer NOT NULL,
    user_id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_warehouse_access OWNER TO postgres;

--
-- Name: user_warehouse_access_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_warehouse_access_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_warehouse_access_id_seq OWNER TO postgres;

--
-- Name: user_warehouse_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_warehouse_access_id_seq OWNED BY public.user_warehouse_access.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    email character varying(255),
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    full_name character varying(120),
    google_subject_id character varying(128),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_active boolean NOT NULL,
    is_verified boolean NOT NULL,
    last_login_at timestamp without time zone,
    last_logout_at timestamp without time zone,
    last_login_ip character varying(45),
    login_location character varying(255),
    login_method character varying(30),
    failed_login_count integer NOT NULL,
    locked_until timestamp without time zone,
    email_verified_at timestamp without time zone,
    password_changed_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: warehouse_grid_cells; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_grid_cells (
    id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    cell_type character varying(30) NOT NULL,
    traversable boolean NOT NULL,
    occupied boolean NOT NULL,
    restricted boolean NOT NULL,
    cost double precision NOT NULL,
    metadata text NOT NULL
);


ALTER TABLE public.warehouse_grid_cells OWNER TO postgres;

--
-- Name: warehouse_grid_cells_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.warehouse_grid_cells_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.warehouse_grid_cells_id_seq OWNER TO postgres;

--
-- Name: warehouse_grid_cells_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.warehouse_grid_cells_id_seq OWNED BY public.warehouse_grid_cells.id;


--
-- Name: warehouse_locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_locations (
    id character varying(50) NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    zone character varying(20) NOT NULL,
    aisle character varying(20) NOT NULL,
    rack character varying(20) NOT NULL,
    shelf character varying(20) NOT NULL,
    x double precision,
    y double precision,
    capacity integer,
    current_utilization integer,
    location_type character varying(20),
    status character varying(20),
    created_at timestamp without time zone
);


ALTER TABLE public.warehouse_locations OWNER TO postgres;

--
-- Name: warehouse_obstacles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_obstacles (
    id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    obstacle_type character varying(30) NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    active boolean NOT NULL,
    severity character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.warehouse_obstacles OWNER TO postgres;

--
-- Name: warehouse_obstacles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.warehouse_obstacles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.warehouse_obstacles_id_seq OWNER TO postgres;

--
-- Name: warehouse_obstacles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.warehouse_obstacles_id_seq OWNED BY public.warehouse_obstacles.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouses (
    id character varying(20) NOT NULL,
    name character varying(120) NOT NULL,
    location character varying(120),
    latitude double precision,
    longitude double precision,
    created_at timestamp without time zone
);


ALTER TABLE public.warehouses OWNER TO postgres;

--
-- Name: access_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log ALTER COLUMN id SET DEFAULT nextval('public.access_log_id_seq'::regclass);


--
-- Name: ai_recommendations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_recommendations ALTER COLUMN id SET DEFAULT nextval('public.ai_recommendations_id_seq'::regclass);


--
-- Name: audit_ledger id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_ledger ALTER COLUMN id SET DEFAULT nextval('public.audit_ledger_id_seq'::regclass);


--
-- Name: backup_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_records ALTER COLUMN id SET DEFAULT nextval('public.backup_records_id_seq'::regclass);


--
-- Name: digital_twin_simulations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.digital_twin_simulations ALTER COLUMN id SET DEFAULT nextval('public.digital_twin_simulations_id_seq'::regclass);


--
-- Name: experiment_runs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_runs ALTER COLUMN id SET DEFAULT nextval('public.experiment_runs_id_seq'::regclass);


--
-- Name: experiments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiments ALTER COLUMN id SET DEFAULT nextval('public.experiments_id_seq'::regclass);


--
-- Name: health_thresholds id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_thresholds ALTER COLUMN id SET DEFAULT nextval('public.health_thresholds_id_seq'::regclass);


--
-- Name: inventory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory ALTER COLUMN id SET DEFAULT nextval('public.inventory_id_seq'::regclass);


--
-- Name: inventory_reservations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations ALTER COLUMN id SET DEFAULT nextval('public.inventory_reservations_id_seq'::regclass);


--
-- Name: notification_preferences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences ALTER COLUMN id SET DEFAULT nextval('public.notification_preferences_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: order_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_events ALTER COLUMN id SET DEFAULT nextval('public.order_events_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: otp_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_records ALTER COLUMN id SET DEFAULT nextval('public.otp_records_id_seq'::regclass);


--
-- Name: packing_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packing_records ALTER COLUMN id SET DEFAULT nextval('public.packing_records_id_seq'::regclass);


--
-- Name: recovery_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes ALTER COLUMN id SET DEFAULT nextval('public.recovery_codes_id_seq'::regclass);


--
-- Name: recovery_credentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials ALTER COLUMN id SET DEFAULT nextval('public.recovery_credentials_id_seq'::regclass);


--
-- Name: robot_reservations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_reservations ALTER COLUMN id SET DEFAULT nextval('public.robot_reservations_id_seq'::regclass);


--
-- Name: robot_routes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes ALTER COLUMN id SET DEFAULT nextval('public.robot_routes_id_seq'::regclass);


--
-- Name: robot_telemetry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_telemetry ALTER COLUMN id SET DEFAULT nextval('public.robot_telemetry_id_seq'::regclass);


--
-- Name: robots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots ALTER COLUMN id SET DEFAULT nextval('public.robots_id_seq'::regclass);


--
-- Name: scenarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scenarios ALTER COLUMN id SET DEFAULT nextval('public.scenarios_id_seq'::regclass);


--
-- Name: shrinkage_flags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shrinkage_flags ALTER COLUMN id SET DEFAULT nextval('public.shrinkage_flags_id_seq'::regclass);


--
-- Name: simulation_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_events ALTER COLUMN id SET DEFAULT nextval('public.simulation_events_id_seq'::regclass);


--
-- Name: simulation_snapshots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_snapshots ALTER COLUMN id SET DEFAULT nextval('public.simulation_snapshots_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: system_health_snapshots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_health_snapshots ALTER COLUMN id SET DEFAULT nextval('public.system_health_snapshots_id_seq'::regclass);


--
-- Name: system_incidents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_incidents ALTER COLUMN id SET DEFAULT nextval('public.system_incidents_id_seq'::regclass);


--
-- Name: task_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_events ALTER COLUMN id SET DEFAULT nextval('public.task_events_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: user_warehouse_access id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access ALTER COLUMN id SET DEFAULT nextval('public.user_warehouse_access_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: warehouse_grid_cells id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_grid_cells ALTER COLUMN id SET DEFAULT nextval('public.warehouse_grid_cells_id_seq'::regclass);


--
-- Name: warehouse_obstacles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_obstacles ALTER COLUMN id SET DEFAULT nextval('public.warehouse_obstacles_id_seq'::regclass);


--
-- Data for Name: access_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access_log (id, "timestamp", username, warehouse_id, action, ip_address) FROM stdin;
590	2026-08-17 09:20:41.465589	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.165
591	2026-08-17 02:17:41.465589	admin	WH-BOM-01	add_stock	192.168.1.119
592	2026-08-17 17:31:41.465589	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.12
593	2026-08-17 07:12:41.465589	admin	WH-BOM-01	view	192.168.1.238
594	2026-08-19 10:12:41.465589	harsha200797@gmail.com		login	192.168.1.234
595	2026-08-18 12:22:41.465589	harsha200797@gmail.com	WH-DEL-01	add_stock	192.168.1.154
596	2026-08-16 16:58:41.465589	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.73
597	2026-08-16 21:30:41.465589	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.254
598	2026-08-18 16:38:41.465589	admin	WH-BOM-01	view	192.168.1.61
599	2026-08-19 00:12:41.465589	harsha200797@gmail.com	WH-CCU-01	add_stock	192.168.1.244
600	2026-08-18 17:46:41.465589	admin	WH-BLR-01	add_stock	192.168.1.232
601	2026-08-17 13:21:41.465589	admin	WH-CCU-01	view	192.168.1.228
602	2026-08-18 21:14:41.46659	admin	WH-BOM-01	view	192.168.1.75
603	2026-08-16 08:20:41.46659	harsha200797@gmail.com	WH-CCU-01	add_stock	192.168.1.167
604	2026-08-19 03:47:41.46659	admin	WH-BOM-01	view	192.168.1.219
605	2026-08-17 20:54:41.46659	harsha200797@gmail.com	WH-CCU-01	add_stock	192.168.1.34
606	2026-08-19 05:59:41.46659	admin		login	192.168.1.233
607	2026-08-18 11:38:41.46659	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.155
608	2026-08-16 14:11:41.46659	admin	WH-CCU-01	view	192.168.1.17
609	2026-08-17 19:21:41.46659	admin	WH-CHN-01	view	192.168.1.46
610	2026-08-17 03:33:41.46659	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.239
611	2026-08-19 09:00:41.46659	admin	WH-CCU-01	view	192.168.1.209
612	2026-08-17 14:20:41.46659	harsha200797@gmail.com	WH-DEL-01	add_stock	192.168.1.161
613	2026-08-18 03:17:41.46659	harsha200797@gmail.com	WH-CCU-01	add_stock	192.168.1.84
614	2026-08-17 17:56:41.46659	harsha200797@gmail.com		login	192.168.1.195
615	2026-08-16 18:55:41.46659	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.44
616	2026-08-19 05:38:41.46659	admin	WH-CHN-01	view	192.168.1.152
617	2026-08-17 07:21:41.46659	harsha200797@gmail.com		login	192.168.1.69
618	2026-08-18 01:37:41.46659	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.52
619	2026-08-18 21:22:41.46659	admin		login	192.168.1.151
620	2026-08-19 10:25:41.46659	harsha200797@gmail.com	WH-DEL-01	view	192.168.1.139
621	2026-08-17 06:33:41.46659	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.156
622	2026-08-16 22:54:41.46659	admin		login	192.168.1.189
623	2026-08-18 07:20:41.46659	admin	WH-CCU-01	view	192.168.1.150
624	2026-08-18 04:57:41.46659	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.231
625	2026-08-19 00:24:41.46659	harsha200797@gmail.com	WH-BOM-01	add_stock	192.168.1.82
626	2026-08-19 05:50:41.46659	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.181
627	2026-08-18 23:30:41.467102	admin	WH-CHN-01	view	192.168.1.198
628	2026-08-17 18:05:41.467102	admin		login	192.168.1.30
629	2026-08-16 11:33:41.467102	admin	WH-CCU-01	view	192.168.1.119
630	2026-08-16 10:59:41.467102	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.31
631	2026-08-18 06:17:41.467102	harsha200797@gmail.com		login	192.168.1.172
632	2026-08-17 01:23:41.467102	admin	WH-BOM-01	add_stock	192.168.1.60
633	2026-08-16 09:10:41.467102	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.194
634	2026-08-16 13:02:41.467102	harsha200797@gmail.com		login	192.168.1.75
635	2026-08-16 19:30:41.467102	harsha200797@gmail.com	WH-DEL-01	add_stock	192.168.1.121
636	2026-08-17 20:12:41.467102	admin	WH-BLR-01	view	192.168.1.240
637	2026-08-19 10:05:41.467102	admin		login	192.168.1.33
638	2026-08-19 07:00:41.467102	harsha200797@gmail.com	WH-CHN-01	add_stock	192.168.1.15
639	2026-08-16 09:10:41.467102	harsha200797@gmail.com	WH-DEL-01	add_stock	192.168.1.168
640	2026-08-19 18:28:49.570329	test_admin_hardened		login	testclient
641	2026-08-19 18:28:57.114494	test_admin_hardened		login	testclient
642	2026-08-19 18:29:04.271851	test_admin_hardened		login	testclient
643	2026-08-19 18:29:12.00374	test_admin_hardened		login	testclient
644	2026-08-19 18:29:12.957258	test_admin_hardened		login	testclient
645	2026-08-19 18:29:13.898541	test_admin_hardened		login	testclient
646	2026-08-19 18:29:34.45295	test_admin		login	testclient
\.


--
-- Data for Name: ai_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_recommendations (id, "timestamp", warehouse_id, item_id, title, risk_level, action_recommended, confidence_score, input_factors, status, decision_by, decision_time, notes, recommendation_type, description, priority, score, confidence_or_reliability, source_model, source_entity_type, source_entity_id, recommended_action, estimated_impact, explanation, supporting_metrics, created_at, reviewed_at, reviewed_by, review_notes, expires_at, metadata) FROM stdin;
152	2026-08-19 18:25:14.486078	WH-BLR-01	ITM-RAM-01	Replenishment Recommended: Corsair DDR5 32GB 6000MHz RAM	MEDIUM	Replenish 75 units.	45	{}	NEW		\N		REPLENISHMENT	Projected lead demand (26.4 units) and safety stock (25 units) exceeds available stock (45 units).	MEDIUM	58	MEDIUM	Weekday Seasonality Regression	Item	ITM-RAM-01	Replenish 75 units.	54400	Outbound demand forecast (26.4 units) indicates available stock (45 units) will deplete below safety stock target (25 units) within lead time of 4 days. WAPE forecast reliability stands at 45%.	{"current_stock": 45, "lead_demand": 26.4, "safety_stock": 25, "reorder_point": 51.4, "shortage_qty": 6.4, "unit_cost": 8500.0, "wape": 50.2, "evidence": ["Current closing stock: 45 units (ACTUAL \\u2014 MySQL)", "Safety stock threshold: 25 units", "Forecasted 4-day lead demand: 26.4 units (FORECAST \\u2014 ML MODEL)", "Reorder point threshold: 51.4 units"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
153	2026-08-19 18:25:14.486078	WH-CHN-01	ITM-GPU-01	Replenishment Recommended: Nvidia RTX 4080 Founders Edition	MEDIUM	Replenish 50 units.	35	{}	NEW		\N		REPLENISHMENT	Projected lead demand (6.1 units) and safety stock (10 units) exceeds available stock (15 units).	MEDIUM	53	MEDIUM	Weekday Seasonality Regression	Item	ITM-GPU-01	Replenish 50 units.	104500	Outbound demand forecast (6.1 units) indicates available stock (15 units) will deplete below safety stock target (10 units) within lead time of 7 days. WAPE forecast reliability stands at 35%.	{"current_stock": 15, "lead_demand": 6.1, "safety_stock": 10, "reorder_point": 16.1, "shortage_qty": 1.1, "unit_cost": 95000.0, "wape": 570.0, "evidence": ["Current closing stock: 15 units (ACTUAL \\u2014 MySQL)", "Safety stock threshold: 10 units", "Forecasted 7-day lead demand: 6.1 units (FORECAST \\u2014 ML MODEL)", "Reorder point threshold: 16.1 units"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
154	2026-08-19 18:25:14.486078	WH-DEL-01	ITM-RAM-01	Replenishment Recommended: Corsair DDR5 32GB 6000MHz RAM	MEDIUM	Replenish 75 units.	51	{}	NEW		\N		REPLENISHMENT	Projected lead demand (26.2 units) and safety stock (25 units) exceeds available stock (45 units).	MEDIUM	57	MEDIUM	Weekday Seasonality Regression	Item	ITM-RAM-01	Replenish 75 units.	52700	Outbound demand forecast (26.2 units) indicates available stock (45 units) will deplete below safety stock target (25 units) within lead time of 4 days. WAPE forecast reliability stands at 51%.	{"current_stock": 45, "lead_demand": 26.2, "safety_stock": 25, "reorder_point": 51.2, "shortage_qty": 6.2, "unit_cost": 8500.0, "wape": 89.5, "evidence": ["Current closing stock: 45 units (ACTUAL \\u2014 MySQL)", "Safety stock threshold: 25 units", "Forecasted 4-day lead demand: 26.2 units (FORECAST \\u2014 ML MODEL)", "Reorder point threshold: 51.2 units"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
171	2026-08-19 18:29:26.607643	WH-CCU-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	41	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 296.0 units, but recorded stock is 296.0 units, leading to a discrepancy of +0.0 units.	LOW	41	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 296.0, "actual": 296.0, "evidence": ["Expected closing stock: 296.0 units (Opening + In - Out)", "Recorded closing stock: 296.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
195	2026-08-19 18:29:26.607643	WH-CCU-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 18.0 units, but recorded stock is 18.0 units, leading to a discrepancy of +0.0 units.	LOW	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 18.0, "actual": 18.0, "evidence": ["Expected closing stock: 18.0 units (Opening + In - Out)", "Recorded closing stock: 18.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
196	2026-08-19 18:29:26.607643	WH-CHN-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	HIGH	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 45.0 units, but recorded stock is 45.0 units, leading to a discrepancy of +0.0 units.	HIGH	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 45.0, "actual": 45.0, "evidence": ["Expected closing stock: 45.0 units (Opening + In - Out)", "Recorded closing stock: 45.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
206	2026-08-19 18:29:26.607643	WH-DEL-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 291.0 units, but recorded stock is 291.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 291.0, "actual": 291.0, "evidence": ["Expected closing stock: 291.0 units (Opening + In - Out)", "Recorded closing stock: 291.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
207	2026-08-19 18:29:26.607643	WH-DEL-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 44.0 units, but recorded stock is 44.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 40/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 44.0, "actual": 44.0, "evidence": ["Expected closing stock: 44.0 units (Opening + In - Out)", "Recorded closing stock: 44.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 40/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
209	2026-08-19 18:29:26.607643	WH-DEL-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 67.0 units, but recorded stock is 67.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 67.0, "actual": 67.0, "evidence": ["Expected closing stock: 67.0 units (Opening + In - Out)", "Recorded closing stock: 67.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
213	2026-08-19 18:29:26.607643	WH-BOM-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 87.0 units, but recorded stock is 87.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 87.0, "actual": 87.0, "evidence": ["Expected closing stock: 87.0 units (Opening + In - Out)", "Recorded closing stock: 87.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
159	2026-08-19 18:29:26.607643	WH-BLR-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	45	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 40.0 units, but recorded stock is 40.0 units, leading to a discrepancy of +0.0 units.	LOW	45	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 40.0, "actual": 40.0, "evidence": ["Expected closing stock: 40.0 units (Opening + In - Out)", "Recorded closing stock: 40.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
160	2026-08-19 18:29:26.607643	WH-BOM-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	45	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 65.0 units, but recorded stock is 65.0 units, leading to a discrepancy of +0.0 units.	LOW	45	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 65.0, "actual": 65.0, "evidence": ["Expected closing stock: 65.0 units (Opening + In - Out)", "Recorded closing stock: 65.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
163	2026-08-19 18:29:26.607643	WH-DEL-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	44	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 63.0 units, but recorded stock is 63.0 units, leading to a discrepancy of +0.0 units.	LOW	44	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 63.0, "actual": 63.0, "evidence": ["Expected closing stock: 63.0 units (Opening + In - Out)", "Recorded closing stock: 63.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
174	2026-08-19 18:29:26.607643	WH-BOM-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	40	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 22.0 units, but recorded stock is 22.0 units, leading to a discrepancy of +0.0 units.	LOW	40	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 22.0, "actual": 22.0, "evidence": ["Expected closing stock: 22.0 units (Opening + In - Out)", "Recorded closing stock: 22.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
187	2026-08-19 18:29:26.607643	WH-CCU-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	38	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 76.0 units, but recorded stock is 76.0 units, leading to a discrepancy of +0.0 units.	LOW	38	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 76.0, "actual": 76.0, "evidence": ["Expected closing stock: 76.0 units (Opening + In - Out)", "Recorded closing stock: 76.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
190	2026-08-19 18:29:26.607643	WH-DEL-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	38	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 142.0 units, but recorded stock is 142.0 units, leading to a discrepancy of +0.0 units.	LOW	38	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 142.0, "actual": 142.0, "evidence": ["Expected closing stock: 142.0 units (Opening + In - Out)", "Recorded closing stock: 142.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
175	2026-08-19 18:29:26.607643	WH-BOM-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	40	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 104.0 units, but recorded stock is 104.0 units, leading to a discrepancy of +0.0 units.	LOW	40	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 104.0, "actual": 104.0, "evidence": ["Expected closing stock: 104.0 units (Opening + In - Out)", "Recorded closing stock: 104.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
197	2026-08-19 18:29:26.607643	WH-BLR-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 28.0 units, but recorded stock is 28.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 28.0, "actual": 28.0, "evidence": ["Expected closing stock: 28.0 units (Opening + In - Out)", "Recorded closing stock: 28.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
198	2026-08-19 18:29:26.607643	WH-BLR-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 87.0 units, but recorded stock is 87.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 87.0, "actual": 87.0, "evidence": ["Expected closing stock: 87.0 units (Opening + In - Out)", "Recorded closing stock: 87.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
176	2026-08-19 18:29:26.607643	WH-BOM-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	40	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 56.0 units, but recorded stock is 56.0 units, leading to a discrepancy of +0.0 units.	LOW	40	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 56.0, "actual": 56.0, "evidence": ["Expected closing stock: 56.0 units (Opening + In - Out)", "Recorded closing stock: 56.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
178	2026-08-19 18:29:26.607643	WH-CHN-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	40	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 30.0 units, but recorded stock is 30.0 units, leading to a discrepancy of +0.0 units.	LOW	40	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 30.0, "actual": 30.0, "evidence": ["Expected closing stock: 30.0 units (Opening + In - Out)", "Recorded closing stock: 30.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
188	2026-08-19 18:29:26.607643	WH-CHN-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	38	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 89.0 units, but recorded stock is 89.0 units, leading to a discrepancy of +0.0 units.	LOW	38	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 89.0, "actual": 89.0, "evidence": ["Expected closing stock: 89.0 units (Opening + In - Out)", "Recorded closing stock: 89.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
193	2026-08-19 18:29:26.607643	WH-BLR-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 88.0 units, but recorded stock is 88.0 units, leading to a discrepancy of +0.0 units.	LOW	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 88.0, "actual": 88.0, "evidence": ["Expected closing stock: 88.0 units (Opening + In - Out)", "Recorded closing stock: 88.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
161	2026-08-19 18:29:26.607643	WH-CCU-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	45	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 65.0 units, but recorded stock is 65.0 units, leading to a discrepancy of +0.0 units.	LOW	45	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 65.0, "actual": 65.0, "evidence": ["Expected closing stock: 65.0 units (Opening + In - Out)", "Recorded closing stock: 65.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
167	2026-08-19 18:29:26.607643	WH-CCU-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	43	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 106.0 units, but recorded stock is 106.0 units, leading to a discrepancy of +0.0 units.	LOW	43	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 106.0, "actual": 106.0, "evidence": ["Expected closing stock: 106.0 units (Opening + In - Out)", "Recorded closing stock: 106.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
157	2026-08-19 18:24:57.595219	WH-CCU-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	46	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 217.0 units, but recorded stock is 217.0 units, leading to a discrepancy of +0.0 units.	LOW	46	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 217.0, "actual": 217.0, "evidence": ["Expected closing stock: 217.0 units (Opening + In - Out)", "Recorded closing stock: 217.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
155	2026-08-19 18:29:26.607643	WH-CHN-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	MEDIUM	Perform physical stock audit count and check transaction logs.	53	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 85.0 units, but recorded stock is 85.0 units, leading to a discrepancy of +0.0 units.	MEDIUM	53	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 39/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 85.0, "actual": 85.0, "evidence": ["Expected closing stock: 85.0 units (Opening + In - Out)", "Recorded closing stock: 85.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 39/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
156	2026-08-19 18:29:26.607643	WH-BLR-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	49	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 29.0 units, but recorded stock is 29.0 units, leading to a discrepancy of +0.0 units.	LOW	49	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 29.0, "actual": 29.0, "evidence": ["Expected closing stock: 29.0 units (Opening + In - Out)", "Recorded closing stock: 29.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
158	2026-08-19 18:29:26.607643	WH-BLR-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	45	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 145.0 units, but recorded stock is 145.0 units, leading to a discrepancy of +0.0 units.	LOW	45	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 145.0, "actual": 145.0, "evidence": ["Expected closing stock: 145.0 units (Opening + In - Out)", "Recorded closing stock: 145.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
162	2026-08-19 18:29:26.607643	WH-DEL-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	45	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 88.0 units, but recorded stock is 88.0 units, leading to a discrepancy of +0.0 units.	LOW	45	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 88.0, "actual": 88.0, "evidence": ["Expected closing stock: 88.0 units (Opening + In - Out)", "Recorded closing stock: 88.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
164	2026-08-19 18:29:26.607643	WH-BOM-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	43	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 285.0 units, but recorded stock is 285.0 units, leading to a discrepancy of +0.0 units.	LOW	43	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 285.0, "actual": 285.0, "evidence": ["Expected closing stock: 285.0 units (Opening + In - Out)", "Recorded closing stock: 285.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
165	2026-08-19 18:29:26.607643	WH-CCU-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	43	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 53.0 units, but recorded stock is 53.0 units, leading to a discrepancy of +0.0 units.	LOW	43	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 53.0, "actual": 53.0, "evidence": ["Expected closing stock: 53.0 units (Opening + In - Out)", "Recorded closing stock: 53.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
169	2026-08-19 18:24:57.595219	WH-BLR-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	41	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 67.0 units, but recorded stock is 67.0 units, leading to a discrepancy of +0.0 units.	LOW	41	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 67.0, "actual": 67.0, "evidence": ["Expected closing stock: 67.0 units (Opening + In - Out)", "Recorded closing stock: 67.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
166	2026-08-19 18:29:26.607643	WH-CCU-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	43	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 38.0 units, but recorded stock is 38.0 units, leading to a discrepancy of +0.0 units.	LOW	43	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 38.0, "actual": 38.0, "evidence": ["Expected closing stock: 38.0 units (Opening + In - Out)", "Recorded closing stock: 38.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
177	2026-08-19 18:29:26.607643	WH-CHN-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	40	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 292.0 units, but recorded stock is 292.0 units, leading to a discrepancy of +0.0 units.	LOW	40	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 292.0, "actual": 292.0, "evidence": ["Expected closing stock: 292.0 units (Opening + In - Out)", "Recorded closing stock: 292.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
173	2026-08-19 18:28:57.182254	WH-BLR-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	40	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 145.0 units, but recorded stock is 145.0 units, leading to a discrepancy of +0.0 units.	LOW	40	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 145.0, "actual": 145.0, "evidence": ["Expected closing stock: 145.0 units (Opening + In - Out)", "Recorded closing stock: 145.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
172	2026-08-19 18:29:04.306422	WH-CHN-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	41	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 292.0 units, but recorded stock is 292.0 units, leading to a discrepancy of +0.0 units.	LOW	41	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 292.0, "actual": 292.0, "evidence": ["Expected closing stock: 292.0 units (Opening + In - Out)", "Recorded closing stock: 292.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
179	2026-08-19 18:24:57.595219	WH-DEL-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	40	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 143.0 units, but recorded stock is 143.0 units, leading to a discrepancy of +0.0 units.	LOW	40	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 143.0, "actual": 143.0, "evidence": ["Expected closing stock: 143.0 units (Opening + In - Out)", "Recorded closing stock: 143.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
194	2026-08-19 18:24:57.595219	WH-BLR-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 84.0 units, but recorded stock is 84.0 units, leading to a discrepancy of +0.0 units.	LOW	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 84.0, "actual": 84.0, "evidence": ["Expected closing stock: 84.0 units (Opening + In - Out)", "Recorded closing stock: 84.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
185	2026-08-19 18:29:26.607643	WH-CHN-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	39	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 77.0 units, but recorded stock is 77.0 units, leading to a discrepancy of +0.0 units.	LOW	39	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 77.0, "actual": 77.0, "evidence": ["Expected closing stock: 77.0 units (Opening + In - Out)", "Recorded closing stock: 77.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
191	2026-08-19 18:29:26.607643	WH-DEL-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	38	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 72.0 units, but recorded stock is 72.0 units, leading to a discrepancy of +0.0 units.	LOW	38	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 72.0, "actual": 72.0, "evidence": ["Expected closing stock: 72.0 units (Opening + In - Out)", "Recorded closing stock: 72.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
180	2026-08-19 18:28:57.182254	WH-DEL-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	40	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 88.0 units, but recorded stock is 88.0 units, leading to a discrepancy of +0.0 units.	LOW	40	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 88.0, "actual": 88.0, "evidence": ["Expected closing stock: 88.0 units (Opening + In - Out)", "Recorded closing stock: 88.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
210	2026-08-19 18:29:26.607643	WH-BLR-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 421.0 units, but recorded stock is 421.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 421.0, "actual": 421.0, "evidence": ["Expected closing stock: 421.0 units (Opening + In - Out)", "Recorded closing stock: 421.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
181	2026-08-19 18:25:04.879831	WH-BOM-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	39	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 65.0 units, but recorded stock is 65.0 units, leading to a discrepancy of +0.0 units.	LOW	39	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 39/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 65.0, "actual": 65.0, "evidence": ["Expected closing stock: 65.0 units (Opening + In - Out)", "Recorded closing stock: 65.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 39/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
182	2026-08-19 18:25:04.879831	WH-BOM-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	39	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 42.0 units, but recorded stock is 42.0 units, leading to a discrepancy of +0.0 units.	LOW	39	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 39/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 42.0, "actual": 42.0, "evidence": ["Expected closing stock: 42.0 units (Opening + In - Out)", "Recorded closing stock: 42.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 39/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
183	2026-08-19 18:25:04.879831	WH-BOM-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	39	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 89.0 units, but recorded stock is 89.0 units, leading to a discrepancy of +0.0 units.	LOW	39	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 39/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 89.0, "actual": 89.0, "evidence": ["Expected closing stock: 89.0 units (Opening + In - Out)", "Recorded closing stock: 89.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 39/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
184	2026-08-19 18:25:04.879831	WH-CCU-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	39	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 84.0 units, but recorded stock is 84.0 units, leading to a discrepancy of +0.0 units.	LOW	39	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 39/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 84.0, "actual": 84.0, "evidence": ["Expected closing stock: 84.0 units (Opening + In - Out)", "Recorded closing stock: 84.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 39/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
186	2026-08-19 18:29:26.607643	WH-BOM-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	38	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 143.0 units, but recorded stock is 143.0 units, leading to a discrepancy of +0.0 units.	LOW	38	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 143.0, "actual": 143.0, "evidence": ["Expected closing stock: 143.0 units (Opening + In - Out)", "Recorded closing stock: 143.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
200	2026-08-19 18:25:04.879831	WH-BOM-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 48.0 units, but recorded stock is 48.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 48.0, "actual": 48.0, "evidence": ["Expected closing stock: 48.0 units (Opening + In - Out)", "Recorded closing stock: 48.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
203	2026-08-19 18:25:04.879831	WH-CCU-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 89.0 units, but recorded stock is 89.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 89.0, "actual": 89.0, "evidence": ["Expected closing stock: 89.0 units (Opening + In - Out)", "Recorded closing stock: 89.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
204	2026-08-19 18:25:04.879831	WH-CHN-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 16.0 units, but recorded stock is 16.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 16.0, "actual": 16.0, "evidence": ["Expected closing stock: 16.0 units (Opening + In - Out)", "Recorded closing stock: 16.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
212	2026-08-19 18:25:04.879831	WH-BLR-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 66.0 units, but recorded stock is 66.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 66.0, "actual": 66.0, "evidence": ["Expected closing stock: 66.0 units (Opening + In - Out)", "Recorded closing stock: 66.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
214	2026-08-19 18:25:04.879831	WH-CCU-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 65.0 units, but recorded stock is 65.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 65.0, "actual": 65.0, "evidence": ["Expected closing stock: 65.0 units (Opening + In - Out)", "Recorded closing stock: 65.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
215	2026-08-19 18:25:04.879831	WH-CHN-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 141.0 units, but recorded stock is 141.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 141.0, "actual": 141.0, "evidence": ["Expected closing stock: 141.0 units (Opening + In - Out)", "Recorded closing stock: 141.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
216	2026-08-19 18:25:04.879831	WH-CHN-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 37.0 units, but recorded stock is 37.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 37.0, "actual": 37.0, "evidence": ["Expected closing stock: 37.0 units (Opening + In - Out)", "Recorded closing stock: 37.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
218	2026-08-19 18:25:04.879831	WH-CHN-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 74.0 units, but recorded stock is 74.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 74.0, "actual": 74.0, "evidence": ["Expected closing stock: 74.0 units (Opening + In - Out)", "Recorded closing stock: 74.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
219	2026-08-19 18:25:04.879831	WH-DEL-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 66.0 units, but recorded stock is 66.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 66.0, "actual": 66.0, "evidence": ["Expected closing stock: 66.0 units (Opening + In - Out)", "Recorded closing stock: 66.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
217	2026-08-19 18:29:26.607643	WH-CHN-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 102.0 units, but recorded stock is 102.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 102.0, "actual": 102.0, "evidence": ["Expected closing stock: 102.0 units (Opening + In - Out)", "Recorded closing stock: 102.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
208	2026-08-19 18:28:57.182254	WH-DEL-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 72.0 units, but recorded stock is 72.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 72.0, "actual": 72.0, "evidence": ["Expected closing stock: 72.0 units (Opening + In - Out)", "Recorded closing stock: 72.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
211	2026-08-19 18:28:57.182254	WH-BLR-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 421.0 units, but recorded stock is 421.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 421.0, "actual": 421.0, "evidence": ["Expected closing stock: 421.0 units (Opening + In - Out)", "Recorded closing stock: 421.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
168	2026-08-19 18:29:04.306422	WH-BOM-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	42	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 143.0 units, but recorded stock is 143.0 units, leading to a discrepancy of +0.0 units.	LOW	42	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 143.0, "actual": 143.0, "evidence": ["Expected closing stock: 143.0 units (Opening + In - Out)", "Recorded closing stock: 143.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
170	2026-08-19 18:29:04.306422	WH-BOM-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	41	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 87.0 units, but recorded stock is 87.0 units, leading to a discrepancy of +0.0 units.	LOW	41	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 87.0, "actual": 87.0, "evidence": ["Expected closing stock: 87.0 units (Opening + In - Out)", "Recorded closing stock: 87.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
189	2026-08-19 18:29:04.306422	WH-DEL-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	38	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 291.0 units, but recorded stock is 291.0 units, leading to a discrepancy of +0.0 units.	LOW	38	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 291.0, "actual": 291.0, "evidence": ["Expected closing stock: 291.0 units (Opening + In - Out)", "Recorded closing stock: 291.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
192	2026-08-19 18:29:04.306422	WH-BLR-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	HIGH	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 29.0 units, but recorded stock is 29.0 units, leading to a discrepancy of +0.0 units.	HIGH	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 29.0, "actual": 29.0, "evidence": ["Expected closing stock: 29.0 units (Opening + In - Out)", "Recorded closing stock: 29.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
199	2026-08-19 18:29:04.306422	WH-BOM-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 285.0 units, but recorded stock is 285.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 285.0, "actual": 285.0, "evidence": ["Expected closing stock: 285.0 units (Opening + In - Out)", "Recorded closing stock: 285.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
201	2026-08-19 18:29:04.306422	WH-CCU-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 53.0 units, but recorded stock is 53.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 53.0, "actual": 53.0, "evidence": ["Expected closing stock: 53.0 units (Opening + In - Out)", "Recorded closing stock: 53.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
202	2026-08-19 18:29:04.306422	WH-CCU-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 18.0 units, but recorded stock is 18.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 18.0, "actual": 18.0, "evidence": ["Expected closing stock: 18.0 units (Opening + In - Out)", "Recorded closing stock: 18.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
205	2026-08-19 18:29:04.306422	WH-CHN-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 102.0 units, but recorded stock is 102.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 102.0, "actual": 102.0, "evidence": ["Expected closing stock: 102.0 units (Opening + In - Out)", "Recorded closing stock: 102.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
220	2026-08-19 18:29:04.306422	WH-DEL-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 44.0 units, but recorded stock is 44.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 40/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 44.0, "actual": 44.0, "evidence": ["Expected closing stock: 44.0 units (Opening + In - Out)", "Recorded closing stock: 44.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 40/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
221	2026-08-19 18:29:04.306422	WH-DEL-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 67.0 units, but recorded stock is 67.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 67.0, "actual": 67.0, "evidence": ["Expected closing stock: 67.0 units (Opening + In - Out)", "Recorded closing stock: 67.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-19 18:24:50.198425	\N	\N	\N	\N	{}
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
c6a0f47c242e
\.


--
-- Data for Name: audit_ledger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_ledger (id, "timestamp", event_type, details, prev_hash, hash) FROM stdin;
728	2026-08-19 18:24:17	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:24:17.913292"}	0000000000000000000000000000000000000000000000000000000000000000	2d0eb7e365fe6534313bc3100d32fb18918d75339f53cf05b55e774803c8ff60
729	2026-08-19 18:24:17	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	2d0eb7e365fe6534313bc3100d32fb18918d75339f53cf05b55e774803c8ff60	862640f5c9895f6a9b011cfdc7763dc7b7af8cdab8a9d8336fcada08d36b1c8e
730	2026-08-19 18:24:46	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	862640f5c9895f6a9b011cfdc7763dc7b7af8cdab8a9d8336fcada08d36b1c8e	707c8fcf5f66d25ec91a4b9955e4fd4398b1294cec94bb1d13e0600922102b4c
731	2026-08-19 18:24:46	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	707c8fcf5f66d25ec91a4b9955e4fd4398b1294cec94bb1d13e0600922102b4c	6254ab42a25019f6f83067d443e04fce420f2e9e272882458385ffd40c13913c
732	2026-08-19 18:24:46	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	6254ab42a25019f6f83067d443e04fce420f2e9e272882458385ffd40c13913c	c7c07917a255450045d28ecf45f678dd22b24df371f4deea971d22fd57490547
733	2026-08-19 18:24:46	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	c7c07917a255450045d28ecf45f678dd22b24df371f4deea971d22fd57490547	076ce896e06043b602d556bb84b78884a0c09d975edce79d0ba85628d979e3a0
734	2026-08-19 18:24:46	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	076ce896e06043b602d556bb84b78884a0c09d975edce79d0ba85628d979e3a0	278e651c77ad482036ac57aaeb604ffe2e4e6cb7d2cad6fc628baee6bdaee57a
735	2026-08-19 18:24:46	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	278e651c77ad482036ac57aaeb604ffe2e4e6cb7d2cad6fc628baee6bdaee57a	8ddadf8f7f002e3e9c7cbbb55c351901cb6e9a6664e45ddaf65c98ec8ba3ea84
736	2026-08-19 18:24:46	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	8ddadf8f7f002e3e9c7cbbb55c351901cb6e9a6664e45ddaf65c98ec8ba3ea84	8ffbda260771ab55006a3ad80a8db89e712c757834ddd410a6694f88610cf9ff
737	2026-08-19 18:24:46	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	8ffbda260771ab55006a3ad80a8db89e712c757834ddd410a6694f88610cf9ff	5baf3c007002fce888410a8a05c8dde08e51b1990f837ad5298ef1f16580a254
738	2026-08-19 18:24:46	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	5baf3c007002fce888410a8a05c8dde08e51b1990f837ad5298ef1f16580a254	43ee8fb5292ece984bfb3e652a97bf54ae4c81a2f156eaf3212ec2fa82d4c414
739	2026-08-19 18:24:46	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	43ee8fb5292ece984bfb3e652a97bf54ae4c81a2f156eaf3212ec2fa82d4c414	82879389ac3002a39d09ea3b04f5a124884970b2ebb048db9f38728c49c9e3d6
740	2026-08-19 18:24:46	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	82879389ac3002a39d09ea3b04f5a124884970b2ebb048db9f38728c49c9e3d6	da2318d709d39cbdfb92bb96825b07f5ed2571663c72a7cce6f9c0c9f37af0b7
741	2026-08-19 18:24:46	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	da2318d709d39cbdfb92bb96825b07f5ed2571663c72a7cce6f9c0c9f37af0b7	6b6c3e62a9aff2cbdfa78bbd3461b3939f22c742b14f475fbf9e253651761ac7
742	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	6b6c3e62a9aff2cbdfa78bbd3461b3939f22c742b14f475fbf9e253651761ac7	e0b4dd526b7e03f58e9ebf929cf7507956d77d379c413293382313c413cdcb2d
743	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	e0b4dd526b7e03f58e9ebf929cf7507956d77d379c413293382313c413cdcb2d	89fbfd9aacaf0923ca8bc21e73f688379d3db0e48e8c37a26dca93d13c93e62d
744	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	89fbfd9aacaf0923ca8bc21e73f688379d3db0e48e8c37a26dca93d13c93e62d	529977eec2bf153a8168ee579f3892e5c2cc96b71c2e7485b59dab1c4f10a52d
745	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	529977eec2bf153a8168ee579f3892e5c2cc96b71c2e7485b59dab1c4f10a52d	052e26640f78e35b45b57ec68fd36cd3abcbd0c0395ab8bcca2284877ec08888
746	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	052e26640f78e35b45b57ec68fd36cd3abcbd0c0395ab8bcca2284877ec08888	c3f6391d383a3cdebd6342e977b3dfa75ef73ecb260f869acbca1b864cff3d8e
747	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-24"}	c3f6391d383a3cdebd6342e977b3dfa75ef73ecb260f869acbca1b864cff3d8e	a94939434cac3f48642a9e091f505d88caff85764a6367605ef08f8e83a62f41
748	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	a94939434cac3f48642a9e091f505d88caff85764a6367605ef08f8e83a62f41	c3bedf493b5387ff5a1dfefaa3776d48c704e7a5da15ac789d1dc3ce8d414a41
749	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	c3bedf493b5387ff5a1dfefaa3776d48c704e7a5da15ac789d1dc3ce8d414a41	b08394442d3f09168ccb7d1c4b7fcab4359491b61c3218410fec7fbaca9061a5
750	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-28"}	b08394442d3f09168ccb7d1c4b7fcab4359491b61c3218410fec7fbaca9061a5	b75d9e3239213d609b1bef3a93983ea3c8e791c3f125cc65d499a4583d8f4501
751	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-07-28"}	b75d9e3239213d609b1bef3a93983ea3c8e791c3f125cc65d499a4583d8f4501	080d031bfb773cc7555798d3f0f57f352b4e551fe50fcffc580ee4ae4d7e6ec7
752	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-29"}	080d031bfb773cc7555798d3f0f57f352b4e551fe50fcffc580ee4ae4d7e6ec7	3fe2d1b6f4cff1bbe24c52ad4a402a5df8e080f04a1b19be7d9958d29484d851
753	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-30"}	3fe2d1b6f4cff1bbe24c52ad4a402a5df8e080f04a1b19be7d9958d29484d851	b9d029d19d1be071e879821f10c9f3593f0dbfb968a1b6b1f80779246bb81f13
754	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-30"}	b9d029d19d1be071e879821f10c9f3593f0dbfb968a1b6b1f80779246bb81f13	f85538c0f66c2415c5844d41381999fa3392d1ecbb6f4f853d0995dbb0bc86f2
755	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-31"}	f85538c0f66c2415c5844d41381999fa3392d1ecbb6f4f853d0995dbb0bc86f2	ee04019a3c9887d68cd0011354b4cea4782761dd68484f215667f3d22142dcb2
756	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-31"}	ee04019a3c9887d68cd0011354b4cea4782761dd68484f215667f3d22142dcb2	28df79762b3e41b06eb2a9bc3439fc04ffe08a8fc83033bf4cab0ddb9ea53a6a
757	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-01"}	28df79762b3e41b06eb2a9bc3439fc04ffe08a8fc83033bf4cab0ddb9ea53a6a	feaa2300f6fa17eff4af55fe991b55e88cdaed0a16602498a6d2e7b513a2dc81
758	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	feaa2300f6fa17eff4af55fe991b55e88cdaed0a16602498a6d2e7b513a2dc81	7a2ae1751bf427194ba3d534ea2157e59d0cdb360215b0c049ad46931be18c02
759	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	7a2ae1751bf427194ba3d534ea2157e59d0cdb360215b0c049ad46931be18c02	1202fada849527c68c0f2b223ccea08e9401b8e0d2c7aa2ac2ff2c97e1efd1b2
760	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-02"}	1202fada849527c68c0f2b223ccea08e9401b8e0d2c7aa2ac2ff2c97e1efd1b2	4b5a416532300d420b91763aad4baabd18c7eddabb8182bc422631ac2dccacdf
761	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	4b5a416532300d420b91763aad4baabd18c7eddabb8182bc422631ac2dccacdf	45553291a2b4d4beea227d43f829df922243c1ce93ed15cf99c552891c10fc9c
762	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	45553291a2b4d4beea227d43f829df922243c1ce93ed15cf99c552891c10fc9c	f840ef78ac797a0ab990edde82f3a021b58d3869f281e818ceb7174ac7e12c29
763	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-04"}	f840ef78ac797a0ab990edde82f3a021b58d3869f281e818ceb7174ac7e12c29	70e047afb44408b2bef95c62017374881b7a9f35259f4c873af48da13e4e1a81
764	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	70e047afb44408b2bef95c62017374881b7a9f35259f4c873af48da13e4e1a81	9104190110e71adb86b5d054217c82849e76d0ab713594fbf6050062f38e3ce8
765	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-07"}	9104190110e71adb86b5d054217c82849e76d0ab713594fbf6050062f38e3ce8	ee287b2fc4d9866dfeac6f7f230039768994f37ec8caa9615c7b152fd3daeca3
766	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-08"}	ee287b2fc4d9866dfeac6f7f230039768994f37ec8caa9615c7b152fd3daeca3	e2a3389baf616f330db0a6293474061bfb9fba509285d4e7e2db18c9e7b4db9a
767	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	e2a3389baf616f330db0a6293474061bfb9fba509285d4e7e2db18c9e7b4db9a	cfd669ba06d8017477c839d2f20405dff71f2a69090e15ca46d32dcc47b7577b
768	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	cfd669ba06d8017477c839d2f20405dff71f2a69090e15ca46d32dcc47b7577b	47af2be5e9690595a6fc561e8a22dc5b86dbbac5e39536547135e47711dc7b3c
769	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	47af2be5e9690595a6fc561e8a22dc5b86dbbac5e39536547135e47711dc7b3c	a4715d6c23e68bed96f8cab63b305857804eeb2e3869208207b4787a0bf2ab2c
770	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-10"}	a4715d6c23e68bed96f8cab63b305857804eeb2e3869208207b4787a0bf2ab2c	7cd87542c255b69039aca01cb3a0f5ce66b2dffff766d6ddd3c0b27a8882dbf0
771	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-10"}	7cd87542c255b69039aca01cb3a0f5ce66b2dffff766d6ddd3c0b27a8882dbf0	f27bb16d7200ad9d18b8feb6f3e89fa6db611f76db90c151ddc5368be8f95cad
772	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-11"}	f27bb16d7200ad9d18b8feb6f3e89fa6db611f76db90c151ddc5368be8f95cad	88fbec29919970fc13cfd6eaddc9d87a362f5286c5629a8d055c8ae1c6a73e2e
773	2026-08-19 18:24:46	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-SSD-01", "quantity": 90, "date": "2026-08-11"}	88fbec29919970fc13cfd6eaddc9d87a362f5286c5629a8d055c8ae1c6a73e2e	e4003d9b58289e78e6c4d601d741c34c3040f8282437e11d244a0e05cd093669
774	2026-08-19 18:24:46	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	e4003d9b58289e78e6c4d601d741c34c3040f8282437e11d244a0e05cd093669	579c0d544221778e2de3192309f450eea719b709a6a3f7406a2d9d42d3576b44
775	2026-08-19 18:24:46	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	579c0d544221778e2de3192309f450eea719b709a6a3f7406a2d9d42d3576b44	71d5f4c3eeacef0b6f5b6c1bd3d4272592e231814505000c7d05150f577ba3ec
776	2026-08-19 18:24:50	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:24:50.116588"}	71d5f4c3eeacef0b6f5b6c1bd3d4272592e231814505000c7d05150f577ba3ec	b6856c5da0915b2af0f5643650d822e34db54e6a24abcae33fe7562230ea3671
777	2026-08-19 18:24:50	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	b6856c5da0915b2af0f5643650d822e34db54e6a24abcae33fe7562230ea3671	66f83754f29658a272664756ebf5198b675f0207a52beb996196af1e9a66da07
778	2026-08-19 18:24:57	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:24:57.552415"}	66f83754f29658a272664756ebf5198b675f0207a52beb996196af1e9a66da07	a4130257276731935f3ca9e5f2317eb075f4fe63dc965d085f38cc0835782f83
779	2026-08-19 18:24:57	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	a4130257276731935f3ca9e5f2317eb075f4fe63dc965d085f38cc0835782f83	613c51a3bb9f3342c03d236718c54e15725eb489ec5c06bb7063fdfd4c4b7baa
780	2026-08-19 18:25:04	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:25:04.847009"}	613c51a3bb9f3342c03d236718c54e15725eb489ec5c06bb7063fdfd4c4b7baa	badde88920b01c002d9533aaa6e9ca3295202f8d5dae03f11ed1d8f3e519bbf6
781	2026-08-19 18:25:04	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	badde88920b01c002d9533aaa6e9ca3295202f8d5dae03f11ed1d8f3e519bbf6	105dbd86ca7e23bf9f9ead35618bf8fa04b886873f000b4f8f9feb8e25317a95
782	2026-08-19 18:25:12	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:25:12.560159"}	105dbd86ca7e23bf9f9ead35618bf8fa04b886873f000b4f8f9feb8e25317a95	2c8e1d63445fc9d888ecce1ba461460ce6e597f89c995a71240c7a8945667f63
785	2026-08-19 18:25:13	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	43e084dcfb50ca0623c2160ad972df5cc427dcab46cca89b32ff2c6f6b486018	20bd42864fffbe2d784d20b98fcfe60cb61bd168bd882c7fc6e804e9aaa25410
786	2026-08-19 18:25:14	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:25:14.455071"}	20bd42864fffbe2d784d20b98fcfe60cb61bd168bd882c7fc6e804e9aaa25410	b9fbafc68e9f93ceee6148a9c44a0fe320be3c3cad16d4a52e9ed63f5de67e32
783	2026-08-19 18:25:12	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	2c8e1d63445fc9d888ecce1ba461460ce6e597f89c995a71240c7a8945667f63	5d7e800a465b9d400ffbf0c051013c81c30ca3ba4dfcabdde04d1eb13647ef54
784	2026-08-19 18:25:13	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:25:13.513476"}	5d7e800a465b9d400ffbf0c051013c81c30ca3ba4dfcabdde04d1eb13647ef54	43e084dcfb50ca0623c2160ad972df5cc427dcab46cca89b32ff2c6f6b486018
787	2026-08-19 18:25:14	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	b9fbafc68e9f93ceee6148a9c44a0fe320be3c3cad16d4a52e9ed63f5de67e32	f2ae250ec04fe695f14678270483a086c763d7044e7bae8a8317136139f8b27d
788	2026-08-19 18:28:40	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	f2ae250ec04fe695f14678270483a086c763d7044e7bae8a8317136139f8b27d	65860016ed4fd53e2df28d50b28974401e9265201cce81e3c7598ac0b3c80da4
789	2026-08-19 18:28:40	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	65860016ed4fd53e2df28d50b28974401e9265201cce81e3c7598ac0b3c80da4	336b8afbae4f0d1327866f5dce06600e454b1c7f85d85122a7796c48c4590204
790	2026-08-19 18:28:40	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	336b8afbae4f0d1327866f5dce06600e454b1c7f85d85122a7796c48c4590204	3e81088b2aac7ccf642743e70a6f383ae6c4f6ac6c74d9f006037c09cb7255b2
791	2026-08-19 18:28:40	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	3e81088b2aac7ccf642743e70a6f383ae6c4f6ac6c74d9f006037c09cb7255b2	d5b72f38a59c52bfd8dd2c387249d58b580071348e2c2afa81c4672f261d911c
792	2026-08-19 18:28:40	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	d5b72f38a59c52bfd8dd2c387249d58b580071348e2c2afa81c4672f261d911c	527958dc2ffdc54db65ed6660d7c2d1b4a0aca248e75cc6c7d76b944e8b2e978
793	2026-08-19 18:28:40	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	527958dc2ffdc54db65ed6660d7c2d1b4a0aca248e75cc6c7d76b944e8b2e978	0726c0fae77879afa7a96134f5a41b6a72a420bc89ebda96999a0b76369fd318
794	2026-08-19 18:28:40	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	0726c0fae77879afa7a96134f5a41b6a72a420bc89ebda96999a0b76369fd318	e24662be287276693a966c139fd124799dc43ad169613501390d85c1760151f0
795	2026-08-19 18:28:40	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	e24662be287276693a966c139fd124799dc43ad169613501390d85c1760151f0	957a1168bb5a7698a5d8650e9188c5a918d38e1d1e5206cd4b12541e9149c532
796	2026-08-19 18:28:40	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	957a1168bb5a7698a5d8650e9188c5a918d38e1d1e5206cd4b12541e9149c532	4b427a4a4730b8f5b761556fc21e7131cfa3f88298aa6303b7ea12f30ec43f2f
797	2026-08-19 18:28:41	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	4b427a4a4730b8f5b761556fc21e7131cfa3f88298aa6303b7ea12f30ec43f2f	ae1d8b6913b164966a32821f28ed2cfe6bd0eeab8099ebd6b3c6fb44f36882dc
798	2026-08-19 18:28:41	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	ae1d8b6913b164966a32821f28ed2cfe6bd0eeab8099ebd6b3c6fb44f36882dc	3adc4f8341540bc45631bbe91264c98f888a925827646418434d15a0b6df532d
799	2026-08-19 18:28:41	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	3adc4f8341540bc45631bbe91264c98f888a925827646418434d15a0b6df532d	36738c4f20675602fbdf48bf1a81cac0a2f7a12880942726db57d7bb97f86c27
800	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	36738c4f20675602fbdf48bf1a81cac0a2f7a12880942726db57d7bb97f86c27	4a09f8d91917c8ade7e6431bfcf3ee00465d7bfa68140d3b815551dba0ab06dc
801	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	4a09f8d91917c8ade7e6431bfcf3ee00465d7bfa68140d3b815551dba0ab06dc	75b23cea120324dc1e5bd4a463ecd372eab0793c526d3bf108381221e9e86747
802	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	75b23cea120324dc1e5bd4a463ecd372eab0793c526d3bf108381221e9e86747	a9ba784c80289c0a0e9dbd84cdad3cfd6e5409b0fd3a390a2e496453c45e9868
803	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	a9ba784c80289c0a0e9dbd84cdad3cfd6e5409b0fd3a390a2e496453c45e9868	4745ff06c88c79cb39136ed0823f81723fbd886419b7d6a0b6a294893fce36df
804	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	4745ff06c88c79cb39136ed0823f81723fbd886419b7d6a0b6a294893fce36df	7138b5724d629ea4216856a8e3158c615df2bf20e63cb809b9a1cbf06511fb49
805	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-24"}	7138b5724d629ea4216856a8e3158c615df2bf20e63cb809b9a1cbf06511fb49	4c43d16e787026255684e4518faaa6dcfc4948b7915cbd5fcfe70be6beb1bbc3
806	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	4c43d16e787026255684e4518faaa6dcfc4948b7915cbd5fcfe70be6beb1bbc3	ff157fd25abb669fe288d4f3e83e44fd4d8c811d718a091bc7f9555cff9d98ab
807	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	ff157fd25abb669fe288d4f3e83e44fd4d8c811d718a091bc7f9555cff9d98ab	0b1904d9d516ee88a3c8ef8de58374df66d257fac330c550915e12d68ea4a025
808	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-27"}	0b1904d9d516ee88a3c8ef8de58374df66d257fac330c550915e12d68ea4a025	4dd09680f4073954f127e3502e1840970166cbf84cab789316a390a8763ed9f5
809	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	4dd09680f4073954f127e3502e1840970166cbf84cab789316a390a8763ed9f5	25c1761dc76ce61306c3ee85a4fba5623f49fb1bf5d35b4d1472ab1942501cdb
810	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	25c1761dc76ce61306c3ee85a4fba5623f49fb1bf5d35b4d1472ab1942501cdb	7626f746dfbbbcd71c0ec72e03296ab7a21819fd0a97b308b07ba7461d2155cf
811	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-29"}	7626f746dfbbbcd71c0ec72e03296ab7a21819fd0a97b308b07ba7461d2155cf	69c03eda812b11bc8103bcd065676cfa0c6c19399d4d04849fdeca53d2d632f1
812	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-30"}	69c03eda812b11bc8103bcd065676cfa0c6c19399d4d04849fdeca53d2d632f1	359b0b81b204c568e45c05352059065f2605deceed57088ad7974d8fe03ab99b
813	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-31"}	359b0b81b204c568e45c05352059065f2605deceed57088ad7974d8fe03ab99b	37aeacc973e2bca3257626e52af983e7813d06d1f7fb88af735f5d882f9abc66
814	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-01"}	37aeacc973e2bca3257626e52af983e7813d06d1f7fb88af735f5d882f9abc66	b0e1315fd8772a81e069b0337476fb886209598732602da1465f19b8dcc97bd6
815	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-02"}	b0e1315fd8772a81e069b0337476fb886209598732602da1465f19b8dcc97bd6	2960ba79524cbd15734ccf93f0d3421ba955db66759ee2403a375f58f32222b0
816	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-02"}	2960ba79524cbd15734ccf93f0d3421ba955db66759ee2403a375f58f32222b0	4c0d3b862ea59c50cf8173467c4ad13fa1141979db18f9b2fa95ada981937cff
817	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-02"}	4c0d3b862ea59c50cf8173467c4ad13fa1141979db18f9b2fa95ada981937cff	285c89d6cf86bf38a16d708f145063b1352dcb3f1e888690fa5fad2ad1f28baa
818	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-03"}	285c89d6cf86bf38a16d708f145063b1352dcb3f1e888690fa5fad2ad1f28baa	51b34b57755162c887ce58951133bb2a4bc8c47f951f5cb8cae4057021633267
819	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	51b34b57755162c887ce58951133bb2a4bc8c47f951f5cb8cae4057021633267	243f7db5bbb51bfedcb15542059ac4e344fc357b5b030c724e7e9b17004310de
820	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-04"}	243f7db5bbb51bfedcb15542059ac4e344fc357b5b030c724e7e9b17004310de	0425102852b7d62447752f7d36959f53052c2b78b8170d6b4d969a597cc2aa36
821	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-04"}	0425102852b7d62447752f7d36959f53052c2b78b8170d6b4d969a597cc2aa36	7ce1ee8656cccee49c08d870593559847d3d847237b53d081fe78a65e8c5d994
822	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-04"}	7ce1ee8656cccee49c08d870593559847d3d847237b53d081fe78a65e8c5d994	9434d72cb7e086a866591d095de871446b8f8966edcb6c1bb85cea46a87a5cf1
823	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-05"}	9434d72cb7e086a866591d095de871446b8f8966edcb6c1bb85cea46a87a5cf1	dc677d85eaa5ddbfb442888a7ba81d86c5a70ea0a57d8ab36de78d8bae26ddee
824	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-06"}	dc677d85eaa5ddbfb442888a7ba81d86c5a70ea0a57d8ab36de78d8bae26ddee	92eea840ac2ebcd34fc6ec4bce0a8fa3502f838ae6fd1081de516334518e1820
825	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-08"}	92eea840ac2ebcd34fc6ec4bce0a8fa3502f838ae6fd1081de516334518e1820	d2a12aca23aa53e607dcc37ae1f9a2b18082cbd8890f4854e4494569469940e0
826	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	d2a12aca23aa53e607dcc37ae1f9a2b18082cbd8890f4854e4494569469940e0	e8f0abe565f833a337cfb1992f80ba2045e95a3638a2dad5a876a4e3b6507ec1
827	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-09"}	e8f0abe565f833a337cfb1992f80ba2045e95a3638a2dad5a876a4e3b6507ec1	f8c4abc1039148272a428ff73c7f1bf49b26c912735fdb36e4f2e79f263fcfbf
828	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-10"}	f8c4abc1039148272a428ff73c7f1bf49b26c912735fdb36e4f2e79f263fcfbf	ee353193578cfc9a8b707dae0cc78ec7e3062a03860197443934c9ef206d6d98
829	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-11"}	ee353193578cfc9a8b707dae0cc78ec7e3062a03860197443934c9ef206d6d98	b46154fef196402ae2f9cf6e3be058c5e5058d696efb88c1e64076aefa09e562
830	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	b46154fef196402ae2f9cf6e3be058c5e5058d696efb88c1e64076aefa09e562	1d8ecad24332c7fc537760f45ced96ea4c8e48efe6739cba668fb8f33b3f3e3f
831	2026-08-19 18:28:41	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	1d8ecad24332c7fc537760f45ced96ea4c8e48efe6739cba668fb8f33b3f3e3f	63caf86001658b42c3ded170cd4526e38b1a3e9098edcc5435f22db9e58f7fef
832	2026-08-19 18:28:41	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	63caf86001658b42c3ded170cd4526e38b1a3e9098edcc5435f22db9e58f7fef	7ee2e1362c77cadc5e64bcb3cf2bfef31e7442aebf5121044ea98f57aeaf6657
833	2026-08-19 18:28:41	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	7ee2e1362c77cadc5e64bcb3cf2bfef31e7442aebf5121044ea98f57aeaf6657	6cdbbc98a15e5ae41539ec17f42c2b720d7bceef861cad6aaa829fd8ee7a17d1
834	2026-08-19 18:28:49	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:28:49.587070"}	6cdbbc98a15e5ae41539ec17f42c2b720d7bceef861cad6aaa829fd8ee7a17d1	216768ed255c7ebc6ec79d69a9fa24685c49ff2ccb04f36c4bb64e9dfd3b2eee
835	2026-08-19 18:28:49	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	216768ed255c7ebc6ec79d69a9fa24685c49ff2ccb04f36c4bb64e9dfd3b2eee	7196b532a6126fe38b4d1fbd9183890eda24d5a1655b55c8e3641c663ef22ab9
836	2026-08-19 18:28:57	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:28:57.143273"}	7196b532a6126fe38b4d1fbd9183890eda24d5a1655b55c8e3641c663ef22ab9	bca58d6ccdd86d494006ebf96f8df0eefd8dad3203dcef11d272eb1a16f9c953
837	2026-08-19 18:28:57	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	bca58d6ccdd86d494006ebf96f8df0eefd8dad3203dcef11d272eb1a16f9c953	ba0de5fa8b855e53e765d2daac6a58f435c734d7cef02cbe05fc47bd5d99caa8
838	2026-08-19 18:29:04	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:29:04.277851"}	ba0de5fa8b855e53e765d2daac6a58f435c734d7cef02cbe05fc47bd5d99caa8	76b1ad4b62f00e8e84078abf26543a37911605d9ec8b7b4574fd9a6324459ab5
840	2026-08-19 18:29:12	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:29:12.018408"}	7f56b3fddeb9da5a8bd8c8f86f3470f03372d2686a5078dbd945c6a881c05c48	f294aaba2c657cbaa489ad85af558da5532cb0008159e4eebae310d5a0018c0b
839	2026-08-19 18:29:04	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	76b1ad4b62f00e8e84078abf26543a37911605d9ec8b7b4574fd9a6324459ab5	7f56b3fddeb9da5a8bd8c8f86f3470f03372d2686a5078dbd945c6a881c05c48
841	2026-08-19 18:29:12	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	f294aaba2c657cbaa489ad85af558da5532cb0008159e4eebae310d5a0018c0b	924c8761eb30f84af23c2ec6ca0015b5e709b5ca6349807e49f2beadfb8dd3d9
842	2026-08-19 18:29:12	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:29:12.975593"}	924c8761eb30f84af23c2ec6ca0015b5e709b5ca6349807e49f2beadfb8dd3d9	3dfb50cf005908abf0352e127f4b99d898ffc9d3d8354eca0d1ebee73d50965a
845	2026-08-19 18:29:13	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	589cff907512d35abeb8af1ebc711add6c85856b04053d8b4d1effb59b6d4874	f728594800c44843796063ccdc1c1cb227450805f102183b71bfcda62410cffc
843	2026-08-19 18:29:13	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "5", "source_entity_type": "USER", "recipients_count": 3}	3dfb50cf005908abf0352e127f4b99d898ffc9d3d8354eca0d1ebee73d50965a	1928f64fb6b2b4b7f9699ffc24ac645b911007cf266b1e36958a7e50e7f8b99e
844	2026-08-19 18:29:13	user_login	{"username": "test_admin_hardened", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:29:13.910176"}	1928f64fb6b2b4b7f9699ffc24ac645b911007cf266b1e36958a7e50e7f8b99e	589cff907512d35abeb8af1ebc711add6c85856b04053d8b4d1effb59b6d4874
846	2026-08-19 18:29:34	user_login	{"username": "test_admin", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T18:29:34.468950"}	f728594800c44843796063ccdc1c1cb227450805f102183b71bfcda62410cffc	cead4afdb3241f491249e1e1d36e030196c9d8356c9be7a2a8ea7d717deaf303
847	2026-08-19 18:29:34	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "2", "source_entity_type": "USER", "recipients_count": 3}	cead4afdb3241f491249e1e1d36e030196c9d8356c9be7a2a8ea7d717deaf303	65d56220b350e4c14f9edc18f452c964c307842298ff614a7ce2f95bb5603de8
\.


--
-- Data for Name: backup_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_records (id, backup_id, filename, created_at, size_bytes, sha256, status, storage_key, error_message, backup_type, started_at, completed_at, storage_provider, bucket, checksum_algorithm, verification_status, verification_at, restore_test_status, restore_test_at, retention_status, initiated_by, audit_ref) FROM stdin;
13	BK-7C5FE0477FA99D5D	warehouse_postgres_2026-08-19_18-24-17.sql.gz	2026-08-19 18:24:17.956875	\N	\N	RUNNING	\N	\N	MANUAL	2026-08-19 18:24:17.956875	\N	Backblaze B2 Storage	harsha-warehouse-backups	SHA-256	PENDING	\N	PENDING	\N	ACTIVE	SYSTEM	\N
14	BK-CC1AFA390BBB3FB6	warehouse_postgres_2026-08-19_18-29-38.sql.gz	2026-08-19 18:29:38.676633	\N	\N	RUNNING	\N	\N	MANUAL	2026-08-19 18:29:38.673636	\N	Backblaze B2 Storage	harsha-warehouse-backups	SHA-256	PENDING	\N	PENDING	\N	ACTIVE	SYSTEM	\N
\.


--
-- Data for Name: digital_twin_simulations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.digital_twin_simulations (id, warehouse_id, simulation_status, simulation_time_seconds, speed_multiplier, seed, mode, scenario_type, tick_count, created_at, started_at, paused_at, stopped_at, completed_at, error_message, created_by) FROM stdin;
\.


--
-- Data for Name: experiment_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.experiment_runs (id, experiment_id, repetition_number, random_seed, status, started_at, completed_at, duration_seconds, error_message, metrics, created_at) FROM stdin;
\.


--
-- Data for Name: experiments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.experiments (id, scenario_id, experiment_name, description, status, algorithm_name, algorithm_version, configuration, random_seed, repetitions, started_at, completed_at, duration_seconds, created_by, error_message, metrics_summary, created_at) FROM stdin;
\.


--
-- Data for Name: health_thresholds; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health_thresholds (id, key, value, description, created_at, updated_at) FROM stdin;
13	api_latency_warning_ms	400	Warn	2026-08-19 18:22:50.801112	2026-08-19 18:22:50.833288
14	queue_warning_depth	10	Warning threshold for RabbitMQ queue depth	2026-08-19 18:24:12.94791	2026-08-19 18:24:12.94791
15	queue_critical_depth	50	Critical threshold for RabbitMQ queue depth	2026-08-19 18:24:12.94791	2026-08-19 18:24:12.94791
16	api_latency_critical_ms	1000	Critical threshold for API request response time	2026-08-19 18:24:12.94791	2026-08-19 18:24:12.94791
17	database_latency_warning_ms	100	Warning threshold for Supabase DB response time	2026-08-19 18:24:12.94791	2026-08-19 18:24:12.94791
18	database_latency_critical_ms	500	Critical threshold for Supabase DB response time	2026-08-19 18:24:12.94791	2026-08-19 18:24:12.94791
19	backup_age_warning_hours	26	Warning threshold for backup age	2026-08-19 18:24:12.94791	2026-08-19 18:24:12.94791
20	backup_age_critical_hours	48	Critical threshold for backup age	2026-08-19 18:24:12.94791	2026-08-19 18:24:12.94791
21	worker_stale_timeout_seconds	60	Heartbeat threshold for stale Celery worker status	2026-08-19 18:24:12.94791	2026-08-19 18:24:12.94791
22	api_error_rate_warning_pct	5	Warning threshold for API request error percentage	2026-08-19 18:24:12.94791	2026-08-19 18:24:12.94791
23	api_error_rate_critical_pct	15	Critical threshold for API request error percentage	2026-08-19 18:24:12.94791	2026-08-19 18:24:12.94791
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (id, warehouse_id, item_id, location_id, on_hand, reserved, available, damaged, created_at, updated_at) FROM stdin;
380	WH-BLR-01	ITM-CPU-01	WH-WH-BLR-01-LOC-ITM-CPU-01-STORAGE	52	0	52	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
381	WH-BLR-01	ITM-GPU-01	WH-WH-BLR-01-LOC-ITM-GPU-01-STORAGE	29	0	29	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
382	WH-BLR-01	ITM-RAM-01	WH-WH-BLR-01-LOC-ITM-RAM-01-STORAGE	70	0	70	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
383	WH-BLR-01	ITM-SSD-01	WH-WH-BLR-01-LOC-ITM-SSD-01-STORAGE	58	0	58	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
384	WH-BLR-01	ITM-HDD-01	WH-WH-BLR-01-LOC-ITM-HDD-01-STORAGE	83	0	83	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
385	WH-BLR-01	ITM-CHG-01	WH-WH-BLR-01-LOC-ITM-CHG-01-STORAGE	122	0	122	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
386	WH-BLR-01	ITM-CBL-01	WH-WH-BLR-01-LOC-ITM-CBL-01-STORAGE	421	0	421	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
387	WH-CHN-01	ITM-CPU-01	WH-WH-CHN-01-LOC-ITM-CPU-01-STORAGE	38	0	38	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
388	WH-CHN-01	ITM-GPU-01	WH-WH-CHN-01-LOC-ITM-GPU-01-STORAGE	16	0	16	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
389	WH-CHN-01	ITM-RAM-01	WH-WH-CHN-01-LOC-ITM-RAM-01-STORAGE	61	0	61	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
390	WH-CHN-01	ITM-SSD-01	WH-WH-CHN-01-LOC-ITM-SSD-01-STORAGE	46	0	46	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
391	WH-CHN-01	ITM-HDD-01	WH-WH-CHN-01-LOC-ITM-HDD-01-STORAGE	82	0	82	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
392	WH-CHN-01	ITM-CHG-01	WH-WH-CHN-01-LOC-ITM-CHG-01-STORAGE	105	0	105	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
393	WH-CHN-01	ITM-CBL-01	WH-WH-CHN-01-LOC-ITM-CBL-01-STORAGE	421	0	421	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
394	WH-BOM-01	ITM-CPU-01	WH-WH-BOM-01-LOC-ITM-CPU-01-STORAGE	61	0	61	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
395	WH-BOM-01	ITM-GPU-01	WH-WH-BOM-01-LOC-ITM-GPU-01-STORAGE	21	0	21	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
396	WH-BOM-01	ITM-RAM-01	WH-WH-BOM-01-LOC-ITM-RAM-01-STORAGE	83	0	83	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
397	WH-BOM-01	ITM-SSD-01	WH-WH-BOM-01-LOC-ITM-SSD-01-STORAGE	56	0	56	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
398	WH-BOM-01	ITM-HDD-01	WH-WH-BOM-01-LOC-ITM-HDD-01-STORAGE	71	0	71	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
399	WH-BOM-01	ITM-CHG-01	WH-WH-BOM-01-LOC-ITM-CHG-01-STORAGE	135	0	135	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
400	WH-BOM-01	ITM-CBL-01	WH-WH-BOM-01-LOC-ITM-CBL-01-STORAGE	153	0	153	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
401	WH-DEL-01	ITM-CPU-01	WH-WH-DEL-01-LOC-ITM-CPU-01-STORAGE	48	0	48	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
402	WH-DEL-01	ITM-GPU-01	WH-WH-DEL-01-LOC-ITM-GPU-01-STORAGE	34	0	34	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
403	WH-DEL-01	ITM-RAM-01	WH-WH-DEL-01-LOC-ITM-RAM-01-STORAGE	105	0	105	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
404	WH-DEL-01	ITM-SSD-01	WH-WH-DEL-01-LOC-ITM-SSD-01-STORAGE	53	0	53	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
405	WH-DEL-01	ITM-HDD-01	WH-WH-DEL-01-LOC-ITM-HDD-01-STORAGE	85	0	85	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.406274
406	WH-DEL-01	ITM-CHG-01	WH-WH-DEL-01-LOC-ITM-CHG-01-STORAGE	125	0	125	0	2026-08-19 18:28:41.406274	2026-08-19 18:28:41.407275
407	WH-DEL-01	ITM-CBL-01	WH-WH-DEL-01-LOC-ITM-CBL-01-STORAGE	435	0	435	0	2026-08-19 18:28:41.407275	2026-08-19 18:28:41.407275
408	WH-CCU-01	ITM-CPU-01	WH-WH-CCU-01-LOC-ITM-CPU-01-STORAGE	51	0	51	0	2026-08-19 18:28:41.407275	2026-08-19 18:28:41.407275
409	WH-CCU-01	ITM-GPU-01	WH-WH-CCU-01-LOC-ITM-GPU-01-STORAGE	44	0	44	0	2026-08-19 18:28:41.407275	2026-08-19 18:28:41.407275
410	WH-CCU-01	ITM-RAM-01	WH-WH-CCU-01-LOC-ITM-RAM-01-STORAGE	71	0	71	0	2026-08-19 18:28:41.407275	2026-08-19 18:28:41.407275
411	WH-CCU-01	ITM-SSD-01	WH-WH-CCU-01-LOC-ITM-SSD-01-STORAGE	65	0	65	0	2026-08-19 18:28:41.407275	2026-08-19 18:28:41.407275
412	WH-CCU-01	ITM-HDD-01	WH-WH-CCU-01-LOC-ITM-HDD-01-STORAGE	35	0	35	0	2026-08-19 18:28:41.407275	2026-08-19 18:28:41.407275
413	WH-CCU-01	ITM-CHG-01	WH-WH-CCU-01-LOC-ITM-CHG-01-STORAGE	132	0	132	0	2026-08-19 18:28:41.407275	2026-08-19 18:28:41.407275
414	WH-CCU-01	ITM-CBL-01	WH-WH-CCU-01-LOC-ITM-CBL-01-STORAGE	440	0	440	0	2026-08-19 18:28:41.407275	2026-08-19 18:28:41.407275
\.


--
-- Data for Name: inventory_reservations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_reservations (id, order_id, item_id, location_id, reserved_qty, released_qty, created_at) FROM stdin;
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id, name, category, unit_cost, lead_time_days, safety_stock, sku, description, unit, weight_kg, dimensions, barcode, is_active, reorder_threshold, preferred_storage_type, created_at) FROM stdin;
ITM-CPU-01	AMD Ryzen 9 7900X Processor	Electronics	38000	5	15	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 18:28:40.971003
ITM-GPU-01	Nvidia RTX 4080 Founders Edition	Electronics	95000	7	10	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 18:28:40.982007
ITM-RAM-01	Corsair DDR5 32GB 6000MHz RAM	Electronics	8500	4	25	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 18:28:40.990006
ITM-SSD-01	Samsung 990 Pro 2TB NVMe SSD	Storage	12000	3	30	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 18:28:40.996009
ITM-HDD-01	WD Red Pro 8TB NAS Hard Drive	Storage	16500	5	20	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 18:28:41.004009
ITM-CHG-01	Anker 100W GaN Wall Charger	Accessories	2500	2	50	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 18:28:41.012255
ITM-CBL-01	Apple USB-C Braided Cable 2m	Accessories	800	1	100	\N	\N	units	0		\N	t	20	STORAGE	2026-08-19 18:28:41.019357
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_preferences (id, user_id, category, in_app_enabled, email_enabled, min_severity, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, warehouse_id, event_type, notification_type, title, message, severity, status, channel, source_entity_type, source_entity_id, created_at, read_at, delivered_at, failed_at, retry_count, expires_at, metadata, idempotency_key) FROM stdin;
141	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_admin_hardened logged in successfully.	INFO	DELIVERED	IN_APP	USER	5	2026-08-19 18:22:23.132525	\N	2026-08-19 18:22:23.194265	\N	0	\N	{"username": "test_admin_hardened", "message": "User test_admin_hardened logged in successfully."}	USER_LOGIN_5_2_1787143943.132525
147	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_e2e_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	18	2026-08-19 18:22:41.486292	\N	2026-08-19 18:22:41.509601	\N	0	\N	{"username": "test_e2e_admin", "message": "User test_e2e_admin logged in successfully."}	USER_LOGIN_18_1_1787143961.486292
166	3	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-B	2026-08-19 18:22:43.591168	\N	2026-08-19 18:22:43.613389	\N	0	\N	{"robot_code": "ROB-B", "task_number": "TSK-E2E-PICK-2", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-B_3_1787143963.591168
168	1	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-B	2026-08-19 18:22:43.591168	\N	2026-08-19 18:22:43.632057	\N	0	\N	{"robot_code": "ROB-B", "task_number": "TSK-E2E-PICK-2", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-B_1_1787143963.591168
172	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_path_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	19	2026-08-19 18:22:45.518053	\N	2026-08-19 18:22:45.537124	\N	0	\N	{"username": "test_path_admin", "message": "User test_path_admin logged in successfully."}	USER_LOGIN_19_5_1787143965.518053
175	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_path_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	19	2026-08-19 18:22:45.518053	\N	2026-08-19 18:22:45.557397	\N	0	\N	{"username": "test_path_admin", "message": "User test_path_admin logged in successfully."}	USER_LOGIN_19_1_1787143965.518053
195	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_tasks_staff logged in successfully.	INFO	DELIVERED	IN_APP	USER	20	2026-08-19 18:22:52.736706	\N	2026-08-19 18:22:52.753701	\N	0	\N	{"username": "test_tasks_staff", "message": "User test_tasks_staff logged in successfully."}	USER_LOGIN_20_5_1787143972.736706
199	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_tasks_staff logged in successfully.	INFO	DELIVERED	IN_APP	USER	20	2026-08-19 18:22:52.736706	\N	2026-08-19 18:22:52.7747	\N	0	\N	{"username": "test_tasks_staff", "message": "User test_tasks_staff logged in successfully."}	USER_LOGIN_20_2_1787143972.736706
139	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_admin_hardened logged in successfully.	INFO	DELIVERED	IN_APP	USER	5	2026-08-19 18:22:23.132525	\N	2026-08-19 18:22:23.168695	\N	0	\N	{"username": "test_admin_hardened", "message": "User test_admin_hardened logged in successfully."}	USER_LOGIN_5_5_1787143943.132525
148	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_e2e_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	18	2026-08-19 18:22:41.486292	\N	2026-08-19 18:22:41.516673	\N	0	\N	{"username": "test_e2e_admin", "message": "User test_e2e_admin logged in successfully."}	USER_LOGIN_18_2_1787143961.486292
176	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_path_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	19	2026-08-19 18:22:45.518053	\N	2026-08-19 18:22:45.56225	\N	0	\N	{"username": "test_path_admin", "message": "User test_path_admin logged in successfully."}	USER_LOGIN_19_2_1787143965.518053
180	3	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-PATH-E2E	2026-08-19 18:22:46.011086	\N	2026-08-19 18:22:46.038906	\N	0	\N	{"robot_code": "ROB-PATH-E2E", "task_number": "TSK-PATH-01", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-PATH-E2E_3_1787143966.011086
184	2	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-PATH-E2E	2026-08-19 18:22:46.011086	\N	2026-08-19 18:22:46.063524	\N	0	\N	{"robot_code": "ROB-PATH-E2E", "task_number": "TSK-PATH-01", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-PATH-E2E_2_1787143966.011086
198	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_tasks_staff logged in successfully.	INFO	DELIVERED	IN_APP	USER	20	2026-08-19 18:22:52.736706	\N	2026-08-19 18:22:52.769697	\N	0	\N	{"username": "test_tasks_staff", "message": "User test_tasks_staff logged in successfully."}	USER_LOGIN_20_1_1787143972.736706
140	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_admin_hardened logged in successfully.	INFO	DELIVERED	IN_APP	USER	5	2026-08-19 18:22:23.132525	\N	2026-08-19 18:22:23.184721	\N	0	\N	{"username": "test_admin_hardened", "message": "User test_admin_hardened logged in successfully."}	USER_LOGIN_5_1_1787143943.132525
145	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_e2e_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	18	2026-08-19 18:22:41.486292	\N	2026-08-19 18:22:41.497602	\N	0	\N	{"username": "test_e2e_admin", "message": "User test_e2e_admin logged in successfully."}	USER_LOGIN_18_5_1787143961.486292
154	1	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-E2E-01	2026-08-19 18:22:41.994485	\N	2026-08-19 18:22:42.022203	\N	0	\N	{"robot_code": "ROB-E2E-01", "task_number": "TSK-E2E-PICK-1", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-E2E-01_1_1787143961.994485
158	5	\N	ROBOT_FAILED	ROBOTS_ALERT	Robot Failed Alert	Robot ROB-A failed in None. Action is required.	HIGH	DELIVERED	IN_APP	ROBOT	ROB-A	2026-08-19 18:22:43.216721	\N	2026-08-19 18:22:43.230938	\N	0	\N	{"robot_code": "ROB-A", "failure_count": 1, "message": "Robot ROB-A failed in None. Action is required."}	ROBOT_FAILED_ROB-A_5_1787143963.216721
162	2	\N	ROBOT_FAILED	ROBOTS_ALERT	Robot Failed Alert	Robot ROB-A failed in None. Action is required.	HIGH	DELIVERED	IN_APP	ROBOT	ROB-A	2026-08-19 18:22:43.216721	\N	2026-08-19 18:22:43.252288	\N	0	\N	{"robot_code": "ROB-A", "failure_count": 1, "message": "Robot ROB-A failed in None. Action is required."}	ROBOT_FAILED_ROB-A_2_1787143963.216721
165	5	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-B	2026-08-19 18:22:43.591168	\N	2026-08-19 18:22:43.607409	\N	0	\N	{"robot_code": "ROB-B", "task_number": "TSK-E2E-PICK-2", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-B_5_1787143963.591168
169	2	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-B	2026-08-19 18:22:43.591168	\N	2026-08-19 18:22:43.641588	\N	0	\N	{"robot_code": "ROB-B", "task_number": "TSK-E2E-PICK-2", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-B_2_1787143963.591168
187	5	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-REPLAN	2026-08-19 18:22:47.394982	\N	2026-08-19 18:22:47.408993	\N	0	\N	{"robot_code": "ROB-REPLAN", "task_number": "TSK-PATH-03", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-REPLAN_5_1787143967.394982
191	1	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-REPLAN	2026-08-19 18:22:47.394982	\N	2026-08-19 18:22:47.427744	\N	0	\N	{"robot_code": "ROB-REPLAN", "task_number": "TSK-PATH-03", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-REPLAN_1_1787143967.394982
151	5	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-E2E-01	2026-08-19 18:22:41.994485	\N	2026-08-19 18:22:42.007207	\N	0	\N	{"robot_code": "ROB-E2E-01", "task_number": "TSK-E2E-PICK-1", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-E2E-01_5_1787143961.994485
153	3	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-E2E-01	2026-08-19 18:22:41.994485	\N	2026-08-19 18:22:42.016967	\N	0	\N	{"robot_code": "ROB-E2E-01", "task_number": "TSK-E2E-PICK-1", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-E2E-01_3_1787143961.994485
155	2	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-E2E-01	2026-08-19 18:22:41.994485	\N	2026-08-19 18:22:42.026501	\N	0	\N	{"robot_code": "ROB-E2E-01", "task_number": "TSK-E2E-PICK-1", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-E2E-01_2_1787143961.994485
159	3	\N	ROBOT_FAILED	ROBOTS_ALERT	Robot Failed Alert	Robot ROB-A failed in None. Action is required.	HIGH	DELIVERED	IN_APP	ROBOT	ROB-A	2026-08-19 18:22:43.216721	\N	2026-08-19 18:22:43.235665	\N	0	\N	{"robot_code": "ROB-A", "failure_count": 1, "message": "Robot ROB-A failed in None. Action is required."}	ROBOT_FAILED_ROB-A_3_1787143963.216721
161	1	\N	ROBOT_FAILED	ROBOTS_ALERT	Robot Failed Alert	Robot ROB-A failed in None. Action is required.	HIGH	DELIVERED	IN_APP	ROBOT	ROB-A	2026-08-19 18:22:43.216721	\N	2026-08-19 18:22:43.247576	\N	0	\N	{"robot_code": "ROB-A", "failure_count": 1, "message": "Robot ROB-A failed in None. Action is required."}	ROBOT_FAILED_ROB-A_1_1787143963.216721
179	5	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-PATH-E2E	2026-08-19 18:22:46.011086	\N	2026-08-19 18:22:46.030768	\N	0	\N	{"robot_code": "ROB-PATH-E2E", "task_number": "TSK-PATH-01", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-PATH-E2E_5_1787143966.011086
183	1	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-PATH-E2E	2026-08-19 18:22:46.011086	\N	2026-08-19 18:22:46.054093	\N	0	\N	{"robot_code": "ROB-PATH-E2E", "task_number": "TSK-PATH-01", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-PATH-E2E_1_1787143966.011086
188	3	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-REPLAN	2026-08-19 18:22:47.394982	\N	2026-08-19 18:22:47.412984	\N	0	\N	{"robot_code": "ROB-REPLAN", "task_number": "TSK-PATH-03", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-REPLAN_3_1787143967.394982
192	2	\N	TASK_COMPLETED	TASKS_ALERT	Task Completed Alert	System event 'ROBOT_TASK_COMPLETED' processed successfully.	SUCCESS	DELIVERED	IN_APP	ROBOT	ROB-REPLAN	2026-08-19 18:22:47.394982	\N	2026-08-19 18:22:47.432351	\N	0	\N	{"robot_code": "ROB-REPLAN", "task_number": "TSK-PATH-03", "message": "System event 'ROBOT_TASK_COMPLETED' processed successfully."}	TASK_COMPLETED_ROB-REPLAN_2_1787143967.394982
203	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_admin_hardened logged in successfully.	INFO	DELIVERED	IN_APP	USER	5	2026-08-19 18:28:49.592062	\N	2026-08-19 18:28:49.609171	\N	0	\N	{"username": "test_admin_hardened", "message": "User test_admin_hardened logged in successfully."}	USER_LOGIN_5_1_1787144329.592062
204	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_admin_hardened logged in successfully.	INFO	DELIVERED	IN_APP	USER	5	2026-08-19 18:28:49.592062	\N	2026-08-19 18:28:49.643177	\N	0	\N	{"username": "test_admin_hardened", "message": "User test_admin_hardened logged in successfully."}	USER_LOGIN_5_2_1787144329.592062
205	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_admin_hardened logged in successfully.	INFO	DELIVERED	IN_APP	USER	5	2026-08-19 18:28:49.592062	\N	2026-08-19 18:28:49.649169	\N	0	\N	{"username": "test_admin_hardened", "message": "User test_admin_hardened logged in successfully."}	USER_LOGIN_5_5_1787144329.592062
206	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	2	2026-08-19 18:29:34.476972	\N	2026-08-19 18:29:34.481965	\N	0	\N	{"username": "test_admin", "message": "User test_admin logged in successfully."}	USER_LOGIN_2_5_1787144374.476972
208	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	2	2026-08-19 18:29:34.476972	\N	2026-08-19 18:29:34.493683	\N	0	\N	{"username": "test_admin", "message": "User test_admin logged in successfully."}	USER_LOGIN_2_1_1787144374.476972
207	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	2	2026-08-19 18:29:34.476972	\N	2026-08-19 18:29:34.487687	\N	0	\N	{"username": "test_admin", "message": "User test_admin logged in successfully."}	USER_LOGIN_2_2_1787144374.476972
115	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User notif_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	15	2026-08-19 18:21:33.938399	\N	2026-08-19 18:21:33.94487	\N	0	\N	{"username": "notif_admin", "message": "User notif_admin logged in successfully."}	USER_LOGIN_15_1_1787143893.938399
116	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User notif_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	15	2026-08-19 18:21:33.938399	\N	2026-08-19 18:21:33.949884	\N	0	\N	{"username": "notif_admin", "message": "User notif_admin logged in successfully."}	USER_LOGIN_15_5_1787143893.938399
117	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User notif_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	15	2026-08-19 18:21:33.938399	\N	2026-08-19 18:21:33.956873	\N	0	\N	{"username": "notif_admin", "message": "User notif_admin logged in successfully."}	USER_LOGIN_15_2_1787143893.938399
121	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_staff logged in successfully.	INFO	DELIVERED	IN_APP	USER	16	2026-08-19 18:21:38.804724	\N	2026-08-19 18:21:38.81972	\N	0	\N	{"username": "test_staff", "message": "User test_staff logged in successfully."}	USER_LOGIN_16_5_1787143898.804724
122	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_staff logged in successfully.	INFO	DELIVERED	IN_APP	USER	16	2026-08-19 18:21:38.804724	\N	2026-08-19 18:21:38.827721	\N	0	\N	{"username": "test_staff", "message": "User test_staff logged in successfully."}	USER_LOGIN_16_2_1787143898.804724
126	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_robots_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	17	2026-08-19 18:21:52.638552	\N	2026-08-19 18:21:52.654364	\N	0	\N	{"username": "test_robots_admin", "message": "User test_robots_admin logged in successfully."}	USER_LOGIN_17_1_1787143912.638552
127	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_robots_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	17	2026-08-19 18:21:52.638552	\N	2026-08-19 18:21:52.661628	\N	0	\N	{"username": "test_robots_admin", "message": "User test_robots_admin logged in successfully."}	USER_LOGIN_17_5_1787143912.638552
128	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_robots_admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	17	2026-08-19 18:21:52.638552	\N	2026-08-19 18:21:52.667633	\N	0	\N	{"username": "test_robots_admin", "message": "User test_robots_admin logged in successfully."}	USER_LOGIN_17_2_1787143912.638552
132	3	\N	ROBOT_FAILED	ROBOTS_ALERT	Robot Failed Alert	Robot ROB-FAIL failed in None. Action is required.	HIGH	DELIVERED	IN_APP	ROBOT	ROB-FAIL	2026-08-19 18:22:01.987214	\N	2026-08-19 18:22:02.002309	\N	0	\N	{"robot_code": "ROB-FAIL", "failure_count": 1, "message": "Robot ROB-FAIL failed in None. Action is required."}	ROBOT_FAILED_ROB-FAIL_3_1787143921.987214
133	1	\N	ROBOT_FAILED	ROBOTS_ALERT	Robot Failed Alert	Robot ROB-FAIL failed in None. Action is required.	HIGH	DELIVERED	IN_APP	ROBOT	ROB-FAIL	2026-08-19 18:22:01.987214	\N	2026-08-19 18:22:02.010008	\N	0	\N	{"robot_code": "ROB-FAIL", "failure_count": 1, "message": "Robot ROB-FAIL failed in None. Action is required."}	ROBOT_FAILED_ROB-FAIL_1_1787143921.987214
134	5	\N	ROBOT_FAILED	ROBOTS_ALERT	Robot Failed Alert	Robot ROB-FAIL failed in None. Action is required.	HIGH	DELIVERED	IN_APP	ROBOT	ROB-FAIL	2026-08-19 18:22:01.987214	\N	2026-08-19 18:22:02.017689	\N	0	\N	{"robot_code": "ROB-FAIL", "failure_count": 1, "message": "Robot ROB-FAIL failed in None. Action is required."}	ROBOT_FAILED_ROB-FAIL_5_1787143921.987214
135	2	\N	ROBOT_FAILED	ROBOTS_ALERT	Robot Failed Alert	Robot ROB-FAIL failed in None. Action is required.	HIGH	DELIVERED	IN_APP	ROBOT	ROB-FAIL	2026-08-19 18:22:01.987214	\N	2026-08-19 18:22:02.023493	\N	0	\N	{"robot_code": "ROB-FAIL", "failure_count": 1, "message": "Robot ROB-FAIL failed in None. Action is required."}	ROBOT_FAILED_ROB-FAIL_2_1787143921.987214
120	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User test_staff logged in successfully.	INFO	DELIVERED	IN_APP	USER	16	2026-08-19 18:21:38.804724	\N	2026-08-19 18:21:38.813734	\N	0	\N	{"username": "test_staff", "message": "User test_staff logged in successfully."}	USER_LOGIN_16_1_1787143898.804724
\.


--
-- Data for Name: order_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_events (id, order_id, "timestamp", status, event_type, operator, notes) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, order_id, item_id, requested_qty, reserved_qty, picked_qty, packed_qty, shipped_qty, status) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, customer_ref, warehouse_id, created_at, updated_at, status, priority, total_items, notes, created_by) FROM stdin;
\.


--
-- Data for Name: otp_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.otp_records (id, user_id, purpose, code_hash, expires_at, attempts, max_attempts, consumed_at, created_at, request_ip, context_data) FROM stdin;
1	1	ADMIN_CREATION	$2b$12$3xqRDMhLeoAerRIDkUlr5OzzABgRkrLPjfZCKGTPj3edBn/wUBsui	2026-08-19 17:04:52.461116	2	5	2026-08-19 16:55:59.972851	2026-08-19 16:54:52.461116	127.0.0.1	{"target_email": "harsha200797@gmail.com", "full_name": "harshavardhan", "target_role": "admin"}
2	2	PASSWORD_CHANGE	$2b$12$JxlKold6nS4f1Zi8DhtUl.JbN8T.p4wLdwsYv4oAFLlQR9i0tyG2W	2026-08-19 18:30:09.582648	2	5	2026-08-19 18:20:15.708313	2026-08-19 18:20:09.582648	testclient	{"new_password_hash": "$2b$12$6r11Vxdfp6ZAFSeRFIDIqezssLxtfn8KMuApYPmwW6UwYWNlrOZYO"}
4	5	ADMIN_CREATION	$2b$12$xKzg8JY59zwC24P3qe0PbeL2.stlUZYXh2u4rkIYG8TMmVUFrC/Oa	2026-08-19 18:32:29.709933	1	5	\N	2026-08-19 18:22:29.709933	testclient	{"target_email": "testadmin.security@gmail.com", "full_name": "Test Security Admin", "target_role": "admin"}
\.


--
-- Data for Name: packing_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.packing_records (id, order_id, status, started_at, completed_at, operator, package_count, weight_kg, notes) FROM stdin;
\.


--
-- Data for Name: recovery_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recovery_codes (id, user_id, code_hash, used, created_at, used_at) FROM stdin;
9	2	$2b$12$xDILEOIFx594SSxYV8GazOGUBQePfkbNwllEVI5YaSe32hUCxi4.W	f	2026-08-19 18:29:35.791531	\N
10	2	$2b$12$.RpxTCnzQqPM1iK4Y9QxfuwkZVMszWby3Ie1tXmASuwzBHAmz..xW	f	2026-08-19 18:29:36.179045	\N
11	2	$2b$12$jG5CakVSvbW97mUS8GshNO5T6dQ7WkGm4hByxbcK9Mgiz/V6pEkf.	f	2026-08-19 18:29:36.562902	\N
12	2	$2b$12$2r6HrR659Es9hrkhzb8A2O./7AbP9FGm5pjecgpKQscbLoQMwosiS	f	2026-08-19 18:29:36.965628	\N
13	2	$2b$12$Uc0h/l1JmW465kXpsR3Cw.tQRRPY442PjSoF/283h01oI5IkPQo2m	f	2026-08-19 18:29:37.351818	\N
14	2	$2b$12$8LJBvau3/qQf155j3Un5Ze6BX5QR1d5wXuigGk0cXWNWqyXpyxwJu	f	2026-08-19 18:29:37.737358	\N
15	2	$2b$12$WlYM/NtWgTIVblqdzb/LIuJVSTP5xld.BY00O.ieech0XzLJ.6I32	f	2026-08-19 18:29:38.123018	\N
16	2	$2b$12$v1kR7yvHdEFAHnhkng1jKuUVoiXUZEhrx7Gxe3a2edi9wSS41WQNO	f	2026-08-19 18:29:38.512569	\N
\.


--
-- Data for Name: recovery_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recovery_credentials (id, user_id, password_hash, created_at, updated_at) FROM stdin;
2	2	$2b$12$DWGst6uVMipY4RqlqKtq1OfdpQG5NvL66DEIgBq/RCc1WzbaM0vv6	2026-08-19 18:29:35.385238	2026-08-19 18:29:35.385238
\.


--
-- Data for Name: robot_reservations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robot_reservations (id, robot_id, warehouse_id, x, y, tick) FROM stdin;
\.


--
-- Data for Name: robot_routes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robot_routes (id, robot_id, task_id, warehouse_id, start_x, start_y, goal_x, goal_y, algorithm, path_data, distance, cost, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: robot_telemetry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robot_telemetry (id, robot_id, event_type, "timestamp", x, y, battery, status, task_id, metadata) FROM stdin;
\.


--
-- Data for Name: robots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robots (id, robot_code, name, warehouse_id, status, battery_level, current_location_id, current_x, current_y, target_location_id, target_x, target_y, assigned_task_id, total_tasks_completed, total_distance, total_operating_time, utilization_percent, failure_count, created_at, updated_at, last_heartbeat_at, robot_type, max_payload, max_speed, enabled, metadata) FROM stdin;
92	RB-BLR-01	Bangalore AGV 01	WH-BLR-01	CHARGING	100	WH-WH-BLR-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	AGV	200	1.5	t	{}
93	RB-BLR-02	Bangalore AGV 02	WH-BLR-01	CHARGING	100	WH-WH-BLR-01-CHARGING-2	12	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	AGV	200	1.5	t	{}
94	RB-BLR-03	Bangalore AGV 03	WH-BLR-01	IDLE	92.5	WH-WH-BLR-01-RECEIVING	1	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	AGV	200	1.5	t	{}
95	RB-CHN-01	Chennai AGV 01	WH-CHN-01	CHARGING	100	WH-WH-CHN-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	AGV	200	1.5	t	{}
96	RB-BOM-01	Mumbai AGV 01	WH-BOM-01	CHARGING	100	WH-WH-BOM-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	AGV	200	1.5	t	{}
97	RB-DEL-01	Delhi AGV 01	WH-DEL-01	CHARGING	100	WH-WH-DEL-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	AGV	200	1.5	t	{}
98	RB-CCU-01	Kolkata AGV 01	WH-CCU-01	CHARGING	100	WH-WH-CCU-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	2026-08-19 18:28:41.433607	AGV	200	1.5	t	{}
\.


--
-- Data for Name: scenarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scenarios (id, name, description, warehouse_id, scenario_type, configuration, random_seed, status, tags, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipments (id, order_id, status, tracking_reference, carrier, created_at, shipped_at, delivered_at) FROM stdin;
\.


--
-- Data for Name: shrinkage_flags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shrinkage_flags (id, date, warehouse_id, item_id, item_name, deviation_score, expected_quantity, actual_quantity, discrepancy_quantity, estimated_exposure, severity, likely_cause, explanation) FROM stdin;
21	2026-08-05	WH-BLR-01	ITM-GPU-01	Nvidia RTX 4080 Founders Edition	0.85	15	5	-10	950000	CRITICAL	UNUSUAL_OUTBOUND_ACTIVITY	Sudden unrecorded drop of 10 units (Valued at ₹9,50,000) occurred outside regular stock-out operations.
22	2026-07-25	WH-CHN-01	ITM-CPU-01	AMD Ryzen 9 7900X Processor	0.72	20	5	-15	570000	HIGH	POSSIBLE_DAMAGE_OR_WASTAGE	Discrepancy of 15 units (Valued at ₹5,70,000) reported at the dock. Unrecorded scraping suspected.
\.


--
-- Data for Name: simulation_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.simulation_events (id, simulation_id, warehouse_id, event_type, severity, sim_time_seconds, real_timestamp, robot_id, task_id, location_id, route_id, message, metadata) FROM stdin;
\.


--
-- Data for Name: simulation_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.simulation_snapshots (id, simulation_id, warehouse_id, snapshot_version, taken_at, sim_time_seconds, robot_states, task_states, obstacle_states, sim_inventory_delta, metadata) FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, date, warehouse_id, item_id, stock_in, stock_out, closing_stock, is_anomaly, anomaly_type, entry_source, entered_by) FROM stdin;
10716	2026-07-13	WH-BLR-01	ITM-CPU-01	0	2	43	f	none	simulated	system_sim
10717	2026-07-13	WH-BLR-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
10718	2026-07-13	WH-BLR-01	ITM-RAM-01	0	2	73	f	none	simulated	system_sim
10719	2026-07-13	WH-BLR-01	ITM-SSD-01	0	2	88	f	none	simulated	system_sim
10720	2026-07-13	WH-BLR-01	ITM-HDD-01	0	3	57	f	none	simulated	system_sim
10721	2026-07-13	WH-BLR-01	ITM-CHG-01	0	5	145	f	none	simulated	system_sim
10722	2026-07-13	WH-BLR-01	ITM-CBL-01	0	3	297	f	none	simulated	system_sim
10723	2026-07-13	WH-CHN-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
10724	2026-07-13	WH-CHN-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
10725	2026-07-13	WH-CHN-01	ITM-RAM-01	0	4	71	f	none	simulated	system_sim
10726	2026-07-13	WH-CHN-01	ITM-SSD-01	0	0	90	f	none	simulated	system_sim
10727	2026-07-13	WH-CHN-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
10728	2026-07-13	WH-CHN-01	ITM-CHG-01	0	7	143	f	none	simulated	system_sim
10729	2026-07-13	WH-CHN-01	ITM-CBL-01	0	8	292	f	none	simulated	system_sim
10730	2026-07-13	WH-BOM-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
10731	2026-07-13	WH-BOM-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
10732	2026-07-13	WH-BOM-01	ITM-RAM-01	0	5	70	f	none	simulated	system_sim
10733	2026-07-13	WH-BOM-01	ITM-SSD-01	0	1	89	f	none	simulated	system_sim
10734	2026-07-13	WH-BOM-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
10735	2026-07-13	WH-BOM-01	ITM-CHG-01	0	7	143	f	none	simulated	system_sim
10736	2026-07-13	WH-BOM-01	ITM-CBL-01	0	7	293	f	none	simulated	system_sim
10737	2026-07-13	WH-DEL-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
10738	2026-07-13	WH-DEL-01	ITM-GPU-01	0	2	28	f	none	simulated	system_sim
10739	2026-07-13	WH-DEL-01	ITM-RAM-01	0	3	72	f	none	simulated	system_sim
10740	2026-07-13	WH-DEL-01	ITM-SSD-01	0	2	88	f	none	simulated	system_sim
10741	2026-07-13	WH-DEL-01	ITM-HDD-01	0	2	58	f	none	simulated	system_sim
10742	2026-07-13	WH-DEL-01	ITM-CHG-01	0	8	142	f	none	simulated	system_sim
10743	2026-07-13	WH-DEL-01	ITM-CBL-01	0	9	291	f	none	simulated	system_sim
10744	2026-07-13	WH-CCU-01	ITM-CPU-01	0	1	44	f	none	simulated	system_sim
10745	2026-07-13	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
10746	2026-07-13	WH-CCU-01	ITM-RAM-01	0	6	69	f	none	simulated	system_sim
10747	2026-07-13	WH-CCU-01	ITM-SSD-01	0	1	89	f	none	simulated	system_sim
10748	2026-07-13	WH-CCU-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
10749	2026-07-13	WH-CCU-01	ITM-CHG-01	0	7	143	f	none	simulated	system_sim
10750	2026-07-13	WH-CCU-01	ITM-CBL-01	0	4	296	f	none	simulated	system_sim
10751	2026-07-14	WH-BLR-01	ITM-CPU-01	0	3	40	f	none	simulated	system_sim
10752	2026-07-14	WH-BLR-01	ITM-GPU-01	0	1	28	f	none	simulated	system_sim
10753	2026-07-14	WH-BLR-01	ITM-RAM-01	0	1	72	f	none	simulated	system_sim
10754	2026-07-14	WH-BLR-01	ITM-SSD-01	0	1	87	f	none	simulated	system_sim
10755	2026-07-14	WH-BLR-01	ITM-HDD-01	0	0	57	f	none	simulated	system_sim
10756	2026-07-14	WH-BLR-01	ITM-CHG-01	0	1	144	f	none	simulated	system_sim
10757	2026-07-14	WH-BLR-01	ITM-CBL-01	0	10	287	f	none	simulated	system_sim
10758	2026-07-14	WH-CHN-01	ITM-CPU-01	0	2	43	f	none	simulated	system_sim
10759	2026-07-14	WH-CHN-01	ITM-GPU-01	0	2	28	f	none	simulated	system_sim
10760	2026-07-14	WH-CHN-01	ITM-RAM-01	0	8	63	f	none	simulated	system_sim
10761	2026-07-14	WH-CHN-01	ITM-SSD-01	0	1	89	f	none	simulated	system_sim
10762	2026-07-14	WH-CHN-01	ITM-HDD-01	0	3	57	f	none	simulated	system_sim
10763	2026-07-14	WH-CHN-01	ITM-CHG-01	0	4	139	f	none	simulated	system_sim
10764	2026-07-14	WH-CHN-01	ITM-CBL-01	0	10	282	f	none	simulated	system_sim
10765	2026-07-14	WH-BOM-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
10766	2026-07-14	WH-BOM-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
10767	2026-07-14	WH-BOM-01	ITM-RAM-01	0	9	61	f	none	simulated	system_sim
10768	2026-07-14	WH-BOM-01	ITM-SSD-01	0	0	89	f	none	simulated	system_sim
10769	2026-07-14	WH-BOM-01	ITM-HDD-01	0	3	57	f	none	simulated	system_sim
10770	2026-07-14	WH-BOM-01	ITM-CHG-01	0	3	140	f	none	simulated	system_sim
10771	2026-07-14	WH-BOM-01	ITM-CBL-01	0	8	285	f	none	simulated	system_sim
10772	2026-07-14	WH-DEL-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
10773	2026-07-14	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
10774	2026-07-14	WH-DEL-01	ITM-RAM-01	0	3	69	f	none	simulated	system_sim
10775	2026-07-14	WH-DEL-01	ITM-SSD-01	0	3	85	f	none	simulated	system_sim
10776	2026-07-14	WH-DEL-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
10777	2026-07-14	WH-DEL-01	ITM-CHG-01	0	6	136	f	none	simulated	system_sim
10778	2026-07-14	WH-DEL-01	ITM-CBL-01	0	10	281	f	none	simulated	system_sim
10779	2026-07-14	WH-CCU-01	ITM-CPU-01	0	2	42	f	none	simulated	system_sim
10780	2026-07-14	WH-CCU-01	ITM-GPU-01	0	2	28	f	none	simulated	system_sim
10781	2026-07-14	WH-CCU-01	ITM-RAM-01	0	1	68	f	none	simulated	system_sim
10782	2026-07-14	WH-CCU-01	ITM-SSD-01	0	0	89	f	none	simulated	system_sim
10783	2026-07-14	WH-CCU-01	ITM-HDD-01	0	1	59	f	none	simulated	system_sim
10784	2026-07-14	WH-CCU-01	ITM-CHG-01	0	9	134	f	none	simulated	system_sim
10785	2026-07-14	WH-CCU-01	ITM-CBL-01	0	9	287	f	none	simulated	system_sim
10786	2026-07-15	WH-BLR-01	ITM-CPU-01	0	1	39	f	none	simulated	system_sim
10787	2026-07-15	WH-BLR-01	ITM-GPU-01	0	2	26	f	none	simulated	system_sim
10788	2026-07-15	WH-BLR-01	ITM-RAM-01	0	6	66	f	none	simulated	system_sim
10789	2026-07-15	WH-BLR-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
10790	2026-07-15	WH-BLR-01	ITM-HDD-01	0	1	56	f	none	simulated	system_sim
10791	2026-07-15	WH-BLR-01	ITM-CHG-01	0	6	138	f	none	simulated	system_sim
10792	2026-07-15	WH-BLR-01	ITM-CBL-01	0	2	285	f	none	simulated	system_sim
10793	2026-07-15	WH-CHN-01	ITM-CPU-01	0	3	40	f	none	simulated	system_sim
10794	2026-07-15	WH-CHN-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
10795	2026-07-15	WH-CHN-01	ITM-RAM-01	0	8	55	f	none	simulated	system_sim
10796	2026-07-15	WH-CHN-01	ITM-SSD-01	0	3	86	f	none	simulated	system_sim
10797	2026-07-15	WH-CHN-01	ITM-HDD-01	0	1	56	f	none	simulated	system_sim
10798	2026-07-15	WH-CHN-01	ITM-CHG-01	0	10	129	f	none	simulated	system_sim
10799	2026-07-15	WH-CHN-01	ITM-CBL-01	0	8	274	f	none	simulated	system_sim
10800	2026-07-15	WH-BOM-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
10801	2026-07-15	WH-BOM-01	ITM-GPU-01	0	1	28	f	none	simulated	system_sim
10802	2026-07-15	WH-BOM-01	ITM-RAM-01	0	3	58	f	none	simulated	system_sim
10803	2026-07-15	WH-BOM-01	ITM-SSD-01	0	0	89	f	none	simulated	system_sim
10804	2026-07-15	WH-BOM-01	ITM-HDD-01	0	1	56	f	none	simulated	system_sim
10805	2026-07-15	WH-BOM-01	ITM-CHG-01	0	1	139	f	none	simulated	system_sim
10806	2026-07-15	WH-BOM-01	ITM-CBL-01	0	5	280	f	none	simulated	system_sim
10807	2026-07-15	WH-DEL-01	ITM-CPU-01	0	2	40	f	none	simulated	system_sim
10808	2026-07-15	WH-DEL-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
10809	2026-07-15	WH-DEL-01	ITM-RAM-01	0	7	62	f	none	simulated	system_sim
10810	2026-07-15	WH-DEL-01	ITM-SSD-01	0	2	83	f	none	simulated	system_sim
10811	2026-07-15	WH-DEL-01	ITM-HDD-01	0	3	55	f	none	simulated	system_sim
10812	2026-07-15	WH-DEL-01	ITM-CHG-01	0	5	131	f	none	simulated	system_sim
10813	2026-07-15	WH-DEL-01	ITM-CBL-01	0	10	271	f	none	simulated	system_sim
10814	2026-07-15	WH-CCU-01	ITM-CPU-01	0	2	40	f	none	simulated	system_sim
10815	2026-07-15	WH-CCU-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
10816	2026-07-15	WH-CCU-01	ITM-RAM-01	0	8	60	f	none	simulated	system_sim
10817	2026-07-15	WH-CCU-01	ITM-SSD-01	0	2	87	f	none	simulated	system_sim
10818	2026-07-15	WH-CCU-01	ITM-HDD-01	0	0	59	f	none	simulated	system_sim
10819	2026-07-15	WH-CCU-01	ITM-CHG-01	0	8	126	f	none	simulated	system_sim
10820	2026-07-15	WH-CCU-01	ITM-CBL-01	0	7	280	f	none	simulated	system_sim
10821	2026-07-16	WH-BLR-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
10822	2026-07-16	WH-BLR-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
10823	2026-07-16	WH-BLR-01	ITM-RAM-01	0	6	60	f	none	simulated	system_sim
10824	2026-07-16	WH-BLR-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
10825	2026-07-16	WH-BLR-01	ITM-HDD-01	0	1	55	f	none	simulated	system_sim
10826	2026-07-16	WH-BLR-01	ITM-CHG-01	0	6	132	f	none	simulated	system_sim
10827	2026-07-16	WH-BLR-01	ITM-CBL-01	0	3	282	f	none	simulated	system_sim
10828	2026-07-16	WH-CHN-01	ITM-CPU-01	0	3	37	f	none	simulated	system_sim
10829	2026-07-16	WH-CHN-01	ITM-GPU-01	0	2	26	f	none	simulated	system_sim
10830	2026-07-16	WH-CHN-01	ITM-RAM-01	0	10	45	f	none	simulated	system_sim
10831	2026-07-16	WH-CHN-01	ITM-SSD-01	0	0	86	f	none	simulated	system_sim
10832	2026-07-16	WH-CHN-01	ITM-HDD-01	0	0	56	f	none	simulated	system_sim
10833	2026-07-16	WH-CHN-01	ITM-CHG-01	0	9	120	f	none	simulated	system_sim
10834	2026-07-16	WH-CHN-01	ITM-CBL-01	0	8	266	f	none	simulated	system_sim
10835	2026-07-16	WH-BOM-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
10836	2026-07-16	WH-BOM-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
10837	2026-07-16	WH-BOM-01	ITM-RAM-01	0	1	57	f	none	simulated	system_sim
10838	2026-07-16	WH-BOM-01	ITM-SSD-01	0	2	87	f	none	simulated	system_sim
10839	2026-07-16	WH-BOM-01	ITM-HDD-01	0	0	56	f	none	simulated	system_sim
10840	2026-07-16	WH-BOM-01	ITM-CHG-01	0	4	135	f	none	simulated	system_sim
10841	2026-07-16	WH-BOM-01	ITM-CBL-01	0	3	277	f	none	simulated	system_sim
10842	2026-07-16	WH-DEL-01	ITM-CPU-01	0	0	40	f	none	simulated	system_sim
10843	2026-07-16	WH-DEL-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
10844	2026-07-16	WH-DEL-01	ITM-RAM-01	0	7	55	f	none	simulated	system_sim
10845	2026-07-16	WH-DEL-01	ITM-SSD-01	0	2	81	f	none	simulated	system_sim
10846	2026-07-16	WH-DEL-01	ITM-HDD-01	0	0	55	f	none	simulated	system_sim
10847	2026-07-16	WH-DEL-01	ITM-CHG-01	0	4	127	f	none	simulated	system_sim
10848	2026-07-16	WH-DEL-01	ITM-CBL-01	0	2	269	f	none	simulated	system_sim
10849	2026-07-16	WH-CCU-01	ITM-CPU-01	0	1	39	f	none	simulated	system_sim
10850	2026-07-16	WH-CCU-01	ITM-GPU-01	0	2	26	f	none	simulated	system_sim
10851	2026-07-16	WH-CCU-01	ITM-RAM-01	0	3	57	f	none	simulated	system_sim
10852	2026-07-16	WH-CCU-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
10853	2026-07-16	WH-CCU-01	ITM-HDD-01	0	0	59	f	none	simulated	system_sim
10854	2026-07-16	WH-CCU-01	ITM-CHG-01	0	3	123	f	none	simulated	system_sim
10855	2026-07-16	WH-CCU-01	ITM-CBL-01	0	4	276	f	none	simulated	system_sim
10856	2026-07-17	WH-BLR-01	ITM-CPU-01	0	1	38	f	none	simulated	system_sim
10857	2026-07-17	WH-BLR-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
10858	2026-07-17	WH-BLR-01	ITM-RAM-01	0	8	52	f	none	simulated	system_sim
10859	2026-07-17	WH-BLR-01	ITM-SSD-01	0	3	84	f	none	simulated	system_sim
10860	2026-07-17	WH-BLR-01	ITM-HDD-01	0	3	52	f	none	simulated	system_sim
10861	2026-07-17	WH-BLR-01	ITM-CHG-01	0	1	131	f	none	simulated	system_sim
10862	2026-07-17	WH-BLR-01	ITM-CBL-01	0	5	277	f	none	simulated	system_sim
10863	2026-07-17	WH-CHN-01	ITM-CPU-01	0	0	37	f	none	simulated	system_sim
10864	2026-07-17	WH-CHN-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
10865	2026-07-17	WH-CHN-01	ITM-RAM-01	0	5	40	f	none	simulated	system_sim
10866	2026-07-17	WH-CHN-01	ITM-SSD-01	0	1	85	f	none	simulated	system_sim
10867	2026-07-17	WH-CHN-01	ITM-HDD-01	0	3	53	f	none	simulated	system_sim
10868	2026-07-17	WH-CHN-01	ITM-CHG-01	0	5	115	f	none	simulated	system_sim
10869	2026-07-17	WH-CHN-01	ITM-CBL-01	0	2	264	f	none	simulated	system_sim
10870	2026-07-17	WH-BOM-01	ITM-CPU-01	0	1	41	f	none	simulated	system_sim
10871	2026-07-17	WH-BOM-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
10872	2026-07-17	WH-BOM-01	ITM-RAM-01	0	2	55	f	none	simulated	system_sim
10873	2026-07-17	WH-BOM-01	ITM-SSD-01	0	2	85	f	none	simulated	system_sim
10874	2026-07-17	WH-BOM-01	ITM-HDD-01	0	3	53	f	none	simulated	system_sim
10875	2026-07-17	WH-BOM-01	ITM-CHG-01	0	3	132	f	none	simulated	system_sim
10876	2026-07-17	WH-BOM-01	ITM-CBL-01	0	5	272	f	none	simulated	system_sim
10877	2026-07-17	WH-DEL-01	ITM-CPU-01	0	3	37	f	none	simulated	system_sim
10878	2026-07-17	WH-DEL-01	ITM-GPU-01	0	1	26	f	none	simulated	system_sim
10879	2026-07-17	WH-DEL-01	ITM-RAM-01	0	8	47	f	none	simulated	system_sim
10880	2026-07-17	WH-DEL-01	ITM-SSD-01	0	2	79	f	none	simulated	system_sim
10881	2026-07-17	WH-DEL-01	ITM-HDD-01	0	2	53	f	none	simulated	system_sim
10882	2026-07-17	WH-DEL-01	ITM-CHG-01	0	8	119	f	none	simulated	system_sim
10883	2026-07-17	WH-DEL-01	ITM-CBL-01	0	1	268	f	none	simulated	system_sim
10884	2026-07-17	WH-CCU-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
10885	2026-07-17	WH-CCU-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
10886	2026-07-17	WH-CCU-01	ITM-RAM-01	0	10	47	f	none	simulated	system_sim
10887	2026-07-17	WH-CCU-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
10888	2026-07-17	WH-CCU-01	ITM-HDD-01	0	3	56	f	none	simulated	system_sim
10889	2026-07-17	WH-CCU-01	ITM-CHG-01	0	7	116	f	none	simulated	system_sim
10890	2026-07-17	WH-CCU-01	ITM-CBL-01	0	3	273	f	none	simulated	system_sim
10891	2026-07-18	WH-BLR-01	ITM-CPU-01	0	1	37	f	none	simulated	system_sim
10892	2026-07-18	WH-BLR-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
10893	2026-07-18	WH-BLR-01	ITM-RAM-01	0	1	51	f	none	simulated	system_sim
10894	2026-07-18	WH-BLR-01	ITM-SSD-01	0	1	83	f	none	simulated	system_sim
10895	2026-07-18	WH-BLR-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
10896	2026-07-18	WH-BLR-01	ITM-CHG-01	0	7	124	f	none	simulated	system_sim
10897	2026-07-18	WH-BLR-01	ITM-CBL-01	0	4	273	f	none	simulated	system_sim
10898	2026-07-18	WH-CHN-01	ITM-CPU-01	0	3	34	f	none	simulated	system_sim
10899	2026-07-18	WH-CHN-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
10900	2026-07-18	WH-CHN-01	ITM-RAM-01	0	8	32	f	none	simulated	system_sim
10901	2026-07-18	WH-CHN-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
10902	2026-07-18	WH-CHN-01	ITM-HDD-01	0	1	52	f	none	simulated	system_sim
10903	2026-07-18	WH-CHN-01	ITM-CHG-01	0	8	107	f	none	simulated	system_sim
10904	2026-07-18	WH-CHN-01	ITM-CBL-01	0	2	262	f	none	simulated	system_sim
10905	2026-07-18	WH-BOM-01	ITM-CPU-01	0	1	40	f	none	simulated	system_sim
10906	2026-07-18	WH-BOM-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
10907	2026-07-18	WH-BOM-01	ITM-RAM-01	0	10	45	f	none	simulated	system_sim
10908	2026-07-18	WH-BOM-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
10909	2026-07-18	WH-BOM-01	ITM-HDD-01	0	0	53	f	none	simulated	system_sim
10910	2026-07-18	WH-BOM-01	ITM-CHG-01	0	10	122	f	none	simulated	system_sim
10911	2026-07-18	WH-BOM-01	ITM-CBL-01	0	1	271	f	none	simulated	system_sim
10912	2026-07-18	WH-DEL-01	ITM-CPU-01	0	0	37	f	none	simulated	system_sim
10913	2026-07-18	WH-DEL-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
10914	2026-07-18	WH-DEL-01	ITM-RAM-01	0	1	46	f	none	simulated	system_sim
10915	2026-07-18	WH-DEL-01	ITM-SSD-01	0	0	79	f	none	simulated	system_sim
10916	2026-07-18	WH-DEL-01	ITM-HDD-01	0	1	52	f	none	simulated	system_sim
10917	2026-07-18	WH-DEL-01	ITM-CHG-01	0	6	113	f	none	simulated	system_sim
10918	2026-07-18	WH-DEL-01	ITM-CBL-01	0	9	259	f	none	simulated	system_sim
10919	2026-07-18	WH-CCU-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
10920	2026-07-18	WH-CCU-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
10921	2026-07-18	WH-CCU-01	ITM-RAM-01	0	10	37	f	none	simulated	system_sim
10922	2026-07-18	WH-CCU-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
10923	2026-07-18	WH-CCU-01	ITM-HDD-01	0	0	56	f	none	simulated	system_sim
10924	2026-07-18	WH-CCU-01	ITM-CHG-01	0	5	111	f	none	simulated	system_sim
10925	2026-07-18	WH-CCU-01	ITM-CBL-01	0	8	265	f	none	simulated	system_sim
10926	2026-07-19	WH-BLR-01	ITM-CPU-01	0	1	36	f	none	simulated	system_sim
10927	2026-07-19	WH-BLR-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
10928	2026-07-19	WH-BLR-01	ITM-RAM-01	0	4	47	f	none	simulated	system_sim
10929	2026-07-19	WH-BLR-01	ITM-SSD-01	0	2	81	f	none	simulated	system_sim
10930	2026-07-19	WH-BLR-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
10931	2026-07-19	WH-BLR-01	ITM-CHG-01	0	7	117	f	none	simulated	system_sim
10932	2026-07-19	WH-BLR-01	ITM-CBL-01	0	4	269	f	none	simulated	system_sim
10933	2026-07-19	WH-CHN-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
10934	2026-07-19	WH-CHN-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
10935	2026-07-19	WH-CHN-01	ITM-RAM-01	75	5	102	f	none	simulated	system_sim
10936	2026-07-19	WH-CHN-01	ITM-SSD-01	0	2	83	f	none	simulated	system_sim
10937	2026-07-19	WH-CHN-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
10938	2026-07-19	WH-CHN-01	ITM-CHG-01	0	8	99	f	none	simulated	system_sim
10939	2026-07-19	WH-CHN-01	ITM-CBL-01	0	4	258	f	none	simulated	system_sim
10940	2026-07-19	WH-BOM-01	ITM-CPU-01	0	3	37	f	none	simulated	system_sim
10941	2026-07-19	WH-BOM-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
10942	2026-07-19	WH-BOM-01	ITM-RAM-01	0	2	43	f	none	simulated	system_sim
10943	2026-07-19	WH-BOM-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
10944	2026-07-19	WH-BOM-01	ITM-HDD-01	0	1	52	f	none	simulated	system_sim
10945	2026-07-19	WH-BOM-01	ITM-CHG-01	0	6	116	f	none	simulated	system_sim
10946	2026-07-19	WH-BOM-01	ITM-CBL-01	0	9	262	f	none	simulated	system_sim
10947	2026-07-19	WH-DEL-01	ITM-CPU-01	0	1	36	f	none	simulated	system_sim
10948	2026-07-19	WH-DEL-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
10949	2026-07-19	WH-DEL-01	ITM-RAM-01	0	10	36	f	none	simulated	system_sim
10950	2026-07-19	WH-DEL-01	ITM-SSD-01	0	1	78	f	none	simulated	system_sim
10951	2026-07-19	WH-DEL-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
10952	2026-07-19	WH-DEL-01	ITM-CHG-01	0	8	105	f	none	simulated	system_sim
10953	2026-07-19	WH-DEL-01	ITM-CBL-01	0	2	257	f	none	simulated	system_sim
10954	2026-07-19	WH-CCU-01	ITM-CPU-01	0	3	36	f	none	simulated	system_sim
10955	2026-07-19	WH-CCU-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
10956	2026-07-19	WH-CCU-01	ITM-RAM-01	75	9	103	f	none	simulated	system_sim
10957	2026-07-19	WH-CCU-01	ITM-SSD-01	0	1	86	f	none	simulated	system_sim
10958	2026-07-19	WH-CCU-01	ITM-HDD-01	0	0	56	f	none	simulated	system_sim
10959	2026-07-19	WH-CCU-01	ITM-CHG-01	0	1	110	f	none	simulated	system_sim
10960	2026-07-19	WH-CCU-01	ITM-CBL-01	0	7	258	f	none	simulated	system_sim
10961	2026-07-20	WH-BLR-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
10962	2026-07-20	WH-BLR-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
10963	2026-07-20	WH-BLR-01	ITM-RAM-01	0	9	38	f	none	simulated	system_sim
10964	2026-07-20	WH-BLR-01	ITM-SSD-01	0	3	78	f	none	simulated	system_sim
10965	2026-07-20	WH-BLR-01	ITM-HDD-01	0	2	50	f	none	simulated	system_sim
10966	2026-07-20	WH-BLR-01	ITM-CHG-01	0	6	111	f	none	simulated	system_sim
10967	2026-07-20	WH-BLR-01	ITM-CBL-01	0	4	265	f	none	simulated	system_sim
10968	2026-07-20	WH-CHN-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
10969	2026-07-20	WH-CHN-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
10970	2026-07-20	WH-CHN-01	ITM-RAM-01	0	2	100	f	none	simulated	system_sim
10971	2026-07-20	WH-CHN-01	ITM-SSD-01	0	2	81	f	none	simulated	system_sim
10972	2026-07-20	WH-CHN-01	ITM-HDD-01	0	3	49	f	none	simulated	system_sim
10973	2026-07-20	WH-CHN-01	ITM-CHG-01	0	3	96	f	none	simulated	system_sim
10974	2026-07-20	WH-CHN-01	ITM-CBL-01	0	4	254	f	none	simulated	system_sim
10975	2026-07-20	WH-BOM-01	ITM-CPU-01	0	1	36	f	none	simulated	system_sim
10976	2026-07-20	WH-BOM-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
10977	2026-07-20	WH-BOM-01	ITM-RAM-01	0	9	34	f	none	simulated	system_sim
10978	2026-07-20	WH-BOM-01	ITM-SSD-01	0	2	83	f	none	simulated	system_sim
10979	2026-07-20	WH-BOM-01	ITM-HDD-01	0	2	50	f	none	simulated	system_sim
10980	2026-07-20	WH-BOM-01	ITM-CHG-01	0	7	109	f	none	simulated	system_sim
10981	2026-07-20	WH-BOM-01	ITM-CBL-01	0	1	261	f	none	simulated	system_sim
10982	2026-07-20	WH-DEL-01	ITM-CPU-01	0	3	33	f	none	simulated	system_sim
10983	2026-07-20	WH-DEL-01	ITM-GPU-01	0	2	24	f	none	simulated	system_sim
10984	2026-07-20	WH-DEL-01	ITM-RAM-01	75	9	102	f	none	simulated	system_sim
10985	2026-07-20	WH-DEL-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
10986	2026-07-20	WH-DEL-01	ITM-HDD-01	0	3	49	f	none	simulated	system_sim
10987	2026-07-20	WH-DEL-01	ITM-CHG-01	0	2	103	f	none	simulated	system_sim
10988	2026-07-20	WH-DEL-01	ITM-CBL-01	0	1	256	f	none	simulated	system_sim
10989	2026-07-20	WH-CCU-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
10990	2026-07-20	WH-CCU-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
10991	2026-07-20	WH-CCU-01	ITM-RAM-01	0	1	102	f	none	simulated	system_sim
10992	2026-07-20	WH-CCU-01	ITM-SSD-01	0	0	86	f	none	simulated	system_sim
10993	2026-07-20	WH-CCU-01	ITM-HDD-01	0	0	56	f	none	simulated	system_sim
10994	2026-07-20	WH-CCU-01	ITM-CHG-01	0	8	102	f	none	simulated	system_sim
10995	2026-07-20	WH-CCU-01	ITM-CBL-01	0	4	254	f	none	simulated	system_sim
10996	2026-07-21	WH-BLR-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
10997	2026-07-21	WH-BLR-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
10998	2026-07-21	WH-BLR-01	ITM-RAM-01	0	10	28	f	none	simulated	system_sim
10999	2026-07-21	WH-BLR-01	ITM-SSD-01	0	3	75	f	none	simulated	system_sim
11000	2026-07-21	WH-BLR-01	ITM-HDD-01	0	2	48	f	none	simulated	system_sim
11001	2026-07-21	WH-BLR-01	ITM-CHG-01	0	3	108	f	none	simulated	system_sim
11002	2026-07-21	WH-BLR-01	ITM-CBL-01	0	4	261	f	none	simulated	system_sim
11003	2026-07-21	WH-CHN-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
11004	2026-07-21	WH-CHN-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
11005	2026-07-21	WH-CHN-01	ITM-RAM-01	0	4	96	f	none	simulated	system_sim
11006	2026-07-21	WH-CHN-01	ITM-SSD-01	0	0	81	f	none	simulated	system_sim
11007	2026-07-21	WH-CHN-01	ITM-HDD-01	0	2	47	f	none	simulated	system_sim
11008	2026-07-21	WH-CHN-01	ITM-CHG-01	0	9	87	f	none	simulated	system_sim
11009	2026-07-21	WH-CHN-01	ITM-CBL-01	0	10	244	f	none	simulated	system_sim
11010	2026-07-21	WH-BOM-01	ITM-CPU-01	0	2	34	f	none	simulated	system_sim
11011	2026-07-21	WH-BOM-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
11012	2026-07-21	WH-BOM-01	ITM-RAM-01	75	5	104	f	none	simulated	system_sim
11013	2026-07-21	WH-BOM-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
11014	2026-07-21	WH-BOM-01	ITM-HDD-01	0	3	47	f	none	simulated	system_sim
11015	2026-07-21	WH-BOM-01	ITM-CHG-01	0	9	100	f	none	simulated	system_sim
11016	2026-07-21	WH-BOM-01	ITM-CBL-01	0	6	255	f	none	simulated	system_sim
11017	2026-07-21	WH-DEL-01	ITM-CPU-01	0	1	32	f	none	simulated	system_sim
11018	2026-07-21	WH-DEL-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
11019	2026-07-21	WH-DEL-01	ITM-RAM-01	0	1	101	f	none	simulated	system_sim
11020	2026-07-21	WH-DEL-01	ITM-SSD-01	0	1	77	f	none	simulated	system_sim
11021	2026-07-21	WH-DEL-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
11022	2026-07-21	WH-DEL-01	ITM-CHG-01	0	7	96	f	none	simulated	system_sim
11023	2026-07-21	WH-DEL-01	ITM-CBL-01	0	10	246	f	none	simulated	system_sim
11024	2026-07-21	WH-CCU-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
11025	2026-07-21	WH-CCU-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
11026	2026-07-21	WH-CCU-01	ITM-RAM-01	0	2	100	f	none	simulated	system_sim
11027	2026-07-21	WH-CCU-01	ITM-SSD-01	0	1	85	f	none	simulated	system_sim
11028	2026-07-21	WH-CCU-01	ITM-HDD-01	0	3	53	f	none	simulated	system_sim
11029	2026-07-21	WH-CCU-01	ITM-CHG-01	0	7	95	f	none	simulated	system_sim
11030	2026-07-21	WH-CCU-01	ITM-CBL-01	0	1	253	f	none	simulated	system_sim
11031	2026-07-22	WH-BLR-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
11032	2026-07-22	WH-BLR-01	ITM-GPU-01	0	2	21	f	none	simulated	system_sim
11033	2026-07-22	WH-BLR-01	ITM-RAM-01	75	8	95	f	none	simulated	system_sim
11034	2026-07-22	WH-BLR-01	ITM-SSD-01	0	0	75	f	none	simulated	system_sim
11035	2026-07-22	WH-BLR-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
11036	2026-07-22	WH-BLR-01	ITM-CHG-01	0	10	98	f	none	simulated	system_sim
11037	2026-07-22	WH-BLR-01	ITM-CBL-01	0	7	254	f	none	simulated	system_sim
11038	2026-07-22	WH-CHN-01	ITM-CPU-01	0	1	33	f	none	simulated	system_sim
11039	2026-07-22	WH-CHN-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
11040	2026-07-22	WH-CHN-01	ITM-RAM-01	0	1	95	f	none	simulated	system_sim
11041	2026-07-22	WH-CHN-01	ITM-SSD-01	0	3	78	f	none	simulated	system_sim
11042	2026-07-22	WH-CHN-01	ITM-HDD-01	0	2	45	f	none	simulated	system_sim
11043	2026-07-22	WH-CHN-01	ITM-CHG-01	0	10	77	f	none	simulated	system_sim
11044	2026-07-22	WH-CHN-01	ITM-CBL-01	0	9	235	f	none	simulated	system_sim
11045	2026-07-22	WH-BOM-01	ITM-CPU-01	0	2	32	f	none	simulated	system_sim
11046	2026-07-22	WH-BOM-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
11047	2026-07-22	WH-BOM-01	ITM-RAM-01	0	6	98	f	none	simulated	system_sim
11048	2026-07-22	WH-BOM-01	ITM-SSD-01	0	2	81	f	none	simulated	system_sim
11049	2026-07-22	WH-BOM-01	ITM-HDD-01	0	3	44	f	none	simulated	system_sim
11050	2026-07-22	WH-BOM-01	ITM-CHG-01	0	9	91	f	none	simulated	system_sim
11051	2026-07-22	WH-BOM-01	ITM-CBL-01	0	1	254	f	none	simulated	system_sim
11052	2026-07-22	WH-DEL-01	ITM-CPU-01	0	2	30	f	none	simulated	system_sim
11053	2026-07-22	WH-DEL-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
11054	2026-07-22	WH-DEL-01	ITM-RAM-01	0	10	91	f	none	simulated	system_sim
11055	2026-07-22	WH-DEL-01	ITM-SSD-01	0	2	75	f	none	simulated	system_sim
11056	2026-07-22	WH-DEL-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
11057	2026-07-22	WH-DEL-01	ITM-CHG-01	0	1	95	f	none	simulated	system_sim
11058	2026-07-22	WH-DEL-01	ITM-CBL-01	0	2	244	f	none	simulated	system_sim
11059	2026-07-22	WH-CCU-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
11060	2026-07-22	WH-CCU-01	ITM-GPU-01	0	1	22	f	none	simulated	system_sim
11061	2026-07-22	WH-CCU-01	ITM-RAM-01	0	7	93	f	none	simulated	system_sim
11062	2026-07-22	WH-CCU-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
11063	2026-07-22	WH-CCU-01	ITM-HDD-01	0	0	53	f	none	simulated	system_sim
11064	2026-07-22	WH-CCU-01	ITM-CHG-01	0	1	94	f	none	simulated	system_sim
11065	2026-07-22	WH-CCU-01	ITM-CBL-01	0	8	245	f	none	simulated	system_sim
11066	2026-07-23	WH-BLR-01	ITM-CPU-01	0	1	35	f	none	simulated	system_sim
11067	2026-07-23	WH-BLR-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
11068	2026-07-23	WH-BLR-01	ITM-RAM-01	0	1	94	f	none	simulated	system_sim
11069	2026-07-23	WH-BLR-01	ITM-SSD-01	0	3	72	f	none	simulated	system_sim
11070	2026-07-23	WH-BLR-01	ITM-HDD-01	0	3	45	f	none	simulated	system_sim
11071	2026-07-23	WH-BLR-01	ITM-CHG-01	0	8	90	f	none	simulated	system_sim
11072	2026-07-23	WH-BLR-01	ITM-CBL-01	0	10	244	f	none	simulated	system_sim
11073	2026-07-23	WH-CHN-01	ITM-CPU-01	0	3	30	f	none	simulated	system_sim
11074	2026-07-23	WH-CHN-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
11075	2026-07-23	WH-CHN-01	ITM-RAM-01	0	4	91	f	none	simulated	system_sim
11076	2026-07-23	WH-CHN-01	ITM-SSD-01	0	3	75	f	none	simulated	system_sim
11077	2026-07-23	WH-CHN-01	ITM-HDD-01	0	0	45	f	none	simulated	system_sim
11078	2026-07-23	WH-CHN-01	ITM-CHG-01	0	7	70	f	none	simulated	system_sim
11079	2026-07-23	WH-CHN-01	ITM-CBL-01	0	5	230	f	none	simulated	system_sim
11080	2026-07-23	WH-BOM-01	ITM-CPU-01	0	0	32	f	none	simulated	system_sim
11081	2026-07-23	WH-BOM-01	ITM-GPU-01	0	1	26	f	none	simulated	system_sim
11082	2026-07-23	WH-BOM-01	ITM-RAM-01	0	7	91	f	none	simulated	system_sim
11083	2026-07-23	WH-BOM-01	ITM-SSD-01	0	0	81	f	none	simulated	system_sim
11084	2026-07-23	WH-BOM-01	ITM-HDD-01	0	2	42	f	none	simulated	system_sim
11085	2026-07-23	WH-BOM-01	ITM-CHG-01	0	2	89	f	none	simulated	system_sim
11086	2026-07-23	WH-BOM-01	ITM-CBL-01	0	2	252	f	none	simulated	system_sim
11087	2026-07-23	WH-DEL-01	ITM-CPU-01	0	3	27	f	none	simulated	system_sim
11088	2026-07-23	WH-DEL-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
11089	2026-07-23	WH-DEL-01	ITM-RAM-01	0	10	81	f	none	simulated	system_sim
11090	2026-07-23	WH-DEL-01	ITM-SSD-01	0	2	73	f	none	simulated	system_sim
11091	2026-07-23	WH-DEL-01	ITM-HDD-01	0	3	46	f	none	simulated	system_sim
11092	2026-07-23	WH-DEL-01	ITM-CHG-01	0	8	87	f	none	simulated	system_sim
11093	2026-07-23	WH-DEL-01	ITM-CBL-01	0	7	237	f	none	simulated	system_sim
11094	2026-07-23	WH-CCU-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
11095	2026-07-23	WH-CCU-01	ITM-GPU-01	0	1	21	f	none	simulated	system_sim
11096	2026-07-23	WH-CCU-01	ITM-RAM-01	0	8	85	f	none	simulated	system_sim
11097	2026-07-23	WH-CCU-01	ITM-SSD-01	0	2	83	f	none	simulated	system_sim
11098	2026-07-23	WH-CCU-01	ITM-HDD-01	0	0	53	f	none	simulated	system_sim
11099	2026-07-23	WH-CCU-01	ITM-CHG-01	0	8	86	f	none	simulated	system_sim
11100	2026-07-23	WH-CCU-01	ITM-CBL-01	0	1	244	f	none	simulated	system_sim
11101	2026-07-24	WH-BLR-01	ITM-CPU-01	0	2	33	f	none	simulated	system_sim
11102	2026-07-24	WH-BLR-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
11103	2026-07-24	WH-BLR-01	ITM-RAM-01	0	5	89	f	none	simulated	system_sim
11104	2026-07-24	WH-BLR-01	ITM-SSD-01	0	2	70	f	none	simulated	system_sim
11105	2026-07-24	WH-BLR-01	ITM-HDD-01	0	0	45	f	none	simulated	system_sim
11106	2026-07-24	WH-BLR-01	ITM-CHG-01	0	8	82	f	none	simulated	system_sim
11107	2026-07-24	WH-BLR-01	ITM-CBL-01	0	7	237	f	none	simulated	system_sim
11108	2026-07-24	WH-CHN-01	ITM-CPU-01	0	0	30	f	none	simulated	system_sim
11109	2026-07-24	WH-CHN-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
11110	2026-07-24	WH-CHN-01	ITM-RAM-01	0	7	84	f	none	simulated	system_sim
11111	2026-07-24	WH-CHN-01	ITM-SSD-01	0	2	73	f	none	simulated	system_sim
11112	2026-07-24	WH-CHN-01	ITM-HDD-01	0	1	44	f	none	simulated	system_sim
11113	2026-07-24	WH-CHN-01	ITM-CHG-01	150	7	213	f	none	simulated	system_sim
11114	2026-07-24	WH-CHN-01	ITM-CBL-01	0	4	226	f	none	simulated	system_sim
11115	2026-07-24	WH-BOM-01	ITM-CPU-01	0	1	31	f	none	simulated	system_sim
11116	2026-07-24	WH-BOM-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
11117	2026-07-24	WH-BOM-01	ITM-RAM-01	0	4	87	f	none	simulated	system_sim
11118	2026-07-24	WH-BOM-01	ITM-SSD-01	0	1	80	f	none	simulated	system_sim
11119	2026-07-24	WH-BOM-01	ITM-HDD-01	0	0	42	f	none	simulated	system_sim
11120	2026-07-24	WH-BOM-01	ITM-CHG-01	0	2	87	f	none	simulated	system_sim
11121	2026-07-24	WH-BOM-01	ITM-CBL-01	0	5	247	f	none	simulated	system_sim
11122	2026-07-24	WH-DEL-01	ITM-CPU-01	0	1	26	f	none	simulated	system_sim
11123	2026-07-24	WH-DEL-01	ITM-GPU-01	0	2	22	f	none	simulated	system_sim
11124	2026-07-24	WH-DEL-01	ITM-RAM-01	0	5	76	f	none	simulated	system_sim
11125	2026-07-24	WH-DEL-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
11126	2026-07-24	WH-DEL-01	ITM-HDD-01	0	3	43	f	none	simulated	system_sim
11127	2026-07-24	WH-DEL-01	ITM-CHG-01	0	3	84	f	none	simulated	system_sim
11128	2026-07-24	WH-DEL-01	ITM-CBL-01	0	6	231	f	none	simulated	system_sim
11129	2026-07-24	WH-CCU-01	ITM-CPU-01	0	1	35	f	none	simulated	system_sim
11130	2026-07-24	WH-CCU-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
11131	2026-07-24	WH-CCU-01	ITM-RAM-01	0	6	79	f	none	simulated	system_sim
11132	2026-07-24	WH-CCU-01	ITM-SSD-01	0	3	80	f	none	simulated	system_sim
11133	2026-07-24	WH-CCU-01	ITM-HDD-01	0	3	50	f	none	simulated	system_sim
11134	2026-07-24	WH-CCU-01	ITM-CHG-01	0	1	85	f	none	simulated	system_sim
11135	2026-07-24	WH-CCU-01	ITM-CBL-01	0	5	239	f	none	simulated	system_sim
11136	2026-07-25	WH-BLR-01	ITM-CPU-01	0	3	30	f	none	simulated	system_sim
11137	2026-07-25	WH-BLR-01	ITM-GPU-01	0	1	18	f	none	simulated	system_sim
11138	2026-07-25	WH-BLR-01	ITM-RAM-01	0	1	88	f	none	simulated	system_sim
11139	2026-07-25	WH-BLR-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
11140	2026-07-25	WH-BLR-01	ITM-HDD-01	0	0	45	f	none	simulated	system_sim
11141	2026-07-25	WH-BLR-01	ITM-CHG-01	0	6	76	f	none	simulated	system_sim
11142	2026-07-25	WH-BLR-01	ITM-CBL-01	0	6	231	f	none	simulated	system_sim
11143	2026-07-25	WH-CHN-01	ITM-CPU-01	0	3	12	t	shrinkage	simulated	system_sim
11144	2026-07-25	WH-CHN-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
11145	2026-07-25	WH-CHN-01	ITM-RAM-01	0	10	74	f	none	simulated	system_sim
11146	2026-07-25	WH-CHN-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
11147	2026-07-25	WH-CHN-01	ITM-HDD-01	0	0	44	f	none	simulated	system_sim
11148	2026-07-25	WH-CHN-01	ITM-CHG-01	0	10	203	f	none	simulated	system_sim
11149	2026-07-25	WH-CHN-01	ITM-CBL-01	0	4	222	f	none	simulated	system_sim
11150	2026-07-25	WH-BOM-01	ITM-CPU-01	0	3	28	f	none	simulated	system_sim
11151	2026-07-25	WH-BOM-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
11152	2026-07-25	WH-BOM-01	ITM-RAM-01	0	3	84	f	none	simulated	system_sim
11153	2026-07-25	WH-BOM-01	ITM-SSD-01	0	1	79	f	none	simulated	system_sim
11154	2026-07-25	WH-BOM-01	ITM-HDD-01	0	0	42	f	none	simulated	system_sim
11155	2026-07-25	WH-BOM-01	ITM-CHG-01	0	7	80	f	none	simulated	system_sim
11156	2026-07-25	WH-BOM-01	ITM-CBL-01	0	8	239	f	none	simulated	system_sim
11157	2026-07-25	WH-DEL-01	ITM-CPU-01	0	2	24	f	none	simulated	system_sim
11158	2026-07-25	WH-DEL-01	ITM-GPU-01	0	2	20	f	none	simulated	system_sim
11159	2026-07-25	WH-DEL-01	ITM-RAM-01	0	1	75	f	none	simulated	system_sim
11160	2026-07-25	WH-DEL-01	ITM-SSD-01	0	1	72	f	none	simulated	system_sim
11161	2026-07-25	WH-DEL-01	ITM-HDD-01	0	3	40	f	none	simulated	system_sim
11162	2026-07-25	WH-DEL-01	ITM-CHG-01	0	6	78	f	none	simulated	system_sim
11163	2026-07-25	WH-DEL-01	ITM-CBL-01	0	9	222	f	none	simulated	system_sim
11164	2026-07-25	WH-CCU-01	ITM-CPU-01	0	3	32	f	none	simulated	system_sim
11165	2026-07-25	WH-CCU-01	ITM-GPU-01	0	1	20	f	none	simulated	system_sim
11166	2026-07-25	WH-CCU-01	ITM-RAM-01	0	10	69	f	none	simulated	system_sim
11167	2026-07-25	WH-CCU-01	ITM-SSD-01	0	2	78	f	none	simulated	system_sim
11168	2026-07-25	WH-CCU-01	ITM-HDD-01	0	2	48	f	none	simulated	system_sim
11169	2026-07-25	WH-CCU-01	ITM-CHG-01	0	9	76	f	none	simulated	system_sim
11170	2026-07-25	WH-CCU-01	ITM-CBL-01	0	9	230	f	none	simulated	system_sim
11171	2026-07-26	WH-BLR-01	ITM-CPU-01	0	0	30	f	none	simulated	system_sim
11172	2026-07-26	WH-BLR-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
11173	2026-07-26	WH-BLR-01	ITM-RAM-01	0	10	78	f	none	simulated	system_sim
11174	2026-07-26	WH-BLR-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
11175	2026-07-26	WH-BLR-01	ITM-HDD-01	0	2	43	f	none	simulated	system_sim
11176	2026-07-26	WH-BLR-01	ITM-CHG-01	0	3	73	f	none	simulated	system_sim
11177	2026-07-26	WH-BLR-01	ITM-CBL-01	0	8	223	f	none	simulated	system_sim
11178	2026-07-26	WH-CHN-01	ITM-CPU-01	45	3	54	f	none	simulated	system_sim
11179	2026-07-26	WH-CHN-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
11180	2026-07-26	WH-CHN-01	ITM-RAM-01	0	9	65	f	none	simulated	system_sim
11181	2026-07-26	WH-CHN-01	ITM-SSD-01	0	1	72	f	none	simulated	system_sim
11182	2026-07-26	WH-CHN-01	ITM-HDD-01	0	0	44	f	none	simulated	system_sim
11183	2026-07-26	WH-CHN-01	ITM-CHG-01	0	2	201	f	none	simulated	system_sim
11184	2026-07-26	WH-CHN-01	ITM-CBL-01	0	2	220	f	none	simulated	system_sim
11185	2026-07-26	WH-BOM-01	ITM-CPU-01	0	1	27	f	none	simulated	system_sim
11186	2026-07-26	WH-BOM-01	ITM-GPU-01	0	2	24	f	none	simulated	system_sim
11187	2026-07-26	WH-BOM-01	ITM-RAM-01	0	4	80	f	none	simulated	system_sim
11188	2026-07-26	WH-BOM-01	ITM-SSD-01	0	0	79	f	none	simulated	system_sim
11189	2026-07-26	WH-BOM-01	ITM-HDD-01	0	1	41	f	none	simulated	system_sim
11190	2026-07-26	WH-BOM-01	ITM-CHG-01	0	1	79	f	none	simulated	system_sim
11191	2026-07-26	WH-BOM-01	ITM-CBL-01	0	5	234	f	none	simulated	system_sim
11192	2026-07-26	WH-DEL-01	ITM-CPU-01	0	3	21	f	none	simulated	system_sim
11193	2026-07-26	WH-DEL-01	ITM-GPU-01	0	2	18	f	none	simulated	system_sim
11194	2026-07-26	WH-DEL-01	ITM-RAM-01	0	10	65	f	none	simulated	system_sim
11195	2026-07-26	WH-DEL-01	ITM-SSD-01	0	0	72	f	none	simulated	system_sim
11196	2026-07-26	WH-DEL-01	ITM-HDD-01	0	0	40	f	none	simulated	system_sim
11197	2026-07-26	WH-DEL-01	ITM-CHG-01	0	4	74	f	none	simulated	system_sim
11198	2026-07-26	WH-DEL-01	ITM-CBL-01	0	4	218	f	none	simulated	system_sim
11199	2026-07-26	WH-CCU-01	ITM-CPU-01	0	1	31	f	none	simulated	system_sim
11200	2026-07-26	WH-CCU-01	ITM-GPU-01	0	2	18	f	none	simulated	system_sim
11201	2026-07-26	WH-CCU-01	ITM-RAM-01	0	9	60	f	none	simulated	system_sim
11202	2026-07-26	WH-CCU-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
11203	2026-07-26	WH-CCU-01	ITM-HDD-01	0	1	47	f	none	simulated	system_sim
11204	2026-07-26	WH-CCU-01	ITM-CHG-01	0	5	71	f	none	simulated	system_sim
11205	2026-07-26	WH-CCU-01	ITM-CBL-01	0	4	226	f	none	simulated	system_sim
11206	2026-07-27	WH-BLR-01	ITM-CPU-01	0	2	28	f	none	simulated	system_sim
11207	2026-07-27	WH-BLR-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11208	2026-07-27	WH-BLR-01	ITM-RAM-01	0	8	70	f	none	simulated	system_sim
11209	2026-07-27	WH-BLR-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
11210	2026-07-27	WH-BLR-01	ITM-HDD-01	0	0	43	f	none	simulated	system_sim
11211	2026-07-27	WH-BLR-01	ITM-CHG-01	150	1	222	f	none	simulated	system_sim
11212	2026-07-27	WH-BLR-01	ITM-CBL-01	0	6	217	f	none	simulated	system_sim
11213	2026-07-27	WH-CHN-01	ITM-CPU-01	0	3	51	f	none	simulated	system_sim
11214	2026-07-27	WH-CHN-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
11215	2026-07-27	WH-CHN-01	ITM-RAM-01	0	1	64	f	none	simulated	system_sim
11216	2026-07-27	WH-CHN-01	ITM-SSD-01	0	3	69	f	none	simulated	system_sim
11217	2026-07-27	WH-CHN-01	ITM-HDD-01	0	3	41	f	none	simulated	system_sim
11218	2026-07-27	WH-CHN-01	ITM-CHG-01	0	6	195	f	none	simulated	system_sim
11219	2026-07-27	WH-CHN-01	ITM-CBL-01	0	4	216	f	none	simulated	system_sim
11220	2026-07-27	WH-BOM-01	ITM-CPU-01	0	1	26	f	none	simulated	system_sim
11221	2026-07-27	WH-BOM-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
11222	2026-07-27	WH-BOM-01	ITM-RAM-01	0	1	79	f	none	simulated	system_sim
11223	2026-07-27	WH-BOM-01	ITM-SSD-01	0	3	76	f	none	simulated	system_sim
11224	2026-07-27	WH-BOM-01	ITM-HDD-01	0	3	38	f	none	simulated	system_sim
11225	2026-07-27	WH-BOM-01	ITM-CHG-01	0	2	77	f	none	simulated	system_sim
11226	2026-07-27	WH-BOM-01	ITM-CBL-01	0	4	230	f	none	simulated	system_sim
11227	2026-07-27	WH-DEL-01	ITM-CPU-01	45	3	63	f	none	simulated	system_sim
11228	2026-07-27	WH-DEL-01	ITM-GPU-01	0	2	16	f	none	simulated	system_sim
11229	2026-07-27	WH-DEL-01	ITM-RAM-01	0	6	59	f	none	simulated	system_sim
11230	2026-07-27	WH-DEL-01	ITM-SSD-01	0	1	71	f	none	simulated	system_sim
11231	2026-07-27	WH-DEL-01	ITM-HDD-01	0	0	40	f	none	simulated	system_sim
11232	2026-07-27	WH-DEL-01	ITM-CHG-01	150	10	214	f	none	simulated	system_sim
11233	2026-07-27	WH-DEL-01	ITM-CBL-01	0	1	217	f	none	simulated	system_sim
11234	2026-07-27	WH-CCU-01	ITM-CPU-01	0	2	29	f	none	simulated	system_sim
11235	2026-07-27	WH-CCU-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
11236	2026-07-27	WH-CCU-01	ITM-RAM-01	0	1	59	f	none	simulated	system_sim
11237	2026-07-27	WH-CCU-01	ITM-SSD-01	0	2	76	f	none	simulated	system_sim
11238	2026-07-27	WH-CCU-01	ITM-HDD-01	0	1	46	f	none	simulated	system_sim
11239	2026-07-27	WH-CCU-01	ITM-CHG-01	150	10	211	f	none	simulated	system_sim
11240	2026-07-27	WH-CCU-01	ITM-CBL-01	0	1	225	f	none	simulated	system_sim
11241	2026-07-28	WH-BLR-01	ITM-CPU-01	0	1	27	f	none	simulated	system_sim
11242	2026-07-28	WH-BLR-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11243	2026-07-28	WH-BLR-01	ITM-RAM-01	0	8	62	f	none	simulated	system_sim
11244	2026-07-28	WH-BLR-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
11245	2026-07-28	WH-BLR-01	ITM-HDD-01	0	1	42	f	none	simulated	system_sim
11246	2026-07-28	WH-BLR-01	ITM-CHG-01	0	6	216	f	none	simulated	system_sim
11247	2026-07-28	WH-BLR-01	ITM-CBL-01	0	10	207	f	none	simulated	system_sim
11248	2026-07-28	WH-CHN-01	ITM-CPU-01	0	2	49	f	none	simulated	system_sim
11249	2026-07-28	WH-CHN-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
11250	2026-07-28	WH-CHN-01	ITM-RAM-01	0	9	55	f	none	simulated	system_sim
11251	2026-07-28	WH-CHN-01	ITM-SSD-01	0	3	66	f	none	simulated	system_sim
11252	2026-07-28	WH-CHN-01	ITM-HDD-01	0	2	39	f	none	simulated	system_sim
11253	2026-07-28	WH-CHN-01	ITM-CHG-01	0	6	189	f	none	simulated	system_sim
11254	2026-07-28	WH-CHN-01	ITM-CBL-01	0	10	206	f	none	simulated	system_sim
11255	2026-07-28	WH-BOM-01	ITM-CPU-01	0	0	26	f	none	simulated	system_sim
11256	2026-07-28	WH-BOM-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
11257	2026-07-28	WH-BOM-01	ITM-RAM-01	0	2	77	f	none	simulated	system_sim
11258	2026-07-28	WH-BOM-01	ITM-SSD-01	0	3	73	f	none	simulated	system_sim
11259	2026-07-28	WH-BOM-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
11260	2026-07-28	WH-BOM-01	ITM-CHG-01	0	10	67	f	none	simulated	system_sim
11261	2026-07-28	WH-BOM-01	ITM-CBL-01	0	1	229	f	none	simulated	system_sim
11262	2026-07-28	WH-DEL-01	ITM-CPU-01	0	1	62	f	none	simulated	system_sim
11263	2026-07-28	WH-DEL-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
11264	2026-07-28	WH-DEL-01	ITM-RAM-01	0	10	49	f	none	simulated	system_sim
11265	2026-07-28	WH-DEL-01	ITM-SSD-01	0	0	71	f	none	simulated	system_sim
11266	2026-07-28	WH-DEL-01	ITM-HDD-01	0	3	37	f	none	simulated	system_sim
11267	2026-07-28	WH-DEL-01	ITM-CHG-01	0	3	211	f	none	simulated	system_sim
11268	2026-07-28	WH-DEL-01	ITM-CBL-01	0	8	209	f	none	simulated	system_sim
11269	2026-07-28	WH-CCU-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
11270	2026-07-28	WH-CCU-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
11271	2026-07-28	WH-CCU-01	ITM-RAM-01	0	4	55	f	none	simulated	system_sim
11272	2026-07-28	WH-CCU-01	ITM-SSD-01	0	0	76	f	none	simulated	system_sim
11273	2026-07-28	WH-CCU-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
11274	2026-07-28	WH-CCU-01	ITM-CHG-01	0	3	208	f	none	simulated	system_sim
11275	2026-07-28	WH-CCU-01	ITM-CBL-01	0	6	219	f	none	simulated	system_sim
11276	2026-07-29	WH-BLR-01	ITM-CPU-01	0	0	27	f	none	simulated	system_sim
11277	2026-07-29	WH-BLR-01	ITM-GPU-01	0	2	15	f	none	simulated	system_sim
11278	2026-07-29	WH-BLR-01	ITM-RAM-01	0	4	58	f	none	simulated	system_sim
11279	2026-07-29	WH-BLR-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
11280	2026-07-29	WH-BLR-01	ITM-HDD-01	0	3	39	f	none	simulated	system_sim
11281	2026-07-29	WH-BLR-01	ITM-CHG-01	0	6	210	f	none	simulated	system_sim
11282	2026-07-29	WH-BLR-01	ITM-CBL-01	0	4	203	f	none	simulated	system_sim
11283	2026-07-29	WH-CHN-01	ITM-CPU-01	0	0	49	f	none	simulated	system_sim
11284	2026-07-29	WH-CHN-01	ITM-GPU-01	0	2	21	f	none	simulated	system_sim
11285	2026-07-29	WH-CHN-01	ITM-RAM-01	0	9	46	f	none	simulated	system_sim
11286	2026-07-29	WH-CHN-01	ITM-SSD-01	0	0	66	f	none	simulated	system_sim
11287	2026-07-29	WH-CHN-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
11288	2026-07-29	WH-CHN-01	ITM-CHG-01	0	2	187	f	none	simulated	system_sim
11289	2026-07-29	WH-CHN-01	ITM-CBL-01	0	3	203	f	none	simulated	system_sim
11290	2026-07-29	WH-BOM-01	ITM-CPU-01	0	1	25	f	none	simulated	system_sim
11291	2026-07-29	WH-BOM-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
11292	2026-07-29	WH-BOM-01	ITM-RAM-01	0	10	67	f	none	simulated	system_sim
11293	2026-07-29	WH-BOM-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
11294	2026-07-29	WH-BOM-01	ITM-HDD-01	0	3	35	f	none	simulated	system_sim
11295	2026-07-29	WH-BOM-01	ITM-CHG-01	150	2	215	f	none	simulated	system_sim
11296	2026-07-29	WH-BOM-01	ITM-CBL-01	0	8	221	f	none	simulated	system_sim
11297	2026-07-29	WH-DEL-01	ITM-CPU-01	0	0	62	f	none	simulated	system_sim
11298	2026-07-29	WH-DEL-01	ITM-GPU-01	0	2	14	f	none	simulated	system_sim
11299	2026-07-29	WH-DEL-01	ITM-RAM-01	0	7	42	f	none	simulated	system_sim
11300	2026-07-29	WH-DEL-01	ITM-SSD-01	0	1	70	f	none	simulated	system_sim
11301	2026-07-29	WH-DEL-01	ITM-HDD-01	0	2	35	f	none	simulated	system_sim
11302	2026-07-29	WH-DEL-01	ITM-CHG-01	0	2	209	f	none	simulated	system_sim
11303	2026-07-29	WH-DEL-01	ITM-CBL-01	0	3	206	f	none	simulated	system_sim
11304	2026-07-29	WH-CCU-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
11305	2026-07-29	WH-CCU-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
11306	2026-07-29	WH-CCU-01	ITM-RAM-01	0	4	51	f	none	simulated	system_sim
11307	2026-07-29	WH-CCU-01	ITM-SSD-01	0	2	74	f	none	simulated	system_sim
11308	2026-07-29	WH-CCU-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
11309	2026-07-29	WH-CCU-01	ITM-CHG-01	0	6	202	f	none	simulated	system_sim
11310	2026-07-29	WH-CCU-01	ITM-CBL-01	0	5	214	f	none	simulated	system_sim
11311	2026-07-30	WH-BLR-01	ITM-CPU-01	0	2	25	f	none	simulated	system_sim
11312	2026-07-30	WH-BLR-01	ITM-GPU-01	0	0	15	f	none	simulated	system_sim
11313	2026-07-30	WH-BLR-01	ITM-RAM-01	0	4	54	f	none	simulated	system_sim
11314	2026-07-30	WH-BLR-01	ITM-SSD-01	0	2	68	f	none	simulated	system_sim
11315	2026-07-30	WH-BLR-01	ITM-HDD-01	0	3	36	f	none	simulated	system_sim
11316	2026-07-30	WH-BLR-01	ITM-CHG-01	0	2	208	f	none	simulated	system_sim
11317	2026-07-30	WH-BLR-01	ITM-CBL-01	0	4	199	f	none	simulated	system_sim
11318	2026-07-30	WH-CHN-01	ITM-CPU-01	0	0	49	f	none	simulated	system_sim
11319	2026-07-30	WH-CHN-01	ITM-GPU-01	0	1	20	f	none	simulated	system_sim
11320	2026-07-30	WH-CHN-01	ITM-RAM-01	0	6	40	f	none	simulated	system_sim
11321	2026-07-30	WH-CHN-01	ITM-SSD-01	0	1	65	f	none	simulated	system_sim
11322	2026-07-30	WH-CHN-01	ITM-HDD-01	0	1	38	f	none	simulated	system_sim
11323	2026-07-30	WH-CHN-01	ITM-CHG-01	0	10	177	f	none	simulated	system_sim
11324	2026-07-30	WH-CHN-01	ITM-CBL-01	0	10	193	f	none	simulated	system_sim
11325	2026-07-30	WH-BOM-01	ITM-CPU-01	0	1	24	f	none	simulated	system_sim
11326	2026-07-30	WH-BOM-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
11327	2026-07-30	WH-BOM-01	ITM-RAM-01	0	5	62	f	none	simulated	system_sim
11328	2026-07-30	WH-BOM-01	ITM-SSD-01	0	1	72	f	none	simulated	system_sim
11329	2026-07-30	WH-BOM-01	ITM-HDD-01	0	1	34	f	none	simulated	system_sim
11330	2026-07-30	WH-BOM-01	ITM-CHG-01	0	2	213	f	none	simulated	system_sim
11331	2026-07-30	WH-BOM-01	ITM-CBL-01	0	5	216	f	none	simulated	system_sim
11332	2026-07-30	WH-DEL-01	ITM-CPU-01	0	0	62	f	none	simulated	system_sim
11333	2026-07-30	WH-DEL-01	ITM-GPU-01	30	0	44	f	none	simulated	system_sim
11334	2026-07-30	WH-DEL-01	ITM-RAM-01	0	9	33	f	none	simulated	system_sim
11335	2026-07-30	WH-DEL-01	ITM-SSD-01	0	3	67	f	none	simulated	system_sim
11336	2026-07-30	WH-DEL-01	ITM-HDD-01	0	2	33	f	none	simulated	system_sim
11337	2026-07-30	WH-DEL-01	ITM-CHG-01	0	8	201	f	none	simulated	system_sim
11338	2026-07-30	WH-DEL-01	ITM-CBL-01	0	5	201	f	none	simulated	system_sim
11339	2026-07-30	WH-CCU-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
11340	2026-07-30	WH-CCU-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
11341	2026-07-30	WH-CCU-01	ITM-RAM-01	0	8	43	f	none	simulated	system_sim
11342	2026-07-30	WH-CCU-01	ITM-SSD-01	0	0	74	f	none	simulated	system_sim
11343	2026-07-30	WH-CCU-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
11344	2026-07-30	WH-CCU-01	ITM-CHG-01	0	10	192	f	none	simulated	system_sim
11345	2026-07-30	WH-CCU-01	ITM-CBL-01	0	6	208	f	none	simulated	system_sim
11346	2026-07-31	WH-BLR-01	ITM-CPU-01	0	2	23	f	none	simulated	system_sim
11347	2026-07-31	WH-BLR-01	ITM-GPU-01	0	0	15	f	none	simulated	system_sim
11348	2026-07-31	WH-BLR-01	ITM-RAM-01	0	3	51	f	none	simulated	system_sim
11349	2026-07-31	WH-BLR-01	ITM-SSD-01	0	1	67	f	none	simulated	system_sim
11350	2026-07-31	WH-BLR-01	ITM-HDD-01	0	2	34	f	none	simulated	system_sim
11351	2026-07-31	WH-BLR-01	ITM-CHG-01	0	10	198	f	none	simulated	system_sim
11352	2026-07-31	WH-BLR-01	ITM-CBL-01	0	4	195	f	none	simulated	system_sim
11353	2026-07-31	WH-CHN-01	ITM-CPU-01	0	2	47	f	none	simulated	system_sim
11354	2026-07-31	WH-CHN-01	ITM-GPU-01	0	1	19	f	none	simulated	system_sim
11355	2026-07-31	WH-CHN-01	ITM-RAM-01	0	4	36	f	none	simulated	system_sim
11356	2026-07-31	WH-CHN-01	ITM-SSD-01	0	0	65	f	none	simulated	system_sim
11357	2026-07-31	WH-CHN-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
11358	2026-07-31	WH-CHN-01	ITM-CHG-01	0	5	172	f	none	simulated	system_sim
11359	2026-07-31	WH-CHN-01	ITM-CBL-01	0	8	185	f	none	simulated	system_sim
11360	2026-07-31	WH-BOM-01	ITM-CPU-01	0	1	23	f	none	simulated	system_sim
11361	2026-07-31	WH-BOM-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
11362	2026-07-31	WH-BOM-01	ITM-RAM-01	0	1	61	f	none	simulated	system_sim
11363	2026-07-31	WH-BOM-01	ITM-SSD-01	0	1	71	f	none	simulated	system_sim
11364	2026-07-31	WH-BOM-01	ITM-HDD-01	0	2	32	f	none	simulated	system_sim
11365	2026-07-31	WH-BOM-01	ITM-CHG-01	0	3	210	f	none	simulated	system_sim
11366	2026-07-31	WH-BOM-01	ITM-CBL-01	0	8	208	f	none	simulated	system_sim
11367	2026-07-31	WH-DEL-01	ITM-CPU-01	0	0	62	f	none	simulated	system_sim
11368	2026-07-31	WH-DEL-01	ITM-GPU-01	0	2	42	f	none	simulated	system_sim
11369	2026-07-31	WH-DEL-01	ITM-RAM-01	75	7	101	f	none	simulated	system_sim
11370	2026-07-31	WH-DEL-01	ITM-SSD-01	0	3	64	f	none	simulated	system_sim
11371	2026-07-31	WH-DEL-01	ITM-HDD-01	0	0	33	f	none	simulated	system_sim
11372	2026-07-31	WH-DEL-01	ITM-CHG-01	0	5	196	f	none	simulated	system_sim
11373	2026-07-31	WH-DEL-01	ITM-CBL-01	0	1	200	f	none	simulated	system_sim
11374	2026-07-31	WH-CCU-01	ITM-CPU-01	0	3	26	f	none	simulated	system_sim
11375	2026-07-31	WH-CCU-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
11376	2026-07-31	WH-CCU-01	ITM-RAM-01	0	1	42	f	none	simulated	system_sim
11377	2026-07-31	WH-CCU-01	ITM-SSD-01	0	1	73	f	none	simulated	system_sim
11378	2026-07-31	WH-CCU-01	ITM-HDD-01	0	2	44	f	none	simulated	system_sim
11379	2026-07-31	WH-CCU-01	ITM-CHG-01	0	7	185	f	none	simulated	system_sim
11380	2026-07-31	WH-CCU-01	ITM-CBL-01	0	8	200	f	none	simulated	system_sim
11381	2026-08-01	WH-BLR-01	ITM-CPU-01	0	2	21	f	none	simulated	system_sim
11382	2026-08-01	WH-BLR-01	ITM-GPU-01	0	2	13	f	none	simulated	system_sim
11383	2026-08-01	WH-BLR-01	ITM-RAM-01	0	2	49	f	none	simulated	system_sim
11384	2026-08-01	WH-BLR-01	ITM-SSD-01	0	0	67	f	none	simulated	system_sim
11385	2026-08-01	WH-BLR-01	ITM-HDD-01	0	1	33	f	none	simulated	system_sim
11386	2026-08-01	WH-BLR-01	ITM-CHG-01	0	9	189	f	none	simulated	system_sim
11387	2026-08-01	WH-BLR-01	ITM-CBL-01	0	8	187	f	none	simulated	system_sim
11388	2026-08-01	WH-CHN-01	ITM-CPU-01	0	0	47	f	none	simulated	system_sim
11389	2026-08-01	WH-CHN-01	ITM-GPU-01	0	2	17	f	none	simulated	system_sim
11390	2026-08-01	WH-CHN-01	ITM-RAM-01	75	7	104	f	none	simulated	system_sim
11391	2026-08-01	WH-CHN-01	ITM-SSD-01	0	2	63	f	none	simulated	system_sim
11392	2026-08-01	WH-CHN-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
11393	2026-08-01	WH-CHN-01	ITM-CHG-01	0	8	164	f	none	simulated	system_sim
11394	2026-08-01	WH-CHN-01	ITM-CBL-01	0	4	181	f	none	simulated	system_sim
11395	2026-08-01	WH-BOM-01	ITM-CPU-01	0	0	23	f	none	simulated	system_sim
11396	2026-08-01	WH-BOM-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
11397	2026-08-01	WH-BOM-01	ITM-RAM-01	0	10	51	f	none	simulated	system_sim
11398	2026-08-01	WH-BOM-01	ITM-SSD-01	0	1	70	f	none	simulated	system_sim
11399	2026-08-01	WH-BOM-01	ITM-HDD-01	0	3	29	f	none	simulated	system_sim
11400	2026-08-01	WH-BOM-01	ITM-CHG-01	0	6	204	f	none	simulated	system_sim
11401	2026-08-01	WH-BOM-01	ITM-CBL-01	0	8	200	f	none	simulated	system_sim
11402	2026-08-01	WH-DEL-01	ITM-CPU-01	0	1	61	f	none	simulated	system_sim
11403	2026-08-01	WH-DEL-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
11404	2026-08-01	WH-DEL-01	ITM-RAM-01	0	9	92	f	none	simulated	system_sim
11405	2026-08-01	WH-DEL-01	ITM-SSD-01	0	2	62	f	none	simulated	system_sim
11406	2026-08-01	WH-DEL-01	ITM-HDD-01	0	2	31	f	none	simulated	system_sim
11407	2026-08-01	WH-DEL-01	ITM-CHG-01	0	7	189	f	none	simulated	system_sim
11408	2026-08-01	WH-DEL-01	ITM-CBL-01	0	1	199	f	none	simulated	system_sim
11409	2026-08-01	WH-CCU-01	ITM-CPU-01	0	1	25	f	none	simulated	system_sim
11410	2026-08-01	WH-CCU-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11411	2026-08-01	WH-CCU-01	ITM-RAM-01	0	1	41	f	none	simulated	system_sim
11412	2026-08-01	WH-CCU-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
11413	2026-08-01	WH-CCU-01	ITM-HDD-01	0	0	44	f	none	simulated	system_sim
11414	2026-08-01	WH-CCU-01	ITM-CHG-01	0	7	178	f	none	simulated	system_sim
11415	2026-08-01	WH-CCU-01	ITM-CBL-01	0	9	191	f	none	simulated	system_sim
11416	2026-08-02	WH-BLR-01	ITM-CPU-01	45	1	65	f	none	simulated	system_sim
11417	2026-08-02	WH-BLR-01	ITM-GPU-01	30	1	42	f	none	simulated	system_sim
11418	2026-08-02	WH-BLR-01	ITM-RAM-01	0	8	41	f	none	simulated	system_sim
11419	2026-08-02	WH-BLR-01	ITM-SSD-01	0	3	64	f	none	simulated	system_sim
11420	2026-08-02	WH-BLR-01	ITM-HDD-01	0	0	33	f	none	simulated	system_sim
11421	2026-08-02	WH-BLR-01	ITM-CHG-01	0	3	186	f	none	simulated	system_sim
11422	2026-08-02	WH-BLR-01	ITM-CBL-01	0	3	184	f	none	simulated	system_sim
11423	2026-08-02	WH-CHN-01	ITM-CPU-01	0	0	47	f	none	simulated	system_sim
11424	2026-08-02	WH-CHN-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11425	2026-08-02	WH-CHN-01	ITM-RAM-01	0	9	95	f	none	simulated	system_sim
11426	2026-08-02	WH-CHN-01	ITM-SSD-01	0	0	63	f	none	simulated	system_sim
11427	2026-08-02	WH-CHN-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
11428	2026-08-02	WH-CHN-01	ITM-CHG-01	0	10	154	f	none	simulated	system_sim
11429	2026-08-02	WH-CHN-01	ITM-CBL-01	0	4	177	f	none	simulated	system_sim
11430	2026-08-02	WH-BOM-01	ITM-CPU-01	0	0	23	f	none	simulated	system_sim
11431	2026-08-02	WH-BOM-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
11432	2026-08-02	WH-BOM-01	ITM-RAM-01	0	5	46	f	none	simulated	system_sim
11433	2026-08-02	WH-BOM-01	ITM-SSD-01	0	2	68	f	none	simulated	system_sim
11434	2026-08-02	WH-BOM-01	ITM-HDD-01	60	2	87	f	none	simulated	system_sim
11435	2026-08-02	WH-BOM-01	ITM-CHG-01	0	9	195	f	none	simulated	system_sim
11436	2026-08-02	WH-BOM-01	ITM-CBL-01	0	4	196	f	none	simulated	system_sim
11437	2026-08-02	WH-DEL-01	ITM-CPU-01	0	1	60	f	none	simulated	system_sim
11438	2026-08-02	WH-DEL-01	ITM-GPU-01	0	2	40	f	none	simulated	system_sim
11439	2026-08-02	WH-DEL-01	ITM-RAM-01	0	4	88	f	none	simulated	system_sim
11440	2026-08-02	WH-DEL-01	ITM-SSD-01	0	1	61	f	none	simulated	system_sim
11441	2026-08-02	WH-DEL-01	ITM-HDD-01	0	3	28	f	none	simulated	system_sim
11442	2026-08-02	WH-DEL-01	ITM-CHG-01	0	7	182	f	none	simulated	system_sim
11443	2026-08-02	WH-DEL-01	ITM-CBL-01	0	3	196	f	none	simulated	system_sim
11444	2026-08-02	WH-CCU-01	ITM-CPU-01	0	1	24	f	none	simulated	system_sim
11445	2026-08-02	WH-CCU-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11446	2026-08-02	WH-CCU-01	ITM-RAM-01	0	5	36	f	none	simulated	system_sim
11447	2026-08-02	WH-CCU-01	ITM-SSD-01	0	1	72	f	none	simulated	system_sim
11448	2026-08-02	WH-CCU-01	ITM-HDD-01	0	0	44	f	none	simulated	system_sim
11449	2026-08-02	WH-CCU-01	ITM-CHG-01	0	4	174	f	none	simulated	system_sim
11450	2026-08-02	WH-CCU-01	ITM-CBL-01	0	8	183	f	none	simulated	system_sim
11451	2026-08-03	WH-BLR-01	ITM-CPU-01	0	1	64	f	none	simulated	system_sim
11452	2026-08-03	WH-BLR-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
11453	2026-08-03	WH-BLR-01	ITM-RAM-01	0	5	36	f	none	simulated	system_sim
11454	2026-08-03	WH-BLR-01	ITM-SSD-01	0	0	64	f	none	simulated	system_sim
11455	2026-08-03	WH-BLR-01	ITM-HDD-01	0	3	30	f	none	simulated	system_sim
11456	2026-08-03	WH-BLR-01	ITM-CHG-01	0	10	176	f	none	simulated	system_sim
11457	2026-08-03	WH-BLR-01	ITM-CBL-01	0	7	177	f	none	simulated	system_sim
11458	2026-08-03	WH-CHN-01	ITM-CPU-01	0	0	47	f	none	simulated	system_sim
11459	2026-08-03	WH-CHN-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11460	2026-08-03	WH-CHN-01	ITM-RAM-01	0	8	87	f	none	simulated	system_sim
11461	2026-08-03	WH-CHN-01	ITM-SSD-01	0	3	60	f	none	simulated	system_sim
11462	2026-08-03	WH-CHN-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
11463	2026-08-03	WH-CHN-01	ITM-CHG-01	0	3	151	f	none	simulated	system_sim
11464	2026-08-03	WH-CHN-01	ITM-CBL-01	0	6	171	f	none	simulated	system_sim
11465	2026-08-03	WH-BOM-01	ITM-CPU-01	0	0	23	f	none	simulated	system_sim
11466	2026-08-03	WH-BOM-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
11467	2026-08-03	WH-BOM-01	ITM-RAM-01	0	9	37	f	none	simulated	system_sim
11468	2026-08-03	WH-BOM-01	ITM-SSD-01	0	0	68	f	none	simulated	system_sim
11469	2026-08-03	WH-BOM-01	ITM-HDD-01	0	0	87	f	none	simulated	system_sim
11470	2026-08-03	WH-BOM-01	ITM-CHG-01	0	6	189	f	none	simulated	system_sim
11471	2026-08-03	WH-BOM-01	ITM-CBL-01	0	9	187	f	none	simulated	system_sim
11472	2026-08-03	WH-DEL-01	ITM-CPU-01	0	2	58	f	none	simulated	system_sim
11473	2026-08-03	WH-DEL-01	ITM-GPU-01	0	2	38	f	none	simulated	system_sim
11474	2026-08-03	WH-DEL-01	ITM-RAM-01	0	7	81	f	none	simulated	system_sim
11475	2026-08-03	WH-DEL-01	ITM-SSD-01	0	2	59	f	none	simulated	system_sim
11476	2026-08-03	WH-DEL-01	ITM-HDD-01	60	0	88	f	none	simulated	system_sim
11477	2026-08-03	WH-DEL-01	ITM-CHG-01	0	6	176	f	none	simulated	system_sim
11478	2026-08-03	WH-DEL-01	ITM-CBL-01	0	8	188	f	none	simulated	system_sim
11479	2026-08-03	WH-CCU-01	ITM-CPU-01	0	3	21	f	none	simulated	system_sim
11480	2026-08-03	WH-CCU-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11481	2026-08-03	WH-CCU-01	ITM-RAM-01	75	5	106	f	none	simulated	system_sim
11482	2026-08-03	WH-CCU-01	ITM-SSD-01	0	1	71	f	none	simulated	system_sim
11483	2026-08-03	WH-CCU-01	ITM-HDD-01	0	3	41	f	none	simulated	system_sim
11484	2026-08-03	WH-CCU-01	ITM-CHG-01	0	2	172	f	none	simulated	system_sim
11485	2026-08-03	WH-CCU-01	ITM-CBL-01	0	4	179	f	none	simulated	system_sim
11486	2026-08-04	WH-BLR-01	ITM-CPU-01	0	3	61	f	none	simulated	system_sim
11487	2026-08-04	WH-BLR-01	ITM-GPU-01	0	2	40	f	none	simulated	system_sim
11488	2026-08-04	WH-BLR-01	ITM-RAM-01	75	8	103	f	none	simulated	system_sim
11489	2026-08-04	WH-BLR-01	ITM-SSD-01	0	0	64	f	none	simulated	system_sim
11490	2026-08-04	WH-BLR-01	ITM-HDD-01	0	0	30	f	none	simulated	system_sim
11491	2026-08-04	WH-BLR-01	ITM-CHG-01	0	3	173	f	none	simulated	system_sim
11492	2026-08-04	WH-BLR-01	ITM-CBL-01	0	7	170	f	none	simulated	system_sim
11493	2026-08-04	WH-CHN-01	ITM-CPU-01	0	0	47	f	none	simulated	system_sim
11494	2026-08-04	WH-CHN-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11495	2026-08-04	WH-CHN-01	ITM-RAM-01	0	5	82	f	none	simulated	system_sim
11496	2026-08-04	WH-CHN-01	ITM-SSD-01	0	3	57	f	none	simulated	system_sim
11497	2026-08-04	WH-CHN-01	ITM-HDD-01	0	3	35	f	none	simulated	system_sim
11498	2026-08-04	WH-CHN-01	ITM-CHG-01	0	9	142	f	none	simulated	system_sim
11499	2026-08-04	WH-CHN-01	ITM-CBL-01	0	6	165	f	none	simulated	system_sim
11500	2026-08-04	WH-BOM-01	ITM-CPU-01	0	1	22	f	none	simulated	system_sim
11501	2026-08-04	WH-BOM-01	ITM-GPU-01	0	2	22	f	none	simulated	system_sim
11502	2026-08-04	WH-BOM-01	ITM-RAM-01	75	2	110	f	none	simulated	system_sim
11503	2026-08-04	WH-BOM-01	ITM-SSD-01	0	0	68	f	none	simulated	system_sim
11504	2026-08-04	WH-BOM-01	ITM-HDD-01	0	0	87	f	none	simulated	system_sim
11505	2026-08-04	WH-BOM-01	ITM-CHG-01	0	5	184	f	none	simulated	system_sim
11506	2026-08-04	WH-BOM-01	ITM-CBL-01	0	2	185	f	none	simulated	system_sim
11507	2026-08-04	WH-DEL-01	ITM-CPU-01	0	2	56	f	none	simulated	system_sim
11508	2026-08-04	WH-DEL-01	ITM-GPU-01	0	1	37	f	none	simulated	system_sim
11509	2026-08-04	WH-DEL-01	ITM-RAM-01	0	6	75	f	none	simulated	system_sim
11510	2026-08-04	WH-DEL-01	ITM-SSD-01	0	0	59	f	none	simulated	system_sim
11511	2026-08-04	WH-DEL-01	ITM-HDD-01	0	1	87	f	none	simulated	system_sim
11512	2026-08-04	WH-DEL-01	ITM-CHG-01	0	10	166	f	none	simulated	system_sim
11513	2026-08-04	WH-DEL-01	ITM-CBL-01	0	9	179	f	none	simulated	system_sim
11514	2026-08-04	WH-CCU-01	ITM-CPU-01	45	3	63	f	none	simulated	system_sim
11515	2026-08-04	WH-CCU-01	ITM-GPU-01	0	1	16	f	none	simulated	system_sim
11516	2026-08-04	WH-CCU-01	ITM-RAM-01	0	3	103	f	none	simulated	system_sim
11517	2026-08-04	WH-CCU-01	ITM-SSD-01	0	0	71	f	none	simulated	system_sim
11518	2026-08-04	WH-CCU-01	ITM-HDD-01	0	0	41	f	none	simulated	system_sim
11519	2026-08-04	WH-CCU-01	ITM-CHG-01	0	10	162	f	none	simulated	system_sim
11520	2026-08-04	WH-CCU-01	ITM-CBL-01	0	1	178	f	none	simulated	system_sim
11521	2026-08-05	WH-BLR-01	ITM-CPU-01	0	1	60	f	none	simulated	system_sim
11522	2026-08-05	WH-BLR-01	ITM-GPU-01	0	0	30	t	shrinkage	simulated	system_sim
11523	2026-08-05	WH-BLR-01	ITM-RAM-01	0	9	94	f	none	simulated	system_sim
11524	2026-08-05	WH-BLR-01	ITM-SSD-01	0	0	64	f	none	simulated	system_sim
11525	2026-08-05	WH-BLR-01	ITM-HDD-01	0	2	28	f	none	simulated	system_sim
11526	2026-08-05	WH-BLR-01	ITM-CHG-01	0	7	166	f	none	simulated	system_sim
11527	2026-08-05	WH-BLR-01	ITM-CBL-01	0	9	161	f	none	simulated	system_sim
11528	2026-08-05	WH-CHN-01	ITM-CPU-01	0	3	44	f	none	simulated	system_sim
11529	2026-08-05	WH-CHN-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11530	2026-08-05	WH-CHN-01	ITM-RAM-01	0	3	79	f	none	simulated	system_sim
11531	2026-08-05	WH-CHN-01	ITM-SSD-01	0	3	54	f	none	simulated	system_sim
11532	2026-08-05	WH-CHN-01	ITM-HDD-01	0	1	34	f	none	simulated	system_sim
11533	2026-08-05	WH-CHN-01	ITM-CHG-01	0	2	140	f	none	simulated	system_sim
11534	2026-08-05	WH-CHN-01	ITM-CBL-01	0	8	157	f	none	simulated	system_sim
11535	2026-08-05	WH-BOM-01	ITM-CPU-01	45	2	65	f	none	simulated	system_sim
11536	2026-08-05	WH-BOM-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
11537	2026-08-05	WH-BOM-01	ITM-RAM-01	0	3	107	f	none	simulated	system_sim
11538	2026-08-05	WH-BOM-01	ITM-SSD-01	0	2	66	f	none	simulated	system_sim
11539	2026-08-05	WH-BOM-01	ITM-HDD-01	0	2	85	f	none	simulated	system_sim
11540	2026-08-05	WH-BOM-01	ITM-CHG-01	0	5	179	f	none	simulated	system_sim
11541	2026-08-05	WH-BOM-01	ITM-CBL-01	0	8	177	f	none	simulated	system_sim
11542	2026-08-05	WH-DEL-01	ITM-CPU-01	0	1	55	f	none	simulated	system_sim
11543	2026-08-05	WH-DEL-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
11544	2026-08-05	WH-DEL-01	ITM-RAM-01	0	7	68	f	none	simulated	system_sim
11545	2026-08-05	WH-DEL-01	ITM-SSD-01	0	0	59	f	none	simulated	system_sim
11546	2026-08-05	WH-DEL-01	ITM-HDD-01	0	0	87	f	none	simulated	system_sim
11547	2026-08-05	WH-DEL-01	ITM-CHG-01	0	7	159	f	none	simulated	system_sim
11548	2026-08-05	WH-DEL-01	ITM-CBL-01	0	4	175	f	none	simulated	system_sim
11549	2026-08-05	WH-CCU-01	ITM-CPU-01	0	3	60	f	none	simulated	system_sim
11550	2026-08-05	WH-CCU-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
11551	2026-08-05	WH-CCU-01	ITM-RAM-01	0	2	101	f	none	simulated	system_sim
11552	2026-08-05	WH-CCU-01	ITM-SSD-01	0	0	71	f	none	simulated	system_sim
11553	2026-08-05	WH-CCU-01	ITM-HDD-01	0	3	38	f	none	simulated	system_sim
11554	2026-08-05	WH-CCU-01	ITM-CHG-01	0	3	159	f	none	simulated	system_sim
11555	2026-08-05	WH-CCU-01	ITM-CBL-01	0	10	168	f	none	simulated	system_sim
11556	2026-08-06	WH-BLR-01	ITM-CPU-01	0	2	58	f	none	simulated	system_sim
11557	2026-08-06	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
11558	2026-08-06	WH-BLR-01	ITM-RAM-01	0	4	90	f	none	simulated	system_sim
11559	2026-08-06	WH-BLR-01	ITM-SSD-01	0	1	63	f	none	simulated	system_sim
11560	2026-08-06	WH-BLR-01	ITM-HDD-01	60	0	88	f	none	simulated	system_sim
11561	2026-08-06	WH-BLR-01	ITM-CHG-01	0	10	156	f	none	simulated	system_sim
11562	2026-08-06	WH-BLR-01	ITM-CBL-01	0	3	158	f	none	simulated	system_sim
11563	2026-08-06	WH-CHN-01	ITM-CPU-01	0	1	43	f	none	simulated	system_sim
11564	2026-08-06	WH-CHN-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11565	2026-08-06	WH-CHN-01	ITM-RAM-01	0	2	77	f	none	simulated	system_sim
11566	2026-08-06	WH-CHN-01	ITM-SSD-01	0	0	54	f	none	simulated	system_sim
11567	2026-08-06	WH-CHN-01	ITM-HDD-01	0	1	33	f	none	simulated	system_sim
11568	2026-08-06	WH-CHN-01	ITM-CHG-01	0	4	136	f	none	simulated	system_sim
11569	2026-08-06	WH-CHN-01	ITM-CBL-01	0	2	155	f	none	simulated	system_sim
11570	2026-08-06	WH-BOM-01	ITM-CPU-01	0	0	65	f	none	simulated	system_sim
11571	2026-08-06	WH-BOM-01	ITM-GPU-01	0	1	21	f	none	simulated	system_sim
11572	2026-08-06	WH-BOM-01	ITM-RAM-01	0	2	105	f	none	simulated	system_sim
11573	2026-08-06	WH-BOM-01	ITM-SSD-01	0	1	65	f	none	simulated	system_sim
11574	2026-08-06	WH-BOM-01	ITM-HDD-01	0	1	84	f	none	simulated	system_sim
11575	2026-08-06	WH-BOM-01	ITM-CHG-01	0	9	170	f	none	simulated	system_sim
11576	2026-08-06	WH-BOM-01	ITM-CBL-01	0	5	172	f	none	simulated	system_sim
11577	2026-08-06	WH-DEL-01	ITM-CPU-01	0	3	52	f	none	simulated	system_sim
11578	2026-08-06	WH-DEL-01	ITM-GPU-01	0	2	35	f	none	simulated	system_sim
11579	2026-08-06	WH-DEL-01	ITM-RAM-01	0	8	60	f	none	simulated	system_sim
11580	2026-08-06	WH-DEL-01	ITM-SSD-01	0	3	56	f	none	simulated	system_sim
11581	2026-08-06	WH-DEL-01	ITM-HDD-01	0	0	87	f	none	simulated	system_sim
11582	2026-08-06	WH-DEL-01	ITM-CHG-01	0	9	150	f	none	simulated	system_sim
11583	2026-08-06	WH-DEL-01	ITM-CBL-01	0	7	168	f	none	simulated	system_sim
11584	2026-08-06	WH-CCU-01	ITM-CPU-01	0	3	57	f	none	simulated	system_sim
11585	2026-08-06	WH-CCU-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
11586	2026-08-06	WH-CCU-01	ITM-RAM-01	0	7	94	f	none	simulated	system_sim
11587	2026-08-06	WH-CCU-01	ITM-SSD-01	0	0	71	f	none	simulated	system_sim
11588	2026-08-06	WH-CCU-01	ITM-HDD-01	0	1	37	f	none	simulated	system_sim
11589	2026-08-06	WH-CCU-01	ITM-CHG-01	0	1	158	f	none	simulated	system_sim
11590	2026-08-06	WH-CCU-01	ITM-CBL-01	0	2	166	f	none	simulated	system_sim
11591	2026-08-07	WH-BLR-01	ITM-CPU-01	0	2	56	f	none	simulated	system_sim
11592	2026-08-07	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
11593	2026-08-07	WH-BLR-01	ITM-RAM-01	0	8	82	f	none	simulated	system_sim
11594	2026-08-07	WH-BLR-01	ITM-SSD-01	0	2	61	f	none	simulated	system_sim
11595	2026-08-07	WH-BLR-01	ITM-HDD-01	0	0	88	f	none	simulated	system_sim
11596	2026-08-07	WH-BLR-01	ITM-CHG-01	0	8	148	f	none	simulated	system_sim
11597	2026-08-07	WH-BLR-01	ITM-CBL-01	0	7	151	f	none	simulated	system_sim
11598	2026-08-07	WH-CHN-01	ITM-CPU-01	0	0	43	f	none	simulated	system_sim
11599	2026-08-07	WH-CHN-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11600	2026-08-07	WH-CHN-01	ITM-RAM-01	0	1	76	f	none	simulated	system_sim
11601	2026-08-07	WH-CHN-01	ITM-SSD-01	0	3	51	f	none	simulated	system_sim
11602	2026-08-07	WH-CHN-01	ITM-HDD-01	0	3	30	f	none	simulated	system_sim
11603	2026-08-07	WH-CHN-01	ITM-CHG-01	0	7	129	f	none	simulated	system_sim
11604	2026-08-07	WH-CHN-01	ITM-CBL-01	0	7	148	f	none	simulated	system_sim
11605	2026-08-07	WH-BOM-01	ITM-CPU-01	0	1	64	f	none	simulated	system_sim
11606	2026-08-07	WH-BOM-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
11607	2026-08-07	WH-BOM-01	ITM-RAM-01	0	7	98	f	none	simulated	system_sim
11608	2026-08-07	WH-BOM-01	ITM-SSD-01	0	1	64	f	none	simulated	system_sim
11609	2026-08-07	WH-BOM-01	ITM-HDD-01	0	3	81	f	none	simulated	system_sim
11610	2026-08-07	WH-BOM-01	ITM-CHG-01	0	1	169	f	none	simulated	system_sim
11611	2026-08-07	WH-BOM-01	ITM-CBL-01	0	1	171	f	none	simulated	system_sim
11612	2026-08-07	WH-DEL-01	ITM-CPU-01	0	2	50	f	none	simulated	system_sim
11613	2026-08-07	WH-DEL-01	ITM-GPU-01	0	0	35	f	none	simulated	system_sim
11614	2026-08-07	WH-DEL-01	ITM-RAM-01	0	3	57	f	none	simulated	system_sim
11615	2026-08-07	WH-DEL-01	ITM-SSD-01	0	0	56	f	none	simulated	system_sim
11616	2026-08-07	WH-DEL-01	ITM-HDD-01	0	1	86	f	none	simulated	system_sim
11617	2026-08-07	WH-DEL-01	ITM-CHG-01	0	3	147	f	none	simulated	system_sim
11618	2026-08-07	WH-DEL-01	ITM-CBL-01	0	7	161	f	none	simulated	system_sim
11619	2026-08-07	WH-CCU-01	ITM-CPU-01	0	2	55	f	none	simulated	system_sim
11620	2026-08-07	WH-CCU-01	ITM-GPU-01	0	1	15	f	none	simulated	system_sim
11621	2026-08-07	WH-CCU-01	ITM-RAM-01	0	5	89	f	none	simulated	system_sim
11622	2026-08-07	WH-CCU-01	ITM-SSD-01	0	3	68	f	none	simulated	system_sim
11623	2026-08-07	WH-CCU-01	ITM-HDD-01	0	0	37	f	none	simulated	system_sim
11624	2026-08-07	WH-CCU-01	ITM-CHG-01	0	4	154	f	none	simulated	system_sim
11625	2026-08-07	WH-CCU-01	ITM-CBL-01	0	8	158	f	none	simulated	system_sim
11626	2026-08-08	WH-BLR-01	ITM-CPU-01	0	1	55	f	none	simulated	system_sim
11627	2026-08-08	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
11628	2026-08-08	WH-BLR-01	ITM-RAM-01	0	3	79	f	none	simulated	system_sim
11629	2026-08-08	WH-BLR-01	ITM-SSD-01	0	1	60	f	none	simulated	system_sim
11630	2026-08-08	WH-BLR-01	ITM-HDD-01	0	1	87	f	none	simulated	system_sim
11631	2026-08-08	WH-BLR-01	ITM-CHG-01	0	4	144	f	none	simulated	system_sim
11632	2026-08-08	WH-BLR-01	ITM-CBL-01	0	10	141	f	none	simulated	system_sim
11633	2026-08-08	WH-CHN-01	ITM-CPU-01	0	1	42	f	none	simulated	system_sim
11634	2026-08-08	WH-CHN-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11635	2026-08-08	WH-CHN-01	ITM-RAM-01	0	3	73	f	none	simulated	system_sim
11636	2026-08-08	WH-CHN-01	ITM-SSD-01	0	0	51	f	none	simulated	system_sim
11637	2026-08-08	WH-CHN-01	ITM-HDD-01	0	0	30	f	none	simulated	system_sim
11638	2026-08-08	WH-CHN-01	ITM-CHG-01	0	10	119	f	none	simulated	system_sim
11639	2026-08-08	WH-CHN-01	ITM-CBL-01	300	3	445	f	none	simulated	system_sim
11640	2026-08-08	WH-BOM-01	ITM-CPU-01	0	1	63	f	none	simulated	system_sim
11641	2026-08-08	WH-BOM-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
11642	2026-08-08	WH-BOM-01	ITM-RAM-01	0	1	97	f	none	simulated	system_sim
11643	2026-08-08	WH-BOM-01	ITM-SSD-01	0	3	61	f	none	simulated	system_sim
11644	2026-08-08	WH-BOM-01	ITM-HDD-01	0	2	79	f	none	simulated	system_sim
11645	2026-08-08	WH-BOM-01	ITM-CHG-01	0	6	163	f	none	simulated	system_sim
11646	2026-08-08	WH-BOM-01	ITM-CBL-01	0	2	169	f	none	simulated	system_sim
11647	2026-08-08	WH-DEL-01	ITM-CPU-01	0	1	49	f	none	simulated	system_sim
11648	2026-08-08	WH-DEL-01	ITM-GPU-01	0	1	34	f	none	simulated	system_sim
11649	2026-08-08	WH-DEL-01	ITM-RAM-01	0	10	47	f	none	simulated	system_sim
11650	2026-08-08	WH-DEL-01	ITM-SSD-01	0	0	56	f	none	simulated	system_sim
11651	2026-08-08	WH-DEL-01	ITM-HDD-01	0	0	86	f	none	simulated	system_sim
11652	2026-08-08	WH-DEL-01	ITM-CHG-01	0	3	144	f	none	simulated	system_sim
11653	2026-08-08	WH-DEL-01	ITM-CBL-01	0	1	160	f	none	simulated	system_sim
11654	2026-08-08	WH-CCU-01	ITM-CPU-01	0	2	53	f	none	simulated	system_sim
11655	2026-08-08	WH-CCU-01	ITM-GPU-01	0	1	14	f	none	simulated	system_sim
11656	2026-08-08	WH-CCU-01	ITM-RAM-01	0	3	86	f	none	simulated	system_sim
11657	2026-08-08	WH-CCU-01	ITM-SSD-01	0	0	68	f	none	simulated	system_sim
11658	2026-08-08	WH-CCU-01	ITM-HDD-01	0	0	37	f	none	simulated	system_sim
11659	2026-08-08	WH-CCU-01	ITM-CHG-01	0	3	151	f	none	simulated	system_sim
11660	2026-08-08	WH-CCU-01	ITM-CBL-01	0	1	157	f	none	simulated	system_sim
11661	2026-08-09	WH-BLR-01	ITM-CPU-01	0	0	55	f	none	simulated	system_sim
11662	2026-08-09	WH-BLR-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
11663	2026-08-09	WH-BLR-01	ITM-RAM-01	0	5	74	f	none	simulated	system_sim
11664	2026-08-09	WH-BLR-01	ITM-SSD-01	0	0	60	f	none	simulated	system_sim
11665	2026-08-09	WH-BLR-01	ITM-HDD-01	0	3	84	f	none	simulated	system_sim
11666	2026-08-09	WH-BLR-01	ITM-CHG-01	0	5	139	f	none	simulated	system_sim
11667	2026-08-09	WH-BLR-01	ITM-CBL-01	300	8	433	f	none	simulated	system_sim
11668	2026-08-09	WH-CHN-01	ITM-CPU-01	0	1	41	f	none	simulated	system_sim
11669	2026-08-09	WH-CHN-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11670	2026-08-09	WH-CHN-01	ITM-RAM-01	0	1	72	f	none	simulated	system_sim
11671	2026-08-09	WH-CHN-01	ITM-SSD-01	0	1	50	f	none	simulated	system_sim
11672	2026-08-09	WH-CHN-01	ITM-HDD-01	0	2	28	f	none	simulated	system_sim
11673	2026-08-09	WH-CHN-01	ITM-CHG-01	0	3	116	f	none	simulated	system_sim
11674	2026-08-09	WH-CHN-01	ITM-CBL-01	0	8	437	f	none	simulated	system_sim
11675	2026-08-09	WH-BOM-01	ITM-CPU-01	0	2	61	f	none	simulated	system_sim
11676	2026-08-09	WH-BOM-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
11677	2026-08-09	WH-BOM-01	ITM-RAM-01	0	5	92	f	none	simulated	system_sim
11678	2026-08-09	WH-BOM-01	ITM-SSD-01	0	2	59	f	none	simulated	system_sim
11679	2026-08-09	WH-BOM-01	ITM-HDD-01	0	2	77	f	none	simulated	system_sim
11680	2026-08-09	WH-BOM-01	ITM-CHG-01	0	10	153	f	none	simulated	system_sim
11681	2026-08-09	WH-BOM-01	ITM-CBL-01	0	4	165	f	none	simulated	system_sim
11682	2026-08-09	WH-DEL-01	ITM-CPU-01	0	0	49	f	none	simulated	system_sim
11683	2026-08-09	WH-DEL-01	ITM-GPU-01	0	0	34	f	none	simulated	system_sim
11684	2026-08-09	WH-DEL-01	ITM-RAM-01	0	6	41	f	none	simulated	system_sim
11685	2026-08-09	WH-DEL-01	ITM-SSD-01	0	2	54	f	none	simulated	system_sim
11686	2026-08-09	WH-DEL-01	ITM-HDD-01	0	1	85	f	none	simulated	system_sim
11687	2026-08-09	WH-DEL-01	ITM-CHG-01	0	7	137	f	none	simulated	system_sim
11688	2026-08-09	WH-DEL-01	ITM-CBL-01	0	8	152	f	none	simulated	system_sim
11689	2026-08-09	WH-CCU-01	ITM-CPU-01	0	0	53	f	none	simulated	system_sim
11690	2026-08-09	WH-CCU-01	ITM-GPU-01	30	0	44	f	none	simulated	system_sim
11691	2026-08-09	WH-CCU-01	ITM-RAM-01	0	3	83	f	none	simulated	system_sim
11692	2026-08-09	WH-CCU-01	ITM-SSD-01	0	0	68	f	none	simulated	system_sim
11693	2026-08-09	WH-CCU-01	ITM-HDD-01	0	2	35	f	none	simulated	system_sim
11694	2026-08-09	WH-CCU-01	ITM-CHG-01	0	8	143	f	none	simulated	system_sim
11695	2026-08-09	WH-CCU-01	ITM-CBL-01	0	1	156	f	none	simulated	system_sim
11696	2026-08-10	WH-BLR-01	ITM-CPU-01	0	3	52	f	none	simulated	system_sim
11697	2026-08-10	WH-BLR-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
11698	2026-08-10	WH-BLR-01	ITM-RAM-01	0	3	71	f	none	simulated	system_sim
11699	2026-08-10	WH-BLR-01	ITM-SSD-01	0	0	60	f	none	simulated	system_sim
11700	2026-08-10	WH-BLR-01	ITM-HDD-01	0	1	83	f	none	simulated	system_sim
11701	2026-08-10	WH-BLR-01	ITM-CHG-01	0	8	131	f	none	simulated	system_sim
11702	2026-08-10	WH-BLR-01	ITM-CBL-01	0	9	424	f	none	simulated	system_sim
11703	2026-08-10	WH-CHN-01	ITM-CPU-01	0	1	40	f	none	simulated	system_sim
11704	2026-08-10	WH-CHN-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
11705	2026-08-10	WH-CHN-01	ITM-RAM-01	0	4	68	f	none	simulated	system_sim
11706	2026-08-10	WH-CHN-01	ITM-SSD-01	0	2	48	f	none	simulated	system_sim
11707	2026-08-10	WH-CHN-01	ITM-HDD-01	60	3	85	f	none	simulated	system_sim
11708	2026-08-10	WH-CHN-01	ITM-CHG-01	0	2	114	f	none	simulated	system_sim
11709	2026-08-10	WH-CHN-01	ITM-CBL-01	0	6	431	f	none	simulated	system_sim
11710	2026-08-10	WH-BOM-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
11711	2026-08-10	WH-BOM-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
11712	2026-08-10	WH-BOM-01	ITM-RAM-01	0	3	89	f	none	simulated	system_sim
11713	2026-08-10	WH-BOM-01	ITM-SSD-01	0	3	56	f	none	simulated	system_sim
11714	2026-08-10	WH-BOM-01	ITM-HDD-01	0	3	74	f	none	simulated	system_sim
11715	2026-08-10	WH-BOM-01	ITM-CHG-01	0	9	144	f	none	simulated	system_sim
11716	2026-08-10	WH-BOM-01	ITM-CBL-01	0	9	156	f	none	simulated	system_sim
11717	2026-08-10	WH-DEL-01	ITM-CPU-01	0	0	49	f	none	simulated	system_sim
11718	2026-08-10	WH-DEL-01	ITM-GPU-01	0	0	34	f	none	simulated	system_sim
11719	2026-08-10	WH-DEL-01	ITM-RAM-01	0	7	34	f	none	simulated	system_sim
11720	2026-08-10	WH-DEL-01	ITM-SSD-01	0	0	54	f	none	simulated	system_sim
11721	2026-08-10	WH-DEL-01	ITM-HDD-01	0	0	85	f	none	simulated	system_sim
11722	2026-08-10	WH-DEL-01	ITM-CHG-01	0	2	135	f	none	simulated	system_sim
11723	2026-08-10	WH-DEL-01	ITM-CBL-01	0	8	144	f	none	simulated	system_sim
11724	2026-08-10	WH-CCU-01	ITM-CPU-01	0	0	53	f	none	simulated	system_sim
11725	2026-08-10	WH-CCU-01	ITM-GPU-01	0	0	44	f	none	simulated	system_sim
11726	2026-08-10	WH-CCU-01	ITM-RAM-01	0	10	73	f	none	simulated	system_sim
11727	2026-08-10	WH-CCU-01	ITM-SSD-01	0	3	65	f	none	simulated	system_sim
11728	2026-08-10	WH-CCU-01	ITM-HDD-01	0	0	35	f	none	simulated	system_sim
11729	2026-08-10	WH-CCU-01	ITM-CHG-01	0	10	133	f	none	simulated	system_sim
11730	2026-08-10	WH-CCU-01	ITM-CBL-01	0	8	148	f	none	simulated	system_sim
11731	2026-08-11	WH-BLR-01	ITM-CPU-01	0	0	52	f	none	simulated	system_sim
11732	2026-08-11	WH-BLR-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
11733	2026-08-11	WH-BLR-01	ITM-RAM-01	0	1	70	f	none	simulated	system_sim
11734	2026-08-11	WH-BLR-01	ITM-SSD-01	0	2	58	f	none	simulated	system_sim
11735	2026-08-11	WH-BLR-01	ITM-HDD-01	0	0	83	f	none	simulated	system_sim
11736	2026-08-11	WH-BLR-01	ITM-CHG-01	0	9	122	f	none	simulated	system_sim
11737	2026-08-11	WH-BLR-01	ITM-CBL-01	0	3	421	f	none	simulated	system_sim
11738	2026-08-11	WH-CHN-01	ITM-CPU-01	0	2	38	f	none	simulated	system_sim
11739	2026-08-11	WH-CHN-01	ITM-GPU-01	0	1	16	f	none	simulated	system_sim
11740	2026-08-11	WH-CHN-01	ITM-RAM-01	0	7	61	f	none	simulated	system_sim
11741	2026-08-11	WH-CHN-01	ITM-SSD-01	0	2	46	f	none	simulated	system_sim
11742	2026-08-11	WH-CHN-01	ITM-HDD-01	0	3	82	f	none	simulated	system_sim
11743	2026-08-11	WH-CHN-01	ITM-CHG-01	0	9	105	f	none	simulated	system_sim
11744	2026-08-11	WH-CHN-01	ITM-CBL-01	0	10	421	f	none	simulated	system_sim
11745	2026-08-11	WH-BOM-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
11746	2026-08-11	WH-BOM-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
11747	2026-08-11	WH-BOM-01	ITM-RAM-01	0	6	83	f	none	simulated	system_sim
11748	2026-08-11	WH-BOM-01	ITM-SSD-01	0	0	56	f	none	simulated	system_sim
11749	2026-08-11	WH-BOM-01	ITM-HDD-01	0	3	71	f	none	simulated	system_sim
11750	2026-08-11	WH-BOM-01	ITM-CHG-01	0	9	135	f	none	simulated	system_sim
11751	2026-08-11	WH-BOM-01	ITM-CBL-01	0	3	153	f	none	simulated	system_sim
11752	2026-08-11	WH-DEL-01	ITM-CPU-01	0	1	48	f	none	simulated	system_sim
11753	2026-08-11	WH-DEL-01	ITM-GPU-01	0	0	34	f	none	simulated	system_sim
11754	2026-08-11	WH-DEL-01	ITM-RAM-01	75	4	105	f	none	simulated	system_sim
11755	2026-08-11	WH-DEL-01	ITM-SSD-01	0	1	53	f	none	simulated	system_sim
11756	2026-08-11	WH-DEL-01	ITM-HDD-01	0	0	85	f	none	simulated	system_sim
11757	2026-08-11	WH-DEL-01	ITM-CHG-01	0	10	125	f	none	simulated	system_sim
11758	2026-08-11	WH-DEL-01	ITM-CBL-01	300	9	435	f	none	simulated	system_sim
11759	2026-08-11	WH-CCU-01	ITM-CPU-01	0	2	51	f	none	simulated	system_sim
11760	2026-08-11	WH-CCU-01	ITM-GPU-01	0	0	44	f	none	simulated	system_sim
11761	2026-08-11	WH-CCU-01	ITM-RAM-01	0	2	71	f	none	simulated	system_sim
11762	2026-08-11	WH-CCU-01	ITM-SSD-01	0	0	65	f	none	simulated	system_sim
11763	2026-08-11	WH-CCU-01	ITM-HDD-01	0	0	35	f	none	simulated	system_sim
11764	2026-08-11	WH-CCU-01	ITM-CHG-01	0	1	132	f	none	simulated	system_sim
11765	2026-08-11	WH-CCU-01	ITM-CBL-01	300	8	440	f	none	simulated	system_sim
\.


--
-- Data for Name: system_health_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_health_snapshots (id, service, status, latency_ms, "timestamp") FROM stdin;
1	database	HEALTHY	0	2026-08-19 15:43:16.958992
2	redis	NOT_CONFIGURED	\N	2026-08-19 15:43:16.958992
3	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:43:16.958992
4	celery	NOT_CONFIGURED	\N	2026-08-19 15:43:16.958992
5	email	HEALTHY	\N	2026-08-19 15:43:16.958992
6	backup	DEGRADED	\N	2026-08-19 15:43:16.960009
7	sentry	NOT_CONFIGURED	\N	2026-08-19 15:43:16.960009
8	openai	NOT_CONFIGURED	\N	2026-08-19 15:43:16.960009
9	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:43:16.960009
10	simulation	HEALTHY	\N	2026-08-19 15:43:16.960009
11	application	HEALTHY	4.5	2026-08-19 15:43:16.960009
12	database	HEALTHY	5.94	2026-08-19 15:43:47.085618
13	redis	NOT_CONFIGURED	\N	2026-08-19 15:43:47.085618
14	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:43:47.086299
15	celery	NOT_CONFIGURED	\N	2026-08-19 15:43:47.086299
16	email	HEALTHY	\N	2026-08-19 15:43:47.086299
17	backup	DEGRADED	\N	2026-08-19 15:43:47.086299
18	sentry	NOT_CONFIGURED	\N	2026-08-19 15:43:47.086299
19	openai	NOT_CONFIGURED	\N	2026-08-19 15:43:47.086299
20	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:43:47.086299
21	simulation	HEALTHY	\N	2026-08-19 15:43:47.086299
22	application	HEALTHY	4.5	2026-08-19 15:43:47.086299
23	database	HEALTHY	3.02	2026-08-19 15:44:17.211859
24	redis	NOT_CONFIGURED	\N	2026-08-19 15:44:17.211859
25	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:44:17.211859
26	celery	NOT_CONFIGURED	\N	2026-08-19 15:44:17.211859
27	email	HEALTHY	\N	2026-08-19 15:44:17.211859
28	backup	DEGRADED	\N	2026-08-19 15:44:17.211859
29	sentry	NOT_CONFIGURED	\N	2026-08-19 15:44:17.211859
30	openai	NOT_CONFIGURED	\N	2026-08-19 15:44:17.212864
31	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:44:17.212864
32	simulation	HEALTHY	\N	2026-08-19 15:44:17.212864
33	application	HEALTHY	4.5	2026-08-19 15:44:17.212864
34	database	HEALTHY	5.99	2026-08-19 15:44:47.457941
35	redis	NOT_CONFIGURED	\N	2026-08-19 15:44:47.457941
36	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:44:47.458945
37	celery	NOT_CONFIGURED	\N	2026-08-19 15:44:47.458945
38	email	HEALTHY	\N	2026-08-19 15:44:47.458945
39	backup	DEGRADED	\N	2026-08-19 15:44:47.458945
40	sentry	NOT_CONFIGURED	\N	2026-08-19 15:44:47.458945
41	openai	NOT_CONFIGURED	\N	2026-08-19 15:44:47.458945
42	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:44:47.458945
43	simulation	HEALTHY	\N	2026-08-19 15:44:47.458945
44	application	HEALTHY	4.5	2026-08-19 15:44:47.458945
45	database	HEALTHY	3.71	2026-08-19 15:45:17.632382
46	redis	NOT_CONFIGURED	\N	2026-08-19 15:45:17.632382
47	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:45:17.632382
48	celery	NOT_CONFIGURED	\N	2026-08-19 15:45:17.632382
49	email	HEALTHY	\N	2026-08-19 15:45:17.632382
50	backup	DEGRADED	\N	2026-08-19 15:45:17.632382
51	sentry	NOT_CONFIGURED	\N	2026-08-19 15:45:17.632382
52	openai	NOT_CONFIGURED	\N	2026-08-19 15:45:17.632382
53	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:45:17.632382
54	simulation	HEALTHY	\N	2026-08-19 15:45:17.632382
55	application	HEALTHY	4.5	2026-08-19 15:45:17.632382
56	database	HEALTHY	1	2026-08-19 15:45:47.689904
57	redis	NOT_CONFIGURED	\N	2026-08-19 15:45:47.689904
58	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:45:47.689904
59	celery	NOT_CONFIGURED	\N	2026-08-19 15:45:47.689904
60	email	HEALTHY	\N	2026-08-19 15:45:47.689904
61	backup	DEGRADED	\N	2026-08-19 15:45:47.689904
62	sentry	NOT_CONFIGURED	\N	2026-08-19 15:45:47.689904
63	openai	NOT_CONFIGURED	\N	2026-08-19 15:45:47.689904
64	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:45:47.689904
65	simulation	HEALTHY	\N	2026-08-19 15:45:47.689904
66	application	HEALTHY	4.5	2026-08-19 15:45:47.689904
67	database	HEALTHY	1	2026-08-19 15:46:17.753805
68	redis	NOT_CONFIGURED	\N	2026-08-19 15:46:17.753805
69	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:46:17.753805
70	celery	NOT_CONFIGURED	\N	2026-08-19 15:46:17.753805
71	email	HEALTHY	\N	2026-08-19 15:46:17.753805
72	backup	DEGRADED	\N	2026-08-19 15:46:17.753805
73	sentry	NOT_CONFIGURED	\N	2026-08-19 15:46:17.753805
74	openai	NOT_CONFIGURED	\N	2026-08-19 15:46:17.753805
75	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:46:17.753805
76	simulation	HEALTHY	\N	2026-08-19 15:46:17.753805
77	application	HEALTHY	4.5	2026-08-19 15:46:17.753805
78	database	HEALTHY	1	2026-08-19 15:46:47.800965
79	redis	NOT_CONFIGURED	\N	2026-08-19 15:46:47.800965
80	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:46:47.800965
81	celery	NOT_CONFIGURED	\N	2026-08-19 15:46:47.800965
82	email	HEALTHY	\N	2026-08-19 15:46:47.80197
83	backup	DEGRADED	\N	2026-08-19 15:46:47.80197
84	sentry	NOT_CONFIGURED	\N	2026-08-19 15:46:47.80197
85	openai	NOT_CONFIGURED	\N	2026-08-19 15:46:47.80197
86	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:46:47.80197
87	simulation	HEALTHY	\N	2026-08-19 15:46:47.80197
88	application	HEALTHY	4.5	2026-08-19 15:46:47.80197
89	database	HEALTHY	0	2026-08-19 15:47:17.84018
90	redis	NOT_CONFIGURED	\N	2026-08-19 15:47:17.84018
91	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:47:17.84018
92	celery	NOT_CONFIGURED	\N	2026-08-19 15:47:17.84018
93	email	HEALTHY	\N	2026-08-19 15:47:17.84018
94	backup	DEGRADED	\N	2026-08-19 15:47:17.84018
95	sentry	NOT_CONFIGURED	\N	2026-08-19 15:47:17.84018
96	openai	NOT_CONFIGURED	\N	2026-08-19 15:47:17.84018
97	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:47:17.84018
98	simulation	HEALTHY	\N	2026-08-19 15:47:17.84018
99	application	HEALTHY	4.5	2026-08-19 15:47:17.84018
100	database	HEALTHY	0	2026-08-19 15:47:47.878138
101	redis	NOT_CONFIGURED	\N	2026-08-19 15:47:47.878138
102	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:47:47.878138
103	celery	NOT_CONFIGURED	\N	2026-08-19 15:47:47.878138
104	email	HEALTHY	\N	2026-08-19 15:47:47.878138
105	backup	DEGRADED	\N	2026-08-19 15:47:47.878138
106	sentry	NOT_CONFIGURED	\N	2026-08-19 15:47:47.878138
107	openai	NOT_CONFIGURED	\N	2026-08-19 15:47:47.879137
108	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:47:47.879137
109	simulation	HEALTHY	\N	2026-08-19 15:47:47.879137
110	application	HEALTHY	4.5	2026-08-19 15:47:47.879137
111	database	HEALTHY	0	2026-08-19 15:48:17.938924
112	redis	NOT_CONFIGURED	\N	2026-08-19 15:48:17.938924
113	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:48:17.938924
114	celery	NOT_CONFIGURED	\N	2026-08-19 15:48:17.938924
115	email	HEALTHY	\N	2026-08-19 15:48:17.938924
116	backup	DEGRADED	\N	2026-08-19 15:48:17.938924
117	sentry	NOT_CONFIGURED	\N	2026-08-19 15:48:17.938924
118	openai	NOT_CONFIGURED	\N	2026-08-19 15:48:17.938924
119	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:48:17.938924
120	simulation	HEALTHY	\N	2026-08-19 15:48:17.938924
121	application	HEALTHY	4.5	2026-08-19 15:48:17.938924
122	database	HEALTHY	0	2026-08-19 15:48:47.970409
123	redis	NOT_CONFIGURED	\N	2026-08-19 15:48:47.970409
124	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:48:47.970409
125	celery	NOT_CONFIGURED	\N	2026-08-19 15:48:47.970409
126	email	HEALTHY	\N	2026-08-19 15:48:47.970409
127	backup	DEGRADED	\N	2026-08-19 15:48:47.970409
128	sentry	NOT_CONFIGURED	\N	2026-08-19 15:48:47.970409
129	openai	NOT_CONFIGURED	\N	2026-08-19 15:48:47.970409
130	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:48:47.970409
131	simulation	HEALTHY	\N	2026-08-19 15:48:47.970409
132	application	HEALTHY	4.5	2026-08-19 15:48:47.970409
133	database	HEALTHY	0	2026-08-19 15:49:18.017824
134	redis	NOT_CONFIGURED	\N	2026-08-19 15:49:18.017824
135	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:49:18.017824
136	celery	NOT_CONFIGURED	\N	2026-08-19 15:49:18.017824
137	email	HEALTHY	\N	2026-08-19 15:49:18.017824
138	backup	DEGRADED	\N	2026-08-19 15:49:18.017824
139	sentry	NOT_CONFIGURED	\N	2026-08-19 15:49:18.017824
140	openai	NOT_CONFIGURED	\N	2026-08-19 15:49:18.017824
141	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:49:18.017824
142	simulation	HEALTHY	\N	2026-08-19 15:49:18.017824
143	application	HEALTHY	4.5	2026-08-19 15:49:18.017824
144	database	HEALTHY	0	2026-08-19 15:49:48.067227
145	redis	NOT_CONFIGURED	\N	2026-08-19 15:49:48.067227
146	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:49:48.067227
147	celery	NOT_CONFIGURED	\N	2026-08-19 15:49:48.067227
148	email	HEALTHY	\N	2026-08-19 15:49:48.067227
149	backup	DEGRADED	\N	2026-08-19 15:49:48.068228
150	sentry	NOT_CONFIGURED	\N	2026-08-19 15:49:48.068228
151	openai	NOT_CONFIGURED	\N	2026-08-19 15:49:48.068228
152	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:49:48.068228
153	simulation	HEALTHY	\N	2026-08-19 15:49:48.068228
154	application	HEALTHY	4.5	2026-08-19 15:49:48.068228
155	database	HEALTHY	0	2026-08-19 15:50:18.108276
156	redis	NOT_CONFIGURED	\N	2026-08-19 15:50:18.109288
157	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:50:18.109288
158	celery	NOT_CONFIGURED	\N	2026-08-19 15:50:18.109288
159	email	HEALTHY	\N	2026-08-19 15:50:18.109288
160	backup	DEGRADED	\N	2026-08-19 15:50:18.109288
161	sentry	NOT_CONFIGURED	\N	2026-08-19 15:50:18.109288
162	openai	NOT_CONFIGURED	\N	2026-08-19 15:50:18.109288
163	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:50:18.109288
164	simulation	HEALTHY	\N	2026-08-19 15:50:18.109288
165	application	HEALTHY	4.5	2026-08-19 15:50:18.109288
166	database	HEALTHY	0	2026-08-19 15:50:48.141889
167	redis	NOT_CONFIGURED	\N	2026-08-19 15:50:48.141889
168	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:50:48.141889
169	celery	NOT_CONFIGURED	\N	2026-08-19 15:50:48.141889
170	email	HEALTHY	\N	2026-08-19 15:50:48.141889
171	backup	DEGRADED	\N	2026-08-19 15:50:48.141889
172	sentry	NOT_CONFIGURED	\N	2026-08-19 15:50:48.143248
173	openai	NOT_CONFIGURED	\N	2026-08-19 15:50:48.143248
174	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:50:48.143248
175	simulation	HEALTHY	\N	2026-08-19 15:50:48.143248
176	application	HEALTHY	4.5	2026-08-19 15:50:48.143248
177	database	HEALTHY	0	2026-08-19 15:51:18.179254
178	redis	NOT_CONFIGURED	\N	2026-08-19 15:51:18.179254
179	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:51:18.179254
180	celery	NOT_CONFIGURED	\N	2026-08-19 15:51:18.180254
181	email	HEALTHY	\N	2026-08-19 15:51:18.180254
182	backup	DEGRADED	\N	2026-08-19 15:51:18.180254
183	sentry	NOT_CONFIGURED	\N	2026-08-19 15:51:18.180254
184	openai	NOT_CONFIGURED	\N	2026-08-19 15:51:18.180254
185	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:51:18.180254
186	simulation	HEALTHY	\N	2026-08-19 15:51:18.180254
187	application	HEALTHY	4.5	2026-08-19 15:51:18.180254
188	database	HEALTHY	0.69	2026-08-19 15:51:48.208362
189	redis	NOT_CONFIGURED	\N	2026-08-19 15:51:48.208362
190	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:51:48.208362
191	celery	NOT_CONFIGURED	\N	2026-08-19 15:51:48.208362
192	email	HEALTHY	\N	2026-08-19 15:51:48.208362
193	backup	DEGRADED	\N	2026-08-19 15:51:48.208362
194	sentry	NOT_CONFIGURED	\N	2026-08-19 15:51:48.208362
195	openai	NOT_CONFIGURED	\N	2026-08-19 15:51:48.208362
196	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:51:48.208362
197	simulation	HEALTHY	\N	2026-08-19 15:51:48.208362
198	application	HEALTHY	4.5	2026-08-19 15:51:48.208362
199	database	HEALTHY	1.02	2026-08-19 15:52:18.241292
200	redis	NOT_CONFIGURED	\N	2026-08-19 15:52:18.242297
201	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:52:18.242297
202	celery	NOT_CONFIGURED	\N	2026-08-19 15:52:18.242297
203	email	HEALTHY	\N	2026-08-19 15:52:18.242297
204	backup	DEGRADED	\N	2026-08-19 15:52:18.242297
205	sentry	NOT_CONFIGURED	\N	2026-08-19 15:52:18.242297
206	openai	NOT_CONFIGURED	\N	2026-08-19 15:52:18.242297
207	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:52:18.242297
208	simulation	HEALTHY	\N	2026-08-19 15:52:18.242297
209	application	HEALTHY	4.5	2026-08-19 15:52:18.242297
210	database	HEALTHY	1	2026-08-19 15:52:48.278019
211	redis	NOT_CONFIGURED	\N	2026-08-19 15:52:48.279014
212	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:52:48.279014
213	celery	NOT_CONFIGURED	\N	2026-08-19 15:52:48.279014
214	email	HEALTHY	\N	2026-08-19 15:52:48.279014
215	backup	DEGRADED	\N	2026-08-19 15:52:48.279014
216	sentry	NOT_CONFIGURED	\N	2026-08-19 15:52:48.279014
217	openai	NOT_CONFIGURED	\N	2026-08-19 15:52:48.279014
218	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:52:48.279014
219	simulation	HEALTHY	\N	2026-08-19 15:52:48.279014
220	application	HEALTHY	4.5	2026-08-19 15:52:48.279014
221	database	HEALTHY	1	2026-08-19 15:53:18.310184
222	redis	NOT_CONFIGURED	\N	2026-08-19 15:53:18.310184
223	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:53:18.310184
224	celery	NOT_CONFIGURED	\N	2026-08-19 15:53:18.310184
225	email	HEALTHY	\N	2026-08-19 15:53:18.310184
226	backup	DEGRADED	\N	2026-08-19 15:53:18.310184
227	sentry	NOT_CONFIGURED	\N	2026-08-19 15:53:18.310184
228	openai	NOT_CONFIGURED	\N	2026-08-19 15:53:18.310184
229	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:53:18.311185
230	simulation	HEALTHY	\N	2026-08-19 15:53:18.311185
231	application	HEALTHY	4.5	2026-08-19 15:53:18.311185
232	database	HEALTHY	1.05	2026-08-19 15:53:48.350893
233	redis	NOT_CONFIGURED	\N	2026-08-19 15:53:48.350893
234	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:53:48.350893
235	celery	NOT_CONFIGURED	\N	2026-08-19 15:53:48.350893
236	email	HEALTHY	\N	2026-08-19 15:53:48.350893
237	backup	DEGRADED	\N	2026-08-19 15:53:48.350893
238	sentry	NOT_CONFIGURED	\N	2026-08-19 15:53:48.350893
239	openai	NOT_CONFIGURED	\N	2026-08-19 15:53:48.350893
240	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:53:48.350893
241	simulation	HEALTHY	\N	2026-08-19 15:53:48.350893
242	application	HEALTHY	4.5	2026-08-19 15:53:48.350893
243	database	HEALTHY	0	2026-08-19 15:54:18.38665
244	redis	NOT_CONFIGURED	\N	2026-08-19 15:54:18.38665
245	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:54:18.38665
246	celery	NOT_CONFIGURED	\N	2026-08-19 15:54:18.38665
247	email	HEALTHY	\N	2026-08-19 15:54:18.38665
248	backup	DEGRADED	\N	2026-08-19 15:54:18.38665
249	sentry	NOT_CONFIGURED	\N	2026-08-19 15:54:18.38665
250	openai	NOT_CONFIGURED	\N	2026-08-19 15:54:18.38665
251	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:54:18.38665
252	simulation	HEALTHY	\N	2026-08-19 15:54:18.38665
253	application	HEALTHY	4.5	2026-08-19 15:54:18.38665
254	database	HEALTHY	0	2026-08-19 15:54:48.415246
255	redis	NOT_CONFIGURED	\N	2026-08-19 15:54:48.415246
256	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:54:48.415246
257	celery	NOT_CONFIGURED	\N	2026-08-19 15:54:48.415246
258	email	HEALTHY	\N	2026-08-19 15:54:48.415246
259	backup	DEGRADED	\N	2026-08-19 15:54:48.415246
260	sentry	NOT_CONFIGURED	\N	2026-08-19 15:54:48.415246
261	openai	NOT_CONFIGURED	\N	2026-08-19 15:54:48.415246
262	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:54:48.415246
263	simulation	HEALTHY	\N	2026-08-19 15:54:48.415246
264	application	HEALTHY	4.5	2026-08-19 15:54:48.415246
265	database	HEALTHY	1	2026-08-19 15:55:18.447024
266	redis	NOT_CONFIGURED	\N	2026-08-19 15:55:18.448023
267	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:55:18.448023
268	celery	NOT_CONFIGURED	\N	2026-08-19 15:55:18.448023
269	email	HEALTHY	\N	2026-08-19 15:55:18.448023
270	backup	DEGRADED	\N	2026-08-19 15:55:18.448023
271	sentry	NOT_CONFIGURED	\N	2026-08-19 15:55:18.448023
272	openai	NOT_CONFIGURED	\N	2026-08-19 15:55:18.448023
273	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:55:18.448023
274	simulation	HEALTHY	\N	2026-08-19 15:55:18.448023
275	application	HEALTHY	4.5	2026-08-19 15:55:18.448023
276	database	HEALTHY	0	2026-08-19 15:55:48.482337
277	redis	NOT_CONFIGURED	\N	2026-08-19 15:55:48.482337
278	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:55:48.482337
279	celery	NOT_CONFIGURED	\N	2026-08-19 15:55:48.482337
280	email	HEALTHY	\N	2026-08-19 15:55:48.482337
281	backup	DEGRADED	\N	2026-08-19 15:55:48.482337
282	sentry	NOT_CONFIGURED	\N	2026-08-19 15:55:48.482337
283	openai	NOT_CONFIGURED	\N	2026-08-19 15:55:48.482337
284	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:55:48.482337
285	simulation	HEALTHY	\N	2026-08-19 15:55:48.482337
286	application	HEALTHY	4.5	2026-08-19 15:55:48.482337
287	database	HEALTHY	1.66	2026-08-19 15:56:18.648095
288	redis	NOT_CONFIGURED	\N	2026-08-19 15:56:18.648095
289	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:56:18.648095
290	celery	NOT_CONFIGURED	\N	2026-08-19 15:56:18.648095
291	email	HEALTHY	\N	2026-08-19 15:56:18.648095
292	backup	DEGRADED	\N	2026-08-19 15:56:18.648095
293	sentry	NOT_CONFIGURED	\N	2026-08-19 15:56:18.648095
294	openai	NOT_CONFIGURED	\N	2026-08-19 15:56:18.648095
295	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:56:18.648095
296	simulation	HEALTHY	\N	2026-08-19 15:56:18.648095
297	application	HEALTHY	4.5	2026-08-19 15:56:18.648095
298	database	HEALTHY	0	2026-08-19 15:56:48.675899
299	redis	NOT_CONFIGURED	\N	2026-08-19 15:56:48.675899
300	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:56:48.675899
301	celery	NOT_CONFIGURED	\N	2026-08-19 15:56:48.675899
302	email	HEALTHY	\N	2026-08-19 15:56:48.675899
303	backup	DEGRADED	\N	2026-08-19 15:56:48.675899
304	sentry	NOT_CONFIGURED	\N	2026-08-19 15:56:48.675899
305	openai	NOT_CONFIGURED	\N	2026-08-19 15:56:48.675899
306	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:56:48.675899
307	simulation	HEALTHY	\N	2026-08-19 15:56:48.675899
308	application	HEALTHY	4.5	2026-08-19 15:56:48.675899
309	database	HEALTHY	0	2026-08-19 15:57:18.709025
310	redis	NOT_CONFIGURED	\N	2026-08-19 15:57:18.710392
311	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:57:18.710392
312	celery	NOT_CONFIGURED	\N	2026-08-19 15:57:18.710392
313	email	HEALTHY	\N	2026-08-19 15:57:18.710392
314	backup	DEGRADED	\N	2026-08-19 15:57:18.710392
315	sentry	NOT_CONFIGURED	\N	2026-08-19 15:57:18.710392
316	openai	NOT_CONFIGURED	\N	2026-08-19 15:57:18.710392
317	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:57:18.710392
318	simulation	HEALTHY	\N	2026-08-19 15:57:18.710392
319	application	HEALTHY	4.5	2026-08-19 15:57:18.710392
320	database	HEALTHY	0.51	2026-08-19 15:57:48.749251
321	redis	NOT_CONFIGURED	\N	2026-08-19 15:57:48.750811
322	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:57:48.750811
323	celery	NOT_CONFIGURED	\N	2026-08-19 15:57:48.750811
324	email	HEALTHY	\N	2026-08-19 15:57:48.750811
325	backup	DEGRADED	\N	2026-08-19 15:57:48.750811
326	sentry	NOT_CONFIGURED	\N	2026-08-19 15:57:48.750811
327	openai	NOT_CONFIGURED	\N	2026-08-19 15:57:48.750811
328	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:57:48.750811
329	simulation	HEALTHY	\N	2026-08-19 15:57:48.750811
330	application	HEALTHY	4.5	2026-08-19 15:57:48.750811
331	database	HEALTHY	0	2026-08-19 15:58:18.775742
332	redis	NOT_CONFIGURED	\N	2026-08-19 15:58:18.775742
333	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:58:18.775742
334	celery	NOT_CONFIGURED	\N	2026-08-19 15:58:18.775742
335	email	HEALTHY	\N	2026-08-19 15:58:18.775742
336	backup	DEGRADED	\N	2026-08-19 15:58:18.775742
337	sentry	NOT_CONFIGURED	\N	2026-08-19 15:58:18.775742
338	openai	NOT_CONFIGURED	\N	2026-08-19 15:58:18.775742
339	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:58:18.775742
340	simulation	HEALTHY	\N	2026-08-19 15:58:18.775742
341	application	HEALTHY	4.5	2026-08-19 15:58:18.776745
342	database	HEALTHY	1	2026-08-19 15:58:48.839837
343	redis	NOT_CONFIGURED	\N	2026-08-19 15:58:48.839837
344	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:58:48.839837
345	celery	NOT_CONFIGURED	\N	2026-08-19 15:58:48.839837
346	email	HEALTHY	\N	2026-08-19 15:58:48.839837
347	backup	DEGRADED	\N	2026-08-19 15:58:48.839837
348	sentry	NOT_CONFIGURED	\N	2026-08-19 15:58:48.840835
349	openai	NOT_CONFIGURED	\N	2026-08-19 15:58:48.840835
350	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:58:48.840835
351	simulation	HEALTHY	\N	2026-08-19 15:58:48.840835
352	application	HEALTHY	4.5	2026-08-19 15:58:48.840835
353	database	HEALTHY	0	2026-08-19 15:59:18.887093
354	redis	NOT_CONFIGURED	\N	2026-08-19 15:59:18.887093
355	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:59:18.887093
356	celery	NOT_CONFIGURED	\N	2026-08-19 15:59:18.887093
357	email	HEALTHY	\N	2026-08-19 15:59:18.887093
358	backup	DEGRADED	\N	2026-08-19 15:59:18.887093
359	sentry	NOT_CONFIGURED	\N	2026-08-19 15:59:18.887093
360	openai	NOT_CONFIGURED	\N	2026-08-19 15:59:18.887093
361	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:59:18.887093
362	simulation	HEALTHY	\N	2026-08-19 15:59:18.887093
363	application	HEALTHY	4.5	2026-08-19 15:59:18.887093
364	database	HEALTHY	2	2026-08-19 15:59:48.921252
365	redis	NOT_CONFIGURED	\N	2026-08-19 15:59:48.922252
366	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 15:59:48.922252
367	celery	NOT_CONFIGURED	\N	2026-08-19 15:59:48.922252
368	email	HEALTHY	\N	2026-08-19 15:59:48.922252
369	backup	DEGRADED	\N	2026-08-19 15:59:48.922252
370	sentry	NOT_CONFIGURED	\N	2026-08-19 15:59:48.922252
371	openai	NOT_CONFIGURED	\N	2026-08-19 15:59:48.922252
372	cloudflare	NOT_CONFIGURED	\N	2026-08-19 15:59:48.922252
373	simulation	HEALTHY	\N	2026-08-19 15:59:48.922252
374	application	HEALTHY	4.5	2026-08-19 15:59:48.922252
375	database	HEALTHY	0.72	2026-08-19 16:00:18.986965
376	redis	NOT_CONFIGURED	\N	2026-08-19 16:00:18.986965
377	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:00:18.986965
378	celery	NOT_CONFIGURED	\N	2026-08-19 16:00:18.986965
379	email	HEALTHY	\N	2026-08-19 16:00:18.986965
380	backup	DEGRADED	\N	2026-08-19 16:00:18.986965
381	sentry	NOT_CONFIGURED	\N	2026-08-19 16:00:18.986965
382	openai	NOT_CONFIGURED	\N	2026-08-19 16:00:18.986965
383	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:00:18.986965
384	simulation	HEALTHY	\N	2026-08-19 16:00:18.986965
385	application	HEALTHY	4.5	2026-08-19 16:00:18.986965
386	database	HEALTHY	0	2026-08-19 16:00:49.058315
387	redis	NOT_CONFIGURED	\N	2026-08-19 16:00:49.058315
388	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:00:49.059309
389	celery	NOT_CONFIGURED	\N	2026-08-19 16:00:49.059309
390	email	HEALTHY	\N	2026-08-19 16:00:49.059309
391	backup	DEGRADED	\N	2026-08-19 16:00:49.059309
392	sentry	NOT_CONFIGURED	\N	2026-08-19 16:00:49.059309
393	openai	NOT_CONFIGURED	\N	2026-08-19 16:00:49.059309
394	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:00:49.059309
395	simulation	HEALTHY	\N	2026-08-19 16:00:49.059309
396	application	HEALTHY	4.5	2026-08-19 16:00:49.059309
397	database	HEALTHY	0.99	2026-08-19 16:01:19.090784
398	redis	NOT_CONFIGURED	\N	2026-08-19 16:01:19.090784
399	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:01:19.090784
400	celery	NOT_CONFIGURED	\N	2026-08-19 16:01:19.090784
401	email	HEALTHY	\N	2026-08-19 16:01:19.090784
402	backup	DEGRADED	\N	2026-08-19 16:01:19.090784
403	sentry	NOT_CONFIGURED	\N	2026-08-19 16:01:19.090784
404	openai	NOT_CONFIGURED	\N	2026-08-19 16:01:19.090784
405	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:01:19.090784
406	simulation	HEALTHY	\N	2026-08-19 16:01:19.090784
407	application	HEALTHY	4.5	2026-08-19 16:01:19.090784
408	database	HEALTHY	1	2026-08-19 16:01:49.238816
409	redis	NOT_CONFIGURED	\N	2026-08-19 16:01:49.238816
410	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:01:49.238816
411	celery	NOT_CONFIGURED	\N	2026-08-19 16:01:49.238816
412	email	HEALTHY	\N	2026-08-19 16:01:49.238816
413	backup	DEGRADED	\N	2026-08-19 16:01:49.238816
414	sentry	NOT_CONFIGURED	\N	2026-08-19 16:01:49.238816
415	openai	NOT_CONFIGURED	\N	2026-08-19 16:01:49.239799
416	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:01:49.239799
417	simulation	HEALTHY	\N	2026-08-19 16:01:49.239799
418	application	HEALTHY	4.5	2026-08-19 16:01:49.239799
419	database	HEALTHY	1	2026-08-19 16:02:19.277167
420	redis	NOT_CONFIGURED	\N	2026-08-19 16:02:19.277167
421	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:02:19.277167
422	celery	NOT_CONFIGURED	\N	2026-08-19 16:02:19.278171
423	email	HEALTHY	\N	2026-08-19 16:02:19.278171
424	backup	DEGRADED	\N	2026-08-19 16:02:19.278171
425	sentry	NOT_CONFIGURED	\N	2026-08-19 16:02:19.278171
426	openai	NOT_CONFIGURED	\N	2026-08-19 16:02:19.278171
427	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:02:19.278171
428	simulation	HEALTHY	\N	2026-08-19 16:02:19.278171
429	application	HEALTHY	4.5	2026-08-19 16:02:19.278171
430	database	HEALTHY	0	2026-08-19 16:02:49.309146
431	redis	NOT_CONFIGURED	\N	2026-08-19 16:02:49.309146
432	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:02:49.309146
433	celery	NOT_CONFIGURED	\N	2026-08-19 16:02:49.309146
434	email	HEALTHY	\N	2026-08-19 16:02:49.309146
435	backup	DEGRADED	\N	2026-08-19 16:02:49.309146
436	sentry	NOT_CONFIGURED	\N	2026-08-19 16:02:49.309146
437	openai	NOT_CONFIGURED	\N	2026-08-19 16:02:49.309146
438	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:02:49.309146
439	simulation	HEALTHY	\N	2026-08-19 16:02:49.309146
440	application	HEALTHY	4.5	2026-08-19 16:02:49.309146
441	database	HEALTHY	0	2026-08-19 16:03:19.347408
442	redis	NOT_CONFIGURED	\N	2026-08-19 16:03:19.348405
443	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:03:19.348405
444	celery	NOT_CONFIGURED	\N	2026-08-19 16:03:19.348405
445	email	HEALTHY	\N	2026-08-19 16:03:19.348405
446	backup	DEGRADED	\N	2026-08-19 16:03:19.348405
447	sentry	NOT_CONFIGURED	\N	2026-08-19 16:03:19.348405
448	openai	NOT_CONFIGURED	\N	2026-08-19 16:03:19.348405
449	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:03:19.348405
450	simulation	HEALTHY	\N	2026-08-19 16:03:19.348405
451	application	HEALTHY	4.5	2026-08-19 16:03:19.348405
452	database	HEALTHY	0	2026-08-19 16:03:49.394343
453	redis	NOT_CONFIGURED	\N	2026-08-19 16:03:49.394343
454	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:03:49.394343
455	celery	NOT_CONFIGURED	\N	2026-08-19 16:03:49.394343
456	email	HEALTHY	\N	2026-08-19 16:03:49.394343
457	backup	DEGRADED	\N	2026-08-19 16:03:49.394343
458	sentry	NOT_CONFIGURED	\N	2026-08-19 16:03:49.394343
459	openai	NOT_CONFIGURED	\N	2026-08-19 16:03:49.394343
460	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:03:49.394343
461	simulation	HEALTHY	\N	2026-08-19 16:03:49.394343
462	application	HEALTHY	4.5	2026-08-19 16:03:49.394343
463	database	HEALTHY	1	2026-08-19 16:04:19.434344
464	redis	NOT_CONFIGURED	\N	2026-08-19 16:04:19.43532
465	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:04:19.43532
466	celery	NOT_CONFIGURED	\N	2026-08-19 16:04:19.43532
467	email	HEALTHY	\N	2026-08-19 16:04:19.43532
468	backup	DEGRADED	\N	2026-08-19 16:04:19.43532
469	sentry	NOT_CONFIGURED	\N	2026-08-19 16:04:19.43532
470	openai	NOT_CONFIGURED	\N	2026-08-19 16:04:19.43532
471	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:04:19.43532
472	simulation	HEALTHY	\N	2026-08-19 16:04:19.43532
473	application	HEALTHY	4.5	2026-08-19 16:04:19.43532
474	database	HEALTHY	0	2026-08-19 16:04:49.498861
475	redis	NOT_CONFIGURED	\N	2026-08-19 16:04:49.498861
476	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:04:49.498861
477	celery	NOT_CONFIGURED	\N	2026-08-19 16:04:49.498861
478	email	HEALTHY	\N	2026-08-19 16:04:49.499858
479	backup	DEGRADED	\N	2026-08-19 16:04:49.499858
480	sentry	NOT_CONFIGURED	\N	2026-08-19 16:04:49.499858
481	openai	NOT_CONFIGURED	\N	2026-08-19 16:04:49.499858
482	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:04:49.499858
483	simulation	HEALTHY	\N	2026-08-19 16:04:49.499858
484	application	HEALTHY	4.5	2026-08-19 16:04:49.499858
485	database	HEALTHY	0	2026-08-19 16:05:19.529283
486	redis	NOT_CONFIGURED	\N	2026-08-19 16:05:19.529283
487	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:05:19.529283
488	celery	NOT_CONFIGURED	\N	2026-08-19 16:05:19.529283
489	email	HEALTHY	\N	2026-08-19 16:05:19.529283
490	backup	DEGRADED	\N	2026-08-19 16:05:19.529283
491	sentry	NOT_CONFIGURED	\N	2026-08-19 16:05:19.529283
492	openai	NOT_CONFIGURED	\N	2026-08-19 16:05:19.529283
493	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:05:19.529283
494	simulation	HEALTHY	\N	2026-08-19 16:05:19.529283
495	application	HEALTHY	4.5	2026-08-19 16:05:19.529283
496	database	HEALTHY	1	2026-08-19 16:05:49.581173
497	redis	NOT_CONFIGURED	\N	2026-08-19 16:05:49.581173
498	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:05:49.581173
499	celery	NOT_CONFIGURED	\N	2026-08-19 16:05:49.581173
500	email	HEALTHY	\N	2026-08-19 16:05:49.581173
501	backup	DEGRADED	\N	2026-08-19 16:05:49.581173
502	sentry	NOT_CONFIGURED	\N	2026-08-19 16:05:49.581173
503	openai	NOT_CONFIGURED	\N	2026-08-19 16:05:49.581173
504	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:05:49.581173
505	simulation	HEALTHY	\N	2026-08-19 16:05:49.581173
506	application	HEALTHY	4.5	2026-08-19 16:05:49.581173
507	database	HEALTHY	1	2026-08-19 16:06:19.623269
508	redis	NOT_CONFIGURED	\N	2026-08-19 16:06:19.623269
509	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:06:19.623269
510	celery	NOT_CONFIGURED	\N	2026-08-19 16:06:19.623269
511	email	HEALTHY	\N	2026-08-19 16:06:19.623269
512	backup	DEGRADED	\N	2026-08-19 16:06:19.623269
513	sentry	NOT_CONFIGURED	\N	2026-08-19 16:06:19.623269
514	openai	NOT_CONFIGURED	\N	2026-08-19 16:06:19.623269
515	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:06:19.623269
516	simulation	HEALTHY	\N	2026-08-19 16:06:19.623269
517	application	HEALTHY	4.5	2026-08-19 16:06:19.623269
518	database	HEALTHY	0	2026-08-19 16:06:49.655565
519	redis	NOT_CONFIGURED	\N	2026-08-19 16:06:49.656561
520	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:06:49.656561
521	celery	NOT_CONFIGURED	\N	2026-08-19 16:06:49.656561
522	email	HEALTHY	\N	2026-08-19 16:06:49.656561
523	backup	DEGRADED	\N	2026-08-19 16:06:49.656561
524	sentry	NOT_CONFIGURED	\N	2026-08-19 16:06:49.656561
525	openai	NOT_CONFIGURED	\N	2026-08-19 16:06:49.656561
526	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:06:49.656561
527	simulation	HEALTHY	\N	2026-08-19 16:06:49.656561
528	application	HEALTHY	4.5	2026-08-19 16:06:49.656561
529	database	HEALTHY	0	2026-08-19 16:07:19.686925
530	redis	NOT_CONFIGURED	\N	2026-08-19 16:07:19.687925
531	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:07:19.687925
532	celery	NOT_CONFIGURED	\N	2026-08-19 16:07:19.687925
533	email	HEALTHY	\N	2026-08-19 16:07:19.687925
534	backup	DEGRADED	\N	2026-08-19 16:07:19.687925
535	sentry	NOT_CONFIGURED	\N	2026-08-19 16:07:19.687925
536	openai	NOT_CONFIGURED	\N	2026-08-19 16:07:19.687925
537	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:07:19.687925
538	simulation	HEALTHY	\N	2026-08-19 16:07:19.687925
539	application	HEALTHY	4.5	2026-08-19 16:07:19.687925
540	database	HEALTHY	1	2026-08-19 16:07:49.742458
541	redis	NOT_CONFIGURED	\N	2026-08-19 16:07:49.743901
542	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:07:49.743901
543	celery	NOT_CONFIGURED	\N	2026-08-19 16:07:49.743901
544	email	HEALTHY	\N	2026-08-19 16:07:49.743901
545	backup	DEGRADED	\N	2026-08-19 16:07:49.743901
546	sentry	NOT_CONFIGURED	\N	2026-08-19 16:07:49.743901
547	openai	NOT_CONFIGURED	\N	2026-08-19 16:07:49.743901
548	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:07:49.743901
549	simulation	HEALTHY	\N	2026-08-19 16:07:49.743901
550	application	HEALTHY	4.5	2026-08-19 16:07:49.743901
551	database	HEALTHY	0	2026-08-19 16:08:19.773555
552	redis	NOT_CONFIGURED	\N	2026-08-19 16:08:19.773555
553	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:08:19.773555
554	celery	NOT_CONFIGURED	\N	2026-08-19 16:08:19.773555
555	email	HEALTHY	\N	2026-08-19 16:08:19.773555
556	backup	DEGRADED	\N	2026-08-19 16:08:19.773555
557	sentry	NOT_CONFIGURED	\N	2026-08-19 16:08:19.773555
558	openai	NOT_CONFIGURED	\N	2026-08-19 16:08:19.773555
559	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:08:19.773555
560	simulation	HEALTHY	\N	2026-08-19 16:08:19.773555
561	application	HEALTHY	4.5	2026-08-19 16:08:19.773555
1233	database	HEALTHY	1	2026-08-19 16:39:22.761803
1234	redis	NOT_CONFIGURED	\N	2026-08-19 16:39:22.761803
1235	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:39:22.761803
1236	celery	NOT_CONFIGURED	\N	2026-08-19 16:39:22.761803
1237	email	HEALTHY	\N	2026-08-19 16:39:22.761803
1238	backup	UNAVAILABLE	\N	2026-08-19 16:39:22.761803
1239	sentry	NOT_CONFIGURED	\N	2026-08-19 16:39:22.761803
1240	openai	NOT_CONFIGURED	\N	2026-08-19 16:39:22.761803
1241	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:39:22.761803
1242	simulation	HEALTHY	\N	2026-08-19 16:39:22.761803
1243	application	HEALTHY	4.5	2026-08-19 16:39:22.761803
1354	database	HEALTHY	8.02	2026-08-19 16:44:53.645413
1355	redis	NOT_CONFIGURED	\N	2026-08-19 16:44:53.646429
1356	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:44:53.646429
1357	celery	NOT_CONFIGURED	\N	2026-08-19 16:44:53.646429
1358	email	HEALTHY	\N	2026-08-19 16:44:53.646429
1359	backup	UNAVAILABLE	\N	2026-08-19 16:44:53.646429
1360	sentry	NOT_CONFIGURED	\N	2026-08-19 16:44:53.646429
1361	openai	NOT_CONFIGURED	\N	2026-08-19 16:44:53.646429
1362	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:44:53.64743
1363	simulation	HEALTHY	\N	2026-08-19 16:44:53.64743
1364	application	HEALTHY	4.5	2026-08-19 16:44:53.64743
1409	database	HEALTHY	1.01	2026-08-19 16:47:23.877649
1410	redis	NOT_CONFIGURED	\N	2026-08-19 16:47:23.877649
1411	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:47:23.877649
1412	celery	NOT_CONFIGURED	\N	2026-08-19 16:47:23.877649
1413	email	HEALTHY	\N	2026-08-19 16:47:23.877649
1414	backup	UNAVAILABLE	\N	2026-08-19 16:47:23.877649
1415	sentry	NOT_CONFIGURED	\N	2026-08-19 16:47:23.877649
1416	openai	NOT_CONFIGURED	\N	2026-08-19 16:47:23.877649
1417	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:47:23.877649
1418	simulation	HEALTHY	\N	2026-08-19 16:47:23.87865
1419	application	HEALTHY	4.5	2026-08-19 16:47:23.87865
1453	database	HEALTHY	0	2026-08-19 16:49:24.035361
1454	redis	NOT_CONFIGURED	\N	2026-08-19 16:49:24.035361
1455	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:49:24.035361
1456	celery	NOT_CONFIGURED	\N	2026-08-19 16:49:24.035361
1457	email	HEALTHY	\N	2026-08-19 16:49:24.035361
1458	backup	UNAVAILABLE	\N	2026-08-19 16:49:24.036359
1459	sentry	NOT_CONFIGURED	\N	2026-08-19 16:49:24.036359
1460	openai	NOT_CONFIGURED	\N	2026-08-19 16:49:24.036359
1461	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:49:24.036359
1462	simulation	HEALTHY	\N	2026-08-19 16:49:24.036359
1463	application	HEALTHY	4.5	2026-08-19 16:49:24.036359
1508	database	HEALTHY	4.99	2026-08-19 16:51:54.281725
1509	redis	NOT_CONFIGURED	\N	2026-08-19 16:51:54.281725
1510	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:51:54.281725
1511	celery	NOT_CONFIGURED	\N	2026-08-19 16:51:54.282728
1512	email	HEALTHY	\N	2026-08-19 16:51:54.282728
1513	backup	UNAVAILABLE	\N	2026-08-19 16:51:54.282728
1514	sentry	NOT_CONFIGURED	\N	2026-08-19 16:51:54.282728
1515	openai	NOT_CONFIGURED	\N	2026-08-19 16:51:54.282728
1516	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:51:54.282728
1517	simulation	HEALTHY	\N	2026-08-19 16:51:54.282728
1518	application	HEALTHY	4.5	2026-08-19 16:51:54.282728
1574	database	HEALTHY	1.08	2026-08-19 16:54:54.524623
1575	redis	NOT_CONFIGURED	\N	2026-08-19 16:54:54.524623
1576	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:54:54.524623
1577	celery	NOT_CONFIGURED	\N	2026-08-19 16:54:54.524623
562	database	HEALTHY	0	2026-08-19 16:08:49.807318
563	redis	NOT_CONFIGURED	\N	2026-08-19 16:08:49.807318
564	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:08:49.807318
565	celery	NOT_CONFIGURED	\N	2026-08-19 16:08:49.807318
566	email	HEALTHY	\N	2026-08-19 16:08:49.807318
567	backup	DEGRADED	\N	2026-08-19 16:08:49.807318
568	sentry	NOT_CONFIGURED	\N	2026-08-19 16:08:49.807318
569	openai	NOT_CONFIGURED	\N	2026-08-19 16:08:49.807318
570	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:08:49.807318
571	simulation	HEALTHY	\N	2026-08-19 16:08:49.807318
572	application	HEALTHY	4.5	2026-08-19 16:08:49.807318
573	database	HEALTHY	0.97	2026-08-19 16:09:19.84777
574	redis	NOT_CONFIGURED	\N	2026-08-19 16:09:19.84777
575	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:09:19.84777
576	celery	NOT_CONFIGURED	\N	2026-08-19 16:09:19.84777
577	email	HEALTHY	\N	2026-08-19 16:09:19.84777
578	backup	DEGRADED	\N	2026-08-19 16:09:19.84777
579	sentry	NOT_CONFIGURED	\N	2026-08-19 16:09:19.84777
580	openai	NOT_CONFIGURED	\N	2026-08-19 16:09:19.84777
581	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:09:19.84777
582	simulation	HEALTHY	\N	2026-08-19 16:09:19.84777
583	application	HEALTHY	4.5	2026-08-19 16:09:19.84777
584	database	HEALTHY	1	2026-08-19 16:09:49.883057
585	redis	NOT_CONFIGURED	\N	2026-08-19 16:09:49.883057
586	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:09:49.883057
587	celery	NOT_CONFIGURED	\N	2026-08-19 16:09:49.883057
588	email	HEALTHY	\N	2026-08-19 16:09:49.883057
589	backup	DEGRADED	\N	2026-08-19 16:09:49.883057
590	sentry	NOT_CONFIGURED	\N	2026-08-19 16:09:49.883057
591	openai	NOT_CONFIGURED	\N	2026-08-19 16:09:49.883057
592	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:09:49.883057
593	simulation	HEALTHY	\N	2026-08-19 16:09:49.883057
594	application	HEALTHY	4.5	2026-08-19 16:09:49.883057
595	database	HEALTHY	1	2026-08-19 16:10:19.927704
596	redis	NOT_CONFIGURED	\N	2026-08-19 16:10:19.927704
597	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:10:19.927704
598	celery	NOT_CONFIGURED	\N	2026-08-19 16:10:19.927704
599	email	HEALTHY	\N	2026-08-19 16:10:19.927704
600	backup	DEGRADED	\N	2026-08-19 16:10:19.927704
601	sentry	NOT_CONFIGURED	\N	2026-08-19 16:10:19.927704
602	openai	NOT_CONFIGURED	\N	2026-08-19 16:10:19.927704
603	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:10:19.927704
604	simulation	HEALTHY	\N	2026-08-19 16:10:19.927704
605	application	HEALTHY	4.5	2026-08-19 16:10:19.927704
606	database	HEALTHY	0	2026-08-19 16:10:49.9668
607	redis	NOT_CONFIGURED	\N	2026-08-19 16:10:49.9668
608	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:10:49.9668
609	celery	NOT_CONFIGURED	\N	2026-08-19 16:10:49.9668
610	email	HEALTHY	\N	2026-08-19 16:10:49.9668
611	backup	DEGRADED	\N	2026-08-19 16:10:49.9668
612	sentry	NOT_CONFIGURED	\N	2026-08-19 16:10:49.9668
613	openai	NOT_CONFIGURED	\N	2026-08-19 16:10:49.9668
614	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:10:49.9668
615	simulation	HEALTHY	\N	2026-08-19 16:10:49.9668
616	application	HEALTHY	4.5	2026-08-19 16:10:49.9668
617	database	HEALTHY	0	2026-08-19 16:11:20.002192
618	redis	NOT_CONFIGURED	\N	2026-08-19 16:11:20.002192
619	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:11:20.002192
620	celery	NOT_CONFIGURED	\N	2026-08-19 16:11:20.002192
621	email	HEALTHY	\N	2026-08-19 16:11:20.002192
622	backup	DEGRADED	\N	2026-08-19 16:11:20.002192
623	sentry	NOT_CONFIGURED	\N	2026-08-19 16:11:20.002192
624	openai	NOT_CONFIGURED	\N	2026-08-19 16:11:20.002192
625	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:11:20.002192
626	simulation	HEALTHY	\N	2026-08-19 16:11:20.002192
627	application	HEALTHY	4.5	2026-08-19 16:11:20.002192
628	database	HEALTHY	0	2026-08-19 16:11:50.04983
629	redis	NOT_CONFIGURED	\N	2026-08-19 16:11:50.04983
630	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:11:50.04983
631	celery	NOT_CONFIGURED	\N	2026-08-19 16:11:50.050895
632	email	HEALTHY	\N	2026-08-19 16:11:50.050895
633	backup	DEGRADED	\N	2026-08-19 16:11:50.050895
634	sentry	NOT_CONFIGURED	\N	2026-08-19 16:11:50.050895
635	openai	NOT_CONFIGURED	\N	2026-08-19 16:11:50.050895
636	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:11:50.050895
637	simulation	HEALTHY	\N	2026-08-19 16:11:50.050895
638	application	HEALTHY	4.5	2026-08-19 16:11:50.050895
639	database	HEALTHY	1	2026-08-19 16:12:20.079732
640	redis	NOT_CONFIGURED	\N	2026-08-19 16:12:20.079732
641	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:12:20.079732
642	celery	NOT_CONFIGURED	\N	2026-08-19 16:12:20.079732
643	email	HEALTHY	\N	2026-08-19 16:12:20.079732
644	backup	DEGRADED	\N	2026-08-19 16:12:20.079732
645	sentry	NOT_CONFIGURED	\N	2026-08-19 16:12:20.079732
646	openai	NOT_CONFIGURED	\N	2026-08-19 16:12:20.079732
647	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:12:20.079732
648	simulation	HEALTHY	\N	2026-08-19 16:12:20.079732
649	application	HEALTHY	4.5	2026-08-19 16:12:20.079732
650	database	HEALTHY	0	2026-08-19 16:12:50.133789
651	redis	NOT_CONFIGURED	\N	2026-08-19 16:12:50.133789
652	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:12:50.135114
653	celery	NOT_CONFIGURED	\N	2026-08-19 16:12:50.135114
654	email	HEALTHY	\N	2026-08-19 16:12:50.135114
655	backup	DEGRADED	\N	2026-08-19 16:12:50.135114
656	sentry	NOT_CONFIGURED	\N	2026-08-19 16:12:50.135114
657	openai	NOT_CONFIGURED	\N	2026-08-19 16:12:50.135114
658	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:12:50.135114
659	simulation	HEALTHY	\N	2026-08-19 16:12:50.135114
660	application	HEALTHY	4.5	2026-08-19 16:12:50.135114
661	database	HEALTHY	3	2026-08-19 16:13:20.207174
662	redis	NOT_CONFIGURED	\N	2026-08-19 16:13:20.207174
663	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:13:20.207174
664	celery	NOT_CONFIGURED	\N	2026-08-19 16:13:20.207174
665	email	HEALTHY	\N	2026-08-19 16:13:20.207174
666	backup	DEGRADED	\N	2026-08-19 16:13:20.207174
667	sentry	NOT_CONFIGURED	\N	2026-08-19 16:13:20.207174
668	openai	NOT_CONFIGURED	\N	2026-08-19 16:13:20.207174
669	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:13:20.207174
670	simulation	HEALTHY	\N	2026-08-19 16:13:20.208717
671	application	HEALTHY	4.5	2026-08-19 16:13:20.208717
672	database	HEALTHY	3.99	2026-08-19 16:13:50.405009
673	redis	NOT_CONFIGURED	\N	2026-08-19 16:13:50.40601
674	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:13:50.40601
675	celery	NOT_CONFIGURED	\N	2026-08-19 16:13:50.40601
676	email	HEALTHY	\N	2026-08-19 16:13:50.40601
677	backup	DEGRADED	\N	2026-08-19 16:13:50.40601
678	sentry	NOT_CONFIGURED	\N	2026-08-19 16:13:50.40601
679	openai	NOT_CONFIGURED	\N	2026-08-19 16:13:50.40601
680	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:13:50.40601
681	simulation	HEALTHY	\N	2026-08-19 16:13:50.40601
682	application	HEALTHY	4.5	2026-08-19 16:13:50.40601
683	database	HEALTHY	0	2026-08-19 16:14:20.625927
684	redis	NOT_CONFIGURED	\N	2026-08-19 16:14:20.625927
685	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:14:20.625927
686	celery	NOT_CONFIGURED	\N	2026-08-19 16:14:20.625927
687	email	HEALTHY	\N	2026-08-19 16:14:20.626928
688	backup	DEGRADED	\N	2026-08-19 16:14:20.626928
689	sentry	NOT_CONFIGURED	\N	2026-08-19 16:14:20.626928
690	openai	NOT_CONFIGURED	\N	2026-08-19 16:14:20.626928
691	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:14:20.626928
692	simulation	HEALTHY	\N	2026-08-19 16:14:20.626928
693	application	HEALTHY	4.5	2026-08-19 16:14:20.626928
694	database	HEALTHY	0.99	2026-08-19 16:14:50.668735
695	redis	NOT_CONFIGURED	\N	2026-08-19 16:14:50.668735
696	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:14:50.668735
697	celery	NOT_CONFIGURED	\N	2026-08-19 16:14:50.668735
698	email	HEALTHY	\N	2026-08-19 16:14:50.668735
699	backup	DEGRADED	\N	2026-08-19 16:14:50.668735
700	sentry	NOT_CONFIGURED	\N	2026-08-19 16:14:50.668735
701	openai	NOT_CONFIGURED	\N	2026-08-19 16:14:50.669736
702	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:14:50.669736
703	simulation	HEALTHY	\N	2026-08-19 16:14:50.669736
704	application	HEALTHY	4.5	2026-08-19 16:14:50.669736
705	database	HEALTHY	1.01	2026-08-19 16:15:20.70198
706	redis	NOT_CONFIGURED	\N	2026-08-19 16:15:20.70198
707	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:15:20.70198
708	celery	NOT_CONFIGURED	\N	2026-08-19 16:15:20.70198
709	email	HEALTHY	\N	2026-08-19 16:15:20.70198
710	backup	DEGRADED	\N	2026-08-19 16:15:20.702983
711	sentry	NOT_CONFIGURED	\N	2026-08-19 16:15:20.702983
712	openai	NOT_CONFIGURED	\N	2026-08-19 16:15:20.702983
713	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:15:20.702983
714	simulation	HEALTHY	\N	2026-08-19 16:15:20.702983
715	application	HEALTHY	4.5	2026-08-19 16:15:20.702983
716	database	HEALTHY	1.02	2026-08-19 16:15:50.762278
717	redis	NOT_CONFIGURED	\N	2026-08-19 16:15:50.762278
718	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:15:50.762278
719	celery	NOT_CONFIGURED	\N	2026-08-19 16:15:50.762278
720	email	HEALTHY	\N	2026-08-19 16:15:50.762278
721	backup	DEGRADED	\N	2026-08-19 16:15:50.762278
722	sentry	NOT_CONFIGURED	\N	2026-08-19 16:15:50.762278
723	openai	NOT_CONFIGURED	\N	2026-08-19 16:15:50.762278
724	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:15:50.762278
725	simulation	HEALTHY	\N	2026-08-19 16:15:50.762278
726	application	HEALTHY	4.5	2026-08-19 16:15:50.762278
727	database	HEALTHY	0	2026-08-19 16:16:20.807288
728	redis	NOT_CONFIGURED	\N	2026-08-19 16:16:20.807288
729	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:16:20.807288
730	celery	NOT_CONFIGURED	\N	2026-08-19 16:16:20.807288
731	email	HEALTHY	\N	2026-08-19 16:16:20.808291
732	backup	DEGRADED	\N	2026-08-19 16:16:20.808291
733	sentry	NOT_CONFIGURED	\N	2026-08-19 16:16:20.808291
734	openai	NOT_CONFIGURED	\N	2026-08-19 16:16:20.808291
735	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:16:20.808291
736	simulation	HEALTHY	\N	2026-08-19 16:16:20.808291
737	application	HEALTHY	4.5	2026-08-19 16:16:20.808291
738	database	HEALTHY	1	2026-08-19 16:16:50.86567
739	redis	NOT_CONFIGURED	\N	2026-08-19 16:16:50.86567
740	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:16:50.86567
741	celery	NOT_CONFIGURED	\N	2026-08-19 16:16:50.86567
742	email	HEALTHY	\N	2026-08-19 16:16:50.86567
743	backup	DEGRADED	\N	2026-08-19 16:16:50.86567
744	sentry	NOT_CONFIGURED	\N	2026-08-19 16:16:50.86567
745	openai	NOT_CONFIGURED	\N	2026-08-19 16:16:50.86567
746	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:16:50.86567
747	simulation	HEALTHY	\N	2026-08-19 16:16:50.86567
748	application	HEALTHY	4.5	2026-08-19 16:16:50.86567
749	database	HEALTHY	0	2026-08-19 16:17:20.900338
750	redis	NOT_CONFIGURED	\N	2026-08-19 16:17:20.900338
751	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:17:20.901367
752	celery	NOT_CONFIGURED	\N	2026-08-19 16:17:20.901367
753	email	HEALTHY	\N	2026-08-19 16:17:20.901367
754	backup	DEGRADED	\N	2026-08-19 16:17:20.901367
755	sentry	NOT_CONFIGURED	\N	2026-08-19 16:17:20.901367
756	openai	NOT_CONFIGURED	\N	2026-08-19 16:17:20.901367
757	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:17:20.901367
758	simulation	HEALTHY	\N	2026-08-19 16:17:20.901367
759	application	HEALTHY	4.5	2026-08-19 16:17:20.901367
760	database	HEALTHY	0.99	2026-08-19 16:17:50.958135
761	redis	NOT_CONFIGURED	\N	2026-08-19 16:17:50.958135
762	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:17:50.958135
763	celery	NOT_CONFIGURED	\N	2026-08-19 16:17:50.958135
764	email	HEALTHY	\N	2026-08-19 16:17:50.958135
765	backup	DEGRADED	\N	2026-08-19 16:17:50.958135
766	sentry	NOT_CONFIGURED	\N	2026-08-19 16:17:50.958135
767	openai	NOT_CONFIGURED	\N	2026-08-19 16:17:50.959133
768	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:17:50.959133
769	simulation	HEALTHY	\N	2026-08-19 16:17:50.959133
770	application	HEALTHY	4.5	2026-08-19 16:17:50.959133
771	database	HEALTHY	0	2026-08-19 16:18:20.992804
772	redis	NOT_CONFIGURED	\N	2026-08-19 16:18:20.993803
773	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:18:20.993803
774	celery	NOT_CONFIGURED	\N	2026-08-19 16:18:20.993803
775	email	HEALTHY	\N	2026-08-19 16:18:20.993803
776	backup	DEGRADED	\N	2026-08-19 16:18:20.993803
777	sentry	NOT_CONFIGURED	\N	2026-08-19 16:18:20.993803
778	openai	NOT_CONFIGURED	\N	2026-08-19 16:18:20.993803
779	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:18:20.993803
780	simulation	HEALTHY	\N	2026-08-19 16:18:20.993803
781	application	HEALTHY	4.5	2026-08-19 16:18:20.993803
782	database	HEALTHY	0	2026-08-19 16:18:51.042369
783	redis	NOT_CONFIGURED	\N	2026-08-19 16:18:51.042369
784	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:18:51.043367
785	celery	NOT_CONFIGURED	\N	2026-08-19 16:18:51.043367
786	email	HEALTHY	\N	2026-08-19 16:18:51.043367
787	backup	DEGRADED	\N	2026-08-19 16:18:51.043367
788	sentry	NOT_CONFIGURED	\N	2026-08-19 16:18:51.043367
789	openai	NOT_CONFIGURED	\N	2026-08-19 16:18:51.043367
790	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:18:51.043367
791	simulation	HEALTHY	\N	2026-08-19 16:18:51.043367
792	application	HEALTHY	4.5	2026-08-19 16:18:51.043367
793	database	HEALTHY	0	2026-08-19 16:19:21.075709
794	redis	NOT_CONFIGURED	\N	2026-08-19 16:19:21.075709
795	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:19:21.075709
796	celery	NOT_CONFIGURED	\N	2026-08-19 16:19:21.075709
797	email	HEALTHY	\N	2026-08-19 16:19:21.075709
798	backup	DEGRADED	\N	2026-08-19 16:19:21.075709
799	sentry	NOT_CONFIGURED	\N	2026-08-19 16:19:21.075709
800	openai	NOT_CONFIGURED	\N	2026-08-19 16:19:21.075709
801	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:19:21.075709
802	simulation	HEALTHY	\N	2026-08-19 16:19:21.075709
803	application	HEALTHY	4.5	2026-08-19 16:19:21.075709
804	database	HEALTHY	0	2026-08-19 16:19:51.108704
805	redis	NOT_CONFIGURED	\N	2026-08-19 16:19:51.108704
806	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:19:51.108704
807	celery	NOT_CONFIGURED	\N	2026-08-19 16:19:51.108704
808	email	HEALTHY	\N	2026-08-19 16:19:51.108704
809	backup	DEGRADED	\N	2026-08-19 16:19:51.108704
810	sentry	NOT_CONFIGURED	\N	2026-08-19 16:19:51.108704
811	openai	NOT_CONFIGURED	\N	2026-08-19 16:19:51.108704
812	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:19:51.109691
813	simulation	HEALTHY	\N	2026-08-19 16:19:51.109691
814	application	HEALTHY	4.5	2026-08-19 16:19:51.109691
815	database	HEALTHY	1	2026-08-19 16:20:21.135138
816	redis	NOT_CONFIGURED	\N	2026-08-19 16:20:21.135138
817	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:20:21.136481
818	celery	NOT_CONFIGURED	\N	2026-08-19 16:20:21.136481
819	email	HEALTHY	\N	2026-08-19 16:20:21.136481
820	backup	DEGRADED	\N	2026-08-19 16:20:21.136481
821	sentry	NOT_CONFIGURED	\N	2026-08-19 16:20:21.136481
822	openai	NOT_CONFIGURED	\N	2026-08-19 16:20:21.136481
823	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:20:21.136481
824	simulation	HEALTHY	\N	2026-08-19 16:20:21.136481
825	application	HEALTHY	4.5	2026-08-19 16:20:21.136481
826	database	HEALTHY	0.99	2026-08-19 16:20:51.174426
827	redis	NOT_CONFIGURED	\N	2026-08-19 16:20:51.174426
828	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:20:51.174426
829	celery	NOT_CONFIGURED	\N	2026-08-19 16:20:51.174426
830	email	HEALTHY	\N	2026-08-19 16:20:51.174426
831	backup	DEGRADED	\N	2026-08-19 16:20:51.174426
832	sentry	NOT_CONFIGURED	\N	2026-08-19 16:20:51.174426
833	openai	NOT_CONFIGURED	\N	2026-08-19 16:20:51.175438
834	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:20:51.175438
835	simulation	HEALTHY	\N	2026-08-19 16:20:51.175438
836	application	HEALTHY	4.5	2026-08-19 16:20:51.175438
837	database	HEALTHY	1	2026-08-19 16:21:21.215392
838	redis	NOT_CONFIGURED	\N	2026-08-19 16:21:21.216392
839	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:21:21.216392
840	celery	NOT_CONFIGURED	\N	2026-08-19 16:21:21.216392
841	email	HEALTHY	\N	2026-08-19 16:21:21.216392
842	backup	DEGRADED	\N	2026-08-19 16:21:21.216392
843	sentry	NOT_CONFIGURED	\N	2026-08-19 16:21:21.216392
844	openai	NOT_CONFIGURED	\N	2026-08-19 16:21:21.216392
845	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:21:21.216392
846	simulation	HEALTHY	\N	2026-08-19 16:21:21.216392
847	application	HEALTHY	4.5	2026-08-19 16:21:21.216392
848	database	HEALTHY	0	2026-08-19 16:21:51.250566
849	redis	NOT_CONFIGURED	\N	2026-08-19 16:21:51.250566
850	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:21:51.250566
851	celery	NOT_CONFIGURED	\N	2026-08-19 16:21:51.250566
852	email	HEALTHY	\N	2026-08-19 16:21:51.250566
853	backup	DEGRADED	\N	2026-08-19 16:21:51.252337
854	sentry	NOT_CONFIGURED	\N	2026-08-19 16:21:51.252337
855	openai	NOT_CONFIGURED	\N	2026-08-19 16:21:51.252337
856	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:21:51.252337
857	simulation	HEALTHY	\N	2026-08-19 16:21:51.252337
858	application	HEALTHY	4.5	2026-08-19 16:21:51.252337
859	database	HEALTHY	0.99	2026-08-19 16:22:21.278654
860	redis	NOT_CONFIGURED	\N	2026-08-19 16:22:21.278654
861	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:22:21.278654
862	celery	NOT_CONFIGURED	\N	2026-08-19 16:22:21.279694
863	email	HEALTHY	\N	2026-08-19 16:22:21.279694
864	backup	DEGRADED	\N	2026-08-19 16:22:21.279694
865	sentry	NOT_CONFIGURED	\N	2026-08-19 16:22:21.279694
866	openai	NOT_CONFIGURED	\N	2026-08-19 16:22:21.279694
867	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:22:21.279694
868	simulation	HEALTHY	\N	2026-08-19 16:22:21.279694
869	application	HEALTHY	4.5	2026-08-19 16:22:21.279694
870	database	HEALTHY	1	2026-08-19 16:22:51.337485
871	redis	NOT_CONFIGURED	\N	2026-08-19 16:22:51.337485
872	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:22:51.337485
873	celery	NOT_CONFIGURED	\N	2026-08-19 16:22:51.337485
874	email	HEALTHY	\N	2026-08-19 16:22:51.337485
875	backup	DEGRADED	\N	2026-08-19 16:22:51.337485
876	sentry	NOT_CONFIGURED	\N	2026-08-19 16:22:51.337485
877	openai	NOT_CONFIGURED	\N	2026-08-19 16:22:51.337485
878	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:22:51.337485
879	simulation	HEALTHY	\N	2026-08-19 16:22:51.337485
880	application	HEALTHY	4.5	2026-08-19 16:22:51.337485
881	database	HEALTHY	0	2026-08-19 16:23:21.363007
882	redis	NOT_CONFIGURED	\N	2026-08-19 16:23:21.363007
883	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:23:21.363007
884	celery	NOT_CONFIGURED	\N	2026-08-19 16:23:21.363007
885	email	HEALTHY	\N	2026-08-19 16:23:21.363007
886	backup	DEGRADED	\N	2026-08-19 16:23:21.363007
887	sentry	NOT_CONFIGURED	\N	2026-08-19 16:23:21.363007
888	openai	NOT_CONFIGURED	\N	2026-08-19 16:23:21.363007
889	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:23:21.364007
890	simulation	HEALTHY	\N	2026-08-19 16:23:21.364007
891	application	HEALTHY	4.5	2026-08-19 16:23:21.364007
892	database	HEALTHY	1	2026-08-19 16:23:51.414808
893	redis	NOT_CONFIGURED	\N	2026-08-19 16:23:51.415804
894	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:23:51.415804
895	celery	NOT_CONFIGURED	\N	2026-08-19 16:23:51.415804
896	email	HEALTHY	\N	2026-08-19 16:23:51.415804
897	backup	HEALTHY	\N	2026-08-19 16:23:51.415804
898	sentry	NOT_CONFIGURED	\N	2026-08-19 16:23:51.415804
899	openai	NOT_CONFIGURED	\N	2026-08-19 16:23:51.415804
900	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:23:51.415804
901	simulation	HEALTHY	\N	2026-08-19 16:23:51.415804
902	application	HEALTHY	4.5	2026-08-19 16:23:51.415804
903	database	HEALTHY	1.48	2026-08-19 16:24:21.444658
904	redis	NOT_CONFIGURED	\N	2026-08-19 16:24:21.446061
905	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:24:21.446061
906	celery	NOT_CONFIGURED	\N	2026-08-19 16:24:21.446061
907	email	HEALTHY	\N	2026-08-19 16:24:21.446061
908	backup	UNAVAILABLE	\N	2026-08-19 16:24:21.446061
909	sentry	NOT_CONFIGURED	\N	2026-08-19 16:24:21.446061
910	openai	NOT_CONFIGURED	\N	2026-08-19 16:24:21.446061
911	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:24:21.446061
912	simulation	HEALTHY	\N	2026-08-19 16:24:21.446061
913	application	HEALTHY	4.5	2026-08-19 16:24:21.446061
914	database	HEALTHY	1	2026-08-19 16:24:51.476468
915	redis	NOT_CONFIGURED	\N	2026-08-19 16:24:51.476468
916	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:24:51.476468
917	celery	NOT_CONFIGURED	\N	2026-08-19 16:24:51.476468
918	email	HEALTHY	\N	2026-08-19 16:24:51.476468
919	backup	UNAVAILABLE	\N	2026-08-19 16:24:51.476468
920	sentry	NOT_CONFIGURED	\N	2026-08-19 16:24:51.476468
921	openai	NOT_CONFIGURED	\N	2026-08-19 16:24:51.476468
922	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:24:51.476468
923	simulation	HEALTHY	\N	2026-08-19 16:24:51.476468
924	application	HEALTHY	4.5	2026-08-19 16:24:51.476468
925	database	HEALTHY	0	2026-08-19 16:25:21.502303
926	redis	NOT_CONFIGURED	\N	2026-08-19 16:25:21.503337
927	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:25:21.503337
928	celery	NOT_CONFIGURED	\N	2026-08-19 16:25:21.503337
929	email	HEALTHY	\N	2026-08-19 16:25:21.503337
930	backup	UNAVAILABLE	\N	2026-08-19 16:25:21.503337
931	sentry	NOT_CONFIGURED	\N	2026-08-19 16:25:21.503337
932	openai	NOT_CONFIGURED	\N	2026-08-19 16:25:21.503337
933	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:25:21.503337
934	simulation	HEALTHY	\N	2026-08-19 16:25:21.503337
935	application	HEALTHY	4.5	2026-08-19 16:25:21.503337
1244	database	HEALTHY	5	2026-08-19 16:39:52.867529
1245	redis	NOT_CONFIGURED	\N	2026-08-19 16:39:52.868526
1246	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:39:52.868526
1247	celery	NOT_CONFIGURED	\N	2026-08-19 16:39:52.868526
1248	email	HEALTHY	\N	2026-08-19 16:39:52.868526
1249	backup	UNAVAILABLE	\N	2026-08-19 16:39:52.868526
1250	sentry	NOT_CONFIGURED	\N	2026-08-19 16:39:52.868526
1251	openai	NOT_CONFIGURED	\N	2026-08-19 16:39:52.868526
1252	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:39:52.868526
1253	simulation	HEALTHY	\N	2026-08-19 16:39:52.868526
1254	application	HEALTHY	4.5	2026-08-19 16:39:52.868526
1365	database	HEALTHY	0	2026-08-19 16:45:23.700611
1366	redis	NOT_CONFIGURED	\N	2026-08-19 16:45:23.701999
1367	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:45:23.701999
1368	celery	NOT_CONFIGURED	\N	2026-08-19 16:45:23.701999
1369	email	HEALTHY	\N	2026-08-19 16:45:23.701999
1370	backup	UNAVAILABLE	\N	2026-08-19 16:45:23.701999
1371	sentry	NOT_CONFIGURED	\N	2026-08-19 16:45:23.701999
1372	openai	NOT_CONFIGURED	\N	2026-08-19 16:45:23.701999
1373	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:45:23.701999
1374	simulation	HEALTHY	\N	2026-08-19 16:45:23.701999
1375	application	HEALTHY	4.5	2026-08-19 16:45:23.70251
1420	database	HEALTHY	1	2026-08-19 16:47:53.920847
1421	redis	NOT_CONFIGURED	\N	2026-08-19 16:47:53.921847
1422	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:47:53.921847
1423	celery	NOT_CONFIGURED	\N	2026-08-19 16:47:53.921847
1424	email	HEALTHY	\N	2026-08-19 16:47:53.921847
1425	backup	UNAVAILABLE	\N	2026-08-19 16:47:53.921847
1426	sentry	NOT_CONFIGURED	\N	2026-08-19 16:47:53.921847
1427	openai	NOT_CONFIGURED	\N	2026-08-19 16:47:53.921847
1428	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:47:53.921847
1429	simulation	HEALTHY	\N	2026-08-19 16:47:53.921847
1430	application	HEALTHY	4.5	2026-08-19 16:47:53.921847
1519	database	HEALTHY	1.02	2026-08-19 16:52:24.329514
1520	redis	NOT_CONFIGURED	\N	2026-08-19 16:52:24.329514
1521	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:52:24.329514
1522	celery	NOT_CONFIGURED	\N	2026-08-19 16:52:24.329514
1523	email	HEALTHY	\N	2026-08-19 16:52:24.329514
1524	backup	UNAVAILABLE	\N	2026-08-19 16:52:24.330509
1525	sentry	NOT_CONFIGURED	\N	2026-08-19 16:52:24.330509
1526	openai	NOT_CONFIGURED	\N	2026-08-19 16:52:24.330509
1527	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:52:24.330509
1528	simulation	HEALTHY	\N	2026-08-19 16:52:24.330509
1529	application	HEALTHY	4.5	2026-08-19 16:52:24.330509
1618	database	HEALTHY	1	2026-08-19 16:56:54.646138
1619	redis	NOT_CONFIGURED	\N	2026-08-19 16:56:54.646138
1620	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:56:54.646138
1621	celery	NOT_CONFIGURED	\N	2026-08-19 16:56:54.646138
1622	email	HEALTHY	\N	2026-08-19 16:56:54.646138
1623	backup	UNAVAILABLE	\N	2026-08-19 16:56:54.646138
1624	sentry	NOT_CONFIGURED	\N	2026-08-19 16:56:54.646138
1625	openai	NOT_CONFIGURED	\N	2026-08-19 16:56:54.646138
1626	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:56:54.646138
1627	simulation	HEALTHY	\N	2026-08-19 16:56:54.646138
1628	application	HEALTHY	4.5	2026-08-19 16:56:54.646138
1640	database	HEALTHY	1	2026-08-19 16:57:54.722534
1641	redis	NOT_CONFIGURED	\N	2026-08-19 16:57:54.722534
1642	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:57:54.722534
1643	celery	NOT_CONFIGURED	\N	2026-08-19 16:57:54.722534
1644	email	HEALTHY	\N	2026-08-19 16:57:54.722534
1645	backup	UNAVAILABLE	\N	2026-08-19 16:57:54.722534
1646	sentry	NOT_CONFIGURED	\N	2026-08-19 16:57:54.722534
1647	openai	NOT_CONFIGURED	\N	2026-08-19 16:57:54.722534
1648	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:57:54.722534
1649	simulation	HEALTHY	\N	2026-08-19 16:57:54.722534
1650	application	HEALTHY	4.5	2026-08-19 16:57:54.722534
1728	database	HEALTHY	0	2026-08-19 17:01:55.137988
1729	redis	NOT_CONFIGURED	\N	2026-08-19 17:01:55.137988
1730	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:01:55.137988
1731	celery	NOT_CONFIGURED	\N	2026-08-19 17:01:55.137988
1732	email	HEALTHY	\N	2026-08-19 17:01:55.137988
1733	backup	UNAVAILABLE	\N	2026-08-19 17:01:55.137988
1734	sentry	NOT_CONFIGURED	\N	2026-08-19 17:01:55.137988
1735	openai	NOT_CONFIGURED	\N	2026-08-19 17:01:55.137988
1736	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:01:55.137988
1737	simulation	HEALTHY	\N	2026-08-19 17:01:55.137988
1738	application	HEALTHY	4.5	2026-08-19 17:01:55.137988
1882	database	HEALTHY	0.98	2026-08-19 17:08:55.627902
1883	redis	NOT_CONFIGURED	\N	2026-08-19 17:08:55.627902
1884	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:08:55.627902
1885	celery	NOT_CONFIGURED	\N	2026-08-19 17:08:55.627902
1886	email	HEALTHY	\N	2026-08-19 17:08:55.627902
1887	backup	UNAVAILABLE	\N	2026-08-19 17:08:55.627902
1888	sentry	NOT_CONFIGURED	\N	2026-08-19 17:08:55.627902
1889	openai	NOT_CONFIGURED	\N	2026-08-19 17:08:55.627902
1890	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:08:55.627902
1891	simulation	HEALTHY	\N	2026-08-19 17:08:55.627902
1892	application	HEALTHY	4.5	2026-08-19 17:08:55.627902
1920	backup	UNAVAILABLE	\N	2026-08-19 17:10:25.715988
1921	sentry	NOT_CONFIGURED	\N	2026-08-19 17:10:25.715988
1922	openai	NOT_CONFIGURED	\N	2026-08-19 17:10:25.715988
1923	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:10:25.715988
1924	simulation	HEALTHY	\N	2026-08-19 17:10:25.715988
1925	application	HEALTHY	4.5	2026-08-19 17:10:25.715988
1937	database	HEALTHY	1	2026-08-19 17:11:25.815368
1938	redis	NOT_CONFIGURED	\N	2026-08-19 17:11:25.815368
1939	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:11:25.815368
1940	celery	NOT_CONFIGURED	\N	2026-08-19 17:11:25.815368
1941	email	HEALTHY	\N	2026-08-19 17:11:25.816366
1942	backup	UNAVAILABLE	\N	2026-08-19 17:11:25.816366
1943	sentry	NOT_CONFIGURED	\N	2026-08-19 17:11:25.816366
1944	openai	NOT_CONFIGURED	\N	2026-08-19 17:11:25.816366
1945	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:11:25.816366
1946	simulation	HEALTHY	\N	2026-08-19 17:11:25.816366
1947	application	HEALTHY	4.5	2026-08-19 17:11:25.816366
1959	database	HEALTHY	0	2026-08-19 17:12:25.894247
1960	redis	NOT_CONFIGURED	\N	2026-08-19 17:12:25.895254
1961	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:12:25.895254
1962	celery	NOT_CONFIGURED	\N	2026-08-19 17:12:25.895254
1963	email	HEALTHY	\N	2026-08-19 17:12:25.895254
1964	backup	UNAVAILABLE	\N	2026-08-19 17:12:25.895254
1965	sentry	NOT_CONFIGURED	\N	2026-08-19 17:12:25.895254
1966	openai	NOT_CONFIGURED	\N	2026-08-19 17:12:25.895254
1967	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:12:25.895254
1968	simulation	HEALTHY	\N	2026-08-19 17:12:25.895254
1969	application	HEALTHY	4.5	2026-08-19 17:12:25.895254
1979	simulation	HEALTHY	\N	2026-08-19 17:12:55.919062
1980	application	HEALTHY	4.5	2026-08-19 17:12:55.919062
1981	database	HEALTHY	1	2026-08-19 17:13:25.942114
1982	redis	NOT_CONFIGURED	\N	2026-08-19 17:13:25.942114
1983	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:13:25.942114
1984	celery	NOT_CONFIGURED	\N	2026-08-19 17:13:25.942114
936	database	HEALTHY	1.02	2026-08-19 16:25:51.532387
937	redis	NOT_CONFIGURED	\N	2026-08-19 16:25:51.532387
938	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:25:51.532387
939	celery	NOT_CONFIGURED	\N	2026-08-19 16:25:51.53339
940	email	HEALTHY	\N	2026-08-19 16:25:51.53339
941	backup	UNAVAILABLE	\N	2026-08-19 16:25:51.53339
942	sentry	NOT_CONFIGURED	\N	2026-08-19 16:25:51.53339
943	openai	NOT_CONFIGURED	\N	2026-08-19 16:25:51.53339
944	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:25:51.53339
945	simulation	HEALTHY	\N	2026-08-19 16:25:51.53339
946	application	HEALTHY	4.5	2026-08-19 16:25:51.53339
947	database	HEALTHY	1.2	2026-08-19 16:26:21.566467
948	redis	NOT_CONFIGURED	\N	2026-08-19 16:26:21.566467
949	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:26:21.566467
950	celery	NOT_CONFIGURED	\N	2026-08-19 16:26:21.566467
951	email	HEALTHY	\N	2026-08-19 16:26:21.566467
952	backup	UNAVAILABLE	\N	2026-08-19 16:26:21.566467
953	sentry	NOT_CONFIGURED	\N	2026-08-19 16:26:21.567666
954	openai	NOT_CONFIGURED	\N	2026-08-19 16:26:21.567666
955	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:26:21.567666
956	simulation	HEALTHY	\N	2026-08-19 16:26:21.567666
957	application	HEALTHY	4.5	2026-08-19 16:26:21.567666
958	database	HEALTHY	0	2026-08-19 16:26:51.709669
959	redis	NOT_CONFIGURED	\N	2026-08-19 16:26:51.709669
960	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:26:51.709669
961	celery	NOT_CONFIGURED	\N	2026-08-19 16:26:51.709669
962	email	HEALTHY	\N	2026-08-19 16:26:51.709669
963	backup	UNAVAILABLE	\N	2026-08-19 16:26:51.709669
964	sentry	NOT_CONFIGURED	\N	2026-08-19 16:26:51.709669
965	openai	NOT_CONFIGURED	\N	2026-08-19 16:26:51.709669
966	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:26:51.709669
967	simulation	HEALTHY	\N	2026-08-19 16:26:51.709669
968	application	HEALTHY	4.5	2026-08-19 16:26:51.709669
969	database	HEALTHY	0	2026-08-19 16:27:21.740383
970	redis	NOT_CONFIGURED	\N	2026-08-19 16:27:21.740383
971	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:27:21.740383
972	celery	NOT_CONFIGURED	\N	2026-08-19 16:27:21.740383
973	email	HEALTHY	\N	2026-08-19 16:27:21.740383
974	backup	UNAVAILABLE	\N	2026-08-19 16:27:21.740383
975	sentry	NOT_CONFIGURED	\N	2026-08-19 16:27:21.740383
976	openai	NOT_CONFIGURED	\N	2026-08-19 16:27:21.740383
977	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:27:21.740383
978	simulation	HEALTHY	\N	2026-08-19 16:27:21.740383
979	application	HEALTHY	4.5	2026-08-19 16:27:21.740383
980	database	HEALTHY	2.99	2026-08-19 16:27:51.799375
981	redis	NOT_CONFIGURED	\N	2026-08-19 16:27:51.799375
982	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:27:51.799375
983	celery	NOT_CONFIGURED	\N	2026-08-19 16:27:51.799375
984	email	HEALTHY	\N	2026-08-19 16:27:51.799375
985	backup	UNAVAILABLE	\N	2026-08-19 16:27:51.799375
986	sentry	NOT_CONFIGURED	\N	2026-08-19 16:27:51.799375
987	openai	NOT_CONFIGURED	\N	2026-08-19 16:27:51.799375
988	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:27:51.799375
989	simulation	HEALTHY	\N	2026-08-19 16:27:51.799375
990	application	HEALTHY	4.5	2026-08-19 16:27:51.799375
991	database	HEALTHY	1	2026-08-19 16:28:21.849607
992	redis	NOT_CONFIGURED	\N	2026-08-19 16:28:21.849607
993	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:28:21.849607
994	celery	NOT_CONFIGURED	\N	2026-08-19 16:28:21.849607
995	email	HEALTHY	\N	2026-08-19 16:28:21.849607
996	backup	UNAVAILABLE	\N	2026-08-19 16:28:21.849607
997	sentry	NOT_CONFIGURED	\N	2026-08-19 16:28:21.849607
998	openai	NOT_CONFIGURED	\N	2026-08-19 16:28:21.849607
999	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:28:21.849607
1000	simulation	HEALTHY	\N	2026-08-19 16:28:21.849607
1001	application	HEALTHY	4.5	2026-08-19 16:28:21.849607
1002	database	HEALTHY	1.01	2026-08-19 16:28:51.88422
1003	redis	NOT_CONFIGURED	\N	2026-08-19 16:28:51.88422
1004	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:28:51.88422
1005	celery	NOT_CONFIGURED	\N	2026-08-19 16:28:51.88422
1006	email	HEALTHY	\N	2026-08-19 16:28:51.88422
1007	backup	UNAVAILABLE	\N	2026-08-19 16:28:51.88422
1008	sentry	NOT_CONFIGURED	\N	2026-08-19 16:28:51.88422
1009	openai	NOT_CONFIGURED	\N	2026-08-19 16:28:51.88422
1010	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:28:51.88422
1011	simulation	HEALTHY	\N	2026-08-19 16:28:51.88422
1012	application	HEALTHY	4.5	2026-08-19 16:28:51.88422
1013	database	HEALTHY	0	2026-08-19 16:29:21.917869
1014	redis	NOT_CONFIGURED	\N	2026-08-19 16:29:21.917869
1015	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:29:21.917869
1016	celery	NOT_CONFIGURED	\N	2026-08-19 16:29:21.917869
1017	email	HEALTHY	\N	2026-08-19 16:29:21.917869
1018	backup	UNAVAILABLE	\N	2026-08-19 16:29:21.917869
1019	sentry	NOT_CONFIGURED	\N	2026-08-19 16:29:21.917869
1020	openai	NOT_CONFIGURED	\N	2026-08-19 16:29:21.918885
1021	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:29:21.918885
1022	simulation	HEALTHY	\N	2026-08-19 16:29:21.918885
1023	application	HEALTHY	4.5	2026-08-19 16:29:21.918885
1024	database	HEALTHY	0	2026-08-19 16:29:51.951829
1025	redis	NOT_CONFIGURED	\N	2026-08-19 16:29:51.951829
1026	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:29:51.951829
1027	celery	NOT_CONFIGURED	\N	2026-08-19 16:29:51.951829
1028	email	HEALTHY	\N	2026-08-19 16:29:51.951829
1029	backup	UNAVAILABLE	\N	2026-08-19 16:29:51.951829
1030	sentry	NOT_CONFIGURED	\N	2026-08-19 16:29:51.951829
1031	openai	NOT_CONFIGURED	\N	2026-08-19 16:29:51.951829
1032	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:29:51.951829
1033	simulation	HEALTHY	\N	2026-08-19 16:29:51.951829
1034	application	HEALTHY	4.5	2026-08-19 16:29:51.951829
1035	database	HEALTHY	0	2026-08-19 16:30:21.983472
1036	redis	NOT_CONFIGURED	\N	2026-08-19 16:30:21.983472
1037	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:30:21.983472
1038	celery	NOT_CONFIGURED	\N	2026-08-19 16:30:21.983472
1039	email	HEALTHY	\N	2026-08-19 16:30:21.983472
1040	backup	UNAVAILABLE	\N	2026-08-19 16:30:21.983472
1041	sentry	NOT_CONFIGURED	\N	2026-08-19 16:30:21.983472
1042	openai	NOT_CONFIGURED	\N	2026-08-19 16:30:21.98526
1043	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:30:21.98526
1044	simulation	HEALTHY	\N	2026-08-19 16:30:21.98526
1045	application	HEALTHY	4.5	2026-08-19 16:30:21.98526
1046	database	HEALTHY	0	2026-08-19 16:30:52.00886
1047	redis	NOT_CONFIGURED	\N	2026-08-19 16:30:52.00886
1048	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:30:52.00886
1049	celery	NOT_CONFIGURED	\N	2026-08-19 16:30:52.00886
1050	email	HEALTHY	\N	2026-08-19 16:30:52.00886
1051	backup	UNAVAILABLE	\N	2026-08-19 16:30:52.00886
1052	sentry	NOT_CONFIGURED	\N	2026-08-19 16:30:52.00886
1053	openai	NOT_CONFIGURED	\N	2026-08-19 16:30:52.00886
1054	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:30:52.00886
1055	simulation	HEALTHY	\N	2026-08-19 16:30:52.00886
1056	application	HEALTHY	4.5	2026-08-19 16:30:52.00886
1057	database	HEALTHY	4	2026-08-19 16:31:22.11501
1058	redis	NOT_CONFIGURED	\N	2026-08-19 16:31:22.11501
1059	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:31:22.116014
1060	celery	NOT_CONFIGURED	\N	2026-08-19 16:31:22.116014
1061	email	HEALTHY	\N	2026-08-19 16:31:22.116014
1062	backup	UNAVAILABLE	\N	2026-08-19 16:31:22.116014
1063	sentry	NOT_CONFIGURED	\N	2026-08-19 16:31:22.116014
1064	openai	NOT_CONFIGURED	\N	2026-08-19 16:31:22.116014
1065	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:31:22.116014
1066	simulation	HEALTHY	\N	2026-08-19 16:31:22.116014
1067	application	HEALTHY	4.5	2026-08-19 16:31:22.116014
1255	database	HEALTHY	1	2026-08-19 16:40:22.915684
1256	redis	NOT_CONFIGURED	\N	2026-08-19 16:40:22.916712
1257	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:40:22.916712
1258	celery	NOT_CONFIGURED	\N	2026-08-19 16:40:22.916712
1259	email	HEALTHY	\N	2026-08-19 16:40:22.916712
1260	backup	UNAVAILABLE	\N	2026-08-19 16:40:22.916712
1261	sentry	NOT_CONFIGURED	\N	2026-08-19 16:40:22.916712
1262	openai	NOT_CONFIGURED	\N	2026-08-19 16:40:22.916712
1263	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:40:22.916712
1264	simulation	HEALTHY	\N	2026-08-19 16:40:22.916712
1265	application	HEALTHY	4.5	2026-08-19 16:40:22.916712
1266	database	HEALTHY	1.02	2026-08-19 16:40:52.952825
1267	redis	NOT_CONFIGURED	\N	2026-08-19 16:40:52.952825
1268	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:40:52.952825
1269	celery	NOT_CONFIGURED	\N	2026-08-19 16:40:52.952825
1270	email	HEALTHY	\N	2026-08-19 16:40:52.952825
1271	backup	UNAVAILABLE	\N	2026-08-19 16:40:52.952825
1272	sentry	NOT_CONFIGURED	\N	2026-08-19 16:40:52.952825
1273	openai	NOT_CONFIGURED	\N	2026-08-19 16:40:52.952825
1274	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:40:52.952825
1275	simulation	HEALTHY	\N	2026-08-19 16:40:52.952825
1276	application	HEALTHY	4.5	2026-08-19 16:40:52.953826
1398	database	HEALTHY	1	2026-08-19 16:46:53.826913
1399	redis	NOT_CONFIGURED	\N	2026-08-19 16:46:53.826913
1400	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:46:53.826913
1401	celery	NOT_CONFIGURED	\N	2026-08-19 16:46:53.826913
1402	email	HEALTHY	\N	2026-08-19 16:46:53.826913
1403	backup	UNAVAILABLE	\N	2026-08-19 16:46:53.826913
1404	sentry	NOT_CONFIGURED	\N	2026-08-19 16:46:53.826913
1405	openai	NOT_CONFIGURED	\N	2026-08-19 16:46:53.826913
1406	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:46:53.826913
1407	simulation	HEALTHY	\N	2026-08-19 16:46:53.826913
1408	application	HEALTHY	4.5	2026-08-19 16:46:53.826913
1431	database	HEALTHY	0	2026-08-19 16:48:23.956056
1432	redis	NOT_CONFIGURED	\N	2026-08-19 16:48:23.956056
1433	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:48:23.956056
1434	celery	NOT_CONFIGURED	\N	2026-08-19 16:48:23.956056
1435	email	HEALTHY	\N	2026-08-19 16:48:23.956056
1436	backup	UNAVAILABLE	\N	2026-08-19 16:48:23.956056
1437	sentry	NOT_CONFIGURED	\N	2026-08-19 16:48:23.956056
1438	openai	NOT_CONFIGURED	\N	2026-08-19 16:48:23.956056
1439	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:48:23.956056
1440	simulation	HEALTHY	\N	2026-08-19 16:48:23.956056
1441	application	HEALTHY	4.5	2026-08-19 16:48:23.956056
1530	database	HEALTHY	1	2026-08-19 16:52:54.367201
1531	redis	NOT_CONFIGURED	\N	2026-08-19 16:52:54.367201
1532	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:52:54.368216
1533	celery	NOT_CONFIGURED	\N	2026-08-19 16:52:54.368216
1534	email	HEALTHY	\N	2026-08-19 16:52:54.368216
1535	backup	UNAVAILABLE	\N	2026-08-19 16:52:54.368216
1536	sentry	NOT_CONFIGURED	\N	2026-08-19 16:52:54.368216
1537	openai	NOT_CONFIGURED	\N	2026-08-19 16:52:54.368216
1538	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:52:54.368216
1539	simulation	HEALTHY	\N	2026-08-19 16:52:54.368216
1540	application	HEALTHY	4.5	2026-08-19 16:52:54.368216
1596	database	HEALTHY	1	2026-08-19 16:55:54.58314
1597	redis	NOT_CONFIGURED	\N	2026-08-19 16:55:54.584144
1598	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:55:54.584144
1599	celery	NOT_CONFIGURED	\N	2026-08-19 16:55:54.584144
1600	email	HEALTHY	\N	2026-08-19 16:55:54.585141
1601	backup	UNAVAILABLE	\N	2026-08-19 16:55:54.585141
1602	sentry	NOT_CONFIGURED	\N	2026-08-19 16:55:54.585141
1603	openai	NOT_CONFIGURED	\N	2026-08-19 16:55:54.585141
1604	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:55:54.585141
1605	simulation	HEALTHY	\N	2026-08-19 16:55:54.585141
1606	application	HEALTHY	4.5	2026-08-19 16:55:54.585141
1673	database	HEALTHY	0	2026-08-19 16:59:24.861661
1674	redis	NOT_CONFIGURED	\N	2026-08-19 16:59:24.861661
1675	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:59:24.861661
1676	celery	NOT_CONFIGURED	\N	2026-08-19 16:59:24.861661
1677	email	HEALTHY	\N	2026-08-19 16:59:24.861661
1678	backup	UNAVAILABLE	\N	2026-08-19 16:59:24.861661
1679	sentry	NOT_CONFIGURED	\N	2026-08-19 16:59:24.861661
1680	openai	NOT_CONFIGURED	\N	2026-08-19 16:59:24.862679
1681	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:59:24.862679
1682	simulation	HEALTHY	\N	2026-08-19 16:59:24.862679
1683	application	HEALTHY	4.5	2026-08-19 16:59:24.862679
1750	database	HEALTHY	0	2026-08-19 17:02:55.210583
1751	redis	NOT_CONFIGURED	\N	2026-08-19 17:02:55.210583
1752	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:02:55.210583
1753	celery	NOT_CONFIGURED	\N	2026-08-19 17:02:55.210583
1754	email	HEALTHY	\N	2026-08-19 17:02:55.210583
1755	backup	UNAVAILABLE	\N	2026-08-19 17:02:55.210583
1756	sentry	NOT_CONFIGURED	\N	2026-08-19 17:02:55.210583
1757	openai	NOT_CONFIGURED	\N	2026-08-19 17:02:55.210583
1758	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:02:55.210583
1759	simulation	HEALTHY	\N	2026-08-19 17:02:55.210583
1760	application	HEALTHY	4.5	2026-08-19 17:02:55.210583
1772	database	HEALTHY	1	2026-08-19 17:03:55.272424
1773	redis	NOT_CONFIGURED	\N	2026-08-19 17:03:55.272424
1774	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:03:55.273424
1775	celery	NOT_CONFIGURED	\N	2026-08-19 17:03:55.273424
1776	email	HEALTHY	\N	2026-08-19 17:03:55.273424
1777	backup	UNAVAILABLE	\N	2026-08-19 17:03:55.273424
1778	sentry	NOT_CONFIGURED	\N	2026-08-19 17:03:55.273424
1779	openai	NOT_CONFIGURED	\N	2026-08-19 17:03:55.273424
1780	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:03:55.273424
1781	simulation	HEALTHY	\N	2026-08-19 17:03:55.273424
1782	application	HEALTHY	4.5	2026-08-19 17:03:55.273424
1893	database	HEALTHY	0.99	2026-08-19 17:09:25.651834
1894	redis	NOT_CONFIGURED	\N	2026-08-19 17:09:25.651834
1895	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:09:25.651834
1896	celery	NOT_CONFIGURED	\N	2026-08-19 17:09:25.651834
1897	email	HEALTHY	\N	2026-08-19 17:09:25.652832
1898	backup	UNAVAILABLE	\N	2026-08-19 17:09:25.652832
1899	sentry	NOT_CONFIGURED	\N	2026-08-19 17:09:25.652832
1900	openai	NOT_CONFIGURED	\N	2026-08-19 17:09:25.652832
1901	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:09:25.652832
1902	simulation	HEALTHY	\N	2026-08-19 17:09:25.652832
1903	application	HEALTHY	4.5	2026-08-19 17:09:25.652832
1926	database	HEALTHY	0	2026-08-19 17:10:55.749965
1927	redis	NOT_CONFIGURED	\N	2026-08-19 17:10:55.749965
1928	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:10:55.749965
1929	celery	NOT_CONFIGURED	\N	2026-08-19 17:10:55.749965
1930	email	HEALTHY	\N	2026-08-19 17:10:55.749965
1931	backup	UNAVAILABLE	\N	2026-08-19 17:10:55.749965
1068	database	HEALTHY	0	2026-08-19 16:31:52.153956
1069	redis	NOT_CONFIGURED	\N	2026-08-19 16:31:52.154953
1070	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:31:52.154953
1071	celery	NOT_CONFIGURED	\N	2026-08-19 16:31:52.154953
1072	email	HEALTHY	\N	2026-08-19 16:31:52.154953
1073	backup	UNAVAILABLE	\N	2026-08-19 16:31:52.154953
1074	sentry	NOT_CONFIGURED	\N	2026-08-19 16:31:52.154953
1075	openai	NOT_CONFIGURED	\N	2026-08-19 16:31:52.154953
1076	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:31:52.154953
1077	simulation	HEALTHY	\N	2026-08-19 16:31:52.154953
1078	application	HEALTHY	4.5	2026-08-19 16:31:52.154953
1277	database	HEALTHY	0.99	2026-08-19 16:41:22.98843
1278	redis	NOT_CONFIGURED	\N	2026-08-19 16:41:22.98843
1279	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:41:22.98843
1280	celery	NOT_CONFIGURED	\N	2026-08-19 16:41:22.98843
1281	email	HEALTHY	\N	2026-08-19 16:41:22.98843
1282	backup	UNAVAILABLE	\N	2026-08-19 16:41:22.98843
1283	sentry	NOT_CONFIGURED	\N	2026-08-19 16:41:22.98843
1284	openai	NOT_CONFIGURED	\N	2026-08-19 16:41:22.98843
1285	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:41:22.98843
1286	simulation	HEALTHY	\N	2026-08-19 16:41:22.989435
1287	application	HEALTHY	4.5	2026-08-19 16:41:22.989435
1442	database	HEALTHY	0	2026-08-19 16:48:53.990295
1443	redis	NOT_CONFIGURED	\N	2026-08-19 16:48:53.990295
1444	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:48:53.990295
1445	celery	NOT_CONFIGURED	\N	2026-08-19 16:48:53.990295
1446	email	HEALTHY	\N	2026-08-19 16:48:53.990295
1447	backup	UNAVAILABLE	\N	2026-08-19 16:48:53.990295
1448	sentry	NOT_CONFIGURED	\N	2026-08-19 16:48:53.990295
1449	openai	NOT_CONFIGURED	\N	2026-08-19 16:48:53.990295
1450	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:48:53.990295
1451	simulation	HEALTHY	\N	2026-08-19 16:48:53.990295
1452	application	HEALTHY	4.5	2026-08-19 16:48:53.990295
1552	database	HEALTHY	1	2026-08-19 16:53:54.446557
1553	redis	NOT_CONFIGURED	\N	2026-08-19 16:53:54.446557
1554	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:53:54.446557
1555	celery	NOT_CONFIGURED	\N	2026-08-19 16:53:54.447557
1556	email	HEALTHY	\N	2026-08-19 16:53:54.447557
1557	backup	UNAVAILABLE	\N	2026-08-19 16:53:54.447557
1558	sentry	NOT_CONFIGURED	\N	2026-08-19 16:53:54.447557
1559	openai	NOT_CONFIGURED	\N	2026-08-19 16:53:54.447557
1560	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:53:54.447557
1561	simulation	HEALTHY	\N	2026-08-19 16:53:54.447557
1562	application	HEALTHY	4.5	2026-08-19 16:53:54.447557
1629	database	HEALTHY	1	2026-08-19 16:57:24.676924
1630	redis	NOT_CONFIGURED	\N	2026-08-19 16:57:24.676924
1631	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:57:24.676924
1632	celery	NOT_CONFIGURED	\N	2026-08-19 16:57:24.676924
1633	email	HEALTHY	\N	2026-08-19 16:57:24.676924
1634	backup	UNAVAILABLE	\N	2026-08-19 16:57:24.676924
1635	sentry	NOT_CONFIGURED	\N	2026-08-19 16:57:24.676924
1636	openai	NOT_CONFIGURED	\N	2026-08-19 16:57:24.676924
1637	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:57:24.676924
1638	simulation	HEALTHY	\N	2026-08-19 16:57:24.676924
1639	application	HEALTHY	4.5	2026-08-19 16:57:24.676924
1684	database	HEALTHY	0	2026-08-19 16:59:54.900707
1685	redis	NOT_CONFIGURED	\N	2026-08-19 16:59:54.900707
1686	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:59:54.900707
1687	celery	NOT_CONFIGURED	\N	2026-08-19 16:59:54.900707
1688	email	HEALTHY	\N	2026-08-19 16:59:54.900707
1689	backup	UNAVAILABLE	\N	2026-08-19 16:59:54.900707
1690	sentry	NOT_CONFIGURED	\N	2026-08-19 16:59:54.900707
1691	openai	NOT_CONFIGURED	\N	2026-08-19 16:59:54.900707
1692	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:59:54.900707
1693	simulation	HEALTHY	\N	2026-08-19 16:59:54.900707
1694	application	HEALTHY	4.5	2026-08-19 16:59:54.901707
1805	database	HEALTHY	0	2026-08-19 17:05:25.393812
1806	redis	NOT_CONFIGURED	\N	2026-08-19 17:05:25.393812
1807	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:05:25.395155
1808	celery	NOT_CONFIGURED	\N	2026-08-19 17:05:25.395155
1809	email	HEALTHY	\N	2026-08-19 17:05:25.395155
1810	backup	UNAVAILABLE	\N	2026-08-19 17:05:25.395155
1811	sentry	NOT_CONFIGURED	\N	2026-08-19 17:05:25.395155
1812	openai	NOT_CONFIGURED	\N	2026-08-19 17:05:25.395155
1813	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:05:25.395155
1814	simulation	HEALTHY	\N	2026-08-19 17:05:25.395155
1815	application	HEALTHY	4.5	2026-08-19 17:05:25.395155
1871	database	HEALTHY	1	2026-08-19 17:08:25.599105
1872	redis	NOT_CONFIGURED	\N	2026-08-19 17:08:25.599105
1873	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:08:25.599105
1874	celery	NOT_CONFIGURED	\N	2026-08-19 17:08:25.599105
1875	email	HEALTHY	\N	2026-08-19 17:08:25.600226
1876	backup	UNAVAILABLE	\N	2026-08-19 17:08:25.600226
1877	sentry	NOT_CONFIGURED	\N	2026-08-19 17:08:25.600226
1878	openai	NOT_CONFIGURED	\N	2026-08-19 17:08:25.600226
1879	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:08:25.600226
1880	simulation	HEALTHY	\N	2026-08-19 17:08:25.600226
1881	application	HEALTHY	4.5	2026-08-19 17:08:25.600226
1904	database	HEALTHY	0	2026-08-19 17:09:55.684407
1905	redis	NOT_CONFIGURED	\N	2026-08-19 17:09:55.684407
1906	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:09:55.684407
1907	celery	NOT_CONFIGURED	\N	2026-08-19 17:09:55.684407
1908	email	HEALTHY	\N	2026-08-19 17:09:55.684407
1909	backup	UNAVAILABLE	\N	2026-08-19 17:09:55.684407
1910	sentry	NOT_CONFIGURED	\N	2026-08-19 17:09:55.684407
1911	openai	NOT_CONFIGURED	\N	2026-08-19 17:09:55.684407
1912	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:09:55.685409
1913	simulation	HEALTHY	\N	2026-08-19 17:09:55.685409
1914	application	HEALTHY	4.5	2026-08-19 17:09:55.685409
1932	sentry	NOT_CONFIGURED	\N	2026-08-19 17:10:55.749965
1933	openai	NOT_CONFIGURED	\N	2026-08-19 17:10:55.749965
1934	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:10:55.749965
1935	simulation	HEALTHY	\N	2026-08-19 17:10:55.749965
1936	application	HEALTHY	4.5	2026-08-19 17:10:55.749965
1948	database	HEALTHY	0	2026-08-19 17:11:55.854241
1949	redis	NOT_CONFIGURED	\N	2026-08-19 17:11:55.854241
1950	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:11:55.854241
1951	celery	NOT_CONFIGURED	\N	2026-08-19 17:11:55.854241
1952	email	HEALTHY	\N	2026-08-19 17:11:55.854241
1953	backup	UNAVAILABLE	\N	2026-08-19 17:11:55.854241
1954	sentry	NOT_CONFIGURED	\N	2026-08-19 17:11:55.854241
1955	openai	NOT_CONFIGURED	\N	2026-08-19 17:11:55.854241
1956	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:11:55.854241
1957	simulation	HEALTHY	\N	2026-08-19 17:11:55.854241
1958	application	HEALTHY	4.5	2026-08-19 17:11:55.854241
1970	database	HEALTHY	1.03	2026-08-19 17:12:55.91806
1971	redis	NOT_CONFIGURED	\N	2026-08-19 17:12:55.91806
1972	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:12:55.91806
1973	celery	NOT_CONFIGURED	\N	2026-08-19 17:12:55.919062
1974	email	HEALTHY	\N	2026-08-19 17:12:55.919062
1975	backup	UNAVAILABLE	\N	2026-08-19 17:12:55.919062
1976	sentry	NOT_CONFIGURED	\N	2026-08-19 17:12:55.919062
1977	openai	NOT_CONFIGURED	\N	2026-08-19 17:12:55.919062
1978	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:12:55.919062
1079	database	HEALTHY	1.04	2026-08-19 16:32:22.185859
1080	redis	NOT_CONFIGURED	\N	2026-08-19 16:32:22.186818
1081	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:32:22.186818
1082	celery	NOT_CONFIGURED	\N	2026-08-19 16:32:22.186818
1083	email	HEALTHY	\N	2026-08-19 16:32:22.186818
1084	backup	UNAVAILABLE	\N	2026-08-19 16:32:22.186818
1085	sentry	NOT_CONFIGURED	\N	2026-08-19 16:32:22.186818
1086	openai	NOT_CONFIGURED	\N	2026-08-19 16:32:22.186818
1087	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:32:22.186818
1088	simulation	HEALTHY	\N	2026-08-19 16:32:22.186818
1089	application	HEALTHY	4.5	2026-08-19 16:32:22.186818
1288	database	HEALTHY	0	2026-08-19 16:41:53.039874
1289	redis	NOT_CONFIGURED	\N	2026-08-19 16:41:53.039874
1290	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:41:53.039874
1291	celery	NOT_CONFIGURED	\N	2026-08-19 16:41:53.039874
1292	email	HEALTHY	\N	2026-08-19 16:41:53.039874
1293	backup	UNAVAILABLE	\N	2026-08-19 16:41:53.039874
1294	sentry	NOT_CONFIGURED	\N	2026-08-19 16:41:53.039874
1295	openai	NOT_CONFIGURED	\N	2026-08-19 16:41:53.039874
1296	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:41:53.039874
1297	simulation	HEALTHY	\N	2026-08-19 16:41:53.039874
1298	application	HEALTHY	4.5	2026-08-19 16:41:53.039874
1310	database	HEALTHY	1	2026-08-19 16:42:53.12398
1311	redis	NOT_CONFIGURED	\N	2026-08-19 16:42:53.12398
1312	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:42:53.12398
1313	celery	NOT_CONFIGURED	\N	2026-08-19 16:42:53.125099
1314	email	HEALTHY	\N	2026-08-19 16:42:53.125099
1315	backup	UNAVAILABLE	\N	2026-08-19 16:42:53.125099
1316	sentry	NOT_CONFIGURED	\N	2026-08-19 16:42:53.125099
1317	openai	NOT_CONFIGURED	\N	2026-08-19 16:42:53.125099
1318	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:42:53.125099
1319	simulation	HEALTHY	\N	2026-08-19 16:42:53.125099
1320	application	HEALTHY	4.5	2026-08-19 16:42:53.125099
1332	database	HEALTHY	1.02	2026-08-19 16:43:53.236274
1333	redis	NOT_CONFIGURED	\N	2026-08-19 16:43:53.236274
1334	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:43:53.236274
1335	celery	NOT_CONFIGURED	\N	2026-08-19 16:43:53.236274
1336	email	HEALTHY	\N	2026-08-19 16:43:53.236274
1337	backup	UNAVAILABLE	\N	2026-08-19 16:43:53.236274
1338	sentry	NOT_CONFIGURED	\N	2026-08-19 16:43:53.236274
1339	openai	NOT_CONFIGURED	\N	2026-08-19 16:43:53.236274
1340	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:43:53.237251
1341	simulation	HEALTHY	\N	2026-08-19 16:43:53.237251
1342	application	HEALTHY	4.5	2026-08-19 16:43:53.237251
1475	database	HEALTHY	1.17	2026-08-19 16:50:24.100571
1476	redis	NOT_CONFIGURED	\N	2026-08-19 16:50:24.100571
1477	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:50:24.100571
1478	celery	NOT_CONFIGURED	\N	2026-08-19 16:50:24.100571
1479	email	HEALTHY	\N	2026-08-19 16:50:24.100571
1480	backup	UNAVAILABLE	\N	2026-08-19 16:50:24.100571
1481	sentry	NOT_CONFIGURED	\N	2026-08-19 16:50:24.100571
1482	openai	NOT_CONFIGURED	\N	2026-08-19 16:50:24.100571
1483	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:50:24.101579
1484	simulation	HEALTHY	\N	2026-08-19 16:50:24.101579
1485	application	HEALTHY	4.5	2026-08-19 16:50:24.101579
1541	database	HEALTHY	0.96	2026-08-19 16:53:24.409707
1542	redis	NOT_CONFIGURED	\N	2026-08-19 16:53:24.409707
1543	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:53:24.409707
1544	celery	NOT_CONFIGURED	\N	2026-08-19 16:53:24.409707
1545	email	HEALTHY	\N	2026-08-19 16:53:24.409707
1546	backup	UNAVAILABLE	\N	2026-08-19 16:53:24.409707
1547	sentry	NOT_CONFIGURED	\N	2026-08-19 16:53:24.409707
1548	openai	NOT_CONFIGURED	\N	2026-08-19 16:53:24.409707
1549	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:53:24.409707
1550	simulation	HEALTHY	\N	2026-08-19 16:53:24.409707
1551	application	HEALTHY	4.5	2026-08-19 16:53:24.409707
1563	database	HEALTHY	1	2026-08-19 16:54:24.482785
1564	redis	NOT_CONFIGURED	\N	2026-08-19 16:54:24.483784
1565	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:54:24.483784
1566	celery	NOT_CONFIGURED	\N	2026-08-19 16:54:24.483784
1567	email	HEALTHY	\N	2026-08-19 16:54:24.483784
1568	backup	UNAVAILABLE	\N	2026-08-19 16:54:24.483784
1569	sentry	NOT_CONFIGURED	\N	2026-08-19 16:54:24.483784
1570	openai	NOT_CONFIGURED	\N	2026-08-19 16:54:24.483784
1571	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:54:24.483784
1572	simulation	HEALTHY	\N	2026-08-19 16:54:24.483784
1573	application	HEALTHY	4.5	2026-08-19 16:54:24.483784
1651	database	HEALTHY	0	2026-08-19 16:58:24.777371
1652	redis	NOT_CONFIGURED	\N	2026-08-19 16:58:24.777371
1653	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:58:24.777371
1654	celery	NOT_CONFIGURED	\N	2026-08-19 16:58:24.777371
1655	email	HEALTHY	\N	2026-08-19 16:58:24.777371
1656	backup	UNAVAILABLE	\N	2026-08-19 16:58:24.778378
1657	sentry	NOT_CONFIGURED	\N	2026-08-19 16:58:24.778378
1658	openai	NOT_CONFIGURED	\N	2026-08-19 16:58:24.778378
1659	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:58:24.778378
1660	simulation	HEALTHY	\N	2026-08-19 16:58:24.778378
1661	application	HEALTHY	4.5	2026-08-19 16:58:24.778378
1695	database	HEALTHY	1	2026-08-19 17:00:24.962356
1696	redis	NOT_CONFIGURED	\N	2026-08-19 17:00:24.962356
1697	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:00:24.962356
1698	celery	NOT_CONFIGURED	\N	2026-08-19 17:00:24.962356
1699	email	HEALTHY	\N	2026-08-19 17:00:24.962356
1700	backup	UNAVAILABLE	\N	2026-08-19 17:00:24.962356
1701	sentry	NOT_CONFIGURED	\N	2026-08-19 17:00:24.963357
1702	openai	NOT_CONFIGURED	\N	2026-08-19 17:00:24.963357
1703	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:00:24.963357
1704	simulation	HEALTHY	\N	2026-08-19 17:00:24.963357
1705	application	HEALTHY	4.5	2026-08-19 17:00:24.963357
1739	database	HEALTHY	0	2026-08-19 17:02:25.177388
1740	redis	NOT_CONFIGURED	\N	2026-08-19 17:02:25.177388
1741	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:02:25.177388
1742	celery	NOT_CONFIGURED	\N	2026-08-19 17:02:25.177388
1743	email	HEALTHY	\N	2026-08-19 17:02:25.177388
1744	backup	UNAVAILABLE	\N	2026-08-19 17:02:25.177388
1745	sentry	NOT_CONFIGURED	\N	2026-08-19 17:02:25.177388
1746	openai	NOT_CONFIGURED	\N	2026-08-19 17:02:25.177388
1747	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:02:25.177388
1748	simulation	HEALTHY	\N	2026-08-19 17:02:25.177388
1749	application	HEALTHY	4.5	2026-08-19 17:02:25.177388
1816	database	HEALTHY	0.97	2026-08-19 17:05:55.431079
1817	redis	NOT_CONFIGURED	\N	2026-08-19 17:05:55.431079
1818	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:05:55.431079
1819	celery	NOT_CONFIGURED	\N	2026-08-19 17:05:55.431079
1820	email	HEALTHY	\N	2026-08-19 17:05:55.431079
1821	backup	UNAVAILABLE	\N	2026-08-19 17:05:55.431079
1822	sentry	NOT_CONFIGURED	\N	2026-08-19 17:05:55.431079
1823	openai	NOT_CONFIGURED	\N	2026-08-19 17:05:55.431079
1824	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:05:55.432081
1825	simulation	HEALTHY	\N	2026-08-19 17:05:55.432081
1826	application	HEALTHY	4.5	2026-08-19 17:05:55.432081
1827	database	HEALTHY	1	2026-08-19 17:06:25.467058
1828	redis	NOT_CONFIGURED	\N	2026-08-19 17:06:25.467058
1829	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:06:25.467058
1090	database	HEALTHY	0	2026-08-19 16:32:52.218544
1091	redis	NOT_CONFIGURED	\N	2026-08-19 16:32:52.218544
1092	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:32:52.218544
1093	celery	NOT_CONFIGURED	\N	2026-08-19 16:32:52.218544
1094	email	HEALTHY	\N	2026-08-19 16:32:52.218544
1095	backup	UNAVAILABLE	\N	2026-08-19 16:32:52.218544
1096	sentry	NOT_CONFIGURED	\N	2026-08-19 16:32:52.218544
1097	openai	NOT_CONFIGURED	\N	2026-08-19 16:32:52.218544
1098	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:32:52.218544
1099	simulation	HEALTHY	\N	2026-08-19 16:32:52.218544
1100	application	HEALTHY	4.5	2026-08-19 16:32:52.218544
1101	database	HEALTHY	0.99	2026-08-19 16:33:22.244293
1102	redis	NOT_CONFIGURED	\N	2026-08-19 16:33:22.245293
1103	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:33:22.245293
1104	celery	NOT_CONFIGURED	\N	2026-08-19 16:33:22.245293
1105	email	HEALTHY	\N	2026-08-19 16:33:22.245293
1106	backup	UNAVAILABLE	\N	2026-08-19 16:33:22.245293
1107	sentry	NOT_CONFIGURED	\N	2026-08-19 16:33:22.245293
1108	openai	NOT_CONFIGURED	\N	2026-08-19 16:33:22.245293
1109	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:33:22.245293
1110	simulation	HEALTHY	\N	2026-08-19 16:33:22.245293
1111	application	HEALTHY	4.5	2026-08-19 16:33:22.245293
1112	database	HEALTHY	3.11	2026-08-19 16:33:52.306064
1113	redis	NOT_CONFIGURED	\N	2026-08-19 16:33:52.306064
1114	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:33:52.306064
1115	celery	NOT_CONFIGURED	\N	2026-08-19 16:33:52.307043
1116	email	HEALTHY	\N	2026-08-19 16:33:52.307043
1117	backup	UNAVAILABLE	\N	2026-08-19 16:33:52.307043
1118	sentry	NOT_CONFIGURED	\N	2026-08-19 16:33:52.307043
1119	openai	NOT_CONFIGURED	\N	2026-08-19 16:33:52.307043
1120	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:33:52.307043
1121	simulation	HEALTHY	\N	2026-08-19 16:33:52.307043
1122	application	HEALTHY	4.5	2026-08-19 16:33:52.307043
1123	database	HEALTHY	0	2026-08-19 16:34:22.357495
1124	redis	NOT_CONFIGURED	\N	2026-08-19 16:34:22.357495
1125	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:34:22.357495
1126	celery	NOT_CONFIGURED	\N	2026-08-19 16:34:22.357495
1127	email	HEALTHY	\N	2026-08-19 16:34:22.357495
1128	backup	UNAVAILABLE	\N	2026-08-19 16:34:22.357495
1129	sentry	NOT_CONFIGURED	\N	2026-08-19 16:34:22.357495
1130	openai	NOT_CONFIGURED	\N	2026-08-19 16:34:22.357495
1131	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:34:22.357495
1132	simulation	HEALTHY	\N	2026-08-19 16:34:22.357495
1133	application	HEALTHY	4.5	2026-08-19 16:34:22.358492
1134	database	HEALTHY	1	2026-08-19 16:34:52.402575
1135	redis	NOT_CONFIGURED	\N	2026-08-19 16:34:52.403576
1136	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:34:52.403576
1137	celery	NOT_CONFIGURED	\N	2026-08-19 16:34:52.403576
1138	email	HEALTHY	\N	2026-08-19 16:34:52.403576
1139	backup	UNAVAILABLE	\N	2026-08-19 16:34:52.403576
1140	sentry	NOT_CONFIGURED	\N	2026-08-19 16:34:52.403576
1141	openai	NOT_CONFIGURED	\N	2026-08-19 16:34:52.403576
1142	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:34:52.403576
1143	simulation	HEALTHY	\N	2026-08-19 16:34:52.403576
1144	application	HEALTHY	4.5	2026-08-19 16:34:52.403576
1145	database	HEALTHY	0.97	2026-08-19 16:35:22.443843
1146	redis	NOT_CONFIGURED	\N	2026-08-19 16:35:22.443843
1147	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:35:22.443843
1148	celery	NOT_CONFIGURED	\N	2026-08-19 16:35:22.443843
1149	email	HEALTHY	\N	2026-08-19 16:35:22.443843
1150	backup	UNAVAILABLE	\N	2026-08-19 16:35:22.443843
1151	sentry	NOT_CONFIGURED	\N	2026-08-19 16:35:22.443843
1152	openai	NOT_CONFIGURED	\N	2026-08-19 16:35:22.443843
1153	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:35:22.443843
1154	simulation	HEALTHY	\N	2026-08-19 16:35:22.443843
1155	application	HEALTHY	4.5	2026-08-19 16:35:22.443843
1156	database	HEALTHY	0	2026-08-19 16:35:52.503398
1157	redis	NOT_CONFIGURED	\N	2026-08-19 16:35:52.503398
1158	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:35:52.503398
1159	celery	NOT_CONFIGURED	\N	2026-08-19 16:35:52.503398
1160	email	HEALTHY	\N	2026-08-19 16:35:52.503398
1161	backup	UNAVAILABLE	\N	2026-08-19 16:35:52.503398
1162	sentry	NOT_CONFIGURED	\N	2026-08-19 16:35:52.503398
1163	openai	NOT_CONFIGURED	\N	2026-08-19 16:35:52.503398
1164	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:35:52.503398
1165	simulation	HEALTHY	\N	2026-08-19 16:35:52.503398
1166	application	HEALTHY	4.5	2026-08-19 16:35:52.503398
1167	database	HEALTHY	1	2026-08-19 16:36:22.539664
1168	redis	NOT_CONFIGURED	\N	2026-08-19 16:36:22.539664
1169	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:36:22.539664
1170	celery	NOT_CONFIGURED	\N	2026-08-19 16:36:22.539664
1171	email	HEALTHY	\N	2026-08-19 16:36:22.539664
1172	backup	UNAVAILABLE	\N	2026-08-19 16:36:22.539664
1173	sentry	NOT_CONFIGURED	\N	2026-08-19 16:36:22.539664
1174	openai	NOT_CONFIGURED	\N	2026-08-19 16:36:22.539664
1175	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:36:22.539664
1176	simulation	HEALTHY	\N	2026-08-19 16:36:22.539664
1177	application	HEALTHY	4.5	2026-08-19 16:36:22.54062
1178	database	HEALTHY	0.97	2026-08-19 16:36:52.574143
1179	redis	NOT_CONFIGURED	\N	2026-08-19 16:36:52.574143
1180	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:36:52.574143
1181	celery	NOT_CONFIGURED	\N	2026-08-19 16:36:52.574143
1182	email	HEALTHY	\N	2026-08-19 16:36:52.574143
1183	backup	UNAVAILABLE	\N	2026-08-19 16:36:52.574143
1184	sentry	NOT_CONFIGURED	\N	2026-08-19 16:36:52.574143
1185	openai	NOT_CONFIGURED	\N	2026-08-19 16:36:52.574143
1186	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:36:52.574143
1187	simulation	HEALTHY	\N	2026-08-19 16:36:52.574143
1188	application	HEALTHY	4.5	2026-08-19 16:36:52.574143
1189	database	HEALTHY	0.99	2026-08-19 16:37:22.610649
1190	redis	NOT_CONFIGURED	\N	2026-08-19 16:37:22.610649
1191	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:37:22.610649
1192	celery	NOT_CONFIGURED	\N	2026-08-19 16:37:22.610649
1193	email	HEALTHY	\N	2026-08-19 16:37:22.610649
1194	backup	UNAVAILABLE	\N	2026-08-19 16:37:22.610649
1195	sentry	NOT_CONFIGURED	\N	2026-08-19 16:37:22.610649
1196	openai	NOT_CONFIGURED	\N	2026-08-19 16:37:22.610649
1197	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:37:22.610649
1198	simulation	HEALTHY	\N	2026-08-19 16:37:22.612
1199	application	HEALTHY	4.5	2026-08-19 16:37:22.612
1200	database	HEALTHY	0	2026-08-19 16:37:52.647498
1201	redis	NOT_CONFIGURED	\N	2026-08-19 16:37:52.647498
1202	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:37:52.647498
1203	celery	NOT_CONFIGURED	\N	2026-08-19 16:37:52.647498
1204	email	HEALTHY	\N	2026-08-19 16:37:52.647498
1205	backup	UNAVAILABLE	\N	2026-08-19 16:37:52.648498
1206	sentry	NOT_CONFIGURED	\N	2026-08-19 16:37:52.648498
1207	openai	NOT_CONFIGURED	\N	2026-08-19 16:37:52.648498
1208	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:37:52.648498
1209	simulation	HEALTHY	\N	2026-08-19 16:37:52.648498
1210	application	HEALTHY	4.5	2026-08-19 16:37:52.648498
1211	database	HEALTHY	1.01	2026-08-19 16:38:22.697947
1212	redis	NOT_CONFIGURED	\N	2026-08-19 16:38:22.698948
1213	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:38:22.698948
1214	celery	NOT_CONFIGURED	\N	2026-08-19 16:38:22.698948
1215	email	HEALTHY	\N	2026-08-19 16:38:22.698948
1216	backup	UNAVAILABLE	\N	2026-08-19 16:38:22.698948
1217	sentry	NOT_CONFIGURED	\N	2026-08-19 16:38:22.698948
1218	openai	NOT_CONFIGURED	\N	2026-08-19 16:38:22.698948
1219	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:38:22.698948
1220	simulation	HEALTHY	\N	2026-08-19 16:38:22.698948
1221	application	HEALTHY	4.5	2026-08-19 16:38:22.698948
1299	database	HEALTHY	1.01	2026-08-19 16:42:23.083042
1300	redis	NOT_CONFIGURED	\N	2026-08-19 16:42:23.083042
1301	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:42:23.083042
1302	celery	NOT_CONFIGURED	\N	2026-08-19 16:42:23.083042
1303	email	HEALTHY	\N	2026-08-19 16:42:23.083042
1304	backup	UNAVAILABLE	\N	2026-08-19 16:42:23.083042
1305	sentry	NOT_CONFIGURED	\N	2026-08-19 16:42:23.083042
1306	openai	NOT_CONFIGURED	\N	2026-08-19 16:42:23.083042
1307	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:42:23.083042
1308	simulation	HEALTHY	\N	2026-08-19 16:42:23.083042
1309	application	HEALTHY	4.5	2026-08-19 16:42:23.083042
1321	database	HEALTHY	3	2026-08-19 16:43:23.200799
1322	redis	NOT_CONFIGURED	\N	2026-08-19 16:43:23.200799
1323	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:43:23.200799
1324	celery	NOT_CONFIGURED	\N	2026-08-19 16:43:23.200799
1325	email	HEALTHY	\N	2026-08-19 16:43:23.200799
1326	backup	UNAVAILABLE	\N	2026-08-19 16:43:23.200799
1327	sentry	NOT_CONFIGURED	\N	2026-08-19 16:43:23.200799
1328	openai	NOT_CONFIGURED	\N	2026-08-19 16:43:23.200799
1329	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:43:23.200799
1330	simulation	HEALTHY	\N	2026-08-19 16:43:23.200799
1331	application	HEALTHY	4.5	2026-08-19 16:43:23.200799
1376	database	HEALTHY	0	2026-08-19 16:45:53.744071
1377	redis	NOT_CONFIGURED	\N	2026-08-19 16:45:53.744071
1378	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:45:53.744071
1379	celery	NOT_CONFIGURED	\N	2026-08-19 16:45:53.744071
1380	email	HEALTHY	\N	2026-08-19 16:45:53.744071
1381	backup	UNAVAILABLE	\N	2026-08-19 16:45:53.744071
1382	sentry	NOT_CONFIGURED	\N	2026-08-19 16:45:53.744071
1383	openai	NOT_CONFIGURED	\N	2026-08-19 16:45:53.744071
1384	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:45:53.744071
1385	simulation	HEALTHY	\N	2026-08-19 16:45:53.744071
1386	application	HEALTHY	4.5	2026-08-19 16:45:53.7451
1387	database	HEALTHY	1.09	2026-08-19 16:46:23.771516
1388	redis	NOT_CONFIGURED	\N	2026-08-19 16:46:23.771516
1389	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:46:23.771516
1390	celery	NOT_CONFIGURED	\N	2026-08-19 16:46:23.771516
1391	email	HEALTHY	\N	2026-08-19 16:46:23.771516
1392	backup	UNAVAILABLE	\N	2026-08-19 16:46:23.772522
1393	sentry	NOT_CONFIGURED	\N	2026-08-19 16:46:23.772522
1394	openai	NOT_CONFIGURED	\N	2026-08-19 16:46:23.772522
1395	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:46:23.772522
1396	simulation	HEALTHY	\N	2026-08-19 16:46:23.772522
1397	application	HEALTHY	4.5	2026-08-19 16:46:23.772522
1464	database	HEALTHY	0	2026-08-19 16:49:54.067979
1465	redis	NOT_CONFIGURED	\N	2026-08-19 16:49:54.067979
1466	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:49:54.067979
1467	celery	NOT_CONFIGURED	\N	2026-08-19 16:49:54.067979
1468	email	HEALTHY	\N	2026-08-19 16:49:54.067979
1469	backup	UNAVAILABLE	\N	2026-08-19 16:49:54.067979
1470	sentry	NOT_CONFIGURED	\N	2026-08-19 16:49:54.067979
1471	openai	NOT_CONFIGURED	\N	2026-08-19 16:49:54.067979
1472	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:49:54.067979
1473	simulation	HEALTHY	\N	2026-08-19 16:49:54.067979
1474	application	HEALTHY	4.5	2026-08-19 16:49:54.067979
1486	database	HEALTHY	0	2026-08-19 16:50:54.138581
1487	redis	NOT_CONFIGURED	\N	2026-08-19 16:50:54.139722
1488	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:50:54.139722
1489	celery	NOT_CONFIGURED	\N	2026-08-19 16:50:54.139722
1490	email	HEALTHY	\N	2026-08-19 16:50:54.139722
1491	backup	UNAVAILABLE	\N	2026-08-19 16:50:54.139722
1492	sentry	NOT_CONFIGURED	\N	2026-08-19 16:50:54.139722
1493	openai	NOT_CONFIGURED	\N	2026-08-19 16:50:54.139722
1494	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:50:54.139722
1495	simulation	HEALTHY	\N	2026-08-19 16:50:54.139722
1496	application	HEALTHY	4.5	2026-08-19 16:50:54.139722
1578	email	HEALTHY	\N	2026-08-19 16:54:54.524623
1579	backup	UNAVAILABLE	\N	2026-08-19 16:54:54.524623
1580	sentry	NOT_CONFIGURED	\N	2026-08-19 16:54:54.524623
1581	openai	NOT_CONFIGURED	\N	2026-08-19 16:54:54.524623
1582	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:54:54.524623
1583	simulation	HEALTHY	\N	2026-08-19 16:54:54.524623
1584	application	HEALTHY	4.5	2026-08-19 16:54:54.524623
1706	database	HEALTHY	1	2026-08-19 17:00:55.028197
1707	redis	NOT_CONFIGURED	\N	2026-08-19 17:00:55.028197
1708	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:00:55.028197
1709	celery	NOT_CONFIGURED	\N	2026-08-19 17:00:55.028197
1710	email	HEALTHY	\N	2026-08-19 17:00:55.028197
1711	backup	UNAVAILABLE	\N	2026-08-19 17:00:55.028197
1712	sentry	NOT_CONFIGURED	\N	2026-08-19 17:00:55.028197
1713	openai	NOT_CONFIGURED	\N	2026-08-19 17:00:55.029217
1714	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:00:55.029217
1715	simulation	HEALTHY	\N	2026-08-19 17:00:55.029217
1716	application	HEALTHY	4.5	2026-08-19 17:00:55.029217
1761	database	HEALTHY	0.61	2026-08-19 17:03:25.248021
1762	redis	NOT_CONFIGURED	\N	2026-08-19 17:03:25.248588
1763	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:03:25.248588
1764	celery	NOT_CONFIGURED	\N	2026-08-19 17:03:25.248588
1765	email	HEALTHY	\N	2026-08-19 17:03:25.248588
1766	backup	UNAVAILABLE	\N	2026-08-19 17:03:25.248588
1767	sentry	NOT_CONFIGURED	\N	2026-08-19 17:03:25.248588
1768	openai	NOT_CONFIGURED	\N	2026-08-19 17:03:25.248588
1769	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:03:25.248588
1770	simulation	HEALTHY	\N	2026-08-19 17:03:25.248588
1771	application	HEALTHY	4.5	2026-08-19 17:03:25.248588
1830	celery	NOT_CONFIGURED	\N	2026-08-19 17:06:25.467058
1831	email	HEALTHY	\N	2026-08-19 17:06:25.467058
1832	backup	UNAVAILABLE	\N	2026-08-19 17:06:25.467058
1833	sentry	NOT_CONFIGURED	\N	2026-08-19 17:06:25.467058
1834	openai	NOT_CONFIGURED	\N	2026-08-19 17:06:25.467058
1835	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:06:25.46803
1836	simulation	HEALTHY	\N	2026-08-19 17:06:25.46803
1837	application	HEALTHY	4.5	2026-08-19 17:06:25.46803
1838	database	HEALTHY	1	2026-08-19 17:06:55.509036
1839	redis	NOT_CONFIGURED	\N	2026-08-19 17:06:55.509036
1840	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:06:55.509036
1841	celery	NOT_CONFIGURED	\N	2026-08-19 17:06:55.509036
1842	email	HEALTHY	\N	2026-08-19 17:06:55.509036
1843	backup	UNAVAILABLE	\N	2026-08-19 17:06:55.509036
1844	sentry	NOT_CONFIGURED	\N	2026-08-19 17:06:55.509036
1845	openai	NOT_CONFIGURED	\N	2026-08-19 17:06:55.509036
1846	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:06:55.509036
1847	simulation	HEALTHY	\N	2026-08-19 17:06:55.509036
1848	application	HEALTHY	4.5	2026-08-19 17:06:55.509036
1915	database	HEALTHY	0	2026-08-19 17:10:25.715988
1916	redis	NOT_CONFIGURED	\N	2026-08-19 17:10:25.715988
1222	database	HEALTHY	1	2026-08-19 16:38:52.727668
1223	redis	NOT_CONFIGURED	\N	2026-08-19 16:38:52.728667
1224	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:38:52.728667
1225	celery	NOT_CONFIGURED	\N	2026-08-19 16:38:52.728667
1226	email	HEALTHY	\N	2026-08-19 16:38:52.728667
1227	backup	UNAVAILABLE	\N	2026-08-19 16:38:52.728667
1228	sentry	NOT_CONFIGURED	\N	2026-08-19 16:38:52.728667
1229	openai	NOT_CONFIGURED	\N	2026-08-19 16:38:52.728667
1230	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:38:52.728667
1231	simulation	HEALTHY	\N	2026-08-19 16:38:52.728667
1232	application	HEALTHY	4.5	2026-08-19 16:38:52.728667
1343	database	HEALTHY	4	2026-08-19 16:44:23.499576
1344	redis	NOT_CONFIGURED	\N	2026-08-19 16:44:23.499576
1345	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:44:23.499576
1346	celery	NOT_CONFIGURED	\N	2026-08-19 16:44:23.499576
1347	email	HEALTHY	\N	2026-08-19 16:44:23.499576
1348	backup	UNAVAILABLE	\N	2026-08-19 16:44:23.499576
1349	sentry	NOT_CONFIGURED	\N	2026-08-19 16:44:23.499576
1350	openai	NOT_CONFIGURED	\N	2026-08-19 16:44:23.499576
1351	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:44:23.499576
1352	simulation	HEALTHY	\N	2026-08-19 16:44:23.499576
1353	application	HEALTHY	4.5	2026-08-19 16:44:23.499576
1497	database	HEALTHY	0	2026-08-19 16:51:24.168832
1498	redis	NOT_CONFIGURED	\N	2026-08-19 16:51:24.168832
1499	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:51:24.168832
1500	celery	NOT_CONFIGURED	\N	2026-08-19 16:51:24.168832
1501	email	HEALTHY	\N	2026-08-19 16:51:24.168832
1502	backup	UNAVAILABLE	\N	2026-08-19 16:51:24.168832
1503	sentry	NOT_CONFIGURED	\N	2026-08-19 16:51:24.168832
1504	openai	NOT_CONFIGURED	\N	2026-08-19 16:51:24.168832
1505	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:51:24.168832
1506	simulation	HEALTHY	\N	2026-08-19 16:51:24.168832
1507	application	HEALTHY	4.5	2026-08-19 16:51:24.168832
1585	database	HEALTHY	0	2026-08-19 16:55:24.548226
1586	redis	NOT_CONFIGURED	\N	2026-08-19 16:55:24.548226
1587	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:55:24.548226
1588	celery	NOT_CONFIGURED	\N	2026-08-19 16:55:24.548226
1589	email	HEALTHY	\N	2026-08-19 16:55:24.548226
1590	backup	UNAVAILABLE	\N	2026-08-19 16:55:24.548226
1591	sentry	NOT_CONFIGURED	\N	2026-08-19 16:55:24.548226
1592	openai	NOT_CONFIGURED	\N	2026-08-19 16:55:24.548226
1593	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:55:24.548226
1594	simulation	HEALTHY	\N	2026-08-19 16:55:24.548226
1595	application	HEALTHY	4.5	2026-08-19 16:55:24.548226
1607	database	HEALTHY	1	2026-08-19 16:56:24.611586
1608	redis	NOT_CONFIGURED	\N	2026-08-19 16:56:24.611586
1609	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:56:24.611586
1610	celery	NOT_CONFIGURED	\N	2026-08-19 16:56:24.611586
1611	email	HEALTHY	\N	2026-08-19 16:56:24.612583
1612	backup	UNAVAILABLE	\N	2026-08-19 16:56:24.612583
1613	sentry	NOT_CONFIGURED	\N	2026-08-19 16:56:24.612583
1614	openai	NOT_CONFIGURED	\N	2026-08-19 16:56:24.612583
1615	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:56:24.612583
1616	simulation	HEALTHY	\N	2026-08-19 16:56:24.612583
1617	application	HEALTHY	4.5	2026-08-19 16:56:24.612583
1662	database	HEALTHY	0.99	2026-08-19 16:58:54.809106
1663	redis	NOT_CONFIGURED	\N	2026-08-19 16:58:54.809106
1664	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 16:58:54.809106
1665	celery	NOT_CONFIGURED	\N	2026-08-19 16:58:54.809106
1666	email	HEALTHY	\N	2026-08-19 16:58:54.809106
1667	backup	UNAVAILABLE	\N	2026-08-19 16:58:54.809106
1668	sentry	NOT_CONFIGURED	\N	2026-08-19 16:58:54.809106
1669	openai	NOT_CONFIGURED	\N	2026-08-19 16:58:54.809106
1670	cloudflare	NOT_CONFIGURED	\N	2026-08-19 16:58:54.809106
1671	simulation	HEALTHY	\N	2026-08-19 16:58:54.809106
1672	application	HEALTHY	4.5	2026-08-19 16:58:54.809106
1717	database	HEALTHY	0	2026-08-19 17:01:25.08102
1718	redis	NOT_CONFIGURED	\N	2026-08-19 17:01:25.08102
1719	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:01:25.08102
1720	celery	NOT_CONFIGURED	\N	2026-08-19 17:01:25.08102
1721	email	HEALTHY	\N	2026-08-19 17:01:25.082809
1722	backup	UNAVAILABLE	\N	2026-08-19 17:01:25.082809
1723	sentry	NOT_CONFIGURED	\N	2026-08-19 17:01:25.082809
1724	openai	NOT_CONFIGURED	\N	2026-08-19 17:01:25.082809
1725	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:01:25.082809
1726	simulation	HEALTHY	\N	2026-08-19 17:01:25.082809
1727	application	HEALTHY	4.5	2026-08-19 17:01:25.082809
1783	database	HEALTHY	0	2026-08-19 17:04:25.303586
1784	redis	NOT_CONFIGURED	\N	2026-08-19 17:04:25.303586
1785	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:04:25.303586
1786	celery	NOT_CONFIGURED	\N	2026-08-19 17:04:25.303586
1787	email	HEALTHY	\N	2026-08-19 17:04:25.304585
1788	backup	UNAVAILABLE	\N	2026-08-19 17:04:25.304585
1789	sentry	NOT_CONFIGURED	\N	2026-08-19 17:04:25.304585
1790	openai	NOT_CONFIGURED	\N	2026-08-19 17:04:25.304585
1791	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:04:25.304585
1792	simulation	HEALTHY	\N	2026-08-19 17:04:25.304585
1793	application	HEALTHY	4.5	2026-08-19 17:04:25.304585
1794	database	HEALTHY	2	2026-08-19 17:04:55.32883
1795	redis	NOT_CONFIGURED	\N	2026-08-19 17:04:55.32883
1796	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:04:55.32883
1797	celery	NOT_CONFIGURED	\N	2026-08-19 17:04:55.32883
1798	email	HEALTHY	\N	2026-08-19 17:04:55.32983
1799	backup	UNAVAILABLE	\N	2026-08-19 17:04:55.32983
1800	sentry	NOT_CONFIGURED	\N	2026-08-19 17:04:55.32983
1801	openai	NOT_CONFIGURED	\N	2026-08-19 17:04:55.32983
1802	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:04:55.32983
1803	simulation	HEALTHY	\N	2026-08-19 17:04:55.32983
1804	application	HEALTHY	4.5	2026-08-19 17:04:55.32983
1849	database	HEALTHY	0	2026-08-19 17:07:25.558209
1850	redis	NOT_CONFIGURED	\N	2026-08-19 17:07:25.558209
1851	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:07:25.558209
1852	celery	NOT_CONFIGURED	\N	2026-08-19 17:07:25.558209
1853	email	HEALTHY	\N	2026-08-19 17:07:25.558209
1854	backup	UNAVAILABLE	\N	2026-08-19 17:07:25.558209
1855	sentry	NOT_CONFIGURED	\N	2026-08-19 17:07:25.558209
1856	openai	NOT_CONFIGURED	\N	2026-08-19 17:07:25.558209
1857	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:07:25.558209
1858	simulation	HEALTHY	\N	2026-08-19 17:07:25.558209
1859	application	HEALTHY	4.5	2026-08-19 17:07:25.558209
1860	database	HEALTHY	0	2026-08-19 17:07:55.577508
1861	redis	NOT_CONFIGURED	\N	2026-08-19 17:07:55.577508
1862	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:07:55.577508
1863	celery	NOT_CONFIGURED	\N	2026-08-19 17:07:55.577508
1864	email	HEALTHY	\N	2026-08-19 17:07:55.577508
1865	backup	UNAVAILABLE	\N	2026-08-19 17:07:55.577508
1866	sentry	NOT_CONFIGURED	\N	2026-08-19 17:07:55.577508
1867	openai	NOT_CONFIGURED	\N	2026-08-19 17:07:55.577508
1868	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:07:55.577508
1869	simulation	HEALTHY	\N	2026-08-19 17:07:55.577508
1870	application	HEALTHY	4.5	2026-08-19 17:07:55.577508
1917	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:10:25.715988
1918	celery	NOT_CONFIGURED	\N	2026-08-19 17:10:25.715988
1919	email	HEALTHY	\N	2026-08-19 17:10:25.715988
1985	email	HEALTHY	\N	2026-08-19 17:13:25.943111
1986	backup	UNAVAILABLE	\N	2026-08-19 17:13:25.943111
1987	sentry	NOT_CONFIGURED	\N	2026-08-19 17:13:25.943111
1988	openai	NOT_CONFIGURED	\N	2026-08-19 17:13:25.943111
1989	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:13:25.943111
1990	simulation	HEALTHY	\N	2026-08-19 17:13:25.943111
1991	application	HEALTHY	4.5	2026-08-19 17:13:25.943111
2047	database	HEALTHY	0	2026-08-19 17:16:26.257628
2048	redis	NOT_CONFIGURED	\N	2026-08-19 17:16:26.257628
2049	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:16:26.257628
2050	celery	NOT_CONFIGURED	\N	2026-08-19 17:16:26.257628
2051	email	HEALTHY	\N	2026-08-19 17:16:26.257628
2052	backup	UNAVAILABLE	\N	2026-08-19 17:16:26.257628
2053	sentry	NOT_CONFIGURED	\N	2026-08-19 17:16:26.257628
2054	openai	NOT_CONFIGURED	\N	2026-08-19 17:16:26.257628
2055	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:16:26.257628
2056	simulation	HEALTHY	\N	2026-08-19 17:16:26.257628
2057	application	HEALTHY	4.5	2026-08-19 17:16:26.257628
2795	database	HEALTHY	0	2026-08-19 18:15:44.241289
2796	redis	NOT_CONFIGURED	\N	2026-08-19 18:15:44.241289
2797	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:15:44.241289
2798	celery	NOT_CONFIGURED	\N	2026-08-19 18:15:44.241289
2799	email	HEALTHY	\N	2026-08-19 18:15:44.241289
2800	backup	UNAVAILABLE	\N	2026-08-19 18:15:44.241289
2801	sentry	NOT_CONFIGURED	\N	2026-08-19 18:15:44.241289
2802	openai	NOT_CONFIGURED	\N	2026-08-19 18:15:44.242286
2803	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:15:44.242286
2804	simulation	HEALTHY	\N	2026-08-19 18:15:44.242286
2805	application	HEALTHY	4.5	2026-08-19 18:15:44.242286
2861	database	HEALTHY	0	2026-08-19 18:18:44.638647
2862	redis	NOT_CONFIGURED	\N	2026-08-19 18:18:44.638647
2863	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:18:44.638647
2864	celery	NOT_CONFIGURED	\N	2026-08-19 18:18:44.638647
2865	email	HEALTHY	\N	2026-08-19 18:18:44.638647
2866	backup	UNAVAILABLE	\N	2026-08-19 18:18:44.638647
2867	sentry	NOT_CONFIGURED	\N	2026-08-19 18:18:44.638647
2868	openai	NOT_CONFIGURED	\N	2026-08-19 18:18:44.638647
2869	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:18:44.638647
2870	simulation	HEALTHY	\N	2026-08-19 18:18:44.638647
2871	application	HEALTHY	4.5	2026-08-19 18:18:44.638647
3004	database	HEALTHY	1	2026-08-19 18:22:14.838535
3005	redis	NOT_CONFIGURED	\N	2026-08-19 18:22:14.838535
3006	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:22:14.838535
3007	celery	NOT_CONFIGURED	\N	2026-08-19 18:22:14.839526
3008	email	HEALTHY	\N	2026-08-19 18:22:14.839526
3009	backup	UNAVAILABLE	\N	2026-08-19 18:22:14.839526
3010	sentry	NOT_CONFIGURED	\N	2026-08-19 18:22:14.839526
3011	openai	NOT_CONFIGURED	\N	2026-08-19 18:22:14.839526
3012	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:22:14.839526
3013	simulation	HEALTHY	\N	2026-08-19 18:22:14.839526
3014	application	HEALTHY	4.5	2026-08-19 18:22:14.839526
3070	database	HEALTHY	0	2026-08-19 18:24:14.951309
3071	redis	NOT_CONFIGURED	\N	2026-08-19 18:24:14.951309
3072	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:24:14.951309
3073	celery	NOT_CONFIGURED	\N	2026-08-19 18:24:14.951309
3074	email	HEALTHY	\N	2026-08-19 18:24:14.951309
3075	backup	DEGRADED	\N	2026-08-19 18:24:14.951309
3076	sentry	NOT_CONFIGURED	\N	2026-08-19 18:24:14.951309
3077	openai	NOT_CONFIGURED	\N	2026-08-19 18:24:14.951309
3078	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:24:14.951309
3079	simulation	HEALTHY	\N	2026-08-19 18:24:14.951309
3080	application	HEALTHY	4.5	2026-08-19 18:24:14.951309
3158	database	HEALTHY	0	2026-08-19 18:27:45.193278
3159	redis	NOT_CONFIGURED	\N	2026-08-19 18:27:45.193278
3160	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:27:45.193278
3161	celery	NOT_CONFIGURED	\N	2026-08-19 18:27:45.193278
3162	email	HEALTHY	\N	2026-08-19 18:27:45.193278
3163	backup	HEALTHY	\N	2026-08-19 18:27:45.193278
3164	sentry	NOT_CONFIGURED	\N	2026-08-19 18:27:45.193278
3165	openai	NOT_CONFIGURED	\N	2026-08-19 18:27:45.193278
3166	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:27:45.193278
3167	simulation	HEALTHY	\N	2026-08-19 18:27:45.193278
3168	application	HEALTHY	4.5	2026-08-19 18:27:45.19428
1992	database	HEALTHY	0.66	2026-08-19 17:13:55.979767
1993	redis	NOT_CONFIGURED	\N	2026-08-19 17:13:55.979767
1994	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:13:55.979767
1995	celery	NOT_CONFIGURED	\N	2026-08-19 17:13:55.980319
1996	email	HEALTHY	\N	2026-08-19 17:13:55.980319
1997	backup	UNAVAILABLE	\N	2026-08-19 17:13:55.980319
1998	sentry	NOT_CONFIGURED	\N	2026-08-19 17:13:55.980319
1999	openai	NOT_CONFIGURED	\N	2026-08-19 17:13:55.980319
2000	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:13:55.980319
2001	simulation	HEALTHY	\N	2026-08-19 17:13:55.980319
2002	application	HEALTHY	4.5	2026-08-19 17:13:55.980319
2003	database	HEALTHY	0	2026-08-19 17:14:26.015046
2004	redis	NOT_CONFIGURED	\N	2026-08-19 17:14:26.016049
2005	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:14:26.016049
2006	celery	NOT_CONFIGURED	\N	2026-08-19 17:14:26.016049
2007	email	HEALTHY	\N	2026-08-19 17:14:26.016049
2008	backup	UNAVAILABLE	\N	2026-08-19 17:14:26.016049
2009	sentry	NOT_CONFIGURED	\N	2026-08-19 17:14:26.016049
2010	openai	NOT_CONFIGURED	\N	2026-08-19 17:14:26.016049
2011	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:14:26.016049
2012	simulation	HEALTHY	\N	2026-08-19 17:14:26.016049
2013	application	HEALTHY	4.5	2026-08-19 17:14:26.016049
2058	database	HEALTHY	1	2026-08-19 17:16:56.278995
2059	redis	NOT_CONFIGURED	\N	2026-08-19 17:16:56.278995
2060	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:16:56.278995
2061	celery	NOT_CONFIGURED	\N	2026-08-19 17:16:56.278995
2062	email	HEALTHY	\N	2026-08-19 17:16:56.278995
2063	backup	UNAVAILABLE	\N	2026-08-19 17:16:56.278995
2064	sentry	NOT_CONFIGURED	\N	2026-08-19 17:16:56.278995
2065	openai	NOT_CONFIGURED	\N	2026-08-19 17:16:56.278995
2066	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:16:56.278995
2067	simulation	HEALTHY	\N	2026-08-19 17:16:56.278995
2068	application	HEALTHY	4.5	2026-08-19 17:16:56.278995
2069	database	HEALTHY	1	2026-08-19 17:17:26.301842
2070	redis	NOT_CONFIGURED	\N	2026-08-19 17:17:26.301842
2071	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:17:26.301842
2072	celery	NOT_CONFIGURED	\N	2026-08-19 17:17:26.301842
2073	email	HEALTHY	\N	2026-08-19 17:17:26.301842
2074	backup	UNAVAILABLE	\N	2026-08-19 17:17:26.301842
2075	sentry	NOT_CONFIGURED	\N	2026-08-19 17:17:26.301842
2076	openai	NOT_CONFIGURED	\N	2026-08-19 17:17:26.302842
2077	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:17:26.302842
2078	simulation	HEALTHY	\N	2026-08-19 17:17:26.302842
2079	application	HEALTHY	4.5	2026-08-19 17:17:26.302842
2091	database	HEALTHY	0	2026-08-19 17:18:26.381749
2092	redis	NOT_CONFIGURED	\N	2026-08-19 17:18:26.382749
2093	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:18:26.382749
2094	celery	NOT_CONFIGURED	\N	2026-08-19 17:18:26.382749
2095	email	HEALTHY	\N	2026-08-19 17:18:26.382749
2096	backup	UNAVAILABLE	\N	2026-08-19 17:18:26.382749
2097	sentry	NOT_CONFIGURED	\N	2026-08-19 17:18:26.382749
2098	openai	NOT_CONFIGURED	\N	2026-08-19 17:18:26.382749
2099	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:18:26.382749
2100	simulation	HEALTHY	\N	2026-08-19 17:18:26.382749
2101	application	HEALTHY	4.5	2026-08-19 17:18:26.382749
2806	database	HEALTHY	20	2026-08-19 18:16:14.352338
2807	redis	NOT_CONFIGURED	\N	2026-08-19 18:16:14.352338
2808	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:16:14.352338
2809	celery	NOT_CONFIGURED	\N	2026-08-19 18:16:14.352338
2810	email	HEALTHY	\N	2026-08-19 18:16:14.352338
2811	backup	UNAVAILABLE	\N	2026-08-19 18:16:14.352338
2812	sentry	NOT_CONFIGURED	\N	2026-08-19 18:16:14.352338
2813	openai	NOT_CONFIGURED	\N	2026-08-19 18:16:14.352338
2814	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:16:14.352338
2815	simulation	HEALTHY	\N	2026-08-19 18:16:14.352338
2816	application	HEALTHY	4.5	2026-08-19 18:16:14.352338
2817	database	HEALTHY	0	2026-08-19 18:16:44.445018
2818	redis	NOT_CONFIGURED	\N	2026-08-19 18:16:44.445018
2819	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:16:44.445018
2820	celery	NOT_CONFIGURED	\N	2026-08-19 18:16:44.445018
2821	email	HEALTHY	\N	2026-08-19 18:16:44.445018
2822	backup	UNAVAILABLE	\N	2026-08-19 18:16:44.445018
2823	sentry	NOT_CONFIGURED	\N	2026-08-19 18:16:44.446016
2824	openai	NOT_CONFIGURED	\N	2026-08-19 18:16:44.446016
2825	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:16:44.446016
2826	simulation	HEALTHY	\N	2026-08-19 18:16:44.446016
2827	application	HEALTHY	4.5	2026-08-19 18:16:44.446016
2839	database	HEALTHY	1	2026-08-19 18:17:44.557355
2840	redis	NOT_CONFIGURED	\N	2026-08-19 18:17:44.557355
2841	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:17:44.557355
2842	celery	NOT_CONFIGURED	\N	2026-08-19 18:17:44.557355
2843	email	HEALTHY	\N	2026-08-19 18:17:44.557355
2844	backup	UNAVAILABLE	\N	2026-08-19 18:17:44.557355
2845	sentry	NOT_CONFIGURED	\N	2026-08-19 18:17:44.557355
2846	openai	NOT_CONFIGURED	\N	2026-08-19 18:17:44.557355
2847	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:17:44.557355
2848	simulation	HEALTHY	\N	2026-08-19 18:17:44.557355
2849	application	HEALTHY	4.5	2026-08-19 18:17:44.557355
2938	database	HEALTHY	0	2026-08-19 18:20:44.759058
2939	redis	NOT_CONFIGURED	\N	2026-08-19 18:20:44.759058
2940	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:20:44.759058
2941	celery	NOT_CONFIGURED	\N	2026-08-19 18:20:44.759058
2942	email	HEALTHY	\N	2026-08-19 18:20:44.759058
2943	backup	UNAVAILABLE	\N	2026-08-19 18:20:44.759058
2944	sentry	NOT_CONFIGURED	\N	2026-08-19 18:20:44.759058
2945	openai	NOT_CONFIGURED	\N	2026-08-19 18:20:44.759058
2946	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:20:44.759058
2947	simulation	HEALTHY	\N	2026-08-19 18:20:44.759058
2948	application	HEALTHY	4.5	2026-08-19 18:20:44.759058
3081	database	HEALTHY	0	2026-08-19 18:24:18.097997
3082	redis	NOT_CONFIGURED	\N	2026-08-19 18:24:18.099025
3083	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:24:18.099025
3084	celery	NOT_CONFIGURED	\N	2026-08-19 18:24:18.099025
3085	email	HEALTHY	\N	2026-08-19 18:24:18.099025
3086	backup	HEALTHY	\N	2026-08-19 18:24:18.099025
3087	sentry	NOT_CONFIGURED	\N	2026-08-19 18:24:18.099025
3088	openai	NOT_CONFIGURED	\N	2026-08-19 18:24:18.099025
3089	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:24:18.099025
3090	simulation	HEALTHY	\N	2026-08-19 18:24:18.099025
3091	application	HEALTHY	4.5	2026-08-19 18:24:18.099025
2014	database	HEALTHY	1	2026-08-19 17:14:56.049366
2015	redis	NOT_CONFIGURED	\N	2026-08-19 17:14:56.049366
2016	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:14:56.049366
2017	celery	NOT_CONFIGURED	\N	2026-08-19 17:14:56.049366
2018	email	HEALTHY	\N	2026-08-19 17:14:56.049366
2019	backup	UNAVAILABLE	\N	2026-08-19 17:14:56.049366
2020	sentry	NOT_CONFIGURED	\N	2026-08-19 17:14:56.049366
2021	openai	NOT_CONFIGURED	\N	2026-08-19 17:14:56.049366
2022	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:14:56.049366
2023	simulation	HEALTHY	\N	2026-08-19 17:14:56.049366
2024	application	HEALTHY	4.5	2026-08-19 17:14:56.049366
2025	database	HEALTHY	0	2026-08-19 17:15:26.077115
2026	redis	NOT_CONFIGURED	\N	2026-08-19 17:15:26.077115
2027	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:15:26.077115
2028	celery	NOT_CONFIGURED	\N	2026-08-19 17:15:26.077115
2029	email	HEALTHY	\N	2026-08-19 17:15:26.077115
2030	backup	UNAVAILABLE	\N	2026-08-19 17:15:26.077115
2031	sentry	NOT_CONFIGURED	\N	2026-08-19 17:15:26.077115
2032	openai	NOT_CONFIGURED	\N	2026-08-19 17:15:26.077115
2033	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:15:26.077115
2034	simulation	HEALTHY	\N	2026-08-19 17:15:26.077115
2035	application	HEALTHY	4.5	2026-08-19 17:15:26.077115
2036	database	HEALTHY	0.96	2026-08-19 17:15:56.167661
2037	redis	NOT_CONFIGURED	\N	2026-08-19 17:15:56.167661
2038	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:15:56.167661
2039	celery	NOT_CONFIGURED	\N	2026-08-19 17:15:56.167661
2040	email	HEALTHY	\N	2026-08-19 17:15:56.167661
2041	backup	UNAVAILABLE	\N	2026-08-19 17:15:56.167661
2042	sentry	NOT_CONFIGURED	\N	2026-08-19 17:15:56.167661
2043	openai	NOT_CONFIGURED	\N	2026-08-19 17:15:56.167661
2044	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:15:56.167661
2045	simulation	HEALTHY	\N	2026-08-19 17:15:56.167661
2046	application	HEALTHY	4.5	2026-08-19 17:15:56.167661
2080	database	HEALTHY	0	2026-08-19 17:17:56.344446
2081	redis	NOT_CONFIGURED	\N	2026-08-19 17:17:56.344446
2082	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:17:56.344446
2083	celery	NOT_CONFIGURED	\N	2026-08-19 17:17:56.344446
2084	email	HEALTHY	\N	2026-08-19 17:17:56.344446
2085	backup	UNAVAILABLE	\N	2026-08-19 17:17:56.344446
2086	sentry	NOT_CONFIGURED	\N	2026-08-19 17:17:56.344446
2087	openai	NOT_CONFIGURED	\N	2026-08-19 17:17:56.345442
2088	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:17:56.345442
2089	simulation	HEALTHY	\N	2026-08-19 17:17:56.345442
2090	application	HEALTHY	4.5	2026-08-19 17:17:56.345442
2113	database	HEALTHY	1	2026-08-19 17:19:26.448016
2114	redis	NOT_CONFIGURED	\N	2026-08-19 17:19:26.449055
2115	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:19:26.449055
2116	celery	NOT_CONFIGURED	\N	2026-08-19 17:19:26.449055
2117	email	HEALTHY	\N	2026-08-19 17:19:26.449055
2118	backup	UNAVAILABLE	\N	2026-08-19 17:19:26.449055
2119	sentry	NOT_CONFIGURED	\N	2026-08-19 17:19:26.449055
2120	openai	NOT_CONFIGURED	\N	2026-08-19 17:19:26.449055
2121	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:19:26.449055
2122	simulation	HEALTHY	\N	2026-08-19 17:19:26.449055
2123	application	HEALTHY	4.5	2026-08-19 17:19:26.449055
2124	database	HEALTHY	0	2026-08-19 17:19:56.479634
2125	redis	NOT_CONFIGURED	\N	2026-08-19 17:19:56.479634
2126	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:19:56.479634
2127	celery	NOT_CONFIGURED	\N	2026-08-19 17:19:56.479634
2128	email	HEALTHY	\N	2026-08-19 17:19:56.479634
2129	backup	UNAVAILABLE	\N	2026-08-19 17:19:56.479634
2130	sentry	NOT_CONFIGURED	\N	2026-08-19 17:19:56.479634
2131	openai	NOT_CONFIGURED	\N	2026-08-19 17:19:56.480636
2132	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:19:56.480636
2133	simulation	HEALTHY	\N	2026-08-19 17:19:56.480636
2134	application	HEALTHY	4.5	2026-08-19 17:19:56.480636
2828	database	HEALTHY	0	2026-08-19 18:17:14.488657
2829	redis	NOT_CONFIGURED	\N	2026-08-19 18:17:14.488657
2830	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:17:14.488657
2831	celery	NOT_CONFIGURED	\N	2026-08-19 18:17:14.488657
2832	email	HEALTHY	\N	2026-08-19 18:17:14.488657
2833	backup	UNAVAILABLE	\N	2026-08-19 18:17:14.488657
2834	sentry	NOT_CONFIGURED	\N	2026-08-19 18:17:14.488657
2835	openai	NOT_CONFIGURED	\N	2026-08-19 18:17:14.488657
2836	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:17:14.488657
2837	simulation	HEALTHY	\N	2026-08-19 18:17:14.488657
2838	application	HEALTHY	4.5	2026-08-19 18:17:14.488657
2960	database	HEALTHY	0	2026-08-19 18:21:14.785098
2961	redis	NOT_CONFIGURED	\N	2026-08-19 18:21:14.785098
2962	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:21:14.785098
2963	celery	NOT_CONFIGURED	\N	2026-08-19 18:21:14.785098
2964	email	HEALTHY	\N	2026-08-19 18:21:14.785098
2965	backup	UNAVAILABLE	\N	2026-08-19 18:21:14.785098
2966	sentry	NOT_CONFIGURED	\N	2026-08-19 18:21:14.785098
2967	openai	NOT_CONFIGURED	\N	2026-08-19 18:21:14.785098
2968	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:21:14.785098
2969	simulation	HEALTHY	\N	2026-08-19 18:21:14.785098
2970	application	HEALTHY	4.5	2026-08-19 18:21:14.785098
3092	database	HEALTHY	1	2026-08-19 18:24:44.982734
3093	redis	NOT_CONFIGURED	\N	2026-08-19 18:24:44.982734
3094	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:24:44.982734
3095	celery	NOT_CONFIGURED	\N	2026-08-19 18:24:44.982734
3096	email	HEALTHY	\N	2026-08-19 18:24:44.982734
3097	backup	HEALTHY	\N	2026-08-19 18:24:44.982734
3098	sentry	NOT_CONFIGURED	\N	2026-08-19 18:24:44.982734
3099	openai	NOT_CONFIGURED	\N	2026-08-19 18:24:44.982734
3100	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:24:44.982734
3101	simulation	HEALTHY	\N	2026-08-19 18:24:44.982734
3102	application	HEALTHY	4.5	2026-08-19 18:24:44.982734
3169	database	HEALTHY	0	2026-08-19 18:28:15.210472
3170	redis	NOT_CONFIGURED	\N	2026-08-19 18:28:15.210472
3171	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:28:15.210472
3172	celery	NOT_CONFIGURED	\N	2026-08-19 18:28:15.210472
3173	email	HEALTHY	\N	2026-08-19 18:28:15.210472
3174	backup	HEALTHY	\N	2026-08-19 18:28:15.211474
3175	sentry	NOT_CONFIGURED	\N	2026-08-19 18:28:15.211474
3176	openai	NOT_CONFIGURED	\N	2026-08-19 18:28:15.211474
3177	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:28:15.211474
3178	simulation	HEALTHY	\N	2026-08-19 18:28:15.211474
3179	application	HEALTHY	4.5	2026-08-19 18:28:15.211474
2102	database	HEALTHY	1	2026-08-19 17:18:56.413112
2103	redis	NOT_CONFIGURED	\N	2026-08-19 17:18:56.414112
2104	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:18:56.414112
2105	celery	NOT_CONFIGURED	\N	2026-08-19 17:18:56.414112
2106	email	HEALTHY	\N	2026-08-19 17:18:56.414112
2107	backup	UNAVAILABLE	\N	2026-08-19 17:18:56.414112
2108	sentry	NOT_CONFIGURED	\N	2026-08-19 17:18:56.414112
2109	openai	NOT_CONFIGURED	\N	2026-08-19 17:18:56.414112
2110	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:18:56.414112
2111	simulation	HEALTHY	\N	2026-08-19 17:18:56.414112
2112	application	HEALTHY	4.5	2026-08-19 17:18:56.414112
2135	database	HEALTHY	1	2026-08-19 17:20:26.50915
2136	redis	NOT_CONFIGURED	\N	2026-08-19 17:20:26.50915
2137	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:20:26.50915
2138	celery	NOT_CONFIGURED	\N	2026-08-19 17:20:26.50915
2139	email	HEALTHY	\N	2026-08-19 17:20:26.50915
2140	backup	UNAVAILABLE	\N	2026-08-19 17:20:26.50915
2141	sentry	NOT_CONFIGURED	\N	2026-08-19 17:20:26.50915
2142	openai	NOT_CONFIGURED	\N	2026-08-19 17:20:26.50915
2143	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:20:26.50915
2144	simulation	HEALTHY	\N	2026-08-19 17:20:26.50915
2145	application	HEALTHY	4.5	2026-08-19 17:20:26.510152
2146	database	HEALTHY	0	2026-08-19 17:20:56.545429
2147	redis	NOT_CONFIGURED	\N	2026-08-19 17:20:56.545429
2148	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:20:56.545429
2149	celery	NOT_CONFIGURED	\N	2026-08-19 17:20:56.545429
2150	email	HEALTHY	\N	2026-08-19 17:20:56.545429
2151	backup	UNAVAILABLE	\N	2026-08-19 17:20:56.545429
2152	sentry	NOT_CONFIGURED	\N	2026-08-19 17:20:56.545429
2153	openai	NOT_CONFIGURED	\N	2026-08-19 17:20:56.545429
2154	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:20:56.545429
2155	simulation	HEALTHY	\N	2026-08-19 17:20:56.545429
2156	application	HEALTHY	4.5	2026-08-19 17:20:56.545429
2157	database	HEALTHY	1.99	2026-08-19 17:21:26.621726
2158	redis	NOT_CONFIGURED	\N	2026-08-19 17:21:26.621726
2159	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:21:26.621726
2160	celery	NOT_CONFIGURED	\N	2026-08-19 17:21:26.621726
2161	email	HEALTHY	\N	2026-08-19 17:21:26.621726
2162	backup	UNAVAILABLE	\N	2026-08-19 17:21:26.621726
2163	sentry	NOT_CONFIGURED	\N	2026-08-19 17:21:26.621726
2164	openai	NOT_CONFIGURED	\N	2026-08-19 17:21:26.621726
2165	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:21:26.621726
2166	simulation	HEALTHY	\N	2026-08-19 17:21:26.623365
2167	application	HEALTHY	4.5	2026-08-19 17:21:26.623365
2168	database	HEALTHY	0.95	2026-08-19 17:21:56.690583
2169	redis	NOT_CONFIGURED	\N	2026-08-19 17:21:56.690583
2170	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:21:56.690583
2171	celery	NOT_CONFIGURED	\N	2026-08-19 17:21:56.690583
2172	email	HEALTHY	\N	2026-08-19 17:21:56.690583
2173	backup	UNAVAILABLE	\N	2026-08-19 17:21:56.690583
2174	sentry	NOT_CONFIGURED	\N	2026-08-19 17:21:56.690583
2175	openai	NOT_CONFIGURED	\N	2026-08-19 17:21:56.690583
2176	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:21:56.690583
2177	simulation	HEALTHY	\N	2026-08-19 17:21:56.690583
2178	application	HEALTHY	4.5	2026-08-19 17:21:56.691599
2179	database	HEALTHY	0	2026-08-19 17:22:26.735083
2180	redis	NOT_CONFIGURED	\N	2026-08-19 17:22:26.735083
2181	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:22:26.735083
2182	celery	NOT_CONFIGURED	\N	2026-08-19 17:22:26.735083
2183	email	HEALTHY	\N	2026-08-19 17:22:26.735083
2184	backup	UNAVAILABLE	\N	2026-08-19 17:22:26.735083
2185	sentry	NOT_CONFIGURED	\N	2026-08-19 17:22:26.735083
2186	openai	NOT_CONFIGURED	\N	2026-08-19 17:22:26.735083
2187	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:22:26.735083
2188	simulation	HEALTHY	\N	2026-08-19 17:22:26.735083
2189	application	HEALTHY	4.5	2026-08-19 17:22:26.735083
2190	database	HEALTHY	0	2026-08-19 17:22:56.766909
2191	redis	NOT_CONFIGURED	\N	2026-08-19 17:22:56.766909
2192	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:22:56.766909
2193	celery	NOT_CONFIGURED	\N	2026-08-19 17:22:56.766909
2194	email	HEALTHY	\N	2026-08-19 17:22:56.766909
2195	backup	UNAVAILABLE	\N	2026-08-19 17:22:56.766909
2196	sentry	NOT_CONFIGURED	\N	2026-08-19 17:22:56.766909
2197	openai	NOT_CONFIGURED	\N	2026-08-19 17:22:56.766909
2198	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:22:56.766909
2199	simulation	HEALTHY	\N	2026-08-19 17:22:56.766909
2200	application	HEALTHY	4.5	2026-08-19 17:22:56.766909
2201	database	HEALTHY	0	2026-08-19 17:23:26.808649
2202	redis	NOT_CONFIGURED	\N	2026-08-19 17:23:26.808649
2203	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:23:26.808649
2204	celery	NOT_CONFIGURED	\N	2026-08-19 17:23:26.808649
2205	email	HEALTHY	\N	2026-08-19 17:23:26.808649
2206	backup	UNAVAILABLE	\N	2026-08-19 17:23:26.808649
2207	sentry	NOT_CONFIGURED	\N	2026-08-19 17:23:26.808649
2208	openai	NOT_CONFIGURED	\N	2026-08-19 17:23:26.808649
2209	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:23:26.809651
2210	simulation	HEALTHY	\N	2026-08-19 17:23:26.809651
2211	application	HEALTHY	4.5	2026-08-19 17:23:26.809651
2212	database	HEALTHY	1	2026-08-19 17:23:56.848013
2213	redis	NOT_CONFIGURED	\N	2026-08-19 17:23:56.848013
2214	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:23:56.849295
2215	celery	NOT_CONFIGURED	\N	2026-08-19 17:23:56.849295
2216	email	HEALTHY	\N	2026-08-19 17:23:56.849295
2217	backup	UNAVAILABLE	\N	2026-08-19 17:23:56.849295
2218	sentry	NOT_CONFIGURED	\N	2026-08-19 17:23:56.849295
2219	openai	NOT_CONFIGURED	\N	2026-08-19 17:23:56.849295
2220	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:23:56.849295
2221	simulation	HEALTHY	\N	2026-08-19 17:23:56.849295
2222	application	HEALTHY	4.5	2026-08-19 17:23:56.849295
2223	database	HEALTHY	1.05	2026-08-19 17:24:26.879047
2224	redis	NOT_CONFIGURED	\N	2026-08-19 17:24:26.880047
2225	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:24:26.880047
2226	celery	NOT_CONFIGURED	\N	2026-08-19 17:24:26.880047
2227	email	HEALTHY	\N	2026-08-19 17:24:26.880047
2228	backup	UNAVAILABLE	\N	2026-08-19 17:24:26.880047
2229	sentry	NOT_CONFIGURED	\N	2026-08-19 17:24:26.880047
2230	openai	NOT_CONFIGURED	\N	2026-08-19 17:24:26.880047
2231	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:24:26.880047
2232	simulation	HEALTHY	\N	2026-08-19 17:24:26.880047
2233	application	HEALTHY	4.5	2026-08-19 17:24:26.880047
2234	database	HEALTHY	1	2026-08-19 17:24:56.918597
2235	redis	NOT_CONFIGURED	\N	2026-08-19 17:24:56.918597
2236	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:24:56.918597
2237	celery	NOT_CONFIGURED	\N	2026-08-19 17:24:56.918597
2238	email	HEALTHY	\N	2026-08-19 17:24:56.918597
2239	backup	UNAVAILABLE	\N	2026-08-19 17:24:56.918597
2240	sentry	NOT_CONFIGURED	\N	2026-08-19 17:24:56.918597
2241	openai	NOT_CONFIGURED	\N	2026-08-19 17:24:56.918597
2242	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:24:56.918597
2243	simulation	HEALTHY	\N	2026-08-19 17:24:56.918597
2244	application	HEALTHY	4.5	2026-08-19 17:24:56.918597
2245	database	HEALTHY	0	2026-08-19 17:25:26.950968
2246	redis	NOT_CONFIGURED	\N	2026-08-19 17:25:26.950968
2247	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:25:26.950968
2248	celery	NOT_CONFIGURED	\N	2026-08-19 17:25:26.950968
2249	email	HEALTHY	\N	2026-08-19 17:25:26.950968
2250	backup	UNAVAILABLE	\N	2026-08-19 17:25:26.950968
2251	sentry	NOT_CONFIGURED	\N	2026-08-19 17:25:26.950968
2252	openai	NOT_CONFIGURED	\N	2026-08-19 17:25:26.950968
2253	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:25:26.950968
2254	simulation	HEALTHY	\N	2026-08-19 17:25:26.950968
2255	application	HEALTHY	4.5	2026-08-19 17:25:26.950968
2256	database	HEALTHY	1	2026-08-19 17:25:56.983312
2257	redis	NOT_CONFIGURED	\N	2026-08-19 17:25:56.983312
2258	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:25:56.984315
2259	celery	NOT_CONFIGURED	\N	2026-08-19 17:25:56.984315
2260	email	HEALTHY	\N	2026-08-19 17:25:56.984315
2261	backup	UNAVAILABLE	\N	2026-08-19 17:25:56.984315
2262	sentry	NOT_CONFIGURED	\N	2026-08-19 17:25:56.984315
2263	openai	NOT_CONFIGURED	\N	2026-08-19 17:25:56.984315
2264	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:25:56.984315
2265	simulation	HEALTHY	\N	2026-08-19 17:25:56.984315
2266	application	HEALTHY	4.5	2026-08-19 17:25:56.984315
2850	database	HEALTHY	1	2026-08-19 18:18:14.612283
2851	redis	NOT_CONFIGURED	\N	2026-08-19 18:18:14.612283
2852	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:18:14.612283
2853	celery	NOT_CONFIGURED	\N	2026-08-19 18:18:14.612283
2854	email	HEALTHY	\N	2026-08-19 18:18:14.612283
2855	backup	UNAVAILABLE	\N	2026-08-19 18:18:14.612283
2856	sentry	NOT_CONFIGURED	\N	2026-08-19 18:18:14.612283
2857	openai	NOT_CONFIGURED	\N	2026-08-19 18:18:14.612283
2858	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:18:14.612283
2859	simulation	HEALTHY	\N	2026-08-19 18:18:14.613285
2860	application	HEALTHY	4.5	2026-08-19 18:18:14.613285
2982	database	HEALTHY	1	2026-08-19 18:21:44.806761
2983	redis	NOT_CONFIGURED	\N	2026-08-19 18:21:44.806761
2984	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:21:44.806761
2985	celery	NOT_CONFIGURED	\N	2026-08-19 18:21:44.806761
2986	email	HEALTHY	\N	2026-08-19 18:21:44.806761
2987	backup	UNAVAILABLE	\N	2026-08-19 18:21:44.806761
2988	sentry	NOT_CONFIGURED	\N	2026-08-19 18:21:44.806761
2989	openai	NOT_CONFIGURED	\N	2026-08-19 18:21:44.806761
2990	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:21:44.807422
2991	simulation	HEALTHY	\N	2026-08-19 18:21:44.807422
2992	application	HEALTHY	4.5	2026-08-19 18:21:44.807422
3103	database	HEALTHY	0	2026-08-19 18:25:15.01621
3104	redis	NOT_CONFIGURED	\N	2026-08-19 18:25:15.01621
3105	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:25:15.01621
3106	celery	NOT_CONFIGURED	\N	2026-08-19 18:25:15.01621
3107	email	HEALTHY	\N	2026-08-19 18:25:15.01621
3108	backup	HEALTHY	\N	2026-08-19 18:25:15.01621
3109	sentry	NOT_CONFIGURED	\N	2026-08-19 18:25:15.01621
3110	openai	NOT_CONFIGURED	\N	2026-08-19 18:25:15.01621
3111	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:25:15.01621
3112	simulation	HEALTHY	\N	2026-08-19 18:25:15.01621
3113	application	HEALTHY	4.5	2026-08-19 18:25:15.01621
3180	database	HEALTHY	0	2026-08-19 18:28:45.228944
3181	redis	NOT_CONFIGURED	\N	2026-08-19 18:28:45.228944
3182	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:28:45.228944
3183	celery	NOT_CONFIGURED	\N	2026-08-19 18:28:45.228944
3184	email	HEALTHY	\N	2026-08-19 18:28:45.228944
3185	backup	HEALTHY	\N	2026-08-19 18:28:45.228944
3186	sentry	NOT_CONFIGURED	\N	2026-08-19 18:28:45.228944
3187	openai	NOT_CONFIGURED	\N	2026-08-19 18:28:45.228944
3188	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:28:45.228944
3189	simulation	HEALTHY	\N	2026-08-19 18:28:45.228944
3190	application	HEALTHY	4.5	2026-08-19 18:28:45.228944
2267	database	HEALTHY	0	2026-08-19 17:26:27.022829
2268	redis	NOT_CONFIGURED	\N	2026-08-19 17:26:27.022829
2269	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:26:27.022829
2270	celery	NOT_CONFIGURED	\N	2026-08-19 17:26:27.023818
2271	email	HEALTHY	\N	2026-08-19 17:26:27.023818
2272	backup	UNAVAILABLE	\N	2026-08-19 17:26:27.023818
2273	sentry	NOT_CONFIGURED	\N	2026-08-19 17:26:27.023818
2274	openai	NOT_CONFIGURED	\N	2026-08-19 17:26:27.023818
2275	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:26:27.023818
2276	simulation	HEALTHY	\N	2026-08-19 17:26:27.023818
2277	application	HEALTHY	4.5	2026-08-19 17:26:27.023818
2872	database	HEALTHY	0	2026-08-19 18:19:14.677312
2873	redis	NOT_CONFIGURED	\N	2026-08-19 18:19:14.677312
2874	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:19:14.677312
2875	celery	NOT_CONFIGURED	\N	2026-08-19 18:19:14.677312
2876	email	HEALTHY	\N	2026-08-19 18:19:14.677312
2877	backup	UNAVAILABLE	\N	2026-08-19 18:19:14.677312
2878	sentry	NOT_CONFIGURED	\N	2026-08-19 18:19:14.677312
2879	openai	NOT_CONFIGURED	\N	2026-08-19 18:19:14.677312
2880	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:19:14.677312
2881	simulation	HEALTHY	\N	2026-08-19 18:19:14.677312
2882	application	HEALTHY	4.5	2026-08-19 18:19:14.677312
3026	database	HEALTHY	0	2026-08-19 18:22:44.860035
3027	redis	NOT_CONFIGURED	\N	2026-08-19 18:22:44.860035
3028	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:22:44.860035
3029	celery	NOT_CONFIGURED	\N	2026-08-19 18:22:44.860035
3030	email	HEALTHY	\N	2026-08-19 18:22:44.860035
3031	backup	UNAVAILABLE	\N	2026-08-19 18:22:44.860035
3032	sentry	NOT_CONFIGURED	\N	2026-08-19 18:22:44.860035
3033	openai	NOT_CONFIGURED	\N	2026-08-19 18:22:44.860035
3034	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:22:44.860035
3035	simulation	HEALTHY	\N	2026-08-19 18:22:44.860035
3036	application	HEALTHY	4.5	2026-08-19 18:22:44.860035
3114	database	HEALTHY	0.76	2026-08-19 18:25:45.048196
3115	redis	NOT_CONFIGURED	\N	2026-08-19 18:25:45.048706
3116	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:25:45.048706
3117	celery	NOT_CONFIGURED	\N	2026-08-19 18:25:45.048706
3118	email	HEALTHY	\N	2026-08-19 18:25:45.048706
3119	backup	HEALTHY	\N	2026-08-19 18:25:45.048706
3120	sentry	NOT_CONFIGURED	\N	2026-08-19 18:25:45.048706
3121	openai	NOT_CONFIGURED	\N	2026-08-19 18:25:45.048706
3122	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:25:45.048706
3123	simulation	HEALTHY	\N	2026-08-19 18:25:45.04912
3124	application	HEALTHY	4.5	2026-08-19 18:25:45.04912
3191	database	HEALTHY	0	2026-08-19 18:29:15.247316
3192	redis	NOT_CONFIGURED	\N	2026-08-19 18:29:15.247316
3193	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:29:15.247316
3194	celery	NOT_CONFIGURED	\N	2026-08-19 18:29:15.247316
3195	email	HEALTHY	\N	2026-08-19 18:29:15.247316
3196	backup	HEALTHY	\N	2026-08-19 18:29:15.247316
3197	sentry	NOT_CONFIGURED	\N	2026-08-19 18:29:15.247316
3198	openai	NOT_CONFIGURED	\N	2026-08-19 18:29:15.247316
3199	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:29:15.248321
3200	simulation	HEALTHY	\N	2026-08-19 18:29:15.248321
3201	application	HEALTHY	4.5	2026-08-19 18:29:15.248321
2278	database	HEALTHY	0	2026-08-19 17:26:57.054833
2279	redis	NOT_CONFIGURED	\N	2026-08-19 17:26:57.054833
2280	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:26:57.054833
2281	celery	NOT_CONFIGURED	\N	2026-08-19 17:26:57.054833
2282	email	HEALTHY	\N	2026-08-19 17:26:57.054833
2283	backup	UNAVAILABLE	\N	2026-08-19 17:26:57.054833
2284	sentry	NOT_CONFIGURED	\N	2026-08-19 17:26:57.055832
2285	openai	NOT_CONFIGURED	\N	2026-08-19 17:26:57.055832
2286	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:26:57.055832
2287	simulation	HEALTHY	\N	2026-08-19 17:26:57.055832
2288	application	HEALTHY	4.5	2026-08-19 17:26:57.055832
2289	database	HEALTHY	1.37	2026-08-19 17:27:27.103673
2290	redis	NOT_CONFIGURED	\N	2026-08-19 17:27:27.103673
2291	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:27:27.103673
2292	celery	NOT_CONFIGURED	\N	2026-08-19 17:27:27.103673
2293	email	HEALTHY	\N	2026-08-19 17:27:27.103673
2294	backup	UNAVAILABLE	\N	2026-08-19 17:27:27.103673
2295	sentry	NOT_CONFIGURED	\N	2026-08-19 17:27:27.103673
2296	openai	NOT_CONFIGURED	\N	2026-08-19 17:27:27.103673
2297	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:27:27.103673
2298	simulation	HEALTHY	\N	2026-08-19 17:27:27.103673
2299	application	HEALTHY	4.5	2026-08-19 17:27:27.103673
2300	database	HEALTHY	2.02	2026-08-19 17:27:57.169766
2301	redis	NOT_CONFIGURED	\N	2026-08-19 17:27:57.169766
2302	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:27:57.169766
2303	celery	NOT_CONFIGURED	\N	2026-08-19 17:27:57.169766
2304	email	HEALTHY	\N	2026-08-19 17:27:57.169766
2305	backup	UNAVAILABLE	\N	2026-08-19 17:27:57.169766
2306	sentry	NOT_CONFIGURED	\N	2026-08-19 17:27:57.169766
2307	openai	NOT_CONFIGURED	\N	2026-08-19 17:27:57.169766
2308	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:27:57.169766
2309	simulation	HEALTHY	\N	2026-08-19 17:27:57.169766
2310	application	HEALTHY	4.5	2026-08-19 17:27:57.169766
2344	database	HEALTHY	0	2026-08-19 17:29:57.346478
2345	redis	NOT_CONFIGURED	\N	2026-08-19 17:29:57.346478
2346	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:29:57.346478
2347	celery	NOT_CONFIGURED	\N	2026-08-19 17:29:57.346478
2348	email	HEALTHY	\N	2026-08-19 17:29:57.346478
2349	backup	UNAVAILABLE	\N	2026-08-19 17:29:57.346478
2350	sentry	NOT_CONFIGURED	\N	2026-08-19 17:29:57.346478
2351	openai	NOT_CONFIGURED	\N	2026-08-19 17:29:57.346478
2352	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:29:57.346478
2353	simulation	HEALTHY	\N	2026-08-19 17:29:57.346478
2354	application	HEALTHY	4.5	2026-08-19 17:29:57.346478
2366	database	HEALTHY	1	2026-08-19 17:30:57.403266
2367	redis	NOT_CONFIGURED	\N	2026-08-19 17:30:57.404307
2368	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:30:57.404307
2369	celery	NOT_CONFIGURED	\N	2026-08-19 17:30:57.404307
2370	email	HEALTHY	\N	2026-08-19 17:30:57.404307
2371	backup	UNAVAILABLE	\N	2026-08-19 17:30:57.404307
2372	sentry	NOT_CONFIGURED	\N	2026-08-19 17:30:57.404307
2373	openai	NOT_CONFIGURED	\N	2026-08-19 17:30:57.404307
2374	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:30:57.404307
2375	simulation	HEALTHY	\N	2026-08-19 17:30:57.404307
2376	application	HEALTHY	4.5	2026-08-19 17:30:57.404307
2883	database	HEALTHY	0	2026-08-19 18:19:23.320233
2884	redis	NOT_CONFIGURED	\N	2026-08-19 18:19:23.320233
2885	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:19:23.320233
2886	celery	NOT_CONFIGURED	\N	2026-08-19 18:19:23.320233
2887	email	HEALTHY	\N	2026-08-19 18:19:23.321235
2888	backup	HEALTHY	\N	2026-08-19 18:19:23.321235
2889	sentry	NOT_CONFIGURED	\N	2026-08-19 18:19:23.321235
2890	openai	NOT_CONFIGURED	\N	2026-08-19 18:19:23.321235
2891	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:19:23.321235
2892	simulation	HEALTHY	\N	2026-08-19 18:19:23.321235
2893	application	HEALTHY	4.5	2026-08-19 18:19:23.321235
3125	database	HEALTHY	0	2026-08-19 18:26:15.084718
3126	redis	NOT_CONFIGURED	\N	2026-08-19 18:26:15.084718
3127	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:26:15.084718
3128	celery	NOT_CONFIGURED	\N	2026-08-19 18:26:15.084718
3129	email	HEALTHY	\N	2026-08-19 18:26:15.084718
3130	backup	HEALTHY	\N	2026-08-19 18:26:15.084718
3131	sentry	NOT_CONFIGURED	\N	2026-08-19 18:26:15.084718
3132	openai	NOT_CONFIGURED	\N	2026-08-19 18:26:15.084718
3133	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:26:15.084718
3134	simulation	HEALTHY	\N	2026-08-19 18:26:15.084718
3135	application	HEALTHY	4.5	2026-08-19 18:26:15.084718
2311	database	HEALTHY	1	2026-08-19 17:28:27.211457
2312	redis	NOT_CONFIGURED	\N	2026-08-19 17:28:27.212453
2313	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:28:27.212453
2314	celery	NOT_CONFIGURED	\N	2026-08-19 17:28:27.212453
2315	email	HEALTHY	\N	2026-08-19 17:28:27.212453
2316	backup	UNAVAILABLE	\N	2026-08-19 17:28:27.212453
2317	sentry	NOT_CONFIGURED	\N	2026-08-19 17:28:27.212453
2318	openai	NOT_CONFIGURED	\N	2026-08-19 17:28:27.212453
2319	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:28:27.212453
2320	simulation	HEALTHY	\N	2026-08-19 17:28:27.212453
2321	application	HEALTHY	4.5	2026-08-19 17:28:27.212453
2322	database	HEALTHY	1.02	2026-08-19 17:28:57.260897
2323	redis	NOT_CONFIGURED	\N	2026-08-19 17:28:57.260897
2324	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:28:57.260897
2325	celery	NOT_CONFIGURED	\N	2026-08-19 17:28:57.260897
2326	email	HEALTHY	\N	2026-08-19 17:28:57.260897
2327	backup	UNAVAILABLE	\N	2026-08-19 17:28:57.260897
2328	sentry	NOT_CONFIGURED	\N	2026-08-19 17:28:57.260897
2329	openai	NOT_CONFIGURED	\N	2026-08-19 17:28:57.260897
2330	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:28:57.260897
2331	simulation	HEALTHY	\N	2026-08-19 17:28:57.260897
2332	application	HEALTHY	4.5	2026-08-19 17:28:57.260897
2333	database	HEALTHY	0.99	2026-08-19 17:29:27.314667
2334	redis	NOT_CONFIGURED	\N	2026-08-19 17:29:27.314667
2335	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:29:27.314667
2336	celery	NOT_CONFIGURED	\N	2026-08-19 17:29:27.314667
2337	email	HEALTHY	\N	2026-08-19 17:29:27.314667
2338	backup	UNAVAILABLE	\N	2026-08-19 17:29:27.315669
2339	sentry	NOT_CONFIGURED	\N	2026-08-19 17:29:27.315669
2340	openai	NOT_CONFIGURED	\N	2026-08-19 17:29:27.315669
2341	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:29:27.315669
2342	simulation	HEALTHY	\N	2026-08-19 17:29:27.315669
2343	application	HEALTHY	4.5	2026-08-19 17:29:27.315669
2377	database	HEALTHY	1	2026-08-19 17:31:27.440109
2378	redis	NOT_CONFIGURED	\N	2026-08-19 17:31:27.440109
2379	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:31:27.441127
2380	celery	NOT_CONFIGURED	\N	2026-08-19 17:31:27.441127
2381	email	HEALTHY	\N	2026-08-19 17:31:27.441127
2382	backup	UNAVAILABLE	\N	2026-08-19 17:31:27.441127
2383	sentry	NOT_CONFIGURED	\N	2026-08-19 17:31:27.441127
2384	openai	NOT_CONFIGURED	\N	2026-08-19 17:31:27.441127
2385	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:31:27.441127
2386	simulation	HEALTHY	\N	2026-08-19 17:31:27.441127
2387	application	HEALTHY	4.5	2026-08-19 17:31:27.441127
2388	database	HEALTHY	1	2026-08-19 17:31:57.466346
2389	redis	NOT_CONFIGURED	\N	2026-08-19 17:31:57.466346
2390	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:31:57.467337
2391	celery	NOT_CONFIGURED	\N	2026-08-19 17:31:57.467337
2392	email	HEALTHY	\N	2026-08-19 17:31:57.467337
2393	backup	UNAVAILABLE	\N	2026-08-19 17:31:57.467337
2394	sentry	NOT_CONFIGURED	\N	2026-08-19 17:31:57.467337
2395	openai	NOT_CONFIGURED	\N	2026-08-19 17:31:57.467337
2396	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:31:57.467826
2397	simulation	HEALTHY	\N	2026-08-19 17:31:57.467826
2398	application	HEALTHY	4.5	2026-08-19 17:31:57.467826
2894	database	HEALTHY	0	2026-08-19 18:19:44.706697
2895	redis	NOT_CONFIGURED	\N	2026-08-19 18:19:44.706697
2896	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:19:44.707697
2897	celery	NOT_CONFIGURED	\N	2026-08-19 18:19:44.707697
2898	email	HEALTHY	\N	2026-08-19 18:19:44.707697
2899	backup	DEGRADED	\N	2026-08-19 18:19:44.707697
2900	sentry	NOT_CONFIGURED	\N	2026-08-19 18:19:44.707697
2901	openai	NOT_CONFIGURED	\N	2026-08-19 18:19:44.707697
2902	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:19:44.707697
2903	simulation	HEALTHY	\N	2026-08-19 18:19:44.707697
2904	application	HEALTHY	4.5	2026-08-19 18:19:44.707697
3048	database	HEALTHY	1	2026-08-19 18:23:14.89588
3049	redis	NOT_CONFIGURED	\N	2026-08-19 18:23:14.89588
3050	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:23:14.89588
3051	celery	NOT_CONFIGURED	\N	2026-08-19 18:23:14.89588
3052	email	HEALTHY	\N	2026-08-19 18:23:14.89588
3053	backup	UNAVAILABLE	\N	2026-08-19 18:23:14.89588
3054	sentry	NOT_CONFIGURED	\N	2026-08-19 18:23:14.896879
3055	openai	NOT_CONFIGURED	\N	2026-08-19 18:23:14.896879
3056	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:23:14.896879
3057	simulation	HEALTHY	\N	2026-08-19 18:23:14.896879
3058	application	HEALTHY	4.5	2026-08-19 18:23:14.896879
3136	database	HEALTHY	0	2026-08-19 18:26:45.12315
3137	redis	NOT_CONFIGURED	\N	2026-08-19 18:26:45.12315
3138	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:26:45.12315
3139	celery	NOT_CONFIGURED	\N	2026-08-19 18:26:45.12315
3140	email	HEALTHY	\N	2026-08-19 18:26:45.12315
3141	backup	HEALTHY	\N	2026-08-19 18:26:45.12315
3142	sentry	NOT_CONFIGURED	\N	2026-08-19 18:26:45.12315
3143	openai	NOT_CONFIGURED	\N	2026-08-19 18:26:45.124151
3144	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:26:45.124151
3145	simulation	HEALTHY	\N	2026-08-19 18:26:45.124151
3146	application	HEALTHY	4.5	2026-08-19 18:26:45.124151
2355	database	HEALTHY	1.01	2026-08-19 17:30:27.373681
2356	redis	NOT_CONFIGURED	\N	2026-08-19 17:30:27.373681
2357	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:30:27.373681
2358	celery	NOT_CONFIGURED	\N	2026-08-19 17:30:27.373681
2359	email	HEALTHY	\N	2026-08-19 17:30:27.373681
2360	backup	UNAVAILABLE	\N	2026-08-19 17:30:27.373681
2361	sentry	NOT_CONFIGURED	\N	2026-08-19 17:30:27.373681
2362	openai	NOT_CONFIGURED	\N	2026-08-19 17:30:27.373681
2363	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:30:27.373681
2364	simulation	HEALTHY	\N	2026-08-19 17:30:27.373681
2365	application	HEALTHY	4.5	2026-08-19 17:30:27.373681
2399	database	HEALTHY	0	2026-08-19 17:32:27.491365
2400	redis	NOT_CONFIGURED	\N	2026-08-19 17:32:27.492366
2401	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:32:27.492366
2402	celery	NOT_CONFIGURED	\N	2026-08-19 17:32:27.492366
2403	email	HEALTHY	\N	2026-08-19 17:32:27.492366
2404	backup	UNAVAILABLE	\N	2026-08-19 17:32:27.492366
2405	sentry	NOT_CONFIGURED	\N	2026-08-19 17:32:27.492366
2406	openai	NOT_CONFIGURED	\N	2026-08-19 17:32:27.492366
2407	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:32:27.492366
2408	simulation	HEALTHY	\N	2026-08-19 17:32:27.492366
2409	application	HEALTHY	4.5	2026-08-19 17:32:27.492366
2410	database	HEALTHY	0	2026-08-19 17:32:57.531701
2411	redis	NOT_CONFIGURED	\N	2026-08-19 17:32:57.531701
2412	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:32:57.531701
2413	celery	NOT_CONFIGURED	\N	2026-08-19 17:32:57.531701
2414	email	HEALTHY	\N	2026-08-19 17:32:57.531701
2415	backup	UNAVAILABLE	\N	2026-08-19 17:32:57.532697
2416	sentry	NOT_CONFIGURED	\N	2026-08-19 17:32:57.532697
2417	openai	NOT_CONFIGURED	\N	2026-08-19 17:32:57.532697
2418	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:32:57.532697
2419	simulation	HEALTHY	\N	2026-08-19 17:32:57.532697
2420	application	HEALTHY	4.5	2026-08-19 17:32:57.532697
2421	database	HEALTHY	1	2026-08-19 17:33:27.564793
2422	redis	NOT_CONFIGURED	\N	2026-08-19 17:33:27.564793
2423	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:33:27.564793
2424	celery	NOT_CONFIGURED	\N	2026-08-19 17:33:27.564793
2425	email	HEALTHY	\N	2026-08-19 17:33:27.564793
2426	backup	UNAVAILABLE	\N	2026-08-19 17:33:27.564793
2427	sentry	NOT_CONFIGURED	\N	2026-08-19 17:33:27.564793
2428	openai	NOT_CONFIGURED	\N	2026-08-19 17:33:27.564793
2429	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:33:27.564793
2430	simulation	HEALTHY	\N	2026-08-19 17:33:27.564793
2431	application	HEALTHY	4.5	2026-08-19 17:33:27.565787
2432	database	HEALTHY	0	2026-08-19 17:33:57.596783
2433	redis	NOT_CONFIGURED	\N	2026-08-19 17:33:57.596783
2434	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:33:57.596783
2435	celery	NOT_CONFIGURED	\N	2026-08-19 17:33:57.596783
2436	email	HEALTHY	\N	2026-08-19 17:33:57.596783
2437	backup	UNAVAILABLE	\N	2026-08-19 17:33:57.596783
2438	sentry	NOT_CONFIGURED	\N	2026-08-19 17:33:57.596783
2439	openai	NOT_CONFIGURED	\N	2026-08-19 17:33:57.596783
2440	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:33:57.596783
2441	simulation	HEALTHY	\N	2026-08-19 17:33:57.596783
2442	application	HEALTHY	4.5	2026-08-19 17:33:57.596783
2443	database	HEALTHY	0	2026-08-19 17:34:27.650013
2444	redis	NOT_CONFIGURED	\N	2026-08-19 17:34:27.650013
2445	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:34:27.650013
2446	celery	NOT_CONFIGURED	\N	2026-08-19 17:34:27.650013
2447	email	HEALTHY	\N	2026-08-19 17:34:27.651012
2448	backup	UNAVAILABLE	\N	2026-08-19 17:34:27.651012
2449	sentry	NOT_CONFIGURED	\N	2026-08-19 17:34:27.651012
2450	openai	NOT_CONFIGURED	\N	2026-08-19 17:34:27.651012
2451	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:34:27.651012
2452	simulation	HEALTHY	\N	2026-08-19 17:34:27.651012
2453	application	HEALTHY	4.5	2026-08-19 17:34:27.651012
2454	database	HEALTHY	1.11	2026-08-19 17:34:57.714404
2455	redis	NOT_CONFIGURED	\N	2026-08-19 17:34:57.714404
2456	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:34:57.714404
2457	celery	NOT_CONFIGURED	\N	2026-08-19 17:34:57.714404
2458	email	HEALTHY	\N	2026-08-19 17:34:57.714404
2459	backup	UNAVAILABLE	\N	2026-08-19 17:34:57.714404
2460	sentry	NOT_CONFIGURED	\N	2026-08-19 17:34:57.714404
2461	openai	NOT_CONFIGURED	\N	2026-08-19 17:34:57.714404
2462	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:34:57.714404
2463	simulation	HEALTHY	\N	2026-08-19 17:34:57.714404
2464	application	HEALTHY	4.5	2026-08-19 17:34:57.714404
2465	database	HEALTHY	1	2026-08-19 17:35:27.773865
2466	redis	NOT_CONFIGURED	\N	2026-08-19 17:35:27.773865
2467	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:35:27.773865
2468	celery	NOT_CONFIGURED	\N	2026-08-19 17:35:27.773865
2469	email	HEALTHY	\N	2026-08-19 17:35:27.773865
2470	backup	UNAVAILABLE	\N	2026-08-19 17:35:27.773865
2471	sentry	NOT_CONFIGURED	\N	2026-08-19 17:35:27.773865
2472	openai	NOT_CONFIGURED	\N	2026-08-19 17:35:27.773865
2473	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:35:27.773865
2474	simulation	HEALTHY	\N	2026-08-19 17:35:27.773865
2475	application	HEALTHY	4.5	2026-08-19 17:35:27.773865
2476	database	HEALTHY	1.01	2026-08-19 17:35:57.808189
2477	redis	NOT_CONFIGURED	\N	2026-08-19 17:35:57.808189
2478	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:35:57.80919
2479	celery	NOT_CONFIGURED	\N	2026-08-19 17:35:57.80919
2480	email	HEALTHY	\N	2026-08-19 17:35:57.80919
2481	backup	UNAVAILABLE	\N	2026-08-19 17:35:57.80919
2482	sentry	NOT_CONFIGURED	\N	2026-08-19 17:35:57.80919
2483	openai	NOT_CONFIGURED	\N	2026-08-19 17:35:57.81019
2484	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:35:57.81019
2485	simulation	HEALTHY	\N	2026-08-19 17:35:57.81019
2486	application	HEALTHY	4.5	2026-08-19 17:35:57.81019
2487	database	HEALTHY	1	2026-08-19 17:36:27.83402
2488	redis	NOT_CONFIGURED	\N	2026-08-19 17:36:27.83402
2489	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:36:27.835025
2490	celery	NOT_CONFIGURED	\N	2026-08-19 17:36:27.835025
2491	email	HEALTHY	\N	2026-08-19 17:36:27.835025
2492	backup	UNAVAILABLE	\N	2026-08-19 17:36:27.835025
2493	sentry	NOT_CONFIGURED	\N	2026-08-19 17:36:27.835025
2494	openai	NOT_CONFIGURED	\N	2026-08-19 17:36:27.835025
2495	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:36:27.835025
2496	simulation	HEALTHY	\N	2026-08-19 17:36:27.835025
2497	application	HEALTHY	4.5	2026-08-19 17:36:27.835025
2498	database	HEALTHY	1.53	2026-08-19 17:36:57.871032
2499	redis	NOT_CONFIGURED	\N	2026-08-19 17:36:57.871032
2500	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:36:57.871032
2501	celery	NOT_CONFIGURED	\N	2026-08-19 17:36:57.871032
2502	email	HEALTHY	\N	2026-08-19 17:36:57.871032
2503	backup	UNAVAILABLE	\N	2026-08-19 17:36:57.871032
2504	sentry	NOT_CONFIGURED	\N	2026-08-19 17:36:57.871032
2505	openai	NOT_CONFIGURED	\N	2026-08-19 17:36:57.871032
2506	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:36:57.871032
2507	simulation	HEALTHY	\N	2026-08-19 17:36:57.871032
2508	application	HEALTHY	4.5	2026-08-19 17:36:57.871032
2509	database	HEALTHY	1	2026-08-19 17:37:27.902669
2510	redis	NOT_CONFIGURED	\N	2026-08-19 17:37:27.902669
2511	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:37:27.902669
2512	celery	NOT_CONFIGURED	\N	2026-08-19 17:37:27.902669
2513	email	HEALTHY	\N	2026-08-19 17:37:27.902669
2514	backup	UNAVAILABLE	\N	2026-08-19 17:37:27.902669
2515	sentry	NOT_CONFIGURED	\N	2026-08-19 17:37:27.902669
2516	openai	NOT_CONFIGURED	\N	2026-08-19 17:37:27.902669
2517	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:37:27.902669
2518	simulation	HEALTHY	\N	2026-08-19 17:37:27.903673
2519	application	HEALTHY	4.5	2026-08-19 17:37:27.903673
2520	database	HEALTHY	0	2026-08-19 17:37:57.944225
2521	redis	NOT_CONFIGURED	\N	2026-08-19 17:37:57.945225
2522	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:37:57.945225
2523	celery	NOT_CONFIGURED	\N	2026-08-19 17:37:57.945225
2524	email	HEALTHY	\N	2026-08-19 17:37:57.945225
2525	backup	UNAVAILABLE	\N	2026-08-19 17:37:57.945225
2526	sentry	NOT_CONFIGURED	\N	2026-08-19 17:37:57.945225
2527	openai	NOT_CONFIGURED	\N	2026-08-19 17:37:57.945225
2528	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:37:57.945225
2529	simulation	HEALTHY	\N	2026-08-19 17:37:57.945225
2530	application	HEALTHY	4.5	2026-08-19 17:37:57.945225
2905	database	HEALTHY	0.99	2026-08-19 18:19:53.354593
2906	redis	NOT_CONFIGURED	\N	2026-08-19 18:19:53.354593
2907	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:19:53.354593
2908	celery	NOT_CONFIGURED	\N	2026-08-19 18:19:53.354593
2909	email	HEALTHY	\N	2026-08-19 18:19:53.354593
2910	backup	DEGRADED	\N	2026-08-19 18:19:53.354593
2911	sentry	NOT_CONFIGURED	\N	2026-08-19 18:19:53.354593
2912	openai	NOT_CONFIGURED	\N	2026-08-19 18:19:53.354593
2913	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:19:53.354593
2914	simulation	HEALTHY	\N	2026-08-19 18:19:53.354593
2915	application	HEALTHY	4.5	2026-08-19 18:19:53.354593
3202	database	HEALTHY	0	2026-08-19 18:29:38.786087
3203	redis	NOT_CONFIGURED	\N	2026-08-19 18:29:38.786087
3204	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:29:38.786087
3205	celery	NOT_CONFIGURED	\N	2026-08-19 18:29:38.786087
3206	email	HEALTHY	\N	2026-08-19 18:29:38.786087
3207	backup	HEALTHY	\N	2026-08-19 18:29:38.786087
3208	sentry	NOT_CONFIGURED	\N	2026-08-19 18:29:38.786087
3209	openai	NOT_CONFIGURED	\N	2026-08-19 18:29:38.786087
3210	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:29:38.786087
3211	simulation	HEALTHY	\N	2026-08-19 18:29:38.786087
3212	application	HEALTHY	4.5	2026-08-19 18:29:38.786087
2531	database	HEALTHY	0	2026-08-19 17:38:27.967346
2532	redis	NOT_CONFIGURED	\N	2026-08-19 17:38:27.967346
2533	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:38:27.967346
2534	celery	NOT_CONFIGURED	\N	2026-08-19 17:38:27.967346
2535	email	HEALTHY	\N	2026-08-19 17:38:27.967346
2536	backup	UNAVAILABLE	\N	2026-08-19 17:38:27.967346
2537	sentry	NOT_CONFIGURED	\N	2026-08-19 17:38:27.967346
2538	openai	NOT_CONFIGURED	\N	2026-08-19 17:38:27.967346
2539	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:38:27.967346
2540	simulation	HEALTHY	\N	2026-08-19 17:38:27.967346
2541	application	HEALTHY	4.5	2026-08-19 17:38:27.968347
2542	database	HEALTHY	1.98	2026-08-19 17:38:58.030375
2543	redis	NOT_CONFIGURED	\N	2026-08-19 17:38:58.030375
2544	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:38:58.030375
2545	celery	NOT_CONFIGURED	\N	2026-08-19 17:38:58.030375
2546	email	HEALTHY	\N	2026-08-19 17:38:58.031351
2547	backup	UNAVAILABLE	\N	2026-08-19 17:38:58.031351
2548	sentry	NOT_CONFIGURED	\N	2026-08-19 17:38:58.031351
2549	openai	NOT_CONFIGURED	\N	2026-08-19 17:38:58.031351
2550	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:38:58.031351
2551	simulation	HEALTHY	\N	2026-08-19 17:38:58.031351
2552	application	HEALTHY	4.5	2026-08-19 17:38:58.031351
2916	database	HEALTHY	0	2026-08-19 18:20:14.732593
2917	redis	NOT_CONFIGURED	\N	2026-08-19 18:20:14.733594
2918	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:20:14.733594
2919	celery	NOT_CONFIGURED	\N	2026-08-19 18:20:14.733594
2920	email	HEALTHY	\N	2026-08-19 18:20:14.733594
2921	backup	DEGRADED	\N	2026-08-19 18:20:14.733594
2922	sentry	NOT_CONFIGURED	\N	2026-08-19 18:20:14.733594
2923	openai	NOT_CONFIGURED	\N	2026-08-19 18:20:14.733594
2924	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:20:14.733594
2925	simulation	HEALTHY	\N	2026-08-19 18:20:14.733594
2926	application	HEALTHY	4.5	2026-08-19 18:20:14.733594
2553	database	HEALTHY	1.98	2026-08-19 17:39:28.098572
2554	redis	NOT_CONFIGURED	\N	2026-08-19 17:39:28.09958
2555	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:39:28.09958
2556	celery	NOT_CONFIGURED	\N	2026-08-19 17:39:28.09958
2557	email	HEALTHY	\N	2026-08-19 17:39:28.09958
2558	backup	UNAVAILABLE	\N	2026-08-19 17:39:28.09958
2559	sentry	NOT_CONFIGURED	\N	2026-08-19 17:39:28.09958
2560	openai	NOT_CONFIGURED	\N	2026-08-19 17:39:28.09958
2561	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:39:28.09958
2562	simulation	HEALTHY	\N	2026-08-19 17:39:28.09958
2563	application	HEALTHY	4.5	2026-08-19 17:39:28.09958
2564	database	HEALTHY	2.05	2026-08-19 17:39:58.159519
2565	redis	NOT_CONFIGURED	\N	2026-08-19 17:39:58.159519
2566	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:39:58.160514
2567	celery	NOT_CONFIGURED	\N	2026-08-19 17:39:58.160514
2568	email	HEALTHY	\N	2026-08-19 17:39:58.160514
2569	backup	UNAVAILABLE	\N	2026-08-19 17:39:58.160514
2570	sentry	NOT_CONFIGURED	\N	2026-08-19 17:39:58.160514
2571	openai	NOT_CONFIGURED	\N	2026-08-19 17:39:58.160514
2572	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:39:58.160514
2573	simulation	HEALTHY	\N	2026-08-19 17:39:58.160514
2574	application	HEALTHY	4.5	2026-08-19 17:39:58.160514
2927	database	HEALTHY	0	2026-08-19 18:20:23.392267
2928	redis	NOT_CONFIGURED	\N	2026-08-19 18:20:23.393267
2929	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:20:23.393267
2930	celery	NOT_CONFIGURED	\N	2026-08-19 18:20:23.393267
2931	email	HEALTHY	\N	2026-08-19 18:20:23.393267
2932	backup	UNAVAILABLE	\N	2026-08-19 18:20:23.393267
2933	sentry	NOT_CONFIGURED	\N	2026-08-19 18:20:23.393267
2934	openai	NOT_CONFIGURED	\N	2026-08-19 18:20:23.393267
2935	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:20:23.393267
2936	simulation	HEALTHY	\N	2026-08-19 18:20:23.393267
2937	application	HEALTHY	4.5	2026-08-19 18:20:23.393267
2949	database	HEALTHY	1.32	2026-08-19 18:20:53.414661
2950	redis	NOT_CONFIGURED	\N	2026-08-19 18:20:53.414661
2951	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:20:53.414661
2952	celery	NOT_CONFIGURED	\N	2026-08-19 18:20:53.414661
2953	email	HEALTHY	\N	2026-08-19 18:20:53.414661
2954	backup	UNAVAILABLE	\N	2026-08-19 18:20:53.414661
2955	sentry	NOT_CONFIGURED	\N	2026-08-19 18:20:53.414661
2956	openai	NOT_CONFIGURED	\N	2026-08-19 18:20:53.414661
2957	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:20:53.414661
2958	simulation	HEALTHY	\N	2026-08-19 18:20:53.414661
2959	application	HEALTHY	4.5	2026-08-19 18:20:53.414661
2993	database	HEALTHY	0.59	2026-08-19 18:21:53.566404
2994	redis	NOT_CONFIGURED	\N	2026-08-19 18:21:53.566404
2995	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:21:53.566404
2996	celery	NOT_CONFIGURED	\N	2026-08-19 18:21:53.566404
2997	email	HEALTHY	\N	2026-08-19 18:21:53.566404
2998	backup	UNAVAILABLE	\N	2026-08-19 18:21:53.566404
2999	sentry	NOT_CONFIGURED	\N	2026-08-19 18:21:53.566404
3000	openai	NOT_CONFIGURED	\N	2026-08-19 18:21:53.566404
3001	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:21:53.566404
3002	simulation	HEALTHY	\N	2026-08-19 18:21:53.566404
3003	application	HEALTHY	4.5	2026-08-19 18:21:53.566404
2575	database	HEALTHY	0.99	2026-08-19 17:40:28.243079
2576	redis	NOT_CONFIGURED	\N	2026-08-19 17:40:28.243079
2577	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:40:28.243079
2578	celery	NOT_CONFIGURED	\N	2026-08-19 17:40:28.243079
2579	email	HEALTHY	\N	2026-08-19 17:40:28.244076
2580	backup	UNAVAILABLE	\N	2026-08-19 17:40:28.244076
2581	sentry	NOT_CONFIGURED	\N	2026-08-19 17:40:28.244076
2582	openai	NOT_CONFIGURED	\N	2026-08-19 17:40:28.244076
2583	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:40:28.244076
2584	simulation	HEALTHY	\N	2026-08-19 17:40:28.244076
2585	application	HEALTHY	4.5	2026-08-19 17:40:28.244076
2971	database	HEALTHY	0	2026-08-19 18:21:23.527444
2972	redis	NOT_CONFIGURED	\N	2026-08-19 18:21:23.527444
2973	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:21:23.527444
2974	celery	NOT_CONFIGURED	\N	2026-08-19 18:21:23.527444
2975	email	HEALTHY	\N	2026-08-19 18:21:23.527444
2976	backup	UNAVAILABLE	\N	2026-08-19 18:21:23.527444
2977	sentry	NOT_CONFIGURED	\N	2026-08-19 18:21:23.527444
2978	openai	NOT_CONFIGURED	\N	2026-08-19 18:21:23.527444
2979	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:21:23.527444
2980	simulation	HEALTHY	\N	2026-08-19 18:21:23.527444
2981	application	HEALTHY	4.5	2026-08-19 18:21:23.527444
3015	database	HEALTHY	0	2026-08-19 18:22:23.59173
3016	redis	NOT_CONFIGURED	\N	2026-08-19 18:22:23.59173
3017	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:22:23.59173
3018	celery	NOT_CONFIGURED	\N	2026-08-19 18:22:23.59173
3019	email	HEALTHY	\N	2026-08-19 18:22:23.59173
3020	backup	UNAVAILABLE	\N	2026-08-19 18:22:23.59173
3021	sentry	NOT_CONFIGURED	\N	2026-08-19 18:22:23.59173
3022	openai	NOT_CONFIGURED	\N	2026-08-19 18:22:23.59173
3023	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:22:23.59173
3024	simulation	HEALTHY	\N	2026-08-19 18:22:23.59173
3025	application	HEALTHY	4.5	2026-08-19 18:22:23.59173
3037	database	HEALTHY	1.38	2026-08-19 18:22:53.650897
3038	redis	NOT_CONFIGURED	\N	2026-08-19 18:22:53.650897
3039	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:22:53.650897
3040	celery	NOT_CONFIGURED	\N	2026-08-19 18:22:53.650897
3041	email	HEALTHY	\N	2026-08-19 18:22:53.650897
3042	backup	UNAVAILABLE	\N	2026-08-19 18:22:53.650897
3043	sentry	NOT_CONFIGURED	\N	2026-08-19 18:22:53.650897
3044	openai	NOT_CONFIGURED	\N	2026-08-19 18:22:53.650897
3045	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:22:53.650897
3046	simulation	HEALTHY	\N	2026-08-19 18:22:53.650897
3047	application	HEALTHY	4.5	2026-08-19 18:22:53.651893
2586	database	HEALTHY	0	2026-08-19 17:40:58.284176
2587	redis	NOT_CONFIGURED	\N	2026-08-19 17:40:58.285177
2588	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 17:40:58.285177
2589	celery	NOT_CONFIGURED	\N	2026-08-19 17:40:58.285177
2590	email	HEALTHY	\N	2026-08-19 17:40:58.285177
2591	backup	UNAVAILABLE	\N	2026-08-19 17:40:58.285177
2592	sentry	NOT_CONFIGURED	\N	2026-08-19 17:40:58.285177
2593	openai	NOT_CONFIGURED	\N	2026-08-19 17:40:58.285177
2594	cloudflare	NOT_CONFIGURED	\N	2026-08-19 17:40:58.285177
2595	simulation	HEALTHY	\N	2026-08-19 17:40:58.285177
2596	application	HEALTHY	4.5	2026-08-19 17:40:58.285177
2597	database	HEALTHY	1	2026-08-19 18:03:54.409594
2598	redis	NOT_CONFIGURED	\N	2026-08-19 18:03:54.409594
2599	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:03:54.409594
2600	celery	NOT_CONFIGURED	\N	2026-08-19 18:03:54.409594
2601	email	HEALTHY	\N	2026-08-19 18:03:54.409594
2602	backup	UNAVAILABLE	\N	2026-08-19 18:03:54.409594
2603	sentry	NOT_CONFIGURED	\N	2026-08-19 18:03:54.41064
2604	openai	NOT_CONFIGURED	\N	2026-08-19 18:03:54.41064
2605	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:03:54.41064
2606	simulation	HEALTHY	\N	2026-08-19 18:03:54.41064
2607	application	HEALTHY	4.5	2026-08-19 18:03:54.41064
2608	database	HEALTHY	1	2026-08-19 18:06:56.751729
2609	redis	NOT_CONFIGURED	\N	2026-08-19 18:06:56.751729
2610	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:06:56.751729
2611	celery	NOT_CONFIGURED	\N	2026-08-19 18:06:56.751729
2612	email	HEALTHY	\N	2026-08-19 18:06:56.751729
2613	backup	UNAVAILABLE	\N	2026-08-19 18:06:56.751729
2614	sentry	NOT_CONFIGURED	\N	2026-08-19 18:06:56.751729
2615	openai	NOT_CONFIGURED	\N	2026-08-19 18:06:56.751729
2616	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:06:56.751729
2617	simulation	HEALTHY	\N	2026-08-19 18:06:56.751729
2618	application	HEALTHY	4.5	2026-08-19 18:06:56.751729
2619	database	HEALTHY	1.03	2026-08-19 18:07:26.79446
2620	redis	NOT_CONFIGURED	\N	2026-08-19 18:07:26.79446
2621	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:07:26.79446
2622	celery	NOT_CONFIGURED	\N	2026-08-19 18:07:26.79446
2623	email	HEALTHY	\N	2026-08-19 18:07:26.79446
2624	backup	UNAVAILABLE	\N	2026-08-19 18:07:26.79446
2625	sentry	NOT_CONFIGURED	\N	2026-08-19 18:07:26.79446
2626	openai	NOT_CONFIGURED	\N	2026-08-19 18:07:26.79446
2627	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:07:26.79446
2628	simulation	HEALTHY	\N	2026-08-19 18:07:26.79446
2629	application	HEALTHY	4.5	2026-08-19 18:07:26.79446
2630	database	HEALTHY	1.01	2026-08-19 18:07:56.8419
2631	redis	NOT_CONFIGURED	\N	2026-08-19 18:07:56.8419
2632	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:07:56.8419
2633	celery	NOT_CONFIGURED	\N	2026-08-19 18:07:56.8419
2634	email	HEALTHY	\N	2026-08-19 18:07:56.8419
2635	backup	UNAVAILABLE	\N	2026-08-19 18:07:56.8419
2636	sentry	NOT_CONFIGURED	\N	2026-08-19 18:07:56.8419
2637	openai	NOT_CONFIGURED	\N	2026-08-19 18:07:56.8419
2638	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:07:56.842919
2639	simulation	HEALTHY	\N	2026-08-19 18:07:56.842919
2640	application	HEALTHY	4.5	2026-08-19 18:07:56.842919
2641	database	HEALTHY	0.77	2026-08-19 18:08:26.885614
2642	redis	NOT_CONFIGURED	\N	2026-08-19 18:08:26.885614
2643	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:08:26.886594
2644	celery	NOT_CONFIGURED	\N	2026-08-19 18:08:26.886594
2645	email	HEALTHY	\N	2026-08-19 18:08:26.886594
2646	backup	UNAVAILABLE	\N	2026-08-19 18:08:26.886594
2647	sentry	NOT_CONFIGURED	\N	2026-08-19 18:08:26.886594
2648	openai	NOT_CONFIGURED	\N	2026-08-19 18:08:26.886594
2649	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:08:26.886594
2650	simulation	HEALTHY	\N	2026-08-19 18:08:26.886594
2651	application	HEALTHY	4.5	2026-08-19 18:08:26.886594
2652	database	HEALTHY	1	2026-08-19 18:08:56.920829
2653	redis	NOT_CONFIGURED	\N	2026-08-19 18:08:56.92183
2654	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:08:56.92183
2655	celery	NOT_CONFIGURED	\N	2026-08-19 18:08:56.92183
2656	email	HEALTHY	\N	2026-08-19 18:08:56.92183
2657	backup	UNAVAILABLE	\N	2026-08-19 18:08:56.92183
2658	sentry	NOT_CONFIGURED	\N	2026-08-19 18:08:56.92183
2659	openai	NOT_CONFIGURED	\N	2026-08-19 18:08:56.92183
2660	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:08:56.92183
2661	simulation	HEALTHY	\N	2026-08-19 18:08:56.92183
2662	application	HEALTHY	4.5	2026-08-19 18:08:56.92183
2663	database	HEALTHY	0	2026-08-19 18:09:26.951583
2664	redis	NOT_CONFIGURED	\N	2026-08-19 18:09:26.951583
2665	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:09:26.951583
2666	celery	NOT_CONFIGURED	\N	2026-08-19 18:09:26.951583
2667	email	HEALTHY	\N	2026-08-19 18:09:26.951583
2668	backup	UNAVAILABLE	\N	2026-08-19 18:09:26.951583
2669	sentry	NOT_CONFIGURED	\N	2026-08-19 18:09:26.951583
2670	openai	NOT_CONFIGURED	\N	2026-08-19 18:09:26.951583
2671	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:09:26.951583
2672	simulation	HEALTHY	\N	2026-08-19 18:09:26.951583
2673	application	HEALTHY	4.5	2026-08-19 18:09:26.951583
2674	database	HEALTHY	1	2026-08-19 18:09:56.980211
2675	redis	NOT_CONFIGURED	\N	2026-08-19 18:09:56.980211
2676	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:09:56.980211
2677	celery	NOT_CONFIGURED	\N	2026-08-19 18:09:56.980211
2678	email	HEALTHY	\N	2026-08-19 18:09:56.980211
2679	backup	UNAVAILABLE	\N	2026-08-19 18:09:56.980211
2680	sentry	NOT_CONFIGURED	\N	2026-08-19 18:09:56.980211
2681	openai	NOT_CONFIGURED	\N	2026-08-19 18:09:56.980211
2682	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:09:56.980211
2683	simulation	HEALTHY	\N	2026-08-19 18:09:56.980211
2684	application	HEALTHY	4.5	2026-08-19 18:09:56.980211
2685	database	HEALTHY	0	2026-08-19 18:10:27.031496
2686	redis	NOT_CONFIGURED	\N	2026-08-19 18:10:27.031496
2687	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:10:27.031496
2688	celery	NOT_CONFIGURED	\N	2026-08-19 18:10:27.032495
2689	email	HEALTHY	\N	2026-08-19 18:10:27.032495
2690	backup	UNAVAILABLE	\N	2026-08-19 18:10:27.032495
2691	sentry	NOT_CONFIGURED	\N	2026-08-19 18:10:27.032495
2692	openai	NOT_CONFIGURED	\N	2026-08-19 18:10:27.032495
2693	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:10:27.032495
2694	simulation	HEALTHY	\N	2026-08-19 18:10:27.032495
2695	application	HEALTHY	4.5	2026-08-19 18:10:27.032495
2696	database	HEALTHY	1.01	2026-08-19 18:10:57.109094
2697	redis	NOT_CONFIGURED	\N	2026-08-19 18:10:57.109094
2698	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:10:57.109094
2699	celery	NOT_CONFIGURED	\N	2026-08-19 18:10:57.109094
2700	email	HEALTHY	\N	2026-08-19 18:10:57.109094
2701	backup	UNAVAILABLE	\N	2026-08-19 18:10:57.109094
2702	sentry	NOT_CONFIGURED	\N	2026-08-19 18:10:57.109094
2703	openai	NOT_CONFIGURED	\N	2026-08-19 18:10:57.109094
2704	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:10:57.109094
2705	simulation	HEALTHY	\N	2026-08-19 18:10:57.109094
2706	application	HEALTHY	4.5	2026-08-19 18:10:57.109094
2707	database	HEALTHY	0	2026-08-19 18:11:27.163317
2708	redis	NOT_CONFIGURED	\N	2026-08-19 18:11:27.163317
2709	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:11:27.163317
2710	celery	NOT_CONFIGURED	\N	2026-08-19 18:11:27.163317
2711	email	HEALTHY	\N	2026-08-19 18:11:27.163317
2712	backup	UNAVAILABLE	\N	2026-08-19 18:11:27.163317
2713	sentry	NOT_CONFIGURED	\N	2026-08-19 18:11:27.163317
2714	openai	NOT_CONFIGURED	\N	2026-08-19 18:11:27.163317
2715	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:11:27.163317
2716	simulation	HEALTHY	\N	2026-08-19 18:11:27.163317
2717	application	HEALTHY	4.5	2026-08-19 18:11:27.163317
2718	database	HEALTHY	1	2026-08-19 18:11:57.189044
2719	redis	NOT_CONFIGURED	\N	2026-08-19 18:11:57.189044
2720	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:11:57.189044
2721	celery	NOT_CONFIGURED	\N	2026-08-19 18:11:57.189044
2722	email	HEALTHY	\N	2026-08-19 18:11:57.189044
2723	backup	UNAVAILABLE	\N	2026-08-19 18:11:57.189044
2724	sentry	NOT_CONFIGURED	\N	2026-08-19 18:11:57.189044
2725	openai	NOT_CONFIGURED	\N	2026-08-19 18:11:57.189044
2726	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:11:57.189044
2727	simulation	HEALTHY	\N	2026-08-19 18:11:57.189044
2728	application	HEALTHY	4.5	2026-08-19 18:11:57.189044
2729	database	HEALTHY	11.29	2026-08-19 18:12:27.294227
2730	redis	NOT_CONFIGURED	\N	2026-08-19 18:12:27.295229
2731	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:12:27.295229
2732	celery	NOT_CONFIGURED	\N	2026-08-19 18:12:27.295229
2733	email	HEALTHY	\N	2026-08-19 18:12:27.295229
2734	backup	UNAVAILABLE	\N	2026-08-19 18:12:27.295229
2735	sentry	NOT_CONFIGURED	\N	2026-08-19 18:12:27.295229
2736	openai	NOT_CONFIGURED	\N	2026-08-19 18:12:27.295229
2737	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:12:27.295229
2738	simulation	HEALTHY	\N	2026-08-19 18:12:27.295229
2739	application	HEALTHY	4.5	2026-08-19 18:12:27.295229
2740	database	HEALTHY	0.99	2026-08-19 18:12:57.319008
2741	redis	NOT_CONFIGURED	\N	2026-08-19 18:12:57.319008
2742	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:12:57.319008
2743	celery	NOT_CONFIGURED	\N	2026-08-19 18:12:57.320004
2744	email	HEALTHY	\N	2026-08-19 18:12:57.320004
2745	backup	UNAVAILABLE	\N	2026-08-19 18:12:57.320004
2746	sentry	NOT_CONFIGURED	\N	2026-08-19 18:12:57.320004
2747	openai	NOT_CONFIGURED	\N	2026-08-19 18:12:57.320004
2748	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:12:57.320004
2749	simulation	HEALTHY	\N	2026-08-19 18:12:57.320004
2750	application	HEALTHY	4.5	2026-08-19 18:12:57.320004
2751	database	HEALTHY	1.13	2026-08-19 18:13:27.34698
2752	redis	NOT_CONFIGURED	\N	2026-08-19 18:13:27.348433
2753	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:13:27.348433
2754	celery	NOT_CONFIGURED	\N	2026-08-19 18:13:27.348433
2755	email	HEALTHY	\N	2026-08-19 18:13:27.348433
2756	backup	UNAVAILABLE	\N	2026-08-19 18:13:27.348433
2757	sentry	NOT_CONFIGURED	\N	2026-08-19 18:13:27.348433
2758	openai	NOT_CONFIGURED	\N	2026-08-19 18:13:27.348433
2759	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:13:27.348433
2760	simulation	HEALTHY	\N	2026-08-19 18:13:27.348433
2761	application	HEALTHY	4.5	2026-08-19 18:13:27.348433
2762	database	HEALTHY	3.51	2026-08-19 18:13:57.443364
2763	redis	NOT_CONFIGURED	\N	2026-08-19 18:13:57.443364
2764	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:13:57.443364
2765	celery	NOT_CONFIGURED	\N	2026-08-19 18:13:57.443364
2766	email	HEALTHY	\N	2026-08-19 18:13:57.443364
2767	backup	UNAVAILABLE	\N	2026-08-19 18:13:57.443364
2768	sentry	NOT_CONFIGURED	\N	2026-08-19 18:13:57.443364
2769	openai	NOT_CONFIGURED	\N	2026-08-19 18:13:57.443364
2770	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:13:57.443364
2771	simulation	HEALTHY	\N	2026-08-19 18:13:57.443364
2772	application	HEALTHY	4.5	2026-08-19 18:13:57.443364
2773	database	HEALTHY	1	2026-08-19 18:14:44.167485
2774	redis	NOT_CONFIGURED	\N	2026-08-19 18:14:44.167485
2775	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:14:44.167485
2776	celery	NOT_CONFIGURED	\N	2026-08-19 18:14:44.167485
2777	email	HEALTHY	\N	2026-08-19 18:14:44.167485
2778	backup	HEALTHY	\N	2026-08-19 18:14:44.167485
2779	sentry	NOT_CONFIGURED	\N	2026-08-19 18:14:44.167485
2780	openai	NOT_CONFIGURED	\N	2026-08-19 18:14:44.167485
2781	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:14:44.167485
2782	simulation	HEALTHY	\N	2026-08-19 18:14:44.167485
2783	application	HEALTHY	4.5	2026-08-19 18:14:44.167485
2784	database	HEALTHY	0.54	2026-08-19 18:15:14.21573
2785	redis	NOT_CONFIGURED	\N	2026-08-19 18:15:14.21573
2786	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:15:14.21573
2787	celery	NOT_CONFIGURED	\N	2026-08-19 18:15:14.21573
2788	email	HEALTHY	\N	2026-08-19 18:15:14.21573
2789	backup	UNAVAILABLE	\N	2026-08-19 18:15:14.21573
2790	sentry	NOT_CONFIGURED	\N	2026-08-19 18:15:14.21573
2791	openai	NOT_CONFIGURED	\N	2026-08-19 18:15:14.21573
2792	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:15:14.21573
2793	simulation	HEALTHY	\N	2026-08-19 18:15:14.21573
2794	application	HEALTHY	4.5	2026-08-19 18:15:14.21573
3059	database	HEALTHY	0	2026-08-19 18:23:44.9221
3060	redis	NOT_CONFIGURED	\N	2026-08-19 18:23:44.9221
3061	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:23:44.9221
3062	celery	NOT_CONFIGURED	\N	2026-08-19 18:23:44.9221
3063	email	HEALTHY	\N	2026-08-19 18:23:44.9221
3064	backup	UNAVAILABLE	\N	2026-08-19 18:23:44.9221
3065	sentry	NOT_CONFIGURED	\N	2026-08-19 18:23:44.9221
3066	openai	NOT_CONFIGURED	\N	2026-08-19 18:23:44.9221
3067	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:23:44.9221
3068	simulation	HEALTHY	\N	2026-08-19 18:23:44.9221
3069	application	HEALTHY	4.5	2026-08-19 18:23:44.9221
3147	database	HEALTHY	1	2026-08-19 18:27:15.158229
3148	redis	NOT_CONFIGURED	\N	2026-08-19 18:27:15.158229
3149	rabbitmq	NOT_CONFIGURED	\N	2026-08-19 18:27:15.158229
3150	celery	NOT_CONFIGURED	\N	2026-08-19 18:27:15.158229
3151	email	HEALTHY	\N	2026-08-19 18:27:15.158229
3152	backup	HEALTHY	\N	2026-08-19 18:27:15.158229
3153	sentry	NOT_CONFIGURED	\N	2026-08-19 18:27:15.15922
3154	openai	NOT_CONFIGURED	\N	2026-08-19 18:27:15.15922
3155	cloudflare	NOT_CONFIGURED	\N	2026-08-19 18:27:15.15922
3156	simulation	HEALTHY	\N	2026-08-19 18:27:15.15922
3157	application	HEALTHY	4.5	2026-08-19 18:27:15.15922
\.


--
-- Data for Name: system_incidents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_incidents (id, category, severity, title, description, source, status, fingerprint, started_at, resolved_at, acknowledged_by, created_at) FROM stdin;
6	DATABASE	CRITICAL	Postgres Connection Fail	Database disconnected during test	test	RESOLVED	TEST_DB_OFFLINE	2026-08-19 18:22:51.311948	2026-08-19 18:22:51.373068	test_manager	2026-08-19 18:22:51.313948
\.


--
-- Data for Name: task_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_events (id, task_id, event_type, previous_status, new_status, user_id, created_at, reason, metadata) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, task_number, warehouse_id, task_type, priority, priority_score, status, source_type, source_id, order_id, order_item_id, product_id, source_location_id, destination_location_id, requested_quantity, completed_quantity, assigned_user_id, assigned_robot_id, created_at, prioritized_at, assigned_at, started_at, paused_at, completed_at, failed_at, cancelled_at, due_at, retry_count, failure_reason, notes, metadata, depends_on_task_id) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (id, user_id, session_token_hash, created_at, last_seen_at, expires_at, revoked_at, revoke_reason, login_method, ip_address, login_location, user_agent) FROM stdin;
\.


--
-- Data for Name: user_warehouse_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_warehouse_access (id, user_id, warehouse_id, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, password_hash, role, full_name, google_subject_id, created_at, updated_at, is_active, is_verified, last_login_at, last_logout_at, last_login_ip, login_location, login_method, failed_login_count, locked_until, email_verified_at, password_changed_at) FROM stdin;
5	test_admin_hardened	\N	$2b$12$84cr.UVx0AzxuMsHIMGm7.rRHF2IndskJ7.2ytRfZF/BWKznDLGvq	admin		\N	2026-08-19 15:43:35.82341	2026-08-19 18:29:13.907173	t	t	2026-08-19 18:29:13.904158	\N	testclient	\N	password	0	\N	\N	\N
2	test_admin	\N	$2b$12$OmsHHWKY23exujIxiSkKP.E43CZtgSMZpC3vK91GZe3F/QNXQmGHC	admin		\N	2026-08-19 15:43:35.82341	2026-08-19 18:29:34.465799	t	t	2026-08-19 18:29:34.46378	\N	testclient	\N	password	0	\N	\N	2026-08-19 18:20:15.721325
4	test_viewer	\N	$2b$12$nQPG2Um5UqZfI6jK3B6.WetOxegfqLhd6Pce1RI9tUCKHBMph6XAy	viewer		\N	2026-08-19 15:43:35.82341	2026-08-19 18:19:39.737522	t	t	2026-08-19 18:19:39.736398	\N	testclient	\N	password	0	\N	\N	\N
3	test_manager	\N	$2b$12$GFo8sE.n54/fIADXyKInkucviTcgbabSwv8GzwGEvt397RMAB5bmO	manager		\N	2026-08-19 15:43:35.82341	2026-08-19 18:20:02.256244	t	t	2026-08-19 18:20:02.253668	\N	testclient	\N	password	0	\N	\N	\N
1	admin	\N	$2b$12$ZBDm0khkDRbz0JCeYWHKweMqEuIQNPH4U39P4IhVqCAKD5RILGQrK	admin	System Administrator	\N	2026-08-19 15:43:01.098298	2026-08-19 18:18:36.662353	t	t	2026-08-19 18:18:36.656975	\N	testclient	\N	password	0	\N	\N	\N
\.


--
-- Data for Name: warehouse_grid_cells; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_grid_cells (id, warehouse_id, x, y, cell_type, traversable, occupied, restricted, cost, metadata) FROM stdin;
\.


--
-- Data for Name: warehouse_locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_locations (id, warehouse_id, zone, aisle, rack, shelf, x, y, capacity, current_utilization, location_type, status, created_at) FROM stdin;
WH-WH-BLR-01-RECEIVING	WH-BLR-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-SHIPPING	WH-BLR-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-STAGING	WH-BLR-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-CHARGING-1	WH-BLR-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-CHARGING-2	WH-BLR-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-CPU-01-STORAGE	WH-BLR-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-GPU-01-STORAGE	WH-BLR-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-RAM-01-STORAGE	WH-BLR-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-SSD-01-STORAGE	WH-BLR-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-HDD-01-STORAGE	WH-BLR-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-CHG-01-STORAGE	WH-BLR-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-CBL-01-STORAGE	WH-BLR-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-CPU-01-PICKING	WH-BLR-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-GPU-01-PICKING	WH-BLR-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-RAM-01-PICKING	WH-BLR-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-SSD-01-PICKING	WH-BLR-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-HDD-01-PICKING	WH-BLR-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-CHG-01-PICKING	WH-BLR-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-LOC-ITM-CBL-01-PICKING	WH-BLR-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-1-1	WH-BLR-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-12-1	WH-BLR-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-1-2	WH-BLR-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-2-2	WH-BLR-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-3-2	WH-BLR-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-4-2	WH-BLR-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-5-2	WH-BLR-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-6-2	WH-BLR-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-7-2	WH-BLR-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-8-2	WH-BLR-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-9-2	WH-BLR-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-10-2	WH-BLR-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-11-2	WH-BLR-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-12-2	WH-BLR-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-1-3	WH-BLR-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-12-3	WH-BLR-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-1-4	WH-BLR-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-2-4	WH-BLR-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-3-4	WH-BLR-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-4-4	WH-BLR-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-5-4	WH-BLR-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-6-4	WH-BLR-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-7-4	WH-BLR-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-8-4	WH-BLR-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-9-4	WH-BLR-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-10-4	WH-BLR-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-11-4	WH-BLR-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-12-4	WH-BLR-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-3-5	WH-BLR-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-4-5	WH-BLR-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-5-5	WH-BLR-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-6-5	WH-BLR-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-7-5	WH-BLR-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-8-5	WH-BLR-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-9-5	WH-BLR-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BLR-01-AISLE-10-5	WH-BLR-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-RECEIVING	WH-CHN-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-SHIPPING	WH-CHN-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-STAGING	WH-CHN-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-CHARGING-1	WH-CHN-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-CHARGING-2	WH-CHN-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-CPU-01-STORAGE	WH-CHN-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-GPU-01-STORAGE	WH-CHN-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-RAM-01-STORAGE	WH-CHN-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-SSD-01-STORAGE	WH-CHN-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-HDD-01-STORAGE	WH-CHN-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-CHG-01-STORAGE	WH-CHN-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-CBL-01-STORAGE	WH-CHN-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-CPU-01-PICKING	WH-CHN-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-GPU-01-PICKING	WH-CHN-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-RAM-01-PICKING	WH-CHN-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-SSD-01-PICKING	WH-CHN-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-HDD-01-PICKING	WH-CHN-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-CHG-01-PICKING	WH-CHN-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-LOC-ITM-CBL-01-PICKING	WH-CHN-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-1-1	WH-CHN-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-12-1	WH-CHN-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-1-2	WH-CHN-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-2-2	WH-CHN-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-3-2	WH-CHN-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-4-2	WH-CHN-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-5-2	WH-CHN-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-6-2	WH-CHN-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-7-2	WH-CHN-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-8-2	WH-CHN-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-9-2	WH-CHN-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-10-2	WH-CHN-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-11-2	WH-CHN-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-12-2	WH-CHN-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-1-3	WH-CHN-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-12-3	WH-CHN-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-1-4	WH-CHN-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-2-4	WH-CHN-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-3-4	WH-CHN-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-4-4	WH-CHN-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-5-4	WH-CHN-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-6-4	WH-CHN-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-7-4	WH-CHN-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-8-4	WH-CHN-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-9-4	WH-CHN-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-10-4	WH-CHN-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-11-4	WH-CHN-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-12-4	WH-CHN-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-3-5	WH-CHN-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-4-5	WH-CHN-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-5-5	WH-CHN-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-6-5	WH-CHN-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-7-5	WH-CHN-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-8-5	WH-CHN-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-9-5	WH-CHN-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CHN-01-AISLE-10-5	WH-CHN-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-RECEIVING	WH-BOM-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-SHIPPING	WH-BOM-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-STAGING	WH-BOM-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-CHARGING-1	WH-BOM-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-CHARGING-2	WH-BOM-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-CPU-01-STORAGE	WH-BOM-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-GPU-01-STORAGE	WH-BOM-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-RAM-01-STORAGE	WH-BOM-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-SSD-01-STORAGE	WH-BOM-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-HDD-01-STORAGE	WH-BOM-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-CHG-01-STORAGE	WH-BOM-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-CBL-01-STORAGE	WH-BOM-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-CPU-01-PICKING	WH-BOM-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-GPU-01-PICKING	WH-BOM-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-RAM-01-PICKING	WH-BOM-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-SSD-01-PICKING	WH-BOM-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-HDD-01-PICKING	WH-BOM-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-CHG-01-PICKING	WH-BOM-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-LOC-ITM-CBL-01-PICKING	WH-BOM-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-1-1	WH-BOM-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-12-1	WH-BOM-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-1-2	WH-BOM-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-2-2	WH-BOM-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-3-2	WH-BOM-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-4-2	WH-BOM-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-5-2	WH-BOM-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-6-2	WH-BOM-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-7-2	WH-BOM-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-8-2	WH-BOM-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-9-2	WH-BOM-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-10-2	WH-BOM-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-11-2	WH-BOM-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-12-2	WH-BOM-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-1-3	WH-BOM-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-12-3	WH-BOM-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-1-4	WH-BOM-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-2-4	WH-BOM-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-3-4	WH-BOM-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-4-4	WH-BOM-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-5-4	WH-BOM-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-6-4	WH-BOM-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-7-4	WH-BOM-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-8-4	WH-BOM-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-9-4	WH-BOM-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-10-4	WH-BOM-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-11-4	WH-BOM-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-12-4	WH-BOM-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-3-5	WH-BOM-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-4-5	WH-BOM-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-5-5	WH-BOM-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-6-5	WH-BOM-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-7-5	WH-BOM-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-8-5	WH-BOM-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-9-5	WH-BOM-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-BOM-01-AISLE-10-5	WH-BOM-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-RECEIVING	WH-DEL-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-SHIPPING	WH-DEL-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-STAGING	WH-DEL-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-CHARGING-1	WH-DEL-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-CHARGING-2	WH-DEL-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-CPU-01-STORAGE	WH-DEL-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-GPU-01-STORAGE	WH-DEL-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-RAM-01-STORAGE	WH-DEL-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-SSD-01-STORAGE	WH-DEL-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-HDD-01-STORAGE	WH-DEL-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-CHG-01-STORAGE	WH-DEL-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-CBL-01-STORAGE	WH-DEL-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-CPU-01-PICKING	WH-DEL-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-GPU-01-PICKING	WH-DEL-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-RAM-01-PICKING	WH-DEL-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-SSD-01-PICKING	WH-DEL-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-HDD-01-PICKING	WH-DEL-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-CHG-01-PICKING	WH-DEL-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-LOC-ITM-CBL-01-PICKING	WH-DEL-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-1-1	WH-DEL-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-12-1	WH-DEL-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-1-2	WH-DEL-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-2-2	WH-DEL-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-3-2	WH-DEL-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-4-2	WH-DEL-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-5-2	WH-DEL-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-6-2	WH-DEL-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-7-2	WH-DEL-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-8-2	WH-DEL-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-9-2	WH-DEL-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-10-2	WH-DEL-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-11-2	WH-DEL-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-12-2	WH-DEL-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-1-3	WH-DEL-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-12-3	WH-DEL-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-1-4	WH-DEL-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-2-4	WH-DEL-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-3-4	WH-DEL-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-4-4	WH-DEL-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-5-4	WH-DEL-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-6-4	WH-DEL-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-7-4	WH-DEL-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-8-4	WH-DEL-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-9-4	WH-DEL-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-10-4	WH-DEL-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-11-4	WH-DEL-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-12-4	WH-DEL-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-3-5	WH-DEL-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-4-5	WH-DEL-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-5-5	WH-DEL-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-6-5	WH-DEL-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-7-5	WH-DEL-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-8-5	WH-DEL-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-9-5	WH-DEL-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-DEL-01-AISLE-10-5	WH-DEL-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-RECEIVING	WH-CCU-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-SHIPPING	WH-CCU-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-STAGING	WH-CCU-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-CHARGING-1	WH-CCU-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-CHARGING-2	WH-CCU-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-CPU-01-STORAGE	WH-CCU-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-GPU-01-STORAGE	WH-CCU-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-RAM-01-STORAGE	WH-CCU-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-SSD-01-STORAGE	WH-CCU-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-HDD-01-STORAGE	WH-CCU-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-CHG-01-STORAGE	WH-CCU-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-CBL-01-STORAGE	WH-CCU-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-CPU-01-PICKING	WH-CCU-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-GPU-01-PICKING	WH-CCU-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-RAM-01-PICKING	WH-CCU-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-SSD-01-PICKING	WH-CCU-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-HDD-01-PICKING	WH-CCU-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-CHG-01-PICKING	WH-CCU-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-LOC-ITM-CBL-01-PICKING	WH-CCU-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-1-1	WH-CCU-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-12-1	WH-CCU-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-1-2	WH-CCU-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-2-2	WH-CCU-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-3-2	WH-CCU-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-4-2	WH-CCU-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-5-2	WH-CCU-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-6-2	WH-CCU-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-7-2	WH-CCU-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-8-2	WH-CCU-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-9-2	WH-CCU-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-10-2	WH-CCU-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-11-2	WH-CCU-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-12-2	WH-CCU-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-1-3	WH-CCU-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-12-3	WH-CCU-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-1-4	WH-CCU-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-2-4	WH-CCU-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-3-4	WH-CCU-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-4-4	WH-CCU-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-5-4	WH-CCU-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-6-4	WH-CCU-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-7-4	WH-CCU-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-8-4	WH-CCU-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-9-4	WH-CCU-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-10-4	WH-CCU-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-11-4	WH-CCU-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-12-4	WH-CCU-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-3-5	WH-CCU-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-4-5	WH-CCU-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-5-5	WH-CCU-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-6-5	WH-CCU-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-7-5	WH-CCU-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-8-5	WH-CCU-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-9-5	WH-CCU-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
WH-WH-CCU-01-AISLE-10-5	WH-CCU-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 18:28:40.895184
\.


--
-- Data for Name: warehouse_obstacles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_obstacles (id, warehouse_id, obstacle_type, x, y, width, height, active, severity, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouses (id, name, location, latitude, longitude, created_at) FROM stdin;
WH-BLR-01	Bangalore Fulfillment Center	Bangalore, Karnataka	12.971598	77.594566	2026-08-19 18:28:40.811838
WH-CHN-01	Chennai Port Logistics Hub	Chennai, Tamil Nadu	13.08268	80.270718	2026-08-19 18:28:40.842846
WH-BOM-01	Mumbai Container Terminal	Mumbai, Maharashtra	19.07609	72.877701	2026-08-19 18:28:40.850857
WH-DEL-01	Delhi NCR Logistics Park	Noida, Uttar Pradesh	28.535517	77.391029	2026-08-19 18:28:40.856857
WH-CCU-01	Kolkata Gateway Depot	Kolkata, West Bengal	22.572646	88.363895	2026-08-19 18:28:40.863888
\.


--
-- Name: access_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_log_id_seq', 647, true);


--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_recommendations_id_seq', 221, true);


--
-- Name: audit_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_ledger_id_seq', 847, true);


--
-- Name: backup_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.backup_records_id_seq', 14, true);


--
-- Name: digital_twin_simulations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.digital_twin_simulations_id_seq', 4, true);


--
-- Name: experiment_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.experiment_runs_id_seq', 1, false);


--
-- Name: experiments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.experiments_id_seq', 2, true);


--
-- Name: health_thresholds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.health_thresholds_id_seq', 23, true);


--
-- Name: inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_id_seq', 414, true);


--
-- Name: inventory_reservations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_reservations_id_seq', 4, true);


--
-- Name: notification_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_preferences_id_seq', 1, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 208, true);


--
-- Name: order_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_events_id_seq', 1, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_items_id_seq', 4, true);


--
-- Name: otp_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.otp_records_id_seq', 4, true);


--
-- Name: packing_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.packing_records_id_seq', 1, false);


--
-- Name: recovery_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recovery_codes_id_seq', 16, true);


--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recovery_credentials_id_seq', 2, true);


--
-- Name: robot_reservations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robot_reservations_id_seq', 55, true);


--
-- Name: robot_routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robot_routes_id_seq', 18, true);


--
-- Name: robot_telemetry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robot_telemetry_id_seq', 49, true);


--
-- Name: robots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robots_id_seq', 98, true);


--
-- Name: scenarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scenarios_id_seq', 2, true);


--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shrinkage_flags_id_seq', 22, true);


--
-- Name: simulation_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.simulation_events_id_seq', 8, true);


--
-- Name: simulation_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.simulation_snapshots_id_seq', 5, true);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 11765, true);


--
-- Name: system_health_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_health_snapshots_id_seq', 3212, true);


--
-- Name: system_incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_incidents_id_seq', 6, true);


--
-- Name: task_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_events_id_seq', 26, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasks_id_seq', 23, true);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 1, false);


--
-- Name: user_warehouse_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_warehouse_access_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 20, true);


--
-- Name: warehouse_grid_cells_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.warehouse_grid_cells_id_seq', 780, true);


--
-- Name: warehouse_obstacles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.warehouse_obstacles_id_seq', 2, true);


--
-- Name: access_log access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log
    ADD CONSTRAINT access_log_pkey PRIMARY KEY (id);


--
-- Name: ai_recommendations ai_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_recommendations
    ADD CONSTRAINT ai_recommendations_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_ledger audit_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_ledger
    ADD CONSTRAINT audit_ledger_pkey PRIMARY KEY (id);


--
-- Name: backup_records backup_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_records
    ADD CONSTRAINT backup_records_pkey PRIMARY KEY (id);


--
-- Name: digital_twin_simulations digital_twin_simulations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.digital_twin_simulations
    ADD CONSTRAINT digital_twin_simulations_pkey PRIMARY KEY (id);


--
-- Name: experiment_runs experiment_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_runs
    ADD CONSTRAINT experiment_runs_pkey PRIMARY KEY (id);


--
-- Name: experiments experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT experiments_pkey PRIMARY KEY (id);


--
-- Name: health_thresholds health_thresholds_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_thresholds
    ADD CONSTRAINT health_thresholds_pkey PRIMARY KEY (id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: inventory_reservations inventory_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_events order_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_events
    ADD CONSTRAINT order_events_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: otp_records otp_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_records
    ADD CONSTRAINT otp_records_pkey PRIMARY KEY (id);


--
-- Name: packing_records packing_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packing_records
    ADD CONSTRAINT packing_records_pkey PRIMARY KEY (id);


--
-- Name: recovery_codes recovery_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: recovery_credentials recovery_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials
    ADD CONSTRAINT recovery_credentials_pkey PRIMARY KEY (id);


--
-- Name: robot_reservations robot_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_reservations
    ADD CONSTRAINT robot_reservations_pkey PRIMARY KEY (id);


--
-- Name: robot_routes robot_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes
    ADD CONSTRAINT robot_routes_pkey PRIMARY KEY (id);


--
-- Name: robot_telemetry robot_telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_telemetry
    ADD CONSTRAINT robot_telemetry_pkey PRIMARY KEY (id);


--
-- Name: robots robots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_pkey PRIMARY KEY (id);


--
-- Name: scenarios scenarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scenarios
    ADD CONSTRAINT scenarios_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: shrinkage_flags shrinkage_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shrinkage_flags
    ADD CONSTRAINT shrinkage_flags_pkey PRIMARY KEY (id);


--
-- Name: simulation_events simulation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_events
    ADD CONSTRAINT simulation_events_pkey PRIMARY KEY (id);


--
-- Name: simulation_snapshots simulation_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_snapshots
    ADD CONSTRAINT simulation_snapshots_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: system_health_snapshots system_health_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_health_snapshots
    ADD CONSTRAINT system_health_snapshots_pkey PRIMARY KEY (id);


--
-- Name: system_incidents system_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_incidents
    ADD CONSTRAINT system_incidents_pkey PRIMARY KEY (id);


--
-- Name: task_events task_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: warehouse_grid_cells uq_grid_cell; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_grid_cells
    ADD CONSTRAINT uq_grid_cell UNIQUE (warehouse_id, x, y);


--
-- Name: stock_movements uq_movement; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT uq_movement UNIQUE (date, warehouse_id, item_id);


--
-- Name: otp_records uq_otp_user_purpose; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_records
    ADD CONSTRAINT uq_otp_user_purpose UNIQUE (user_id, purpose);


--
-- Name: notification_preferences uq_user_category_preference; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT uq_user_category_preference UNIQUE (user_id, category);


--
-- Name: user_warehouse_access uq_user_warehouse; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access
    ADD CONSTRAINT uq_user_warehouse UNIQUE (user_id, warehouse_id);


--
-- Name: inventory uq_warehouse_item_location; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT uq_warehouse_item_location UNIQUE (warehouse_id, item_id, location_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_token_hash_key UNIQUE (session_token_hash);


--
-- Name: user_warehouse_access user_warehouse_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access
    ADD CONSTRAINT user_warehouse_access_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouse_grid_cells warehouse_grid_cells_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_grid_cells
    ADD CONSTRAINT warehouse_grid_cells_pkey PRIMARY KEY (id);


--
-- Name: warehouse_locations warehouse_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_pkey PRIMARY KEY (id);


--
-- Name: warehouse_obstacles warehouse_obstacles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_obstacles
    ADD CONSTRAINT warehouse_obstacles_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: ix_access_log_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_access_log_timestamp ON public.access_log USING btree ("timestamp");


--
-- Name: ix_ai_recommendations_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_recommendations_created_at ON public.ai_recommendations USING btree (created_at);


--
-- Name: ix_ai_recommendations_recommendation_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_recommendations_recommendation_type ON public.ai_recommendations USING btree (recommendation_type);


--
-- Name: ix_ai_recommendations_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_recommendations_timestamp ON public.ai_recommendations USING btree ("timestamp");


--
-- Name: ix_backup_records_backup_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_backup_records_backup_id ON public.backup_records USING btree (backup_id);


--
-- Name: ix_backup_records_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_backup_records_created_at ON public.backup_records USING btree (created_at);


--
-- Name: ix_digital_twin_simulations_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_digital_twin_simulations_created_at ON public.digital_twin_simulations USING btree (created_at);


--
-- Name: ix_digital_twin_simulations_simulation_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_digital_twin_simulations_simulation_status ON public.digital_twin_simulations USING btree (simulation_status);


--
-- Name: ix_digital_twin_simulations_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_digital_twin_simulations_warehouse_id ON public.digital_twin_simulations USING btree (warehouse_id);


--
-- Name: ix_experiment_runs_experiment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_experiment_runs_experiment_id ON public.experiment_runs USING btree (experiment_id);


--
-- Name: ix_experiments_scenario_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_experiments_scenario_id ON public.experiments USING btree (scenario_id);


--
-- Name: ix_health_thresholds_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_health_thresholds_key ON public.health_thresholds USING btree (key);


--
-- Name: ix_inventory_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_item_id ON public.inventory USING btree (item_id);


--
-- Name: ix_inventory_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_location_id ON public.inventory USING btree (location_id);


--
-- Name: ix_inventory_reservations_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_reservations_created_at ON public.inventory_reservations USING btree (created_at);


--
-- Name: ix_inventory_reservations_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_reservations_item_id ON public.inventory_reservations USING btree (item_id);


--
-- Name: ix_inventory_reservations_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_reservations_location_id ON public.inventory_reservations USING btree (location_id);


--
-- Name: ix_inventory_reservations_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_reservations_order_id ON public.inventory_reservations USING btree (order_id);


--
-- Name: ix_inventory_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_warehouse_id ON public.inventory USING btree (warehouse_id);


--
-- Name: ix_items_sku; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_items_sku ON public.items USING btree (sku);


--
-- Name: ix_notification_preferences_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notification_preferences_category ON public.notification_preferences USING btree (category);


--
-- Name: ix_notification_preferences_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notification_preferences_user_id ON public.notification_preferences USING btree (user_id);


--
-- Name: ix_notifications_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_created_at ON public.notifications USING btree (created_at);


--
-- Name: ix_notifications_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_event_type ON public.notifications USING btree (event_type);


--
-- Name: ix_notifications_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_status ON public.notifications USING btree (status);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_notifications_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_warehouse_id ON public.notifications USING btree (warehouse_id);


--
-- Name: ix_order_events_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_events_order_id ON public.order_events USING btree (order_id);


--
-- Name: ix_order_events_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_events_timestamp ON public.order_events USING btree ("timestamp");


--
-- Name: ix_order_items_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_items_item_id ON public.order_items USING btree (item_id);


--
-- Name: ix_order_items_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_items_order_id ON public.order_items USING btree (order_id);


--
-- Name: ix_orders_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_created_at ON public.orders USING btree (created_at);


--
-- Name: ix_orders_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_status ON public.orders USING btree (status);


--
-- Name: ix_orders_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_warehouse_id ON public.orders USING btree (warehouse_id);


--
-- Name: ix_otp_records_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_otp_records_expires_at ON public.otp_records USING btree (expires_at);


--
-- Name: ix_otp_records_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_otp_records_user_id ON public.otp_records USING btree (user_id);


--
-- Name: ix_packing_records_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_packing_records_order_id ON public.packing_records USING btree (order_id);


--
-- Name: ix_recovery_codes_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_recovery_codes_user_id ON public.recovery_codes USING btree (user_id);


--
-- Name: ix_recovery_credentials_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_recovery_credentials_user_id ON public.recovery_credentials USING btree (user_id);


--
-- Name: ix_robot_reservations_robot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_reservations_robot_id ON public.robot_reservations USING btree (robot_id);


--
-- Name: ix_robot_reservations_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_reservations_warehouse_id ON public.robot_reservations USING btree (warehouse_id);


--
-- Name: ix_robot_routes_robot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_routes_robot_id ON public.robot_routes USING btree (robot_id);


--
-- Name: ix_robot_routes_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_routes_task_id ON public.robot_routes USING btree (task_id);


--
-- Name: ix_robot_routes_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_routes_warehouse_id ON public.robot_routes USING btree (warehouse_id);


--
-- Name: ix_robot_telemetry_robot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_telemetry_robot_id ON public.robot_telemetry USING btree (robot_id);


--
-- Name: ix_robot_telemetry_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_telemetry_timestamp ON public.robot_telemetry USING btree ("timestamp");


--
-- Name: ix_robots_assigned_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_assigned_task_id ON public.robots USING btree (assigned_task_id);


--
-- Name: ix_robots_current_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_current_location_id ON public.robots USING btree (current_location_id);


--
-- Name: ix_robots_robot_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_robots_robot_code ON public.robots USING btree (robot_code);


--
-- Name: ix_robots_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_status ON public.robots USING btree (status);


--
-- Name: ix_robots_target_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_target_location_id ON public.robots USING btree (target_location_id);


--
-- Name: ix_robots_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_warehouse_id ON public.robots USING btree (warehouse_id);


--
-- Name: ix_scenarios_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_scenarios_warehouse_id ON public.scenarios USING btree (warehouse_id);


--
-- Name: ix_shipments_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_shipments_order_id ON public.shipments USING btree (order_id);


--
-- Name: ix_simulation_events_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_event_type ON public.simulation_events USING btree (event_type);


--
-- Name: ix_simulation_events_real_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_real_timestamp ON public.simulation_events USING btree (real_timestamp);


--
-- Name: ix_simulation_events_robot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_robot_id ON public.simulation_events USING btree (robot_id);


--
-- Name: ix_simulation_events_simulation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_simulation_id ON public.simulation_events USING btree (simulation_id);


--
-- Name: ix_simulation_events_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_task_id ON public.simulation_events USING btree (task_id);


--
-- Name: ix_simulation_events_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_warehouse_id ON public.simulation_events USING btree (warehouse_id);


--
-- Name: ix_simulation_snapshots_simulation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_snapshots_simulation_id ON public.simulation_snapshots USING btree (simulation_id);


--
-- Name: ix_simulation_snapshots_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_snapshots_warehouse_id ON public.simulation_snapshots USING btree (warehouse_id);


--
-- Name: ix_stock_movements_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_date ON public.stock_movements USING btree (date);


--
-- Name: ix_stock_movements_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_item_id ON public.stock_movements USING btree (item_id);


--
-- Name: ix_stock_movements_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_warehouse_id ON public.stock_movements USING btree (warehouse_id);


--
-- Name: ix_system_health_snapshots_service; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_system_health_snapshots_service ON public.system_health_snapshots USING btree (service);


--
-- Name: ix_system_health_snapshots_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_system_health_snapshots_timestamp ON public.system_health_snapshots USING btree ("timestamp");


--
-- Name: ix_system_incidents_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_system_incidents_category ON public.system_incidents USING btree (category);


--
-- Name: ix_system_incidents_fingerprint; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_system_incidents_fingerprint ON public.system_incidents USING btree (fingerprint);


--
-- Name: ix_task_events_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_events_task_id ON public.task_events USING btree (task_id);


--
-- Name: ix_tasks_assigned_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_assigned_user_id ON public.tasks USING btree (assigned_user_id);


--
-- Name: ix_tasks_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_created_at ON public.tasks USING btree (created_at);


--
-- Name: ix_tasks_destination_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_destination_location_id ON public.tasks USING btree (destination_location_id);


--
-- Name: ix_tasks_due_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_due_at ON public.tasks USING btree (due_at);


--
-- Name: ix_tasks_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_order_id ON public.tasks USING btree (order_id);


--
-- Name: ix_tasks_order_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_order_item_id ON public.tasks USING btree (order_item_id);


--
-- Name: ix_tasks_priority_score; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_priority_score ON public.tasks USING btree (priority_score);


--
-- Name: ix_tasks_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_product_id ON public.tasks USING btree (product_id);


--
-- Name: ix_tasks_source_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_source_location_id ON public.tasks USING btree (source_location_id);


--
-- Name: ix_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_status ON public.tasks USING btree (status);


--
-- Name: ix_tasks_task_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_tasks_task_number ON public.tasks USING btree (task_number);


--
-- Name: ix_tasks_task_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_task_type ON public.tasks USING btree (task_type);


--
-- Name: ix_tasks_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_warehouse_id ON public.tasks USING btree (warehouse_id);


--
-- Name: ix_user_sessions_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_sessions_expires_at ON public.user_sessions USING btree (expires_at);


--
-- Name: ix_user_sessions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: ix_user_warehouse_access_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_warehouse_access_user_id ON public.user_warehouse_access USING btree (user_id);


--
-- Name: ix_user_warehouse_access_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_warehouse_access_warehouse_id ON public.user_warehouse_access USING btree (warehouse_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_google_subject_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_google_subject_id ON public.users USING btree (google_subject_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_warehouse_grid_cells_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_grid_cells_warehouse_id ON public.warehouse_grid_cells USING btree (warehouse_id);


--
-- Name: ix_warehouse_locations_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_locations_warehouse_id ON public.warehouse_locations USING btree (warehouse_id);


--
-- Name: ix_warehouse_obstacles_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_obstacles_warehouse_id ON public.warehouse_obstacles USING btree (warehouse_id);


--
-- Name: digital_twin_simulations digital_twin_simulations_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.digital_twin_simulations
    ADD CONSTRAINT digital_twin_simulations_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: experiment_runs experiment_runs_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_runs
    ADD CONSTRAINT experiment_runs_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiments(id) ON DELETE CASCADE;


--
-- Name: experiments experiments_scenario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT experiments_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES public.scenarios(id) ON DELETE CASCADE;


--
-- Name: inventory inventory_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: inventory inventory_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: inventory_reservations inventory_reservations_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: inventory_reservations inventory_reservations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: inventory_reservations inventory_reservations_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: inventory inventory_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: order_events order_events_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_events
    ADD CONSTRAINT order_events_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders orders_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: otp_records otp_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_records
    ADD CONSTRAINT otp_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: packing_records packing_records_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packing_records
    ADD CONSTRAINT packing_records_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: recovery_codes recovery_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: recovery_credentials recovery_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials
    ADD CONSTRAINT recovery_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: robot_reservations robot_reservations_robot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_reservations
    ADD CONSTRAINT robot_reservations_robot_id_fkey FOREIGN KEY (robot_id) REFERENCES public.robots(id) ON DELETE CASCADE;


--
-- Name: robot_reservations robot_reservations_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_reservations
    ADD CONSTRAINT robot_reservations_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: robot_routes robot_routes_robot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes
    ADD CONSTRAINT robot_routes_robot_id_fkey FOREIGN KEY (robot_id) REFERENCES public.robots(id) ON DELETE CASCADE;


--
-- Name: robot_routes robot_routes_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes
    ADD CONSTRAINT robot_routes_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: robot_routes robot_routes_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes
    ADD CONSTRAINT robot_routes_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: robot_telemetry robot_telemetry_robot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_telemetry
    ADD CONSTRAINT robot_telemetry_robot_id_fkey FOREIGN KEY (robot_id) REFERENCES public.robots(id) ON DELETE CASCADE;


--
-- Name: robots robots_assigned_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_assigned_task_id_fkey FOREIGN KEY (assigned_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: robots robots_current_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_current_location_id_fkey FOREIGN KEY (current_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: robots robots_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: robots robots_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: scenarios scenarios_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scenarios
    ADD CONSTRAINT scenarios_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: shipments shipments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: simulation_events simulation_events_simulation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_events
    ADD CONSTRAINT simulation_events_simulation_id_fkey FOREIGN KEY (simulation_id) REFERENCES public.digital_twin_simulations(id) ON DELETE CASCADE;


--
-- Name: simulation_events simulation_events_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_events
    ADD CONSTRAINT simulation_events_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: simulation_snapshots simulation_snapshots_simulation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_snapshots
    ADD CONSTRAINT simulation_snapshots_simulation_id_fkey FOREIGN KEY (simulation_id) REFERENCES public.digital_twin_simulations(id) ON DELETE CASCADE;


--
-- Name: simulation_snapshots simulation_snapshots_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_snapshots
    ADD CONSTRAINT simulation_snapshots_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id);


--
-- Name: stock_movements stock_movements_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: task_events task_events_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_events task_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_assigned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assigned_user_id_fkey FOREIGN KEY (assigned_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_depends_on_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_depends_on_task_id_fkey FOREIGN KEY (depends_on_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_destination_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_destination_location_id_fkey FOREIGN KEY (destination_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_order_item_id_fkey FOREIGN KEY (order_item_id) REFERENCES public.order_items(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_warehouse_access user_warehouse_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access
    ADD CONSTRAINT user_warehouse_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_warehouse_access user_warehouse_access_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access
    ADD CONSTRAINT user_warehouse_access_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: warehouse_grid_cells warehouse_grid_cells_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_grid_cells
    ADD CONSTRAINT warehouse_grid_cells_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: warehouse_locations warehouse_locations_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: warehouse_obstacles warehouse_obstacles_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_obstacles
    ADD CONSTRAINT warehouse_obstacles_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict xoYiS211i2qkwHTRBsT7wmLRIJ2ki80f5DpUaMb6xgtIeS8op2Q98K7FAqMRQ85

