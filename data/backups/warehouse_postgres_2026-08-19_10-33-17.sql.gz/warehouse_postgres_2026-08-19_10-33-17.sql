--
-- PostgreSQL database dump
--

\restrict lLA3ki89phpmfBQ1v1ZJpWnFfWkwTYm9Rjh5RP4fnNMbhWHbKBPcokRdnyiYflL

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_log (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    username character varying(64) NOT NULL,
    warehouse_id character varying(20),
    action character varying(50) NOT NULL,
    ip_address character varying(45)
);


ALTER TABLE public.access_log OWNER TO postgres;

--
-- Name: access_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.access_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.access_log_id_seq OWNER TO postgres;

--
-- Name: access_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.access_log_id_seq OWNED BY public.access_log.id;


--
-- Name: ai_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_recommendations (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(50),
    title character varying(100) NOT NULL,
    risk_level character varying(20),
    action_recommended character varying(100) NOT NULL,
    confidence_score integer,
    input_factors text,
    status character varying(20),
    decision_by character varying(64),
    decision_time timestamp without time zone,
    notes text,
    recommendation_type character varying(50),
    description text,
    priority character varying(20),
    score integer,
    confidence_or_reliability character varying(50),
    source_model character varying(50),
    source_entity_type character varying(50),
    source_entity_id character varying(50),
    recommended_action character varying(200),
    estimated_impact double precision,
    explanation text,
    supporting_metrics text,
    created_at timestamp without time zone NOT NULL,
    reviewed_at timestamp without time zone,
    reviewed_by character varying(64),
    review_notes text,
    expires_at timestamp without time zone,
    metadata text NOT NULL
);


ALTER TABLE public.ai_recommendations OWNER TO postgres;

--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_recommendations_id_seq OWNER TO postgres;

--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_recommendations_id_seq OWNED BY public.ai_recommendations.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: audit_ledger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_ledger (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    event_type character varying(50) NOT NULL,
    details text,
    prev_hash character varying(64) NOT NULL,
    hash character varying(64) NOT NULL
);


ALTER TABLE public.audit_ledger OWNER TO postgres;

--
-- Name: audit_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_ledger_id_seq OWNER TO postgres;

--
-- Name: audit_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_ledger_id_seq OWNED BY public.audit_ledger.id;


--
-- Name: backup_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_records (
    id integer NOT NULL,
    backup_id character varying(64) NOT NULL,
    filename character varying(255) NOT NULL,
    created_at timestamp without time zone,
    size_bytes integer,
    sha256 character varying(64),
    status character varying(20) NOT NULL,
    storage_key character varying(255),
    error_message text
);


ALTER TABLE public.backup_records OWNER TO postgres;

--
-- Name: backup_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.backup_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_records_id_seq OWNER TO postgres;

--
-- Name: backup_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.backup_records_id_seq OWNED BY public.backup_records.id;


--
-- Name: digital_twin_simulations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.digital_twin_simulations (
    id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    simulation_status character varying(20) NOT NULL,
    simulation_time_seconds double precision NOT NULL,
    speed_multiplier double precision NOT NULL,
    seed integer NOT NULL,
    mode character varying(20) NOT NULL,
    scenario_type character varying(30) NOT NULL,
    tick_count integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    started_at timestamp without time zone,
    paused_at timestamp without time zone,
    stopped_at timestamp without time zone,
    completed_at timestamp without time zone,
    error_message text,
    created_by character varying(64) NOT NULL
);


ALTER TABLE public.digital_twin_simulations OWNER TO postgres;

--
-- Name: digital_twin_simulations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.digital_twin_simulations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.digital_twin_simulations_id_seq OWNER TO postgres;

--
-- Name: digital_twin_simulations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.digital_twin_simulations_id_seq OWNED BY public.digital_twin_simulations.id;


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    location_id character varying(50),
    on_hand integer NOT NULL,
    reserved integer NOT NULL,
    available integer NOT NULL,
    damaged integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_id_seq OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_id_seq OWNED BY public.inventory.id;


--
-- Name: inventory_reservations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_reservations (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    location_id character varying(50),
    reserved_qty integer NOT NULL,
    released_qty integer NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.inventory_reservations OWNER TO postgres;

--
-- Name: inventory_reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_reservations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_reservations_id_seq OWNER TO postgres;

--
-- Name: inventory_reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_reservations_id_seq OWNED BY public.inventory_reservations.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id character varying(20) NOT NULL,
    name character varying(150) NOT NULL,
    category character varying(80),
    unit_cost double precision,
    lead_time_days integer,
    safety_stock integer,
    created_at timestamp without time zone,
    sku character varying(64),
    description text,
    unit character varying(20),
    weight_kg double precision,
    dimensions character varying(50),
    barcode character varying(64),
    is_active boolean,
    reorder_threshold integer,
    preferred_storage_type character varying(20)
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_preferences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    category character varying(50) NOT NULL,
    in_app_enabled boolean NOT NULL,
    email_enabled boolean NOT NULL,
    min_severity character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.notification_preferences OWNER TO postgres;

--
-- Name: notification_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_preferences_id_seq OWNER TO postgres;

--
-- Name: notification_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_preferences_id_seq OWNED BY public.notification_preferences.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    warehouse_id character varying(20),
    event_type character varying(50) NOT NULL,
    notification_type character varying(50) NOT NULL,
    title character varying(150) NOT NULL,
    message text NOT NULL,
    severity character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    channel character varying(20) NOT NULL,
    source_entity_type character varying(50),
    source_entity_id character varying(50),
    created_at timestamp without time zone NOT NULL,
    read_at timestamp without time zone,
    delivered_at timestamp without time zone,
    failed_at timestamp without time zone,
    retry_count integer NOT NULL,
    expires_at timestamp without time zone,
    metadata text NOT NULL,
    idempotency_key character varying(255)
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: order_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_events (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    "timestamp" timestamp without time zone,
    status character varying(30) NOT NULL,
    event_type character varying(50) NOT NULL,
    operator character varying(64),
    notes text
);


ALTER TABLE public.order_events OWNER TO postgres;

--
-- Name: order_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_events_id_seq OWNER TO postgres;

--
-- Name: order_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_events_id_seq OWNED BY public.order_events.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    requested_qty integer NOT NULL,
    reserved_qty integer NOT NULL,
    picked_qty integer NOT NULL,
    packed_qty integer NOT NULL,
    shipped_qty integer NOT NULL,
    status character varying(20) NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id character varying(20) NOT NULL,
    customer_ref character varying(100) NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    status character varying(30) NOT NULL,
    priority character varying(20) NOT NULL,
    total_items integer NOT NULL,
    notes text,
    created_by character varying(64)
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: otp_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otp_records (
    id integer NOT NULL,
    user_id integer NOT NULL,
    purpose character varying(50) NOT NULL,
    code_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    attempts integer NOT NULL,
    max_attempts integer NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    request_ip character varying(45),
    context_data text
);


ALTER TABLE public.otp_records OWNER TO postgres;

--
-- Name: otp_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.otp_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.otp_records_id_seq OWNER TO postgres;

--
-- Name: otp_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.otp_records_id_seq OWNED BY public.otp_records.id;


--
-- Name: packing_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.packing_records (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    operator character varying(64),
    package_count integer NOT NULL,
    weight_kg double precision,
    notes text
);


ALTER TABLE public.packing_records OWNER TO postgres;

--
-- Name: packing_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.packing_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.packing_records_id_seq OWNER TO postgres;

--
-- Name: packing_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.packing_records_id_seq OWNED BY public.packing_records.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id integer CONSTRAINT picking_tasks_id_not_null NOT NULL,
    order_id character varying(20),
    order_item_id integer,
    product_id character varying(20) CONSTRAINT picking_tasks_item_id_not_null NOT NULL,
    source_location_id character varying(50),
    requested_quantity integer CONSTRAINT picking_tasks_qty_not_null NOT NULL,
    completed_quantity integer CONSTRAINT picking_tasks_picked_qty_not_null NOT NULL,
    status character varying(30) CONSTRAINT picking_tasks_status_not_null NOT NULL,
    created_at timestamp without time zone,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    notes text,
    task_number character varying(64) NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    task_type character varying(30) NOT NULL,
    priority character varying(20) NOT NULL,
    priority_score integer NOT NULL,
    source_type character varying(30),
    source_id character varying(64),
    destination_location_id character varying(50),
    assigned_user_id integer,
    assigned_robot_id character varying(50),
    prioritized_at timestamp without time zone,
    assigned_at timestamp without time zone,
    paused_at timestamp without time zone,
    failed_at timestamp without time zone,
    cancelled_at timestamp without time zone,
    due_at timestamp without time zone,
    retry_count integer NOT NULL,
    failure_reason text,
    metadata text NOT NULL,
    depends_on_task_id integer
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: picking_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.picking_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.picking_tasks_id_seq OWNER TO postgres;

--
-- Name: picking_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.picking_tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: recovery_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recovery_codes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code_hash character varying(255) NOT NULL,
    used boolean NOT NULL,
    created_at timestamp without time zone,
    used_at timestamp without time zone
);


ALTER TABLE public.recovery_codes OWNER TO postgres;

--
-- Name: recovery_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recovery_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recovery_codes_id_seq OWNER TO postgres;

--
-- Name: recovery_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recovery_codes_id_seq OWNED BY public.recovery_codes.id;


--
-- Name: recovery_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recovery_credentials (
    id integer NOT NULL,
    user_id integer NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.recovery_credentials OWNER TO postgres;

--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recovery_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recovery_credentials_id_seq OWNER TO postgres;

--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recovery_credentials_id_seq OWNED BY public.recovery_credentials.id;


--
-- Name: robot_reservations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robot_reservations (
    id integer NOT NULL,
    robot_id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    tick integer NOT NULL
);


ALTER TABLE public.robot_reservations OWNER TO postgres;

--
-- Name: robot_reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.robot_reservations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.robot_reservations_id_seq OWNER TO postgres;

--
-- Name: robot_reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.robot_reservations_id_seq OWNED BY public.robot_reservations.id;


--
-- Name: robot_routes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robot_routes (
    id integer NOT NULL,
    robot_id integer NOT NULL,
    task_id integer,
    warehouse_id character varying(20) NOT NULL,
    start_x integer NOT NULL,
    start_y integer NOT NULL,
    goal_x integer NOT NULL,
    goal_y integer NOT NULL,
    algorithm character varying(30) NOT NULL,
    path_data text NOT NULL,
    distance double precision NOT NULL,
    cost double precision NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    completed_at timestamp without time zone
);


ALTER TABLE public.robot_routes OWNER TO postgres;

--
-- Name: robot_routes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.robot_routes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.robot_routes_id_seq OWNER TO postgres;

--
-- Name: robot_routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.robot_routes_id_seq OWNED BY public.robot_routes.id;


--
-- Name: robot_telemetry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robot_telemetry (
    id integer NOT NULL,
    robot_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    x double precision NOT NULL,
    y double precision NOT NULL,
    battery double precision NOT NULL,
    status character varying(30) NOT NULL,
    task_id integer,
    metadata text NOT NULL
);


ALTER TABLE public.robot_telemetry OWNER TO postgres;

--
-- Name: robot_telemetry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.robot_telemetry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.robot_telemetry_id_seq OWNER TO postgres;

--
-- Name: robot_telemetry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.robot_telemetry_id_seq OWNED BY public.robot_telemetry.id;


--
-- Name: robots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robots (
    id integer NOT NULL,
    robot_code character varying(30) NOT NULL,
    name character varying(100) NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    status character varying(30) NOT NULL,
    battery_level double precision NOT NULL,
    current_location_id character varying(50),
    current_x double precision NOT NULL,
    current_y double precision NOT NULL,
    target_location_id character varying(50),
    target_x double precision NOT NULL,
    target_y double precision NOT NULL,
    assigned_task_id integer,
    total_tasks_completed integer NOT NULL,
    total_distance double precision NOT NULL,
    total_operating_time double precision NOT NULL,
    utilization_percent double precision NOT NULL,
    failure_count integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    last_heartbeat_at timestamp without time zone NOT NULL,
    robot_type character varying(30) NOT NULL,
    max_payload double precision NOT NULL,
    max_speed double precision NOT NULL,
    enabled boolean NOT NULL,
    metadata text NOT NULL
);


ALTER TABLE public.robots OWNER TO postgres;

--
-- Name: robots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.robots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.robots_id_seq OWNER TO postgres;

--
-- Name: robots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.robots_id_seq OWNED BY public.robots.id;


--
-- Name: shipments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipments (
    id character varying(20) NOT NULL,
    order_id character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    tracking_reference character varying(100),
    carrier character varying(50),
    created_at timestamp without time zone,
    shipped_at timestamp without time zone,
    delivered_at timestamp without time zone
);


ALTER TABLE public.shipments OWNER TO postgres;

--
-- Name: shrinkage_flags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shrinkage_flags (
    id integer NOT NULL,
    date date NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    item_name character varying(150),
    deviation_score double precision,
    expected_quantity double precision,
    actual_quantity double precision,
    discrepancy_quantity double precision,
    estimated_exposure double precision,
    severity character varying(20),
    likely_cause character varying(80),
    explanation text
);


ALTER TABLE public.shrinkage_flags OWNER TO postgres;

--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shrinkage_flags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shrinkage_flags_id_seq OWNER TO postgres;

--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shrinkage_flags_id_seq OWNED BY public.shrinkage_flags.id;


--
-- Name: simulation_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.simulation_events (
    id integer NOT NULL,
    simulation_id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    event_type character varying(50) NOT NULL,
    severity character varying(10) NOT NULL,
    sim_time_seconds double precision NOT NULL,
    real_timestamp timestamp without time zone NOT NULL,
    robot_id integer,
    task_id integer,
    location_id character varying(50),
    route_id integer,
    message text NOT NULL,
    metadata text NOT NULL
);


ALTER TABLE public.simulation_events OWNER TO postgres;

--
-- Name: simulation_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.simulation_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.simulation_events_id_seq OWNER TO postgres;

--
-- Name: simulation_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.simulation_events_id_seq OWNED BY public.simulation_events.id;


--
-- Name: simulation_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.simulation_snapshots (
    id integer NOT NULL,
    simulation_id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    snapshot_version integer NOT NULL,
    taken_at timestamp without time zone NOT NULL,
    sim_time_seconds double precision NOT NULL,
    robot_states text NOT NULL,
    task_states text NOT NULL,
    obstacle_states text NOT NULL,
    sim_inventory_delta text NOT NULL,
    metadata text NOT NULL
);


ALTER TABLE public.simulation_snapshots OWNER TO postgres;

--
-- Name: simulation_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.simulation_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.simulation_snapshots_id_seq OWNER TO postgres;

--
-- Name: simulation_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.simulation_snapshots_id_seq OWNED BY public.simulation_snapshots.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    date date NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    stock_in integer,
    stock_out integer,
    closing_stock integer,
    is_anomaly boolean,
    anomaly_type character varying(30),
    entry_source character varying(20),
    entered_by character varying(64)
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_movements_id_seq OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: task_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_events (
    id integer NOT NULL,
    task_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    previous_status character varying(30),
    new_status character varying(30),
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    reason text,
    metadata text NOT NULL
);


ALTER TABLE public.task_events OWNER TO postgres;

--
-- Name: task_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_events_id_seq OWNER TO postgres;

--
-- Name: task_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_events_id_seq OWNED BY public.task_events.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    session_token_hash character varying(64) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    last_seen_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    revoked_at timestamp without time zone,
    revoke_reason character varying(100),
    login_method character varying(30),
    ip_address character varying(45),
    login_location character varying(255),
    user_agent character varying(500)
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_sessions_id_seq OWNER TO postgres;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: user_warehouse_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_warehouse_access (
    id integer NOT NULL,
    user_id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_warehouse_access OWNER TO postgres;

--
-- Name: user_warehouse_access_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_warehouse_access_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_warehouse_access_id_seq OWNER TO postgres;

--
-- Name: user_warehouse_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_warehouse_access_id_seq OWNED BY public.user_warehouse_access.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    full_name character varying(120),
    google_subject_id character varying(128),
    created_at timestamp without time zone,
    email character varying(255),
    is_active boolean NOT NULL,
    is_verified boolean NOT NULL,
    last_login_at timestamp without time zone,
    last_logout_at timestamp without time zone,
    last_login_ip character varying(45),
    login_location character varying(255),
    login_method character varying(30),
    failed_login_count integer NOT NULL,
    locked_until timestamp without time zone,
    email_verified_at timestamp without time zone,
    password_changed_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: warehouse_grid_cells; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_grid_cells (
    id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    cell_type character varying(30) NOT NULL,
    traversable boolean NOT NULL,
    occupied boolean NOT NULL,
    restricted boolean NOT NULL,
    cost double precision NOT NULL,
    metadata text NOT NULL
);


ALTER TABLE public.warehouse_grid_cells OWNER TO postgres;

--
-- Name: warehouse_grid_cells_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.warehouse_grid_cells_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.warehouse_grid_cells_id_seq OWNER TO postgres;

--
-- Name: warehouse_grid_cells_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.warehouse_grid_cells_id_seq OWNED BY public.warehouse_grid_cells.id;


--
-- Name: warehouse_locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_locations (
    id character varying(50) NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    zone character varying(20) NOT NULL,
    aisle character varying(20) NOT NULL,
    rack character varying(20) NOT NULL,
    shelf character varying(20) NOT NULL,
    x double precision,
    y double precision,
    capacity integer,
    current_utilization integer,
    location_type character varying(20),
    status character varying(20),
    created_at timestamp without time zone
);


ALTER TABLE public.warehouse_locations OWNER TO postgres;

--
-- Name: warehouse_obstacles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_obstacles (
    id integer NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    obstacle_type character varying(30) NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    active boolean NOT NULL,
    severity character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.warehouse_obstacles OWNER TO postgres;

--
-- Name: warehouse_obstacles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.warehouse_obstacles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.warehouse_obstacles_id_seq OWNER TO postgres;

--
-- Name: warehouse_obstacles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.warehouse_obstacles_id_seq OWNED BY public.warehouse_obstacles.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouses (
    id character varying(20) NOT NULL,
    name character varying(120) NOT NULL,
    location character varying(120),
    latitude double precision,
    longitude double precision,
    created_at timestamp without time zone
);


ALTER TABLE public.warehouses OWNER TO postgres;

--
-- Name: access_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log ALTER COLUMN id SET DEFAULT nextval('public.access_log_id_seq'::regclass);


--
-- Name: ai_recommendations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_recommendations ALTER COLUMN id SET DEFAULT nextval('public.ai_recommendations_id_seq'::regclass);


--
-- Name: audit_ledger id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_ledger ALTER COLUMN id SET DEFAULT nextval('public.audit_ledger_id_seq'::regclass);


--
-- Name: backup_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_records ALTER COLUMN id SET DEFAULT nextval('public.backup_records_id_seq'::regclass);


--
-- Name: digital_twin_simulations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.digital_twin_simulations ALTER COLUMN id SET DEFAULT nextval('public.digital_twin_simulations_id_seq'::regclass);


--
-- Name: inventory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory ALTER COLUMN id SET DEFAULT nextval('public.inventory_id_seq'::regclass);


--
-- Name: inventory_reservations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations ALTER COLUMN id SET DEFAULT nextval('public.inventory_reservations_id_seq'::regclass);


--
-- Name: notification_preferences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences ALTER COLUMN id SET DEFAULT nextval('public.notification_preferences_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: order_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_events ALTER COLUMN id SET DEFAULT nextval('public.order_events_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: otp_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_records ALTER COLUMN id SET DEFAULT nextval('public.otp_records_id_seq'::regclass);


--
-- Name: packing_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packing_records ALTER COLUMN id SET DEFAULT nextval('public.packing_records_id_seq'::regclass);


--
-- Name: recovery_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes ALTER COLUMN id SET DEFAULT nextval('public.recovery_codes_id_seq'::regclass);


--
-- Name: recovery_credentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials ALTER COLUMN id SET DEFAULT nextval('public.recovery_credentials_id_seq'::regclass);


--
-- Name: robot_reservations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_reservations ALTER COLUMN id SET DEFAULT nextval('public.robot_reservations_id_seq'::regclass);


--
-- Name: robot_routes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes ALTER COLUMN id SET DEFAULT nextval('public.robot_routes_id_seq'::regclass);


--
-- Name: robot_telemetry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_telemetry ALTER COLUMN id SET DEFAULT nextval('public.robot_telemetry_id_seq'::regclass);


--
-- Name: robots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots ALTER COLUMN id SET DEFAULT nextval('public.robots_id_seq'::regclass);


--
-- Name: shrinkage_flags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shrinkage_flags ALTER COLUMN id SET DEFAULT nextval('public.shrinkage_flags_id_seq'::regclass);


--
-- Name: simulation_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_events ALTER COLUMN id SET DEFAULT nextval('public.simulation_events_id_seq'::regclass);


--
-- Name: simulation_snapshots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_snapshots ALTER COLUMN id SET DEFAULT nextval('public.simulation_snapshots_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: task_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_events ALTER COLUMN id SET DEFAULT nextval('public.task_events_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.picking_tasks_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: user_warehouse_access id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access ALTER COLUMN id SET DEFAULT nextval('public.user_warehouse_access_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: warehouse_grid_cells id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_grid_cells ALTER COLUMN id SET DEFAULT nextval('public.warehouse_grid_cells_id_seq'::regclass);


--
-- Name: warehouse_obstacles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_obstacles ALTER COLUMN id SET DEFAULT nextval('public.warehouse_obstacles_id_seq'::regclass);


--
-- Data for Name: access_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access_log (id, "timestamp", username, warehouse_id, action, ip_address) FROM stdin;
260	2026-08-19 10:29:02.326063	admin		login	testclient
262	2026-08-19 10:29:51.894934	admin		login	testclient
227	2026-08-16 17:26:20.911102	admin	WH-DEL-01	view	192.168.1.57
228	2026-08-16 12:48:20.911102	admin		login	192.168.1.99
229	2026-08-18 23:15:20.911102	admin	WH-CHN-01	view	192.168.1.148
230	2026-08-16 09:26:20.911102	admin	WH-DEL-01	view	192.168.1.145
231	2026-08-19 00:03:20.911102	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.131
232	2026-08-15 22:57:20.912103	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.69
233	2026-08-17 07:35:20.912103	harsha200797@gmail.com	WH-BOM-01	add_stock	192.168.1.175
234	2026-08-19 03:52:20.912103	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.187
235	2026-08-17 15:02:20.912103	admin		login	192.168.1.34
236	2026-08-17 02:30:20.912103	harsha200797@gmail.com		login	192.168.1.93
237	2026-08-16 01:56:20.912103	admin	WH-BLR-01	add_stock	192.168.1.69
238	2026-08-16 00:40:20.912103	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.43
239	2026-08-16 05:09:20.912103	admin	WH-DEL-01	view	192.168.1.157
240	2026-08-18 21:57:20.912103	admin	WH-CHN-01	view	192.168.1.231
241	2026-08-16 12:14:20.912103	admin	WH-DEL-01	view	192.168.1.250
242	2026-08-18 20:28:20.912103	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.191
243	2026-08-16 00:16:20.912103	harsha200797@gmail.com		login	192.168.1.38
244	2026-08-16 16:59:20.912103	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.92
245	2026-08-16 07:44:20.912103	admin	WH-BLR-01	view	192.168.1.41
246	2026-08-17 06:27:20.912103	harsha200797@gmail.com	WH-DEL-01	view	192.168.1.84
247	2026-08-16 13:58:20.912103	harsha200797@gmail.com	WH-CCU-01	add_stock	192.168.1.117
248	2026-08-18 04:45:20.912103	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.49
249	2026-08-17 11:34:20.912103	admin	WH-BOM-01	view	192.168.1.10
250	2026-08-19 07:58:20.912103	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.151
251	2026-08-17 18:32:20.912103	admin	WH-CCU-01	view	192.168.1.154
252	2026-08-16 00:22:20.912103	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.192
253	2026-08-18 03:51:20.912103	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.174
254	2026-08-19 06:06:20.912103	admin	WH-CCU-01	view	192.168.1.228
255	2026-08-16 12:54:20.912103	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.69
256	2026-08-16 01:38:20.912103	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.54
257	2026-08-18 18:51:20.912103	admin	WH-CCU-01	view	192.168.1.231
258	2026-08-18 16:06:20.912103	harsha200797@gmail.com		login	192.168.1.148
259	2026-08-18 17:09:20.912103	harsha200797@gmail.com	WH-CHN-01	add_stock	192.168.1.27
261	2026-08-19 10:29:28.965697	admin		login	testclient
263	2026-08-19 10:30:06.219313	admin		request_admin_creation	testclient
210	2026-08-17 13:06:20.910108	admin	WH-CHN-01	view	192.168.1.221
211	2026-08-16 12:48:20.910108	harsha200797@gmail.com	WH-DEL-01	view	192.168.1.216
212	2026-08-18 03:24:20.910108	admin	WH-CHN-01	view	192.168.1.54
213	2026-08-19 02:10:20.910108	harsha200797@gmail.com	WH-DEL-01	view	192.168.1.251
214	2026-08-16 16:45:20.910108	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.45
215	2026-08-17 22:06:20.910108	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.59
216	2026-08-15 23:41:20.910108	admin		login	192.168.1.10
217	2026-08-19 05:37:20.910108	admin	WH-DEL-01	add_stock	192.168.1.181
218	2026-08-16 09:28:20.910108	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.174
219	2026-08-16 10:25:20.910108	admin	WH-BLR-01	view	192.168.1.247
220	2026-08-19 05:33:20.910108	admin	WH-DEL-01	view	192.168.1.154
221	2026-08-16 04:09:20.910108	harsha200797@gmail.com		login	192.168.1.164
222	2026-08-18 01:35:20.911102	admin	WH-CHN-01	add_stock	192.168.1.110
223	2026-08-19 02:06:20.911102	harsha200797@gmail.com	WH-CHN-01	add_stock	192.168.1.247
224	2026-08-18 04:51:20.911102	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.215
225	2026-08-18 08:31:20.911102	harsha200797@gmail.com		login	192.168.1.42
226	2026-08-16 21:58:20.911102	admin	WH-BOM-01	view	192.168.1.218
\.


--
-- Data for Name: ai_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_recommendations (id, "timestamp", warehouse_id, item_id, title, risk_level, action_recommended, confidence_score, input_factors, status, decision_by, decision_time, notes, recommendation_type, description, priority, score, confidence_or_reliability, source_model, source_entity_type, source_entity_id, recommended_action, estimated_impact, explanation, supporting_metrics, created_at, reviewed_at, reviewed_by, review_notes, expires_at, metadata) FROM stdin;
36	2026-08-19 10:29:52.165621	WH-CCU-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	40	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 22.0 units, but recorded stock is 22.0 units, leading to a discrepancy of +0.0 units.	LOW	40	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 22.0, "actual": 22.0, "evidence": ["Expected closing stock: 22.0 units (Opening + In - Out)", "Recorded closing stock: 22.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
82	2026-08-18 19:45:18.637654	WH-BLR-01	ITM-RAM-01	Replenishment Recommended: Corsair DDR5 32GB 6000MHz RAM	MEDIUM	Replenish 75 units.	45	{}	EXECUTED		\N		REPLENISHMENT	Projected lead demand (29.2 units) and safety stock (25 units) exceeds available stock (54 units).	MEDIUM	50	MEDIUM	Weekday Seasonality Regression	Item	ITM-RAM-01	Replenish 75 units.	1700	Outbound demand forecast (29.2 units) indicates available stock (54 units) will deplete below safety stock target (25 units) within lead time of 4 days. WAPE forecast reliability stands at 45%.	{"current_stock": 54, "lead_demand": 29.2, "safety_stock": 25, "reorder_point": 54.2, "shortage_qty": 0.2, "unit_cost": 8500.0, "wape": 86.5, "evidence": ["Current closing stock: 54 units (ACTUAL \\u2014 MySQL)", "Safety stock threshold: 25 units", "Forecasted 4-day lead demand: 29.2 units (FORECAST \\u2014 ML MODEL)", "Reorder point threshold: 54.2 units"]}	2026-08-18 19:45:18.637654	2026-08-18 19:46:02.09101	admin	Approved via AI Decision Center	\N	{}
67	2026-08-19 10:29:52.165621	WH-BOM-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 15.0 units, but recorded stock is 15.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 15.0, "actual": 15.0, "evidence": ["Expected closing stock: 15.0 units (Opening + In - Out)", "Recorded closing stock: 15.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
1	2026-08-14 11:40:57.885343	WH-BLR-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01	MEDIUM	APPROVED	85	{}	NEW	harsha200797@gmail.com	2026-08-14 11:40:57.88252	Approved via AI Decision Center	\N	\N	MEDIUM	0	HIGH	\N	\N	\N	\N	\N	\N	{}	2026-08-14 11:40:57.885343	\N	\N	\N	\N	{}
2	2026-08-14 11:41:03.619137	WH-BLR-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01	MEDIUM	APPROVED	85	{}	NEW	harsha200797@gmail.com	2026-08-14 11:41:03.618171	Approved via AI Decision Center	\N	\N	MEDIUM	0	HIGH	\N	\N	\N	\N	\N	\N	{}	2026-08-14 11:41:03.619137	\N	\N	\N	\N	{}
3	2026-08-14 11:41:15.400552	WH-BLR-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01	MEDIUM	REJECTED	85	{}	NEW	harsha200797@gmail.com	2026-08-14 11:41:15.399727	Rejected via AI Decision Center	\N	\N	MEDIUM	0	HIGH	\N	\N	\N	\N	\N	\N	{}	2026-08-14 11:41:15.400552	\N	\N	\N	\N	{}
4	2026-08-15 15:57:11.312692	WH-BLR-01	ITM-CPU-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CPU-01	MEDIUM	APPROVED	85	{}	NEW	harsha200797@gmail.com	2026-08-15 15:57:11.309061	Approved via AI Decision Center	\N	\N	MEDIUM	0	HIGH	\N	\N	\N	\N	\N	\N	{}	2026-08-15 15:57:11.312692	\N	\N	\N	\N	{}
11	2026-08-18 19:42:01.879288	WH-BLR-01	ITM-RAM-01	Replenishment Recommended: Corsair DDR5 32GB 6000MHz RAM	MEDIUM	Replenish 75 units.	45	{}	EXECUTED		\N		REPLENISHMENT	Projected lead demand (29.2 units) and safety stock (25 units) exceeds available stock (54 units).	MEDIUM	50	MEDIUM	Weekday Seasonality Regression	Item	ITM-RAM-01	Replenish 75 units.	1700	Outbound demand forecast (29.2 units) indicates available stock (54 units) will deplete below safety stock target (25 units) within lead time of 4 days. WAPE forecast reliability stands at 45%.	{"current_stock": 54, "lead_demand": 29.2, "safety_stock": 25, "reorder_point": 54.2, "shortage_qty": 0.2, "unit_cost": 8500.0, "wape": 86.5, "evidence": ["Current closing stock: 54 units (ACTUAL \\u2014 MySQL)", "Safety stock threshold: 25 units", "Forecasted 4-day lead demand: 29.2 units (FORECAST \\u2014 ML MODEL)", "Reorder point threshold: 54.2 units"]}	2026-08-18 18:53:33.726384	2026-08-18 19:45:13.308181	admin	Approved via AI Decision Center	\N	{}
83	2026-08-19 07:12:33.284306	WH-BLR-01	ITM-RAM-01	Replenishment Recommended: Corsair DDR5 32GB 6000MHz RAM	MEDIUM	Replenish 75 units.	45	{}	EXECUTED		\N		REPLENISHMENT	Projected lead demand (29.2 units) and safety stock (25 units) exceeds available stock (54 units).	MEDIUM	50	MEDIUM	Weekday Seasonality Regression	Item	ITM-RAM-01	Replenish 75 units.	1700	Outbound demand forecast (29.2 units) indicates available stock (54 units) will deplete below safety stock target (25 units) within lead time of 4 days. WAPE forecast reliability stands at 45%.	{"current_stock": 54, "lead_demand": 29.2, "safety_stock": 25, "reorder_point": 54.2, "shortage_qty": 0.2, "unit_cost": 8500.0, "wape": 86.5, "evidence": ["Current closing stock: 54 units (ACTUAL \\u2014 MySQL)", "Safety stock threshold: 25 units", "Forecasted 4-day lead demand: 29.2 units (FORECAST \\u2014 ML MODEL)", "Reorder point threshold: 54.2 units"]}	2026-08-18 19:46:06.74977	2026-08-19 07:13:02.185604	harsha200797@gmail.com	Approved via AI Decision Center	\N	{}
24	2026-08-19 10:29:52.165621	WH-DEL-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	43	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 297.0 units, but recorded stock is 297.0 units, leading to a discrepancy of +0.0 units.	LOW	43	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 297.0, "actual": 297.0, "evidence": ["Expected closing stock: 297.0 units (Opening + In - Out)", "Recorded closing stock: 297.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
64	2026-08-19 10:29:52.165621	WH-BLR-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	HIGH	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 38.0 units, but recorded stock is 38.0 units, leading to a discrepancy of +0.0 units.	HIGH	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 38.0, "actual": 38.0, "evidence": ["Expected closing stock: 38.0 units (Opening + In - Out)", "Recorded closing stock: 38.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
84	2026-08-19 10:29:52.165621	WH-BLR-01	ITM-RAM-01	Replenishment Recommended: Corsair DDR5 32GB 6000MHz RAM	MEDIUM	Replenish 75 units.	45	{}	NEW		\N		REPLENISHMENT	Projected lead demand (22.8 units) and safety stock (25 units) exceeds available stock (42 units).	MEDIUM	57	MEDIUM	Weekday Seasonality Regression	Item	ITM-RAM-01	Replenish 75 units.	49300	Outbound demand forecast (22.8 units) indicates available stock (42 units) will deplete below safety stock target (25 units) within lead time of 4 days. WAPE forecast reliability stands at 45%.	{"current_stock": 42, "lead_demand": 22.8, "safety_stock": 25, "reorder_point": 47.8, "shortage_qty": 5.8, "unit_cost": 8500.0, "wape": 36.7, "evidence": ["Current closing stock: 42 units (ACTUAL \\u2014 MySQL)", "Safety stock threshold: 25 units", "Forecasted 4-day lead demand: 22.8 units (FORECAST \\u2014 ML MODEL)", "Reorder point threshold: 47.8 units"]}	2026-08-19 07:13:02.343672	\N	\N	\N	\N	{}
30	2026-08-19 10:29:52.165621	WH-CCU-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	41	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 290.0 units, but recorded stock is 290.0 units, leading to a discrepancy of +0.0 units.	LOW	41	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 290.0, "actual": 290.0, "evidence": ["Expected closing stock: 290.0 units (Opening + In - Out)", "Recorded closing stock: 290.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
48	2026-08-19 10:29:52.165621	WH-CCU-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	38	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 72.0 units, but recorded stock is 72.0 units, leading to a discrepancy of +0.0 units.	LOW	38	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 40/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 72.0, "actual": 72.0, "evidence": ["Expected closing stock: 72.0 units (Opening + In - Out)", "Recorded closing stock: 72.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 40/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
49	2026-08-19 10:29:52.165621	WH-CCU-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	38	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 59.0 units, but recorded stock is 59.0 units, leading to a discrepancy of +0.0 units.	LOW	38	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 59.0, "actual": 59.0, "evidence": ["Expected closing stock: 59.0 units (Opening + In - Out)", "Recorded closing stock: 59.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
15	2026-08-19 10:29:52.165621	WH-DEL-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	49	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 64.0 units, but recorded stock is 64.0 units, leading to a discrepancy of +0.0 units.	LOW	49	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 64.0, "actual": 64.0, "evidence": ["Expected closing stock: 64.0 units (Opening + In - Out)", "Recorded closing stock: 64.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
26	2026-08-19 10:29:52.165621	WH-BLR-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	42	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 44.0 units, but recorded stock is 44.0 units, leading to a discrepancy of +0.0 units.	LOW	42	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 44.0, "actual": 44.0, "evidence": ["Expected closing stock: 44.0 units (Opening + In - Out)", "Recorded closing stock: 44.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
34	2026-08-19 10:29:52.165621	WH-CHN-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	41	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 28.0 units, but recorded stock is 13.0 units, leading to a discrepancy of -15.0 units.	LOW	41	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	570000	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": -15.0, "expected": 28.0, "actual": 13.0, "evidence": ["Expected closing stock: 28.0 units (Opening + In - Out)", "Recorded closing stock: 13.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: -15.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b9570,000.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
71	2026-08-18 19:00:07.846699	WH-CCU-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 37.0 units, but recorded stock is 37.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 37.0, "actual": 37.0, "evidence": ["Expected closing stock: 37.0 units (Opening + In - Out)", "Recorded closing stock: 37.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
19	2026-08-19 10:29:52.165621	WH-DEL-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	46	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 76.0 units, but recorded stock is 76.0 units, leading to a discrepancy of +0.0 units.	LOW	46	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 76.0, "actual": 76.0, "evidence": ["Expected closing stock: 76.0 units (Opening + In - Out)", "Recorded closing stock: 76.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
28	2026-08-19 10:29:52.165621	WH-BLR-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	41	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 437.0 units, but recorded stock is 437.0 units, leading to a discrepancy of +0.0 units.	LOW	41	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 42/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 437.0, "actual": 437.0, "evidence": ["Expected closing stock: 437.0 units (Opening + In - Out)", "Recorded closing stock: 437.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 42/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
16	2026-08-19 10:29:52.165621	WH-BLR-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	48	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 70.0 units, but recorded stock is 70.0 units, leading to a discrepancy of +0.0 units.	LOW	48	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 70.0, "actual": 70.0, "evidence": ["Expected closing stock: 70.0 units (Opening + In - Out)", "Recorded closing stock: 70.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
18	2026-08-19 10:29:52.165621	WH-BOM-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	46	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 86.0 units, but recorded stock is 86.0 units, leading to a discrepancy of +0.0 units.	LOW	46	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 86.0, "actual": 86.0, "evidence": ["Expected closing stock: 86.0 units (Opening + In - Out)", "Recorded closing stock: 86.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
73	2026-08-19 10:29:52.165621	WH-DEL-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 25.0 units, but recorded stock is 25.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 25.0, "actual": 25.0, "evidence": ["Expected closing stock: 25.0 units (Opening + In - Out)", "Recorded closing stock: 25.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
75	2026-08-18 19:00:07.846699	WH-DEL-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 87.0 units, but recorded stock is 87.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 87.0, "actual": 87.0, "evidence": ["Expected closing stock: 87.0 units (Opening + In - Out)", "Recorded closing stock: 87.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
81	2026-08-18 19:00:07.846699	WH-DEL-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 66.0 units, but recorded stock is 66.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 66.0, "actual": 66.0, "evidence": ["Expected closing stock: 66.0 units (Opening + In - Out)", "Recorded closing stock: 66.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
35	2026-08-19 10:29:52.165621	WH-DEL-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	41	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 33.0 units, but recorded stock is 33.0 units, leading to a discrepancy of +0.0 units.	LOW	41	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 33.0, "actual": 33.0, "evidence": ["Expected closing stock: 33.0 units (Opening + In - Out)", "Recorded closing stock: 33.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
29	2026-08-19 10:29:52.165621	WH-BOM-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	41	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 101.0 units, but recorded stock is 101.0 units, leading to a discrepancy of +0.0 units.	LOW	41	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 101.0, "actual": 101.0, "evidence": ["Expected closing stock: 101.0 units (Opening + In - Out)", "Recorded closing stock: 101.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
58	2026-08-18 19:00:07.846699	WH-CHN-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	HIGH	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 35.0 units, but recorded stock is 20.0 units, leading to a discrepancy of -15.0 units.	HIGH	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	570000	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": -15.0, "expected": 35.0, "actual": 20.0, "evidence": ["Expected closing stock: 35.0 units (Opening + In - Out)", "Recorded closing stock: 20.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: -15.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b9570,000.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
50	2026-08-19 10:29:52.165621	WH-CHN-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	38	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 15.0 units, but recorded stock is 15.0 units, leading to a discrepancy of +0.0 units.	LOW	38	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 15.0, "actual": 15.0, "evidence": ["Expected closing stock: 15.0 units (Opening + In - Out)", "Recorded closing stock: 15.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
13	2026-08-19 10:29:52.165621	WH-BLR-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	49	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 104.0 units, but recorded stock is 104.0 units, leading to a discrepancy of +0.0 units.	LOW	49	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 104.0, "actual": 104.0, "evidence": ["Expected closing stock: 104.0 units (Opening + In - Out)", "Recorded closing stock: 104.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
14	2026-08-19 10:29:52.165621	WH-DEL-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	49	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 120.0 units, but recorded stock is 120.0 units, leading to a discrepancy of +0.0 units.	LOW	49	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 120.0, "actual": 120.0, "evidence": ["Expected closing stock: 120.0 units (Opening + In - Out)", "Recorded closing stock: 120.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
37	2026-08-19 10:29:52.165621	WH-CCU-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	40	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 29.0 units, but recorded stock is 29.0 units, leading to a discrepancy of +0.0 units.	LOW	40	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 29.0, "actual": 29.0, "evidence": ["Expected closing stock: 29.0 units (Opening + In - Out)", "Recorded closing stock: 29.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
21	2026-08-19 10:29:52.165621	WH-BOM-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	45	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 171.0 units, but recorded stock is 171.0 units, leading to a discrepancy of +0.0 units.	LOW	45	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 171.0, "actual": 171.0, "evidence": ["Expected closing stock: 171.0 units (Opening + In - Out)", "Recorded closing stock: 171.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
60	2026-08-19 10:29:52.165621	WH-CHN-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 68.0 units, but recorded stock is 68.0 units, leading to a discrepancy of +0.0 units.	LOW	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 68.0, "actual": 68.0, "evidence": ["Expected closing stock: 68.0 units (Opening + In - Out)", "Recorded closing stock: 68.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
17	2026-08-18 18:54:21.375144	WH-DEL-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	48	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 299.0 units, but recorded stock is 299.0 units, leading to a discrepancy of +0.0 units.	LOW	48	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 43/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 299.0, "actual": 299.0, "evidence": ["Expected closing stock: 299.0 units (Opening + In - Out)", "Recorded closing stock: 299.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 43/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
23	2026-08-19 10:29:52.165621	WH-CHN-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	44	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 58.0 units, but recorded stock is 58.0 units, leading to a discrepancy of +0.0 units.	LOW	44	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 58.0, "actual": 58.0, "evidence": ["Expected closing stock: 58.0 units (Opening + In - Out)", "Recorded closing stock: 58.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
27	2026-08-18 18:54:21.375144	WH-CCU-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	42	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 291.0 units, but recorded stock is 291.0 units, leading to a discrepancy of +0.0 units.	LOW	42	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 41/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 291.0, "actual": 291.0, "evidence": ["Expected closing stock: 291.0 units (Opening + In - Out)", "Recorded closing stock: 291.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 41/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
31	2026-08-19 10:29:52.165621	WH-CCU-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	41	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 87.0 units, but recorded stock is 87.0 units, leading to a discrepancy of +0.0 units.	LOW	41	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 87.0, "actual": 87.0, "evidence": ["Expected closing stock: 87.0 units (Opening + In - Out)", "Recorded closing stock: 87.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
32	2026-08-19 10:29:52.165621	WH-CHN-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	41	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 297.0 units, but recorded stock is 297.0 units, leading to a discrepancy of +0.0 units.	LOW	41	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 297.0, "actual": 297.0, "evidence": ["Expected closing stock: 297.0 units (Opening + In - Out)", "Recorded closing stock: 297.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
42	2026-08-19 10:29:52.165621	WH-BOM-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	39	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 81.0 units, but recorded stock is 81.0 units, leading to a discrepancy of +0.0 units.	LOW	39	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 81.0, "actual": 81.0, "evidence": ["Expected closing stock: 81.0 units (Opening + In - Out)", "Recorded closing stock: 81.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
39	2026-08-19 10:29:52.165621	WH-CHN-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	40	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 87.0 units, but recorded stock is 87.0 units, leading to a discrepancy of +0.0 units.	LOW	40	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 87.0, "actual": 87.0, "evidence": ["Expected closing stock: 87.0 units (Opening + In - Out)", "Recorded closing stock: 87.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
62	2026-08-18 19:00:07.846699	WH-BLR-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 153.0 units, but recorded stock is 153.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 153.0, "actual": 153.0, "evidence": ["Expected closing stock: 153.0 units (Opening + In - Out)", "Recorded closing stock: 153.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
52	2026-08-19 10:29:52.165621	WH-BOM-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 65.0 units, but recorded stock is 65.0 units, leading to a discrepancy of +0.0 units.	LOW	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 65.0, "actual": 65.0, "evidence": ["Expected closing stock: 65.0 units (Opening + In - Out)", "Recorded closing stock: 65.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
55	2026-08-19 10:29:52.165621	WH-CCU-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 35.0 units, but recorded stock is 35.0 units, leading to a discrepancy of +0.0 units.	LOW	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 35.0, "actual": 35.0, "evidence": ["Expected closing stock: 35.0 units (Opening + In - Out)", "Recorded closing stock: 35.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
44	2026-08-18 19:29:00.864755	WH-CCU-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	39	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 88.0 units, but recorded stock is 88.0 units, leading to a discrepancy of +0.0 units.	LOW	39	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 39/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 88.0, "actual": 88.0, "evidence": ["Expected closing stock: 88.0 units (Opening + In - Out)", "Recorded closing stock: 88.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 39/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
46	2026-08-18 19:29:00.864755	WH-BOM-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	38	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 440.0 units, but recorded stock is 440.0 units, leading to a discrepancy of +0.0 units.	LOW	38	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 440.0, "actual": 440.0, "evidence": ["Expected closing stock: 440.0 units (Opening + In - Out)", "Recorded closing stock: 440.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
61	2026-08-18 19:35:51.896756	WH-DEL-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 103.0 units, but recorded stock is 103.0 units, leading to a discrepancy of +0.0 units.	LOW	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 103.0, "actual": 103.0, "evidence": ["Expected closing stock: 103.0 units (Opening + In - Out)", "Recorded closing stock: 103.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
63	2026-08-18 19:35:51.896756	WH-BLR-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 45.0 units, but recorded stock is 45.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 45.0, "actual": 45.0, "evidence": ["Expected closing stock: 45.0 units (Opening + In - Out)", "Recorded closing stock: 45.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
65	2026-08-19 10:29:52.165621	WH-BLR-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 89.0 units, but recorded stock is 89.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 89.0, "actual": 89.0, "evidence": ["Expected closing stock: 89.0 units (Opening + In - Out)", "Recorded closing stock: 89.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
76	2026-08-19 10:29:52.165621	WH-BLR-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 216.0 units, but recorded stock is 216.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 216.0, "actual": 216.0, "evidence": ["Expected closing stock: 216.0 units (Opening + In - Out)", "Recorded closing stock: 216.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
5	2026-08-15 15:57:19.281616	WH-BLR-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01	MEDIUM	REJECTED	85	{}	NEW	harsha200797@gmail.com	2026-08-15 15:57:19.280572	Rejected via AI Decision Center	\N	\N	MEDIUM	0	HIGH	\N	\N	\N	\N	\N	\N	{}	2026-08-15 15:57:19.281616	\N	\N	\N	\N	{}
6	2026-08-15 16:00:03.095474	WH-BLR-01	ITM-CPU-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CPU-01	MEDIUM	APPROVED	85	{}	NEW	harsha200797@gmail.com	2026-08-15 16:00:03.094625	Approved via AI Decision Center	\N	\N	MEDIUM	0	HIGH	\N	\N	\N	\N	\N	\N	{}	2026-08-15 16:00:03.095474	\N	\N	\N	\N	{}
7	2026-08-15 16:00:10.230423	WH-BLR-01	ITM-SSD-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-SSD-01	MEDIUM	REJECTED	85	{}	NEW	harsha200797@gmail.com	2026-08-15 16:00:10.229281	Rejected via AI Decision Center	\N	\N	MEDIUM	0	HIGH	\N	\N	\N	\N	\N	\N	{}	2026-08-15 16:00:10.230423	\N	\N	\N	\N	{}
8	2026-08-17 04:26:11.912743	WH-DEL-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-DEL-01-ITM-CBL-01	MEDIUM	APPROVED	85	{}	NEW	harsha200797@gmail.com	2026-08-17 04:26:11.908925	Approved via AI Decision Center	\N	\N	MEDIUM	0	HIGH	\N	\N	\N	\N	\N	\N	{}	2026-08-17 04:26:11.912743	\N	\N	\N	\N	{}
9	2026-08-18 03:54:36.78954	WH-BLR-01	ITM-RAM-01	Action on REC-REORDER-WH-BLR-01-ITM-RAM-01	MEDIUM	APPROVED	85	{}	NEW	harsha200797@gmail.com	2026-08-18 03:54:36.78754	Approved via AI Decision Center	\N	\N	MEDIUM	0	HIGH	\N	\N	\N	\N	\N	\N	{}	2026-08-18 03:54:36.78954	\N	\N	\N	\N	{}
10	2026-08-18 03:58:11.902789	WH-BLR-01	ITM-CHG-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CHG-01	MEDIUM	REJECTED	85	{}	NEW	harsha200797@gmail.com	2026-08-18 03:58:11.901789	so this idea seems very bad to me	\N	\N	MEDIUM	0	HIGH	\N	\N	\N	\N	\N	\N	{}	2026-08-18 03:58:11.902789	\N	\N	\N	\N	{}
69	2026-08-18 19:35:51.896756	WH-BOM-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 89.0 units, but recorded stock is 89.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 89.0, "actual": 89.0, "evidence": ["Expected closing stock: 89.0 units (Opening + In - Out)", "Recorded closing stock: 89.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
66	2026-08-18 19:35:51.896756	WH-BLR-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 59.0 units, but recorded stock is 59.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 59.0, "actual": 59.0, "evidence": ["Expected closing stock: 59.0 units (Opening + In - Out)", "Recorded closing stock: 59.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
33	2026-08-19 10:29:52.165621	WH-CHN-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	41	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 206.0 units, but recorded stock is 206.0 units, leading to a discrepancy of +0.0 units.	LOW	41	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 206.0, "actual": 206.0, "evidence": ["Expected closing stock: 206.0 units (Opening + In - Out)", "Recorded closing stock: 206.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
20	2026-08-18 19:33:12.075431	WH-BLR-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	45	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 33.0 units, but recorded stock is 33.0 units, leading to a discrepancy of +0.0 units.	LOW	45	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 33.0, "actual": 33.0, "evidence": ["Expected closing stock: 33.0 units (Opening + In - Out)", "Recorded closing stock: 33.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
25	2026-08-18 19:35:51.896756	WH-DEL-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	43	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 15.0 units, but recorded stock is 15.0 units, leading to a discrepancy of +0.0 units.	LOW	43	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 15.0, "actual": 15.0, "evidence": ["Expected closing stock: 15.0 units (Opening + In - Out)", "Recorded closing stock: 15.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
72	2026-08-18 19:35:51.896756	WH-CHN-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 73.0 units, but recorded stock is 73.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 73.0, "actual": 73.0, "evidence": ["Expected closing stock: 73.0 units (Opening + In - Out)", "Recorded closing stock: 73.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
40	2026-08-18 19:29:00.864755	WH-BLR-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	39	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 17.0 units, but recorded stock is 7.0 units, leading to a discrepancy of -10.0 units.	LOW	39	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	950000	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": -10.0, "expected": 17.0, "actual": 7.0, "evidence": ["Expected closing stock: 17.0 units (Opening + In - Out)", "Recorded closing stock: 7.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: -10.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b9950,000.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
41	2026-08-19 10:29:52.165621	WH-BOM-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	39	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 90.0 units, but recorded stock is 90.0 units, leading to a discrepancy of +0.0 units.	LOW	39	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 90.0, "actual": 90.0, "evidence": ["Expected closing stock: 90.0 units (Opening + In - Out)", "Recorded closing stock: 90.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
38	2026-08-18 19:35:51.896756	WH-CHN-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	40	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 89.0 units, but recorded stock is 89.0 units, leading to a discrepancy of +0.0 units.	LOW	40	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 40/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 89.0, "actual": 89.0, "evidence": ["Expected closing stock: 89.0 units (Opening + In - Out)", "Recorded closing stock: 89.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 40/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
22	2026-08-18 19:35:51.896756	WH-BOM-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	45	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 69.0 units, but recorded stock is 69.0 units, leading to a discrepancy of +0.0 units.	LOW	45	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 39/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 69.0, "actual": 69.0, "evidence": ["Expected closing stock: 69.0 units (Opening + In - Out)", "Recorded closing stock: 69.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 39/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
53	2026-08-18 19:35:51.896756	WH-BOM-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 64.0 units, but recorded stock is 64.0 units, leading to a discrepancy of +0.0 units.	LOW	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 64.0, "actual": 64.0, "evidence": ["Expected closing stock: 64.0 units (Opening + In - Out)", "Recorded closing stock: 64.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
57	2026-08-18 19:00:07.846699	WH-CHN-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 219.0 units, but recorded stock is 219.0 units, leading to a discrepancy of +0.0 units.	LOW	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 219.0, "actual": 219.0, "evidence": ["Expected closing stock: 219.0 units (Opening + In - Out)", "Recorded closing stock: 219.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
43	2026-08-18 19:29:00.864755	WH-CCU-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	39	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 58.0 units, but recorded stock is 58.0 units, leading to a discrepancy of +0.0 units.	LOW	39	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 58.0, "actual": 58.0, "evidence": ["Expected closing stock: 58.0 units (Opening + In - Out)", "Recorded closing stock: 58.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
47	2026-08-18 19:29:00.864755	WH-BOM-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	38	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 14.0 units, but recorded stock is 14.0 units, leading to a discrepancy of +0.0 units.	LOW	38	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 14.0, "actual": 14.0, "evidence": ["Expected closing stock: 14.0 units (Opening + In - Out)", "Recorded closing stock: 14.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
51	2026-08-18 19:29:00.864755	WH-CHN-01	ITM-SSD-01	Review Inventory Anomaly: Samsung 990 Pro 2TB NVMe SSD	LOW	Perform physical stock audit count and check transaction logs.	38	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 88.0 units, but recorded stock is 88.0 units, leading to a discrepancy of +0.0 units.	LOW	38	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-SSD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 38/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 88.0, "actual": 88.0, "evidence": ["Expected closing stock: 88.0 units (Opening + In - Out)", "Recorded closing stock: 88.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 38/100 (ML MODEL)", "Unit Cost: \\u20b912,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
54	2026-08-18 19:29:00.864755	WH-BOM-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 104.0 units, but recorded stock is 104.0 units, leading to a discrepancy of +0.0 units.	LOW	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 104.0, "actual": 104.0, "evidence": ["Expected closing stock: 104.0 units (Opening + In - Out)", "Recorded closing stock: 104.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
59	2026-08-18 19:35:51.896756	WH-CHN-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 30.0 units, but recorded stock is 30.0 units, leading to a discrepancy of +0.0 units.	LOW	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 30.0, "actual": 30.0, "evidence": ["Expected closing stock: 30.0 units (Opening + In - Out)", "Recorded closing stock: 30.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
56	2026-08-18 19:29:00.864755	WH-CHN-01	ITM-CBL-01	Review Inventory Anomaly: Apple USB-C Braided Cable 2m	LOW	Perform physical stock audit count and check transaction logs.	37	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 187.0 units, but recorded stock is 187.0 units, leading to a discrepancy of +0.0 units.	LOW	37	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CBL-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 37/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 187.0, "actual": 187.0, "evidence": ["Expected closing stock: 187.0 units (Opening + In - Out)", "Recorded closing stock: 187.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 37/100 (ML MODEL)", "Unit Cost: \\u20b9800.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
45	2026-08-19 10:29:52.165621	WH-DEL-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	39	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 86.0 units, but recorded stock is 86.0 units, leading to a discrepancy of +0.0 units.	LOW	39	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 86.0, "actual": 86.0, "evidence": ["Expected closing stock: 86.0 units (Opening + In - Out)", "Recorded closing stock: 86.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
77	2026-08-18 19:35:51.896756	WH-BLR-01	ITM-RAM-01	Review Inventory Anomaly: Corsair DDR5 32GB 6000MHz RAM	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 35.0 units, but recorded stock is 35.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-RAM-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 35.0, "actual": 35.0, "evidence": ["Expected closing stock: 35.0 units (Opening + In - Out)", "Recorded closing stock: 35.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b98,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
78	2026-08-18 19:35:51.896756	WH-CCU-01	ITM-CPU-01	Review Inventory Anomaly: AMD Ryzen 9 7900X Processor	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 43.0 units, but recorded stock is 43.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 43.0, "actual": 43.0, "evidence": ["Expected closing stock: 43.0 units (Opening + In - Out)", "Recorded closing stock: 43.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b938,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
79	2026-08-18 19:35:51.896756	WH-CCU-01	ITM-GPU-01	Review Inventory Anomaly: Nvidia RTX 4080 Founders Edition	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 23.0 units, but recorded stock is 23.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-GPU-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 23.0, "actual": 23.0, "evidence": ["Expected closing stock: 23.0 units (Opening + In - Out)", "Recorded closing stock: 23.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b995,000.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
80	2026-08-18 19:35:51.896756	WH-DEL-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	35	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 81.0 units, but recorded stock is 81.0 units, leading to a discrepancy of +0.0 units.	LOW	35	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 81.0, "actual": 81.0, "evidence": ["Expected closing stock: 81.0 units (Opening + In - Out)", "Recorded closing stock: 81.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
68	2026-08-18 19:00:07.846699	WH-BOM-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 37.0 units, but recorded stock is 37.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 37.0, "actual": 37.0, "evidence": ["Expected closing stock: 37.0 units (Opening + In - Out)", "Recorded closing stock: 37.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
70	2026-08-18 19:00:07.846699	WH-CCU-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 90.0 units, but recorded stock is 90.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 90.0, "actual": 90.0, "evidence": ["Expected closing stock: 90.0 units (Opening + In - Out)", "Recorded closing stock: 90.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
74	2026-08-18 19:00:07.846699	WH-DEL-01	ITM-HDD-01	Review Inventory Anomaly: WD Red Pro 8TB NAS Hard Drive	LOW	Perform physical stock audit count and check transaction logs.	36	{}	NEW		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 34.0 units, but recorded stock is 34.0 units, leading to a discrepancy of +0.0 units.	LOW	36	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-HDD-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 36/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 34.0, "actual": 34.0, "evidence": ["Expected closing stock: 34.0 units (Opening + In - Out)", "Recorded closing stock: 34.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 36/100 (ML MODEL)", "Unit Cost: \\u20b916,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	\N	\N	\N	\N	{}
12	2026-08-18 19:29:00.864755	WH-BLR-01	ITM-CHG-01	Review Inventory Anomaly: Anker 100W GaN Wall Charger	MEDIUM	Perform physical stock audit count and check transaction logs.	51	{}	APPROVED		\N		ANOMALY	Recorded inventory mismatch. Expected closing stock was 214.0 units, but recorded stock is 214.0 units, leading to a discrepancy of +0.0 units.	MEDIUM	51	HIGH	IsolationForest 2.0 Anomaly Detection	ShrinkageFlag	ITM-CHG-01	Perform physical stock audit count and check transaction logs.	0	IsolationForest anomaly detector identified an atypical discrepancies signature (Score: 35/100) on recorded stock movements. Note: This flags potential discrepancies requiring physical recount, not confirmed theft.	{"discrepancy": 0.0, "expected": 214.0, "actual": 214.0, "evidence": ["Expected closing stock: 214.0 units (Opening + In - Out)", "Recorded closing stock: 214.0 units (ACTUAL \\u2014 MySQL)", "Inventory discrepancy: +0.0 units (CALCULATED)", "Investigation priority score: 35/100 (ML MODEL)", "Unit Cost: \\u20b92,500.00 -> Estimated Exposure: \\u20b90.00 (CALCULATED)"]}	2026-08-18 18:53:33.726384	2026-08-18 19:41:57.198601	admin	Approved via AI Decision Center	\N	{}
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
3bbcc0985a4e
\.


--
-- Data for Name: audit_ledger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_ledger (id, "timestamp", event_type, details, prev_hash, hash) FROM stdin;
1	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	0000000000000000000000000000000000000000000000000000000000000000	9fec238c3824e41f68ed3de9ecae4c1025d771291cb76fa2727bc3d051f02c5b
2	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	9fec238c3824e41f68ed3de9ecae4c1025d771291cb76fa2727bc3d051f02c5b	70ac5e917652707bb444acb6ba7eebdf396d0f41db50027871406eded265e12e
3	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	70ac5e917652707bb444acb6ba7eebdf396d0f41db50027871406eded265e12e	41c04983295fc4cb30fb3e48367ad952b896bb41daa561c37c05073e25a01afd
4	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	41c04983295fc4cb30fb3e48367ad952b896bb41daa561c37c05073e25a01afd	bcb583985e67bd010e93f5ab5d480a54aa7de8817faa7bccc7e68720c68830a2
5	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	bcb583985e67bd010e93f5ab5d480a54aa7de8817faa7bccc7e68720c68830a2	04207a1c67e2a2c68fce2ce9538ae241c1cfa88f3ec87aab3f171a5aba02f80e
6	2026-08-14 10:31:37	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	04207a1c67e2a2c68fce2ce9538ae241c1cfa88f3ec87aab3f171a5aba02f80e	b320925e2d8b0af062401faa74823151f3d2952093d10718d285dab58b296bb3
7	2026-08-14 10:31:37	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	b320925e2d8b0af062401faa74823151f3d2952093d10718d285dab58b296bb3	61aaf8fdb2a61b2d8d7cbaa9655365570e4af100146a1162b556c6307f846dbc
8	2026-08-14 10:31:37	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	61aaf8fdb2a61b2d8d7cbaa9655365570e4af100146a1162b556c6307f846dbc	f9bd686a14b0a4dc3e04a24cb08271861d495c4f72bf961ff25c77232940139e
9	2026-08-14 10:31:37	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	f9bd686a14b0a4dc3e04a24cb08271861d495c4f72bf961ff25c77232940139e	fd5b0e30a0ab87c482ae1e32f600779d0889b6e90cce2e8b342b81f6b02687d1
10	2026-08-14 10:31:37	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	fd5b0e30a0ab87c482ae1e32f600779d0889b6e90cce2e8b342b81f6b02687d1	bbc12990f7f200c4244c90c2f0dd1cf8a406949d8dc5cd3bd52a36355db6d46b
11	2026-08-14 10:31:37	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	bbc12990f7f200c4244c90c2f0dd1cf8a406949d8dc5cd3bd52a36355db6d46b	1a955f61e3af26f3faa7db37fbce37f01f9c72d5709eb38190f3633a7350a6d8
12	2026-08-14 10:31:37	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	1a955f61e3af26f3faa7db37fbce37f01f9c72d5709eb38190f3633a7350a6d8	ee5a288a1442804c3a1eabf5efcc8a1d867f2ae6633c6e1f12c112fc4b7c3827
13	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	ee5a288a1442804c3a1eabf5efcc8a1d867f2ae6633c6e1f12c112fc4b7c3827	14f822f6d1c985a3da215d00f64de67723f6b89ea5738054ed159972fccbed95
14	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	14f822f6d1c985a3da215d00f64de67723f6b89ea5738054ed159972fccbed95	01a9404c776d25feea768be630cadfe4b11e217987585e59a528c3a4391e8c3c
15	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	01a9404c776d25feea768be630cadfe4b11e217987585e59a528c3a4391e8c3c	a0c42a2dad02de4cc119c1902402af4f0db298324d28303c44fc3f4c8d940a8e
16	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	a0c42a2dad02de4cc119c1902402af4f0db298324d28303c44fc3f4c8d940a8e	6a51b6d87f206ac9865a4ddea922837c77f4fad5f371ee87ec966e90834359fa
17	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	6a51b6d87f206ac9865a4ddea922837c77f4fad5f371ee87ec966e90834359fa	0a3e06c8d46b0b776e85375f33e8a19906b45ca7fe4295bb45c5a87500a302e7
18	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-24"}	0a3e06c8d46b0b776e85375f33e8a19906b45ca7fe4295bb45c5a87500a302e7	019959356929a933447c793c1f96ea53fc09158d61fc969d7e5af0d4e2d67d7d
19	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-24"}	019959356929a933447c793c1f96ea53fc09158d61fc969d7e5af0d4e2d67d7d	05005d018a26a90823e8a7ed4babb2caeb9a3d9efbc22026b2362b22931d2015
20	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	05005d018a26a90823e8a7ed4babb2caeb9a3d9efbc22026b2362b22931d2015	b7c23dd7ce30dcd228dc3db26676f929fcc715f537b1ab428bcfda93228d8fe1
21	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	b7c23dd7ce30dcd228dc3db26676f929fcc715f537b1ab428bcfda93228d8fe1	590b9d95c80f69a07835e86e4087fd9916964ef5eaaf685d38acc2be66831b39
22	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	590b9d95c80f69a07835e86e4087fd9916964ef5eaaf685d38acc2be66831b39	496cdce558453e8a1d621aad955dd34952ad0fd137edf3ab9bc82d6eb52fd128
23	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-28"}	496cdce558453e8a1d621aad955dd34952ad0fd137edf3ab9bc82d6eb52fd128	ebf71bb236ad6166f1a795503b988e0891adfbbf10cdc03f2e1e9c924c21205f
24	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-30"}	ebf71bb236ad6166f1a795503b988e0891adfbbf10cdc03f2e1e9c924c21205f	0a584e1e318f990bc8b3968ec9939bc8f05842e414a358dbb70c84d6fba3b2ce
25	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-30"}	0a584e1e318f990bc8b3968ec9939bc8f05842e414a358dbb70c84d6fba3b2ce	ecccde25b9796f65448ebc7757dc8ca652651c624a16fe8b9225f9fcbd1f5524
26	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-31"}	ecccde25b9796f65448ebc7757dc8ca652651c624a16fe8b9225f9fcbd1f5524	d905f0e78c3d1163e777b397522f6ac0a38fdfe1bb5af7f29023c8e403284a72
27	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-31"}	d905f0e78c3d1163e777b397522f6ac0a38fdfe1bb5af7f29023c8e403284a72	907448bac3c94ea38e85697cbdf724116a1a5bc0b69dda126ac55e55a7cc84c3
28	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-01"}	907448bac3c94ea38e85697cbdf724116a1a5bc0b69dda126ac55e55a7cc84c3	a3dc43f283cb582819bfb5f2d4d8e5853e3367d19fbf38b3d00e928b2ff1b069
29	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-01"}	a3dc43f283cb582819bfb5f2d4d8e5853e3367d19fbf38b3d00e928b2ff1b069	a035d1cd8fb439ce8cf4dd3c1c0750585331a665360e09ac66ad5f980f9d1022
30	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-01"}	a035d1cd8fb439ce8cf4dd3c1c0750585331a665360e09ac66ad5f980f9d1022	524ed4e2747b77a4701ecd630d0fc04a02232529fe780db4761048c887df23ef
31	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	524ed4e2747b77a4701ecd630d0fc04a02232529fe780db4761048c887df23ef	d3036f07d5bd572f6211de766368b8f6f936c9092b00563d00bc7d9d3bde734d
32	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-04"}	d3036f07d5bd572f6211de766368b8f6f936c9092b00563d00bc7d9d3bde734d	cf3410d974ae9d1b26473e4291faf9f27ff82dfc8cbdcb3db29e0a59ae9520b0
33	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-05"}	cf3410d974ae9d1b26473e4291faf9f27ff82dfc8cbdcb3db29e0a59ae9520b0	b64754ed00c65777a0a5bb8a8abeec94d172efdf5f0956d57acd924c9cae3feb
34	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	b64754ed00c65777a0a5bb8a8abeec94d172efdf5f0956d57acd924c9cae3feb	cbfc65687a9ea840423f7df28d52ac22872c4255b7de8dd910118aeec7404430
35	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-06"}	cbfc65687a9ea840423f7df28d52ac22872c4255b7de8dd910118aeec7404430	d2e404b8f350e5710d1ff24dd7687e356751467b358d0477f8fef41f54513539
36	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-07"}	d2e404b8f350e5710d1ff24dd7687e356751467b358d0477f8fef41f54513539	078996631a214b1b8a0435c95ca1b089448cb7f5c7119de9d208dd15cfca1be5
37	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-07"}	078996631a214b1b8a0435c95ca1b089448cb7f5c7119de9d208dd15cfca1be5	e3130764a25f7259ac48df031561f38f2a112f01c64e5af2cb9cf691c131e202
38	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-07"}	e3130764a25f7259ac48df031561f38f2a112f01c64e5af2cb9cf691c131e202	e8a91e2cf4f5e1494ff61306017843039dae3e870af7a5a12766e20db808ed11
39	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-09"}	e8a91e2cf4f5e1494ff61306017843039dae3e870af7a5a12766e20db808ed11	ed9c25f919f06d7f9d77e0e16ee0e437957bd2a50663d4623e49e3212133cad9
40	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	ed9c25f919f06d7f9d77e0e16ee0e437957bd2a50663d4623e49e3212133cad9	b78371424c6357301427a32b9dc7c29fd0a665285e283b644eeb401b41adcf15
41	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	b78371424c6357301427a32b9dc7c29fd0a665285e283b644eeb401b41adcf15	49a55e93c11a9fd0e6f6462cb97f0698d004467b39b181f72ce7efda21002970
42	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-11"}	49a55e93c11a9fd0e6f6462cb97f0698d004467b39b181f72ce7efda21002970	955576c3caaba3bc4cf8f80883b60569f9ce039823866cbe4119e99011824335
43	2026-08-14 10:31:37	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	955576c3caaba3bc4cf8f80883b60569f9ce039823866cbe4119e99011824335	b47d7ff2cb2ac7b245648de47de23fe4c46ad572edcb735f39b13d1354a2a15f
44	2026-08-14 10:31:37	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	b47d7ff2cb2ac7b245648de47de23fe4c46ad572edcb735f39b13d1354a2a15f	e818753abb0920c08a2bf30256ff6085f795fb4fb95d6375c778873d9e678e04
45	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	e818753abb0920c08a2bf30256ff6085f795fb4fb95d6375c778873d9e678e04	eefc04076a7e6df54e04259d388ba8be345636b10781eaa6e0e13c6bd43f4d24
46	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	eefc04076a7e6df54e04259d388ba8be345636b10781eaa6e0e13c6bd43f4d24	d17dd23b71b8f78510b3fb518d3d774ea15cc8a9d94ec676ff154b2317712e1d
47	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	d17dd23b71b8f78510b3fb518d3d774ea15cc8a9d94ec676ff154b2317712e1d	be1486b6ba41658865a5851c4913f4670a9c213c339541d51b1e5a3a6c807a4d
48	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	be1486b6ba41658865a5851c4913f4670a9c213c339541d51b1e5a3a6c807a4d	bd1f5abcf03b937803b2a319d10fd69606b4e1f89bbd3757305d8934a761fa4e
49	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	bd1f5abcf03b937803b2a319d10fd69606b4e1f89bbd3757305d8934a761fa4e	43b35a517d273cdd250d13c675c7f2eaa93382417967bca0901f1594a20f7ad1
50	2026-08-14 10:32:16	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	43b35a517d273cdd250d13c675c7f2eaa93382417967bca0901f1594a20f7ad1	49c08f15a6617d7b5303d50be1cd13b681453289044a778d29b61d7a16db46bd
51	2026-08-14 10:32:16	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	49c08f15a6617d7b5303d50be1cd13b681453289044a778d29b61d7a16db46bd	28190f3523bf6fdf04f9f302f2dbcb05353be16604c8517c91b77d7b7c3a65fa
52	2026-08-14 10:32:16	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	28190f3523bf6fdf04f9f302f2dbcb05353be16604c8517c91b77d7b7c3a65fa	af955d7ffdafa661cef81e7a21446852e89fb8fcdc0a98f8ec84746427635f0f
53	2026-08-14 10:32:16	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	af955d7ffdafa661cef81e7a21446852e89fb8fcdc0a98f8ec84746427635f0f	3408cb75e19fe589168ae245d24682d38de950a6149028118a9161bfd37479a1
54	2026-08-14 10:32:16	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	3408cb75e19fe589168ae245d24682d38de950a6149028118a9161bfd37479a1	3c164f761278bc8ae6057a8bf9a2f5bd1892bdaada0a83611a909d2fa210c9cf
55	2026-08-14 10:32:16	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	3c164f761278bc8ae6057a8bf9a2f5bd1892bdaada0a83611a909d2fa210c9cf	a17dd3ee11cbd8527d35b7fd1fe0efc884a5feb12265b7e0b287d11e0cf1b6ab
56	2026-08-14 10:32:16	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	a17dd3ee11cbd8527d35b7fd1fe0efc884a5feb12265b7e0b287d11e0cf1b6ab	8cbeae454d22a1d79003bb8a29f4c3bdb2b1a72e1c6a2f11034f2df0792d196d
57	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	8cbeae454d22a1d79003bb8a29f4c3bdb2b1a72e1c6a2f11034f2df0792d196d	d947a151ac0b85661ca780713fb0f62bf0c94256f338d8a8d9dcd46bef5d8767
58	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	d947a151ac0b85661ca780713fb0f62bf0c94256f338d8a8d9dcd46bef5d8767	8c6ee87d1b34f5396689156a7ff4f242b930d61642121c93e90413fe7dddc153
59	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	8c6ee87d1b34f5396689156a7ff4f242b930d61642121c93e90413fe7dddc153	2663c6cc775172465d9d05d855f32fb5d273f61a3e64be65686453ecb340d90b
60	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	2663c6cc775172465d9d05d855f32fb5d273f61a3e64be65686453ecb340d90b	4644663a5d063468fb4bf2f9d3c54f6b99862a5e9b5868d137c2d830445f1e18
61	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	4644663a5d063468fb4bf2f9d3c54f6b99862a5e9b5868d137c2d830445f1e18	47727baa00800e51e760af268062651aa0bca98d234336d770d1fdb93e0e5770
62	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-25"}	47727baa00800e51e760af268062651aa0bca98d234336d770d1fdb93e0e5770	29b86809adc9278699f43465ad6d6486625da184970e7f56fa320fe85fef4d1b
63	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	29b86809adc9278699f43465ad6d6486625da184970e7f56fa320fe85fef4d1b	3f7322dad5e5a8a0dc0c27bd3a698999605c8cc537926e0dab92854a31b3b34c
64	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	3f7322dad5e5a8a0dc0c27bd3a698999605c8cc537926e0dab92854a31b3b34c	4e3baeb7afbf0380112666ffb34911f0243e0452c6b6d303990cd9b2ad8af378
65	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-28"}	4e3baeb7afbf0380112666ffb34911f0243e0452c6b6d303990cd9b2ad8af378	f49dad9fbbd91066b6660b8586ad3411111dcb9e038dfa37a8c86c8cf12263a6
66	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-29"}	f49dad9fbbd91066b6660b8586ad3411111dcb9e038dfa37a8c86c8cf12263a6	46cc90c2ff611fa17ee4ff236ba4c68b68e99eb05abd306c1295a28914d79d80
67	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-29"}	46cc90c2ff611fa17ee4ff236ba4c68b68e99eb05abd306c1295a28914d79d80	d3d8d8772c8dfd7edba5863c5d8d8479f3ecb7340da599cd871804a803de09a4
68	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-07-30"}	d3d8d8772c8dfd7edba5863c5d8d8479f3ecb7340da599cd871804a803de09a4	dfe65919c3b64766b0cf4d7b1496835222303c2715b59a1677708070841bd019
69	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-30"}	dfe65919c3b64766b0cf4d7b1496835222303c2715b59a1677708070841bd019	fb4006725e3b6f742b7258fcad67adee50cc036e1c225ce7fde29951465bc03d
70	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-31"}	fb4006725e3b6f742b7258fcad67adee50cc036e1c225ce7fde29951465bc03d	f36cd3cd9772543e7a70cd558e6d2905fe9ea91f6c8cc78fe176f6f59af00b38
71	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-01"}	f36cd3cd9772543e7a70cd558e6d2905fe9ea91f6c8cc78fe176f6f59af00b38	0e66dab4135c358542cfc51a0d45dc5bcf56f6b7a5e81f543669873316709142
72	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	0e66dab4135c358542cfc51a0d45dc5bcf56f6b7a5e81f543669873316709142	b48cb8cfd477cd885183d09266dd26edfea7d188030eefe1a9c6b54958b5c2c4
73	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	b48cb8cfd477cd885183d09266dd26edfea7d188030eefe1a9c6b54958b5c2c4	e45a909683be5a9ff9f10fb29203b52c1af073aaf9b0708b03778887e39d624e
74	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-02"}	e45a909683be5a9ff9f10fb29203b52c1af073aaf9b0708b03778887e39d624e	b718755102fc5dfea1183713c4d015c7acf4e254f5cb922bfcf24062ec6378d4
75	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	b718755102fc5dfea1183713c4d015c7acf4e254f5cb922bfcf24062ec6378d4	86bded208d02467281a864babc35a4fb26a61d0bd3ee5b3c094db54a08db166c
76	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-02"}	86bded208d02467281a864babc35a4fb26a61d0bd3ee5b3c094db54a08db166c	0b5eee4514c9510ac18f9d366fef6032cb727e9c80740fa796c13678211da2f7
77	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-03"}	0b5eee4514c9510ac18f9d366fef6032cb727e9c80740fa796c13678211da2f7	1f8a7565c151c5cc33c6477550a99d5ff54487670180ca25e88bd7910aab5cf6
78	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	1f8a7565c151c5cc33c6477550a99d5ff54487670180ca25e88bd7910aab5cf6	67113fed3f5ccb664841cc0a4621b81e9b789935eca2fc3e3f78ff7596ddfd66
79	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-05"}	67113fed3f5ccb664841cc0a4621b81e9b789935eca2fc3e3f78ff7596ddfd66	2b639d1de5a11cac8fdf6e6f4f6a54e50134dadfefb647795dc9b4de823787d8
80	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-06"}	2b639d1de5a11cac8fdf6e6f4f6a54e50134dadfefb647795dc9b4de823787d8	7fa0d4c49ca0175eff3b30e7b813a95d9d323c2fc6dae048802dbd7753ca5a39
81	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-07"}	7fa0d4c49ca0175eff3b30e7b813a95d9d323c2fc6dae048802dbd7753ca5a39	93711097f215f5df5eb6db8dd9b0258d7d37edf3a60bc455b00fbbbd56f19525
82	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-08"}	93711097f215f5df5eb6db8dd9b0258d7d37edf3a60bc455b00fbbbd56f19525	c6c385e16b596ba610830009900b208dca4d19e38e51f2d422623adefdfb23dc
83	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-08"}	c6c385e16b596ba610830009900b208dca4d19e38e51f2d422623adefdfb23dc	14f60b107d484617fa754896e6d3d2c8bdd9f93c7d8481d2036c4aa8ef4ce670
84	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-08"}	14f60b107d484617fa754896e6d3d2c8bdd9f93c7d8481d2036c4aa8ef4ce670	31d10c862268308465dc09d529e03f3c97e0babce3a26c2b73a64133c6b806d9
85	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	31d10c862268308465dc09d529e03f3c97e0babce3a26c2b73a64133c6b806d9	a6add784e9e907c9d95a5aa7f6e08217be94112edb8bbbae183997c94ade938f
180	2026-08-19 09:05:20	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	d4f74c4dccae6e6d877984dd33fd5489e7c4ef8e095b83d1b2e3aa70a3780e01	3d6a7658e560bccf183c03af119a6f14fae6eb80f085fe4c514451a2a534d7e3
86	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	a6add784e9e907c9d95a5aa7f6e08217be94112edb8bbbae183997c94ade938f	4c83de7d66cba340f1237e630a52d647018e61667f5cfb83412fc9ca0730e40d
87	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-10"}	4c83de7d66cba340f1237e630a52d647018e61667f5cfb83412fc9ca0730e40d	52b513610a81bdd38252953810d4878330c46f871482e8deb4ff83f537200213
88	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-11"}	52b513610a81bdd38252953810d4878330c46f871482e8deb4ff83f537200213	f281129f8a1a92ba24e46ff233ea87823a37fa7d6c90ea5dfc3f447b95e54cfa
89	2026-08-14 10:32:16	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	f281129f8a1a92ba24e46ff233ea87823a37fa7d6c90ea5dfc3f447b95e54cfa	7daa064abcef2e925a498b4d8582ae0c9fc16f4484044840ad295c92ad99ea9e
90	2026-08-14 10:32:16	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	7daa064abcef2e925a498b4d8582ae0c9fc16f4484044840ad295c92ad99ea9e	512a1f6c2bddbe8a1de2d737f9cb2e9f5a66f3c453a1708bd7f720ca571e5904
91	2026-08-14 10:32:30	auto_cloud_backup	{"day": 1, "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-103230.json", "size_kb": 373.1, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-103230.json"}	512a1f6c2bddbe8a1de2d737f9cb2e9f5a66f3c453a1708bd7f720ca571e5904	de363723090a193ff54cca0fb77ae7e6900d961e5fd27d3f1816d88737021479
92	2026-08-14 11:06:06	admin_created	{"new_admin_username": "harsha200797+new@gmail.com", "full_name": "Test Admin", "created_by": "admin", "timestamp": "2026-08-14"}	de363723090a193ff54cca0fb77ae7e6900d961e5fd27d3f1816d88737021479	f68241e54ae977d79172ffeaccb40c7ebf9fcf1a6f8c9ded32a24b4c3940d74d
93	2026-08-14 11:10:47	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-111047.json", "size_kb": 375.6, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-111047.json"}	f68241e54ae977d79172ffeaccb40c7ebf9fcf1a6f8c9ded32a24b4c3940d74d	21ef4459852dc8e584b563bf43c1bdeb576b6dabec27e6dd7a46553088800808
94	2026-08-14 11:10:54	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-111054.json", "size_kb": 376.2, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-111054.json"}	21ef4459852dc8e584b563bf43c1bdeb576b6dabec27e6dd7a46553088800808	6ec1ef20e83af2c58b0a5f3e3086944d3275358e468990bca1424a5cc8600eed
95	2026-08-14 11:33:31	password_changed	{"username": "admin", "time": "2026-08-14"}	6ec1ef20e83af2c58b0a5f3e3086944d3275358e468990bca1424a5cc8600eed	b74a392ff372fc25304635e8f306d1114c99a0f91c17cd8c7f0f8fd353de355c
96	2026-08-14 11:40:57	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-14T11:40:57.900905"}	b74a392ff372fc25304635e8f306d1114c99a0f91c17cd8c7f0f8fd353de355c	a15baf8f62b736db2847d593a10f61bdb43c85e1f2048f1eedef170cd3f6d177
97	2026-08-14 11:41:03	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-14T11:41:03.675684"}	a15baf8f62b736db2847d593a10f61bdb43c85e1f2048f1eedef170cd3f6d177	a87f4aaafe3969158aacb0c1098044ef2dd369a6d34de7b94eadfdc89c95eb30
98	2026-08-14 11:41:15	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "REJECTED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Rejected via AI Decision Center", "timestamp": "2026-08-14T11:41:15.432149"}	a87f4aaafe3969158aacb0c1098044ef2dd369a6d34de7b94eadfdc89c95eb30	0606dd498e75406491d52028b12d87b9d0d387f582b23c1adbdfb00b60549196
99	2026-08-14 11:45:45	password_changed	{"username": "harsha200797@gmail.com", "time": "2026-08-14"}	0606dd498e75406491d52028b12d87b9d0d387f582b23c1adbdfb00b60549196	6e2a3e708743536e4b6169d955bbf9a20950343502d38d4509f1750653b4bde0
100	2026-08-14 12:08:06	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-120806.json", "size_kb": 381.0, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-120806.json"}	6e2a3e708743536e4b6169d955bbf9a20950343502d38d4509f1750653b4bde0	e6f66b3914b13908374db2e8d3e618157fd1c53bd3ef2a6683c8e84c120efd4b
101	2026-08-14 12:08:16	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-120816.json", "size_kb": 381.7, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-120816.json"}	e6f66b3914b13908374db2e8d3e618157fd1c53bd3ef2a6683c8e84c120efd4b	2561ce2e0a24827fff7867bbb359b9f4bfa35fd85a5316f310ddec84a261a2a7
102	2026-08-14 12:25:18	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-122518.json", "size_kb": 382.7, "mode": "Local Fallback (Demo)", "message": "Cloud keys unconfigured/invalid. Saved local backup: data/backups/backup-20260814-122518.json"}	2561ce2e0a24827fff7867bbb359b9f4bfa35fd85a5316f310ddec84a261a2a7	6c64e2f16151bf67805b34e34064e92523b2000507f8c454e8f32c726b705a03
103	2026-08-14 12:38:20	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-123805.json", "size_kb": 383.5, "mode": "Local Fallback (Demo)", "message": "Cloud keys unconfigured/invalid. Saved local backup: data/backups/backup-20260814-123805.json"}	6c64e2f16151bf67805b34e34064e92523b2000507f8c454e8f32c726b705a03	446c656ffee74615e54be8ac52e9c12d9c5e83d9c0d2afd391341d5e5b4cc531
104	2026-08-15 07:02:39	auto_cloud_backup	{"day": 2, "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260815-070212.json", "size_kb": 384.5, "mode": "Local Fallback (Demo)", "message": "Cloud keys unconfigured/invalid. Saved local backup: data/backups/backup-20260815-070212.json"}	446c656ffee74615e54be8ac52e9c12d9c5e83d9c0d2afd391341d5e5b4cc531	dd5d0e8f377b6fe7445c6329d12849fa1d9605882bf35d648dc21f5f0b9cf46f
105	2026-08-15 07:46:48	admin_created	{"new_admin_username": "testadmin_1786780003@gmail.com", "full_name": "Test Administrator", "created_by": "admin", "timestamp": "2026-08-15"}	dd5d0e8f377b6fe7445c6329d12849fa1d9605882bf35d648dc21f5f0b9cf46f	e69c4570d4781be51d327b6d16eaa65ca8ef99848968565b90feb4e0e9e09e24
106	2026-08-15 07:47:32	admin_created	{"new_admin_username": "testadmin_1786780047@gmail.com", "full_name": "Test Administrator", "created_by": "admin", "timestamp": "2026-08-15"}	e69c4570d4781be51d327b6d16eaa65ca8ef99848968565b90feb4e0e9e09e24	4bd2228f0bfde8ed7d12a73ba7561425a07ad0be743e8108f6a93e796b8f8327
107	2026-08-15 08:28:10	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260815-082759.json", "size_kb": 389.0, "mode": "Local Fallback (Demo)", "message": "Cloud keys unconfigured/invalid. Saved local backup: data/backups/backup-20260815-082759.json"}	4bd2228f0bfde8ed7d12a73ba7561425a07ad0be743e8108f6a93e796b8f8327	4fd605456925b5c9aff8cf35f2ab7e228b58a464673405ef3132e3c8cb440857
108	2026-08-15 13:10:08	stock_entry	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "date": "2026-08-15", "stock_in": 10, "stock_out": 10, "entered_by": "harsha200797@gmail.com"}	4fd605456925b5c9aff8cf35f2ab7e228b58a464673405ef3132e3c8cb440857	0d578b7bbf6c7317975239cf780a733abe69ec7a333ada1a7c15835b5f677f6b
109	2026-08-15 14:03:01	stock_entry	{"warehouse_id": "WH-BLR-01", "item_id": "ITM005", "date": "2026-08-15", "stock_in": 50, "stock_out": 100, "entered_by": "harsha200797@gmail.com"}	0d578b7bbf6c7317975239cf780a733abe69ec7a333ada1a7c15835b5f677f6b	5cd85a3e5b70ddeee37768fdf1044d84c5207cbb321aa54e248e8b508aff3889
110	2026-08-15 15:51:30	password_changed	{"username": "harsha200797@gmail.com", "time": "2026-08-15"}	5cd85a3e5b70ddeee37768fdf1044d84c5207cbb321aa54e248e8b508aff3889	3ce437ea24e16734005a6cf8dfce2004f0895138be3ad574abeed2b39ec13e29
111	2026-08-15 15:52:47	admin_created	{"new_admin_username": "joyboy56211@gmail.com", "full_name": "joyboy", "created_by": "harsha200797@gmail.com", "timestamp": "2026-08-15"}	3ce437ea24e16734005a6cf8dfce2004f0895138be3ad574abeed2b39ec13e29	893da12539424b2e78e96fee8a866f0dc57d5912b4581527e542f4cb0ac05ade
112	2026-08-15 15:57:11	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CPU-01", "item_id": "ITM-CPU-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-15T15:57:11.325021"}	893da12539424b2e78e96fee8a866f0dc57d5912b4581527e542f4cb0ac05ade	4d17ecdbf11420983f1b32789ddcd4ee32d705d563dfffeedc2f95f8707c3155
113	2026-08-15 15:57:19	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "REJECTED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Rejected via AI Decision Center", "timestamp": "2026-08-15T15:57:19.295618"}	4d17ecdbf11420983f1b32789ddcd4ee32d705d563dfffeedc2f95f8707c3155	7c16120b3afab45f5c479106cf6e04c5e7c8c91cc6d74512979397df1e9412af
114	2026-08-15 16:00:03	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CPU-01", "item_id": "ITM-CPU-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-15T16:00:03.103583"}	7c16120b3afab45f5c479106cf6e04c5e7c8c91cc6d74512979397df1e9412af	f97b0d767ccb8c52014d23d0a0403e5201705b62a4cba15074cb3936189b406c
115	2026-08-15 16:00:10	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-SSD-01", "item_id": "ITM-SSD-01", "action": "REJECTED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Rejected via AI Decision Center", "timestamp": "2026-08-15T16:00:10.267032"}	f97b0d767ccb8c52014d23d0a0403e5201705b62a4cba15074cb3936189b406c	a907e28be5b32cae08436f40b1ec9251836ddf5ee438779a18549f3c23d6a5dc
116	2026-08-17 04:26:11	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-DEL-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-17T04:26:11.921406"}	a907e28be5b32cae08436f40b1ec9251836ddf5ee438779a18549f3c23d6a5dc	3a11abe2365e0f3b2dfb42fe37dd2681990686a58c251b48ff3224023311e4bc
117	2026-08-17 17:12:50	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	3a11abe2365e0f3b2dfb42fe37dd2681990686a58c251b48ff3224023311e4bc	66062465c9c2c575f5e80b7490b044b304b5b36948414254b6353acd08548a96
118	2026-08-17 17:12:50	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	66062465c9c2c575f5e80b7490b044b304b5b36948414254b6353acd08548a96	ac4a1f0949fc9c177eab18d9eae02dd1c6bd7104491a2e12b8ae4c7d73bb6d03
119	2026-08-17 17:12:50	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	ac4a1f0949fc9c177eab18d9eae02dd1c6bd7104491a2e12b8ae4c7d73bb6d03	8cd4d240b61e78139d0d76af3710296345401259b51e850dd627735dcc6ee552
120	2026-08-17 17:12:50	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	8cd4d240b61e78139d0d76af3710296345401259b51e850dd627735dcc6ee552	d1a02f8147edea89d12212c8dd2824ba4eb1191df3d110f5a8c2e60e92384eae
121	2026-08-17 17:12:50	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	d1a02f8147edea89d12212c8dd2824ba4eb1191df3d110f5a8c2e60e92384eae	d7482aa74f49612c9253a9001dcb6efa66f3fe74a6566bb3d68bd837ba9825ee
122	2026-08-17 17:12:51	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	d7482aa74f49612c9253a9001dcb6efa66f3fe74a6566bb3d68bd837ba9825ee	fe02da0a45957de98523c232ead54f90541e2abf3b08304caa80c31a26e8d7ff
123	2026-08-17 17:12:51	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	fe02da0a45957de98523c232ead54f90541e2abf3b08304caa80c31a26e8d7ff	0e17e291f9b3f66832afb60d2d9b79b16b731942d01c843d01c527e8d6873df6
124	2026-08-17 17:12:51	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	0e17e291f9b3f66832afb60d2d9b79b16b731942d01c843d01c527e8d6873df6	75feab0c9b891814ee0ffa5902c9cd8488212c0146d637a3757332e30f25133e
125	2026-08-17 17:12:51	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	75feab0c9b891814ee0ffa5902c9cd8488212c0146d637a3757332e30f25133e	b46851bf1c082a806769f1a6bc64f8cce39221d9f5d1ab3b80d8f01235965e99
126	2026-08-17 17:12:51	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	b46851bf1c082a806769f1a6bc64f8cce39221d9f5d1ab3b80d8f01235965e99	2f3f4f0cb30b4f7a1fdc534764b4e1a07a035c0bf0b8fd6063bbb45a54abf07a
127	2026-08-17 17:12:51	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	2f3f4f0cb30b4f7a1fdc534764b4e1a07a035c0bf0b8fd6063bbb45a54abf07a	c2632523c0c762c7db6bfb83f6da046951b170ab0ad5bffa047ef03f7cc80b3d
128	2026-08-17 17:12:51	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	c2632523c0c762c7db6bfb83f6da046951b170ab0ad5bffa047ef03f7cc80b3d	caea482f43a79ab6afcd34af7ff34ffff161b9af6cdbbe2e32c865f4c5b80c21
129	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	caea482f43a79ab6afcd34af7ff34ffff161b9af6cdbbe2e32c865f4c5b80c21	934c160c5328990efe55549845313ce2546b61b66fcabaa15156d936d9ae3039
181	2026-08-19 09:05:20	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	3d6a7658e560bccf183c03af119a6f14fae6eb80f085fe4c514451a2a534d7e3	49317d5b855ec31f9456d85b10b2c470365dd391133235ba597f36bf9e79c835
130	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	934c160c5328990efe55549845313ce2546b61b66fcabaa15156d936d9ae3039	d817d655b2cd3cc0ffdf2b982d81984eaf3ec77cb1fa0f2f1b233580bbf9dae6
131	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	d817d655b2cd3cc0ffdf2b982d81984eaf3ec77cb1fa0f2f1b233580bbf9dae6	2606df344b018d86f1d9a5199a95f309c4f66ee758f72451b31743f08b173a51
132	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	2606df344b018d86f1d9a5199a95f309c4f66ee758f72451b31743f08b173a51	104ab57cd50ac85db08799b878d1e124e052733ee7221ebe81fd7c535373faf2
133	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	104ab57cd50ac85db08799b878d1e124e052733ee7221ebe81fd7c535373faf2	a06dca47b13cfb5c46943d25ac94597d7600b210378e3238d464e4287677a4e6
134	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	a06dca47b13cfb5c46943d25ac94597d7600b210378e3238d464e4287677a4e6	244e3ca6d930e56fc9617d3843456113f62606c2dada8c348284c6ad6f058678
135	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	244e3ca6d930e56fc9617d3843456113f62606c2dada8c348284c6ad6f058678	c0d0d8ffec901aae9455406c6b2e8c2eaa884811001be190c2f41fac9f78dd06
136	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	c0d0d8ffec901aae9455406c6b2e8c2eaa884811001be190c2f41fac9f78dd06	686d0927db6923f09bcd45991ce5eb5f72c544900656a0ecb8f43acf619ffbe3
137	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-26"}	686d0927db6923f09bcd45991ce5eb5f72c544900656a0ecb8f43acf619ffbe3	6dfa886ed2e4d75ae6004a2d9c78a8056267a75abd468a4837284f8a779a17a4
138	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	6dfa886ed2e4d75ae6004a2d9c78a8056267a75abd468a4837284f8a779a17a4	b7e5765ad53adedc0ee62b6995f5c9b339166cc4ddb5951a4fb0a458bbcebbda
139	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-27"}	b7e5765ad53adedc0ee62b6995f5c9b339166cc4ddb5951a4fb0a458bbcebbda	e3b106953ab3541bb71bfd530fc4a01da4175a70774a2401678049e31086a3e7
140	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	e3b106953ab3541bb71bfd530fc4a01da4175a70774a2401678049e31086a3e7	454ff446883cd830c6a154804ee4a70b9c2c3da72d7f859ebe0b8113ea6c376f
141	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-28"}	454ff446883cd830c6a154804ee4a70b9c2c3da72d7f859ebe0b8113ea6c376f	169b14d7fa81882ac7e69341e2370927f7134ecab2811fa8478d5130c4d88d17
142	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-30"}	169b14d7fa81882ac7e69341e2370927f7134ecab2811fa8478d5130c4d88d17	cdd641de4df2f3bab339ae9cd181a0e63876c643c9e643a29a93227995709083
143	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	cdd641de4df2f3bab339ae9cd181a0e63876c643c9e643a29a93227995709083	e39522e16e91d21e8a4a80778fe12462e053ec390f6b5c3216e85d03fa31ca21
144	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	e39522e16e91d21e8a4a80778fe12462e053ec390f6b5c3216e85d03fa31ca21	7e849f57079394da50c7417d8ad14b943e115c6547fe5274c849a9093796140f
145	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-02"}	7e849f57079394da50c7417d8ad14b943e115c6547fe5274c849a9093796140f	059c145dfcb78472bc9b4da19dd442724899a05315ca822f30ca04b4967a8c33
146	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	059c145dfcb78472bc9b4da19dd442724899a05315ca822f30ca04b4967a8c33	a3ffc065f8b0c2ab707f2f71a1cfe9d4c1ff3ac6518dd9e2ce9e31b27d5466ff
147	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	a3ffc065f8b0c2ab707f2f71a1cfe9d4c1ff3ac6518dd9e2ce9e31b27d5466ff	8ff22aab00c27f7a8015c35719043fd23d45c543068f2ac790f30fd04b4bdfbc
148	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-04"}	8ff22aab00c27f7a8015c35719043fd23d45c543068f2ac790f30fd04b4bdfbc	415ce6c64dcf5f0351128891d0868c08c965d07d00dcf6e443ac77771f309254
149	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-04"}	415ce6c64dcf5f0351128891d0868c08c965d07d00dcf6e443ac77771f309254	c2b196406ac8c8ea6b9ae18c2620bad6e61c8629bf5632dd7e20012ada43f270
150	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-05"}	c2b196406ac8c8ea6b9ae18c2620bad6e61c8629bf5632dd7e20012ada43f270	3493a622ba881b928fdb4a108291590e7073bea957869b9e08754ecc0519618c
151	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	3493a622ba881b928fdb4a108291590e7073bea957869b9e08754ecc0519618c	75c26b4132486f26e48e7284a50012df1417bc3372c1dae9bdccb5d702022ce8
152	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-06"}	75c26b4132486f26e48e7284a50012df1417bc3372c1dae9bdccb5d702022ce8	2d215df23f4bb7b135623e4a91d98a95f65d4f73e4ab56c273a3d6f2a771b9f1
153	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-07"}	2d215df23f4bb7b135623e4a91d98a95f65d4f73e4ab56c273a3d6f2a771b9f1	8b41b613d3bd2d5498a0bfd3d531ef9370140f2115a3b1ab55edabac2f1b112e
154	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-08"}	8b41b613d3bd2d5498a0bfd3d531ef9370140f2115a3b1ab55edabac2f1b112e	b9d9cfa0f5ad56784ebc098fffa90bd1499efb457254868699b485ae99bb2285
155	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-08"}	b9d9cfa0f5ad56784ebc098fffa90bd1499efb457254868699b485ae99bb2285	1ed2275c43ff89111a7cf06caaf63b384c6d5cb833bf3c2ec2b266894a9764ac
156	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-SSD-01", "quantity": 90, "date": "2026-08-08"}	1ed2275c43ff89111a7cf06caaf63b384c6d5cb833bf3c2ec2b266894a9764ac	51046ac25b499ce787f4977beef55c87d464a314ac0b691cd0e2567e1269bf48
182	2026-08-19 09:05:20	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	49317d5b855ec31f9456d85b10b2c470365dd391133235ba597f36bf9e79c835	c615f9bd51d2d0891ad412a112318f98f7f4d4392bb65de0c87b79725936f4c0
157	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-08"}	51046ac25b499ce787f4977beef55c87d464a314ac0b691cd0e2567e1269bf48	50cd75e28d64a6d6bfbf0810cc62a46b2dfcfa401368ba842ed267755f607a95
158	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	50cd75e28d64a6d6bfbf0810cc62a46b2dfcfa401368ba842ed267755f607a95	08bd2233e752e078d1a7261f6da5924217a655378decf82fb2fe01398037c967
159	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-10"}	08bd2233e752e078d1a7261f6da5924217a655378decf82fb2fe01398037c967	e226c35ae0726db5fe1e17adecf913384d87d2c2669a15cfa9075ca0b1fed5be
160	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	e226c35ae0726db5fe1e17adecf913384d87d2c2669a15cfa9075ca0b1fed5be	8fb05c18d8f65b9ccdf5b9ff6107ba6fccc6b51d679a67a37d9554d4bb4afca5
161	2026-08-17 17:12:51	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	8fb05c18d8f65b9ccdf5b9ff6107ba6fccc6b51d679a67a37d9554d4bb4afca5	8ba2e7e8bcf29f525150214716de087532e7214a33c5cea3e9aa35606d994b43
162	2026-08-17 17:12:51	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	8ba2e7e8bcf29f525150214716de087532e7214a33c5cea3e9aa35606d994b43	feacd6a24069190efc752b878c50984d93d6c1b85033b056b376058aa05a5f2d
163	2026-08-18 03:54:36	ai_recommendation_action	{"recommendation_id": "REC-REORDER-WH-BLR-01-ITM-RAM-01", "item_id": "ITM-RAM-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-18T03:54:36.809747"}	feacd6a24069190efc752b878c50984d93d6c1b85033b056b376058aa05a5f2d	402bbafe1b877ccb28cf92c63f834010a200b9a5c34f1a8a77624f090550aaec
164	2026-08-18 03:58:11	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CHG-01", "item_id": "ITM-CHG-01", "action": "REJECTED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "so this idea seems very bad to me", "timestamp": "2026-08-18T03:58:11.910440"}	402bbafe1b877ccb28cf92c63f834010a200b9a5c34f1a8a77624f090550aaec	94f62f428ff2b8fdeeb4b235d507e1b58099960b30c08959ffffd58c6dfd6008
165	2026-08-18 19:26:54	SIMULATION_STARTED	{"simulation_id": 1, "warehouse_id": "WH-BLR-01", "by": "admin", "scenario": "NORMAL_OPERATIONS"}	94f62f428ff2b8fdeeb4b235d507e1b58099960b30c08959ffffd58c6dfd6008	039f31ef65e868594dc53a9d723b3e500d40bb2bd9255c0cd8c31afdcae99c56
166	2026-08-18 19:41:35	SIMULATION_STARTED	{"simulation_id": 2, "warehouse_id": "WH-DEL-01", "by": "harsha200797@gmail.com", "scenario": "NORMAL_OPERATIONS"}	039f31ef65e868594dc53a9d723b3e500d40bb2bd9255c0cd8c31afdcae99c56	b624de62be7151e0833a8882f732f3a7256bcecd15541783025ec9d5467b5e03
167	2026-08-18 19:41:57	AI_RECOMMENDATION_APPROVED	{"recommendation_id": 12, "recommendation_type": "ANOMALY", "approved_by": "admin", "task_id": null, "notes": "Approved via AI Decision Center"}	b624de62be7151e0833a8882f732f3a7256bcecd15541783025ec9d5467b5e03	dcf67232389ee368eb538d562c8e733b4652684e2cd3f03004555f1d39b6c54b
168	2026-08-18 19:45:13	AI_RECOMMENDATION_APPROVED	{"recommendation_id": 11, "recommendation_type": "REPLENISHMENT", "approved_by": "admin", "task_id": 1, "notes": "Approved via AI Decision Center"}	dcf67232389ee368eb538d562c8e733b4652684e2cd3f03004555f1d39b6c54b	f59c630d0a8da0975e307fd724215936ff97bb153326d6e889a07cfeb63c2f19
169	2026-08-18 19:46:02	AI_RECOMMENDATION_APPROVED	{"recommendation_id": 82, "recommendation_type": "REPLENISHMENT", "approved_by": "admin", "task_id": 2, "notes": "Approved via AI Decision Center"}	f59c630d0a8da0975e307fd724215936ff97bb153326d6e889a07cfeb63c2f19	325899a739bc24602dc4eda755889157a4f55a616f684a2d6ae95ac8433e366f
170	2026-08-19 06:20:33	user_login	{"username": "harsha200797@gmail.com", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T06:20:33.183372"}	325899a739bc24602dc4eda755889157a4f55a616f684a2d6ae95ac8433e366f	1c9b2682f8abe355685ecacaadcdfa086ed2584e26d71b216d84f6b86319d15d
171	2026-08-19 06:21:25	user_login	{"username": "harsha200797@gmail.com", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T06:21:25.901386"}	1c9b2682f8abe355685ecacaadcdfa086ed2584e26d71b216d84f6b86319d15d	9f9f908c2f8ec9794b1ee21dc84d62d9ea391128ab0de669ad0605c6f6cf32e9
172	2026-08-19 06:46:02	NOTIF_PUBLISHED_ITEM_CREATED	{"event_type": "ITEM_CREATED", "warehouse_id": null, "severity": "INFO", "source_entity_id": null, "source_entity_type": null, "recipients_count": 0}	9f9f908c2f8ec9794b1ee21dc84d62d9ea391128ab0de669ad0605c6f6cf32e9	fb5a781a96799e0fb79263871d07e370fd9bec5175db7d4966f567b39e954a85
173	2026-08-19 06:47:41	user_login	{"username": "harsha200797@gmail.com", "role": "admin", "method": "password", "ip": "127.0.0.1", "time": "2026-08-19T06:47:41.693501"}	fb5a781a96799e0fb79263871d07e370fd9bec5175db7d4966f567b39e954a85	580e465ec3dda750c857d9912d7834a1586732c4d557bb9602c59fd5d5421a53
174	2026-08-19 06:55:42	role_changed	{"target_username": "joyboy56211@gmail.com", "old_role": "admin", "new_role": "viewer", "changed_by": "harsha200797@gmail.com", "reason": "because it was not eligible", "time": "2026-08-19T06:55:42.431744"}	580e465ec3dda750c857d9912d7834a1586732c4d557bb9602c59fd5d5421a53	5549f5472363920514f0082f56c5211011ba4e4f65b0c04c920fca128cd65633
175	2026-08-19 06:56:00	role_changed	{"target_username": "joyboy56211@gmail.com", "old_role": "viewer", "new_role": "manager", "changed_by": "harsha200797@gmail.com", "reason": "nkrggn", "time": "2026-08-19T06:56:00.678590"}	5549f5472363920514f0082f56c5211011ba4e4f65b0c04c920fca128cd65633	cbd8632028a7ed87039ab846ad01f9227e95cc658a110aff21e7dd7e137c2a6f
176	2026-08-19 06:56:11	role_changed	{"target_username": "joyboy56211@gmail.com", "old_role": "manager", "new_role": "admin", "changed_by": "harsha200797@gmail.com", "reason": "m", "time": "2026-08-19T06:56:11.344271"}	cbd8632028a7ed87039ab846ad01f9227e95cc658a110aff21e7dd7e137c2a6f	3d3938df7959060fd45a668210a9c3e6340510ef377ae8a16c3f0a6154cdf123
177	2026-08-19 07:13:02	AI_RECOMMENDATION_APPROVED	{"recommendation_id": 83, "recommendation_type": "REPLENISHMENT", "approved_by": "harsha200797@gmail.com", "task_id": 3, "notes": "Approved via AI Decision Center"}	3d3938df7959060fd45a668210a9c3e6340510ef377ae8a16c3f0a6154cdf123	d4739971d41c919df515aa66661bb505ba7b45280fc1a939a0fd828fca79eea8
178	2026-08-19 07:13:02	NOTIF_PUBLISHED_AI_RECOMMENDATION_APPROVED	{"event_type": "AI_RECOMMENDATION_APPROVED", "warehouse_id": "WH-BLR-01", "severity": "SUCCESS", "source_entity_id": "3", "source_entity_type": "TASK", "recipients_count": 0}	d4739971d41c919df515aa66661bb505ba7b45280fc1a939a0fd828fca79eea8	6180f09fc0d79ffbd9e5e513a91186669086328ace0d83fa894f5ce952c39c2d
179	2026-08-19 09:05:20	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	6180f09fc0d79ffbd9e5e513a91186669086328ace0d83fa894f5ce952c39c2d	d4f74c4dccae6e6d877984dd33fd5489e7c4ef8e095b83d1b2e3aa70a3780e01
183	2026-08-19 09:05:20	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	c615f9bd51d2d0891ad412a112318f98f7f4d4392bb65de0c87b79725936f4c0	a5a76fef85d5c79343ad9d8cb212117ec431e8bbd5f46fc4dc39c615df8bb749
184	2026-08-19 09:05:20	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	a5a76fef85d5c79343ad9d8cb212117ec431e8bbd5f46fc4dc39c615df8bb749	449234523daef24fb3d32ae9a9b464949ab42d2e699cb00f7cfef018b6ead042
185	2026-08-19 09:05:20	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	449234523daef24fb3d32ae9a9b464949ab42d2e699cb00f7cfef018b6ead042	5e8a6239be7d33d6cadb5113fb0373c1e7bfadd521f4f172237f5eed2522ca2c
186	2026-08-19 09:05:20	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	5e8a6239be7d33d6cadb5113fb0373c1e7bfadd521f4f172237f5eed2522ca2c	bb484411cd44224f47d0169e02dcf02ede58b6cee53f02888dc98b540587bf10
187	2026-08-19 09:05:20	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	bb484411cd44224f47d0169e02dcf02ede58b6cee53f02888dc98b540587bf10	4830139ffa1015bd5dfbbc7ee8c1f942e8373daefdba697a3e0a242b4f0a1b22
188	2026-08-19 09:05:20	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	4830139ffa1015bd5dfbbc7ee8c1f942e8373daefdba697a3e0a242b4f0a1b22	ce25389b057a996581132fb7e9d36ffa1d2eb8fd749ad6fcb5015258fbce4672
189	2026-08-19 09:05:20	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	ce25389b057a996581132fb7e9d36ffa1d2eb8fd749ad6fcb5015258fbce4672	32e506d16f2be6e7ed7527498450abe263fc0ac56290b088c458e9e5f3527572
190	2026-08-19 09:05:20	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	32e506d16f2be6e7ed7527498450abe263fc0ac56290b088c458e9e5f3527572	652aed4f7afb3ee24ebab94c0ff473ad6f9fe6685e34775219bbe3604e3fdb5d
191	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-18"}	652aed4f7afb3ee24ebab94c0ff473ad6f9fe6685e34775219bbe3604e3fdb5d	6943acee1cbc0fe81afda5c2fb13bcc1d2eeda1b458ce160d46c8fbc4c6f1c5e
192	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	6943acee1cbc0fe81afda5c2fb13bcc1d2eeda1b458ce160d46c8fbc4c6f1c5e	6598bf77b8b63544c8774e50f0b101840b7435108ff6639162f03ea87c35c4c1
193	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	6598bf77b8b63544c8774e50f0b101840b7435108ff6639162f03ea87c35c4c1	722a3e4cef5a5267457458936d8793ace57d616cfb415cfc3ce35eaeacca97d1
194	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	722a3e4cef5a5267457458936d8793ace57d616cfb415cfc3ce35eaeacca97d1	1533fd3cf5583bc3f936db4c8db7d215a8ed644235af3237175bc4870e9a9f84
195	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	1533fd3cf5583bc3f936db4c8db7d215a8ed644235af3237175bc4870e9a9f84	7a2c693fc9daaaf6cb5b79888a8be749ddc0763a7574d71cb48b507e006e1628
196	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-23"}	7a2c693fc9daaaf6cb5b79888a8be749ddc0763a7574d71cb48b507e006e1628	7435a4d7a4b66db9af468f8317b620b9f272b9c867746b62a9e7cfcf7ca25938
197	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-25"}	7435a4d7a4b66db9af468f8317b620b9f272b9c867746b62a9e7cfcf7ca25938	74aab3999fdc211853b01e61b10b44f9b551e3cd194f2a2d0dec53a99b8738d2
198	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-25"}	74aab3999fdc211853b01e61b10b44f9b551e3cd194f2a2d0dec53a99b8738d2	078d1a656792c6b048d2e2259d77275588e150fcea45ce64190a8c5456679203
199	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	078d1a656792c6b048d2e2259d77275588e150fcea45ce64190a8c5456679203	956d5e75cdeb649ca093e12d363d7a73c4ab123ccc607fe5d0440f6f42a8452a
200	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-29"}	956d5e75cdeb649ca093e12d363d7a73c4ab123ccc607fe5d0440f6f42a8452a	fb6c84cbcc638aaac633985fb35785166131e946db8cef72edfa06caf341a77b
201	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-29"}	fb6c84cbcc638aaac633985fb35785166131e946db8cef72edfa06caf341a77b	184098414f027ca7a96fd0813aa71a510053037822af38b687276609e9f981d7
202	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-30"}	184098414f027ca7a96fd0813aa71a510053037822af38b687276609e9f981d7	dae24448ad64e17d9b38ce1f4fb2d5ec9cd1096c75240ff38d329605cca00c52
203	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	dae24448ad64e17d9b38ce1f4fb2d5ec9cd1096c75240ff38d329605cca00c52	b06836893a5cba8b85642d1149eff062f61070d8fb053aa19bf58aa568dc6be7
204	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-01"}	b06836893a5cba8b85642d1149eff062f61070d8fb053aa19bf58aa568dc6be7	1cffce2cdf076c4d5334b214c5b17fbd2dfbc5441b2d036f441c04f88c6f754a
205	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-08-01"}	1cffce2cdf076c4d5334b214c5b17fbd2dfbc5441b2d036f441c04f88c6f754a	20913ce94f09bc1eb887de63d942bb5d54a94b5aa80be9fef78653ff08c6507e
206	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	20913ce94f09bc1eb887de63d942bb5d54a94b5aa80be9fef78653ff08c6507e	5deb9f0c12b2fd227f43bd84b6ca3b5075c570a89d199e990c698439776ada0e
207	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-02"}	5deb9f0c12b2fd227f43bd84b6ca3b5075c570a89d199e990c698439776ada0e	2cb05a0eade4675f8c11e9232d99ae18474c7cea0ee9422a7e1a09b66c6a31aa
208	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	2cb05a0eade4675f8c11e9232d99ae18474c7cea0ee9422a7e1a09b66c6a31aa	aa15688242b62e0d9384a8e50ab6fe32654510b7196eb1e92d264b6d7e27c24a
209	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-04"}	aa15688242b62e0d9384a8e50ab6fe32654510b7196eb1e92d264b6d7e27c24a	c6b80220d3a8d9cd414709a4bb53b3ecc9dcd0ed8047382af0752e5a133e8903
210	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-04"}	c6b80220d3a8d9cd414709a4bb53b3ecc9dcd0ed8047382af0752e5a133e8903	b5aa59ec3207b414f5da9ddce3a0467981ba1d354819fb2bf058fb31de1d765d
211	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-04"}	b5aa59ec3207b414f5da9ddce3a0467981ba1d354819fb2bf058fb31de1d765d	5db0c99c4c4487f8763a27903f85c4f76bfd1c97ed491d6db6ede9aa73758dc5
212	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-05"}	5db0c99c4c4487f8763a27903f85c4f76bfd1c97ed491d6db6ede9aa73758dc5	db989b8f8c4418de3dd5e26e532328f19d20cfe92389029280ae0b45a9219974
213	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	db989b8f8c4418de3dd5e26e532328f19d20cfe92389029280ae0b45a9219974	abddd87816992c033214b926f73856679d7ae7104fcac5d69af8b33f05381925
214	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-07"}	abddd87816992c033214b926f73856679d7ae7104fcac5d69af8b33f05381925	039fe3de4c01efc210989cd1fdbee4ae84be58a3a8b5a197839ea9930e416435
215	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-07"}	039fe3de4c01efc210989cd1fdbee4ae84be58a3a8b5a197839ea9930e416435	ed2039f9d9a0588c9e5f3b3c02135e94690a795095950371b67807e655fa3104
216	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	ed2039f9d9a0588c9e5f3b3c02135e94690a795095950371b67807e655fa3104	a659e505cc822c53beb2322e601fb20f7887579188943982e4add617b7cca441
217	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-09"}	a659e505cc822c53beb2322e601fb20f7887579188943982e4add617b7cca441	73c49af75af5b0ad3ca2fa529942ddd1a82ffb031cdfa9492db0e9c54f26b450
218	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-09"}	73c49af75af5b0ad3ca2fa529942ddd1a82ffb031cdfa9492db0e9c54f26b450	cef761d0111856d261f68368f107aa79c7d8799f3a867fe91dc128d40613525b
219	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	cef761d0111856d261f68368f107aa79c7d8799f3a867fe91dc128d40613525b	f8fef2d50da733705c05dfbfac9a0d853f579756546ebbf6be7ee2e93a988620
220	2026-08-19 09:05:20	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-11"}	f8fef2d50da733705c05dfbfac9a0d853f579756546ebbf6be7ee2e93a988620	f6d784ce40051dfc95d8061c8101e247b8467289fa1e48b8ae0eda2e3499bd9f
221	2026-08-19 09:05:20	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	f6d784ce40051dfc95d8061c8101e247b8467289fa1e48b8ae0eda2e3499bd9f	5ee866650cc55fc07442564866f74419fc23f031fc36f42e74db7f78b825abc9
222	2026-08-19 09:05:20	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	5ee866650cc55fc07442564866f74419fc23f031fc36f42e74db7f78b825abc9	f115667ec014d4fe92d47a2d65efda251a8572769d8153773236a7860d5477e0
223	2026-08-19 10:29:02	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T10:29:02.406377"}	f115667ec014d4fe92d47a2d65efda251a8572769d8153773236a7860d5477e0	c2acd3bbdf4e1b67b408f2b2f5fd121c5eb39943afb2639dff035889be0bc87b
224	2026-08-19 10:29:28	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T10:29:28.987244"}	c2acd3bbdf4e1b67b408f2b2f5fd121c5eb39943afb2639dff035889be0bc87b	ea7554352fdc60b63457d3c11323432e7b3727708cb58900a9281773fffbc470
225	2026-08-19 10:29:51	user_login	{"username": "admin", "role": "admin", "method": "password", "ip": "testclient", "time": "2026-08-19T10:29:51.917085"}	ea7554352fdc60b63457d3c11323432e7b3727708cb58900a9281773fffbc470	b30a3ab62dcd3f1bf1c1771762a97cf4f08271fa4e810ea7a6066b469854af94
226	2026-08-19 10:29:52	NOTIF_PUBLISHED_USER_LOGIN	{"event_type": "USER_LOGIN", "warehouse_id": null, "severity": "INFO", "source_entity_id": "1", "source_entity_type": "USER", "recipients_count": 6}	b30a3ab62dcd3f1bf1c1771762a97cf4f08271fa4e810ea7a6066b469854af94	3131cacf09727e26f580ffd35f5c5264f1326e235edf45efc684769eb670c879
\.


--
-- Data for Name: backup_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_records (id, backup_id, filename, created_at, size_bytes, sha256, status, storage_key, error_message) FROM stdin;
1	BK-DA049020A9ED7691	warehouse_sqlite_2026-08-15_12-52-33.db.gz	2026-08-15 12:52:37.900197	57591	2cb59143d8b46715acce3bee8c68a47dd4c2f59e8cf38140799770a06db5350b	FAILED	data/backups/warehouse_sqlite_2026-08-15_12-52-33.db.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
2	BK-503EA0B0E548C2B0	warehouse_sqlite_2026-08-15_13-40-26.db.gz	2026-08-15 13:40:30.907048	58321	b7ade5907b2aea645956bb369ebe9a224ce714295e3c2b61f1ac27ee599803a0	FAILED	data/backups/warehouse_sqlite_2026-08-15_13-40-26.db.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
3	BK-734D48994FBE3917	warehouse_postgres_2026-08-15_15-01-04.sql.gz	2026-08-15 15:01:04.033906	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
4	BK-53D1D7EEB12EA011	warehouse_postgres_2026-08-15_15-01-33.sql.gz	2026-08-15 15:01:37.588028	23045	5fd661b39e81acf7396ff4bc17a66e3e027e57eb02b366724090563da99b489b	FAILED	data/backups/warehouse_postgres_2026-08-15_15-01-33.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
5	BK-C056B388ED2B06C5	warehouse_postgres_2026-08-15_18-46-58.sql.gz	2026-08-15 18:46:58.433478	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
6	BK-084687BC03958C21	warehouse_postgres_2026-08-15_19-46-58.sql.gz	2026-08-15 19:46:58.721681	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
7	BK-80BE0EC4957801A0	warehouse_postgres_2026-08-15_20-46-59.sql.gz	2026-08-15 20:46:59.063067	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
8	BK-27491D98F44844E0	warehouse_postgres_2026-08-16_05-07-36.sql.gz	2026-08-16 05:07:36.369377	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
9	BK-B2C72394440D78AE	warehouse_postgres_2026-08-16_07-09-22.sql.gz	2026-08-16 07:09:22.333943	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
10	BK-14B768057DB11134	warehouse_postgres_2026-08-16_10-41-41.sql.gz	2026-08-16 10:41:41.290469	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
11	BK-89E471803E5E2F61	warehouse_postgres_2026-08-16_14-27-00.sql.gz	2026-08-16 14:27:00.874889	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
12	BK-91A3A46EB7FE2660	warehouse_postgres_2026-08-17_04-38-44.sql.gz	2026-08-17 04:38:44.303452	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
13	BK-CB69B4B642BCAE40	warehouse_postgres_2026-08-17_05-18-30.sql.gz	2026-08-17 05:18:30.601088	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
14	BK-F48D842423DE2A68	warehouse_postgres_2026-08-17_05-18-33.sql.gz	2026-08-17 05:18:33.044259	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
15	BK-626EC2DEF95FDB50	warehouse_postgres_2026-08-17_05-38-44.sql.gz	2026-08-17 05:38:44.47845	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
16	BK-0E8C51C58B69888D	warehouse_postgres_2026-08-17_07-46-31.sql.gz	2026-08-17 07:46:31.673242	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
17	BK-3E1F80FA693E6618	warehouse_postgres_2026-08-17_17-13-07.sql.gz	2026-08-17 17:13:10.736201	25463	2787adc6c92099bb65db355d6eb84b0fc02698d810b0e0bf099c3db38ef00dec	FAILED	data/backups/warehouse_postgres_2026-08-17_17-13-07.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
18	BK-16309FE6074AF3B9	warehouse_postgres_2026-08-17_17-22-33.sql.gz	2026-08-17 17:22:41.231859	25673	777b6473196751d2fbdcd2c420c7ee4e64cbc3c0e88f5d15472e06ecc761517d	FAILED	data/backups/warehouse_postgres_2026-08-17_17-22-33.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
19	BK-7964E0791B49B6C7	warehouse_postgres_2026-08-17_18-07-28.sql.gz	2026-08-17 18:07:31.275304	25765	47589d250cea187bb14f7e52e1b535b7dfc8984efd32bace006f63249d56e057	FAILED	data/backups/warehouse_postgres_2026-08-17_18-07-28.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
20	BK-81C7A3B320BBC4E2	warehouse_postgres_2026-08-17_18-16-09.sql.gz	2026-08-17 18:16:13.456681	27923	169108aee85fba500294c18b3759a950a61c799953ae51412eaf7bbb89e4ac96	FAILED	data/backups/warehouse_postgres_2026-08-17_18-16-09.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
21	BK-7C6CAAEC1F85A669	warehouse_postgres_2026-08-17_18-28-49.sql.gz	2026-08-17 18:28:55.923098	28002	ea6836c917a425302f7896a9fd5779148136111142726b476a8479fbb7eba390	FAILED	data/backups/warehouse_postgres_2026-08-17_18-28-49.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
22	BK-D13E6FC9A76D1EDE	warehouse_postgres_2026-08-18_03-46-42.sql.gz	2026-08-18 03:46:54.33189	28100	6110ab3d6c92d2b9d2d2d4681850b17e8255ca30958394a69f3b6eba02042b7c	FAILED	data/backups/warehouse_postgres_2026-08-18_03-46-42.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
23	BK-55A83B1C16389575	warehouse_postgres_2026-08-18_04-46-54.sql.gz	2026-08-18 04:48:27.370054	28528	dd97d50055a2b208084e84be2b67e8cc74e18724c3dffcb7b4a181555a1416c4	FAILED	data/backups/warehouse_postgres_2026-08-18_04-46-54.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
24	BK-996F9EC8FE432CE7	warehouse_postgres_2026-08-18_05-14-01.sql.gz	2026-08-18 05:14:04.911897	28614	a4a1883eded863bebfeb371dc66826b41fa08a31b991407d6fd50fd9a8918d13	FAILED	data/backups/warehouse_postgres_2026-08-18_05-14-01.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
25	BK-D98D847F8B68056F	warehouse_postgres_2026-08-18_05-19-31.sql.gz	2026-08-18 05:19:35.152464	28693	c98faee76156eb580540d928768ee833dbf447146660965ef5023deddc62bd42	FAILED	data/backups/warehouse_postgres_2026-08-18_05-19-31.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
26	BK-598055BA416B3EBA	warehouse_postgres_2026-08-18_13-42-13.sql.gz	2026-08-18 13:42:15.825328	28885	42df9a441847eeadc3de16a14fb95ee165a915afe3b2a9dc5c1cf20e84981940	FAILED	data/backups/warehouse_postgres_2026-08-18_13-42-13.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
27	BK-FB8AF44C4843E8CA	warehouse_postgres_2026-08-18_15-26-27.sql.gz	2026-08-18 15:26:32.438932	31350	ae41cc4eabe9f6bb5330165547640076ef7a39dd76835699cf4e650aebf7d8ba	FAILED	data/backups/warehouse_postgres_2026-08-18_15-26-27.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
28	BK-415CDA14E78E8075	warehouse_postgres_2026-08-18_18-47-29.sql.gz	2026-08-18 18:47:36.386594	33178	1e73fee4a75e547ac2ff805c851cabdfc57fd09eabb4169e615372b2513715e4	FAILED	data/backups/warehouse_postgres_2026-08-18_18-47-29.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
29	BK-DC1EE3B10980DCD1	warehouse_postgres_2026-08-18_19-04-50.sql.gz	2026-08-18 19:05:54.239843	37001	20af0074903f6473aaac443fb1ea60e6630c9fefa4127408dc0c42a9b975a9f0	FAILED	data/backups/warehouse_postgres_2026-08-18_19-04-50.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
30	BK-AADFE4E1AEC524B1	warehouse_postgres_2026-08-18_19-55-24.sql.gz	2026-08-18 19:55:31.087932	38962	5310ab431d1b4f61a5368f1010f9f4897f1f300b4f6c9e15ef8fdf4f101f2ff7	FAILED	data/backups/warehouse_postgres_2026-08-18_19-55-24.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
31	BK-F1B81E8EB8DF46E6	warehouse_postgres_2026-08-18_22-03-58.sql.gz	2026-08-19 00:47:07.409344	39781	9fea5de8e6e81568fe26bd8c9c6b57db7a17cdc1fa9646ebc7a3a78f33083fcd	FAILED	data/backups/warehouse_postgres_2026-08-18_22-03-58.sql.gz	B2 Upload failed: Could not connect to the endpoint URL: "https://s3.us-east-005.backblazeb2.com/harsha-warehouse-backups/database-backups/warehouse_postgres_2026-08-18_22-03-58.sql.gz"
32	BK-6F9CD6ED1340208C	warehouse_postgres_2026-08-19_06-10-16.sql.gz	2026-08-19 06:11:53.305948	40637	3c9f88aecd099e0c8ed089db08f54120498be380dfc9c129b72507369011c2d9	FAILED	data/backups/warehouse_postgres_2026-08-19_06-10-16.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
33	BK-F9E76872559EB192	warehouse_postgres_2026-08-19_07-13-26.sql.gz	2026-08-19 07:13:36.980394	41901	7967d77852b116fae267b1e8912113dcfe7e901ce60285d8eb57e6c2062b6a23	FAILED	data/backups/warehouse_postgres_2026-08-19_07-13-26.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
\.


--
-- Data for Name: digital_twin_simulations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.digital_twin_simulations (id, warehouse_id, simulation_status, simulation_time_seconds, speed_multiplier, seed, mode, scenario_type, tick_count, created_at, started_at, paused_at, stopped_at, completed_at, error_message, created_by) FROM stdin;
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (id, warehouse_id, item_id, location_id, on_hand, reserved, available, damaged, created_at, updated_at) FROM stdin;
1	WH-BLR-01	ITM-CPU-01	WH-WH-BLR-01-LOC-ITM-CPU-01-STORAGE	57	0	57	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
2	WH-BLR-01	ITM-GPU-01	WH-WH-BLR-01-LOC-ITM-GPU-01-STORAGE	35	0	35	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
3	WH-BLR-01	ITM-RAM-01	WH-WH-BLR-01-LOC-ITM-RAM-01-STORAGE	42	0	42	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
4	WH-BLR-01	ITM-SSD-01	WH-WH-BLR-01-LOC-ITM-SSD-01-STORAGE	52	0	52	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
5	WH-BLR-01	ITM-HDD-01	WH-WH-BLR-01-LOC-ITM-HDD-01-STORAGE	82	0	82	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
6	WH-BLR-01	ITM-CHG-01	WH-WH-BLR-01-LOC-ITM-CHG-01-STORAGE	113	0	113	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
7	WH-BLR-01	ITM-CBL-01	WH-WH-BLR-01-LOC-ITM-CBL-01-STORAGE	432	0	432	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
8	WH-CHN-01	ITM-CPU-01	WH-WH-CHN-01-LOC-ITM-CPU-01-STORAGE	29	0	29	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
9	WH-CHN-01	ITM-GPU-01	WH-WH-CHN-01-LOC-ITM-GPU-01-STORAGE	15	0	15	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
10	WH-CHN-01	ITM-RAM-01	WH-WH-CHN-01-LOC-ITM-RAM-01-STORAGE	75	0	75	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
11	WH-CHN-01	ITM-SSD-01	WH-WH-CHN-01-LOC-ITM-SSD-01-STORAGE	50	0	50	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
12	WH-CHN-01	ITM-HDD-01	WH-WH-CHN-01-LOC-ITM-HDD-01-STORAGE	89	0	89	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
13	WH-CHN-01	ITM-CHG-01	WH-WH-CHN-01-LOC-ITM-CHG-01-STORAGE	149	0	149	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
14	WH-CHN-01	ITM-CBL-01	WH-WH-CHN-01-LOC-ITM-CBL-01-STORAGE	146	0	146	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
15	WH-BOM-01	ITM-CPU-01	WH-WH-BOM-01-LOC-ITM-CPU-01-STORAGE	53	0	53	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
16	WH-BOM-01	ITM-GPU-01	WH-WH-BOM-01-LOC-ITM-GPU-01-STORAGE	40	0	40	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
17	WH-BOM-01	ITM-RAM-01	WH-WH-BOM-01-LOC-ITM-RAM-01-STORAGE	53	0	53	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
18	WH-BOM-01	ITM-SSD-01	WH-WH-BOM-01-LOC-ITM-SSD-01-STORAGE	53	0	53	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
19	WH-BOM-01	ITM-HDD-01	WH-WH-BOM-01-LOC-ITM-HDD-01-STORAGE	83	0	83	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
20	WH-BOM-01	ITM-CHG-01	WH-WH-BOM-01-LOC-ITM-CHG-01-STORAGE	144	0	144	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
21	WH-BOM-01	ITM-CBL-01	WH-WH-BOM-01-LOC-ITM-CBL-01-STORAGE	151	0	151	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
22	WH-DEL-01	ITM-CPU-01	WH-WH-DEL-01-LOC-ITM-CPU-01-STORAGE	51	0	51	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
23	WH-DEL-01	ITM-GPU-01	WH-WH-DEL-01-LOC-ITM-GPU-01-STORAGE	42	0	42	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
24	WH-DEL-01	ITM-RAM-01	WH-WH-DEL-01-LOC-ITM-RAM-01-STORAGE	65	0	65	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
25	WH-DEL-01	ITM-SSD-01	WH-WH-DEL-01-LOC-ITM-SSD-01-STORAGE	56	0	56	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
26	WH-DEL-01	ITM-HDD-01	WH-WH-DEL-01-LOC-ITM-HDD-01-STORAGE	74	0	74	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
27	WH-DEL-01	ITM-CHG-01	WH-WH-DEL-01-LOC-ITM-CHG-01-STORAGE	108	0	108	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
28	WH-DEL-01	ITM-CBL-01	WH-WH-DEL-01-LOC-ITM-CBL-01-STORAGE	168	0	168	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
29	WH-CCU-01	ITM-CPU-01	WH-WH-CCU-01-LOC-ITM-CPU-01-STORAGE	58	0	58	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
30	WH-CCU-01	ITM-GPU-01	WH-WH-CCU-01-LOC-ITM-GPU-01-STORAGE	34	0	34	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
31	WH-CCU-01	ITM-RAM-01	WH-WH-CCU-01-LOC-ITM-RAM-01-STORAGE	95	0	95	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
32	WH-CCU-01	ITM-SSD-01	WH-WH-CCU-01-LOC-ITM-SSD-01-STORAGE	61	0	61	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
33	WH-CCU-01	ITM-HDD-01	WH-WH-CCU-01-LOC-ITM-HDD-01-STORAGE	30	0	30	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
34	WH-CCU-01	ITM-CHG-01	WH-WH-CCU-01-LOC-ITM-CHG-01-STORAGE	115	0	115	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
35	WH-CCU-01	ITM-CBL-01	WH-WH-CCU-01-LOC-ITM-CBL-01-STORAGE	423	0	423	0	2026-08-19 09:05:20.876101	2026-08-19 09:05:20.876101
\.


--
-- Data for Name: inventory_reservations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_reservations (id, order_id, item_id, location_id, reserved_qty, released_qty, created_at) FROM stdin;
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id, name, category, unit_cost, lead_time_days, safety_stock, created_at, sku, description, unit, weight_kg, dimensions, barcode, is_active, reorder_threshold, preferred_storage_type) FROM stdin;
ITM-CPU-01	AMD Ryzen 9 7900X Processor	Electronics	38000	5	15	2026-08-19 09:05:20.501043	\N	\N	units	0		\N	t	20	STORAGE
ITM-GPU-01	Nvidia RTX 4080 Founders Edition	Electronics	95000	7	10	2026-08-19 09:05:20.505045	\N	\N	units	0		\N	t	20	STORAGE
ITM-RAM-01	Corsair DDR5 32GB 6000MHz RAM	Electronics	8500	4	25	2026-08-19 09:05:20.507272	\N	\N	units	0		\N	t	20	STORAGE
ITM-SSD-01	Samsung 990 Pro 2TB NVMe SSD	Storage	12000	3	30	2026-08-19 09:05:20.509868	\N	\N	units	0		\N	t	20	STORAGE
ITM-HDD-01	WD Red Pro 8TB NAS Hard Drive	Storage	16500	5	20	2026-08-19 09:05:20.514992	\N	\N	units	0		\N	t	20	STORAGE
ITM-CHG-01	Anker 100W GaN Wall Charger	Accessories	2500	2	50	2026-08-19 09:05:20.517996	\N	\N	units	0		\N	t	20	STORAGE
ITM-CBL-01	Apple USB-C Braided Cable 2m	Accessories	800	1	100	2026-08-19 09:05:20.520303	\N	\N	units	0		\N	t	20	STORAGE
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_preferences (id, user_id, category, in_app_enabled, email_enabled, min_severity, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, warehouse_id, event_type, notification_type, title, message, severity, status, channel, source_entity_type, source_entity_id, created_at, read_at, delivered_at, failed_at, retry_count, expires_at, metadata, idempotency_key) FROM stdin;
1	3	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 10:29:02.439352	\N	2026-08-19 10:29:02.481828	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_3_1787115542.439352
2	3	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	QUEUED	EMAIL	USER	1	2026-08-19 10:29:02.439352	\N	\N	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	email_USER_LOGIN_1_3_1787115542.439352
3	4	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 10:29:29.003034	\N	2026-08-19 10:29:29.036058	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_4_1787115569.003034
4	4	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	QUEUED	EMAIL	USER	1	2026-08-19 10:29:29.003034	\N	\N	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	email_USER_LOGIN_1_4_1787115569.003034
5	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 10:29:29.003034	\N	2026-08-19 10:29:29.062399	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_5_1787115569.003034
6	5	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	QUEUED	EMAIL	USER	1	2026-08-19 10:29:29.003034	\N	\N	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	email_USER_LOGIN_1_5_1787115569.003034
7	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 10:29:29.003034	\N	2026-08-19 10:29:29.077385	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_2_1787115569.003034
8	2	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	QUEUED	EMAIL	USER	1	2026-08-19 10:29:29.003034	\N	\N	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	email_USER_LOGIN_1_2_1787115569.003034
9	9	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 10:29:29.003034	\N	2026-08-19 10:29:29.090388	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_9_1787115569.003034
10	9	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	QUEUED	EMAIL	USER	1	2026-08-19 10:29:29.003034	\N	\N	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	email_USER_LOGIN_1_9_1787115569.003034
11	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	DELIVERED	IN_APP	USER	1	2026-08-19 10:29:29.003034	\N	2026-08-19 10:29:29.101386	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	USER_LOGIN_1_1_1787115569.003034
12	1	\N	USER_LOGIN	SECURITY_ALERT	User Login Alert	User admin logged in successfully.	INFO	QUEUED	EMAIL	USER	1	2026-08-19 10:29:29.003034	\N	\N	\N	0	\N	{"username": "admin", "message": "User admin logged in successfully."}	email_USER_LOGIN_1_1_1787115569.003034
\.


--
-- Data for Name: order_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_events (id, order_id, "timestamp", status, event_type, operator, notes) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, order_id, item_id, requested_qty, reserved_qty, picked_qty, packed_qty, shipped_qty, status) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, customer_ref, warehouse_id, created_at, updated_at, status, priority, total_items, notes, created_by) FROM stdin;
\.


--
-- Data for Name: otp_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.otp_records (id, user_id, purpose, code_hash, expires_at, attempts, max_attempts, consumed_at, created_at, request_ip, context_data) FROM stdin;
2	1	ADMIN_CREATION	$2b$12$/SamnHAvQbMw61FRaCwPM.3U.lGawZyrU.V.pTxdWhuK9MH0MAIW2	2026-08-19 10:40:00.049258	0	5	\N	2026-08-19 10:30:00.049258	testclient	{"target_email": "sectest@gmail.com", "full_name": "Sec Test Admin", "target_role": "admin"}
\.


--
-- Data for Name: packing_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.packing_records (id, order_id, status, started_at, completed_at, operator, package_count, weight_kg, notes) FROM stdin;
\.


--
-- Data for Name: recovery_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recovery_codes (id, user_id, code_hash, used, created_at, used_at) FROM stdin;
\.


--
-- Data for Name: recovery_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recovery_credentials (id, user_id, password_hash, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: robot_reservations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robot_reservations (id, robot_id, warehouse_id, x, y, tick) FROM stdin;
\.


--
-- Data for Name: robot_routes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robot_routes (id, robot_id, task_id, warehouse_id, start_x, start_y, goal_x, goal_y, algorithm, path_data, distance, cost, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: robot_telemetry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robot_telemetry (id, robot_id, event_type, "timestamp", x, y, battery, status, task_id, metadata) FROM stdin;
\.


--
-- Data for Name: robots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robots (id, robot_code, name, warehouse_id, status, battery_level, current_location_id, current_x, current_y, target_location_id, target_x, target_y, assigned_task_id, total_tasks_completed, total_distance, total_operating_time, utilization_percent, failure_count, created_at, updated_at, last_heartbeat_at, robot_type, max_payload, max_speed, enabled, metadata) FROM stdin;
1	RB-BLR-01	Bangalore AGV 01	WH-BLR-01	CHARGING	100	WH-WH-BLR-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	AGV	200	1.5	t	{}
2	RB-BLR-02	Bangalore AGV 02	WH-BLR-01	CHARGING	100	WH-WH-BLR-01-CHARGING-2	12	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	AGV	200	1.5	t	{}
3	RB-BLR-03	Bangalore AGV 03	WH-BLR-01	IDLE	92.5	WH-WH-BLR-01-RECEIVING	1	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	AGV	200	1.5	t	{}
4	RB-CHN-01	Chennai AGV 01	WH-CHN-01	CHARGING	100	WH-WH-CHN-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	AGV	200	1.5	t	{}
5	RB-BOM-01	Mumbai AGV 01	WH-BOM-01	CHARGING	100	WH-WH-BOM-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	AGV	200	1.5	t	{}
6	RB-DEL-01	Delhi AGV 01	WH-DEL-01	CHARGING	100	WH-WH-DEL-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	AGV	200	1.5	t	{}
7	RB-CCU-01	Kolkata AGV 01	WH-CCU-01	CHARGING	100	WH-WH-CCU-01-CHARGING-1	11	5	\N	0	0	\N	0	0	0	0	0	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	2026-08-19 09:05:20.891104	AGV	200	1.5	t	{}
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipments (id, order_id, status, tracking_reference, carrier, created_at, shipped_at, delivered_at) FROM stdin;
\.


--
-- Data for Name: shrinkage_flags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shrinkage_flags (id, date, warehouse_id, item_id, item_name, deviation_score, expected_quantity, actual_quantity, discrepancy_quantity, estimated_exposure, severity, likely_cause, explanation) FROM stdin;
5	2026-08-05	WH-BLR-01	ITM-GPU-01	Nvidia RTX 4080 Founders Edition	0.85	15	5	-10	950000	CRITICAL	UNUSUAL_OUTBOUND_ACTIVITY	Sudden unrecorded drop of 10 units (Valued at ₹9,50,000) occurred outside regular stock-out operations.
6	2026-07-25	WH-CHN-01	ITM-CPU-01	AMD Ryzen 9 7900X Processor	0.72	20	5	-15	570000	HIGH	POSSIBLE_DAMAGE_OR_WASTAGE	Discrepancy of 15 units (Valued at ₹5,70,000) reported at the dock. Unrecorded scraping suspected.
\.


--
-- Data for Name: simulation_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.simulation_events (id, simulation_id, warehouse_id, event_type, severity, sim_time_seconds, real_timestamp, robot_id, task_id, location_id, route_id, message, metadata) FROM stdin;
\.


--
-- Data for Name: simulation_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.simulation_snapshots (id, simulation_id, warehouse_id, snapshot_version, taken_at, sim_time_seconds, robot_states, task_states, obstacle_states, sim_inventory_delta, metadata) FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, date, warehouse_id, item_id, stock_in, stock_out, closing_stock, is_anomaly, anomaly_type, entry_source, entered_by) FROM stdin;
2103	2026-07-13	WH-BLR-01	ITM-CPU-01	0	1	44	f	none	simulated	system_sim
2104	2026-07-13	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
2105	2026-07-13	WH-BLR-01	ITM-RAM-01	0	9	66	f	none	simulated	system_sim
2106	2026-07-13	WH-BLR-01	ITM-SSD-01	0	1	89	f	none	simulated	system_sim
2107	2026-07-13	WH-BLR-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
2108	2026-07-13	WH-BLR-01	ITM-CHG-01	0	10	140	f	none	simulated	system_sim
2109	2026-07-13	WH-BLR-01	ITM-CBL-01	0	2	298	f	none	simulated	system_sim
2110	2026-07-13	WH-CHN-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
2111	2026-07-13	WH-CHN-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
2112	2026-07-13	WH-CHN-01	ITM-RAM-01	0	7	68	f	none	simulated	system_sim
2113	2026-07-13	WH-CHN-01	ITM-SSD-01	0	3	87	f	none	simulated	system_sim
2114	2026-07-13	WH-CHN-01	ITM-HDD-01	0	2	58	f	none	simulated	system_sim
2115	2026-07-13	WH-CHN-01	ITM-CHG-01	0	5	145	f	none	simulated	system_sim
2116	2026-07-13	WH-CHN-01	ITM-CBL-01	0	2	298	f	none	simulated	system_sim
2117	2026-07-13	WH-BOM-01	ITM-CPU-01	0	2	43	f	none	simulated	system_sim
2118	2026-07-13	WH-BOM-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
2119	2026-07-13	WH-BOM-01	ITM-RAM-01	0	10	65	f	none	simulated	system_sim
2120	2026-07-13	WH-BOM-01	ITM-SSD-01	0	3	87	f	none	simulated	system_sim
2121	2026-07-13	WH-BOM-01	ITM-HDD-01	0	1	59	f	none	simulated	system_sim
2122	2026-07-13	WH-BOM-01	ITM-CHG-01	0	4	146	f	none	simulated	system_sim
2123	2026-07-13	WH-BOM-01	ITM-CBL-01	0	10	290	f	none	simulated	system_sim
2124	2026-07-13	WH-DEL-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
2125	2026-07-13	WH-DEL-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
2126	2026-07-13	WH-DEL-01	ITM-RAM-01	0	6	69	f	none	simulated	system_sim
2127	2026-07-13	WH-DEL-01	ITM-SSD-01	0	2	88	f	none	simulated	system_sim
2128	2026-07-13	WH-DEL-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
2129	2026-07-13	WH-DEL-01	ITM-CHG-01	0	10	140	f	none	simulated	system_sim
2130	2026-07-13	WH-DEL-01	ITM-CBL-01	0	2	298	f	none	simulated	system_sim
2131	2026-07-13	WH-CCU-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
2132	2026-07-13	WH-CCU-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
2133	2026-07-13	WH-CCU-01	ITM-RAM-01	0	3	72	f	none	simulated	system_sim
2134	2026-07-13	WH-CCU-01	ITM-SSD-01	0	0	90	f	none	simulated	system_sim
2135	2026-07-13	WH-CCU-01	ITM-HDD-01	0	1	59	f	none	simulated	system_sim
2136	2026-07-13	WH-CCU-01	ITM-CHG-01	0	7	143	f	none	simulated	system_sim
2137	2026-07-13	WH-CCU-01	ITM-CBL-01	0	5	295	f	none	simulated	system_sim
2138	2026-07-14	WH-BLR-01	ITM-CPU-01	0	2	42	f	none	simulated	system_sim
2139	2026-07-14	WH-BLR-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
2140	2026-07-14	WH-BLR-01	ITM-RAM-01	0	6	60	f	none	simulated	system_sim
2141	2026-07-14	WH-BLR-01	ITM-SSD-01	0	1	88	f	none	simulated	system_sim
2142	2026-07-14	WH-BLR-01	ITM-HDD-01	0	1	59	f	none	simulated	system_sim
2143	2026-07-14	WH-BLR-01	ITM-CHG-01	0	7	133	f	none	simulated	system_sim
2144	2026-07-14	WH-BLR-01	ITM-CBL-01	0	8	290	f	none	simulated	system_sim
2145	2026-07-14	WH-CHN-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
2146	2026-07-14	WH-CHN-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
2147	2026-07-14	WH-CHN-01	ITM-RAM-01	0	2	66	f	none	simulated	system_sim
2148	2026-07-14	WH-CHN-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
2149	2026-07-14	WH-CHN-01	ITM-HDD-01	0	1	57	f	none	simulated	system_sim
2150	2026-07-14	WH-CHN-01	ITM-CHG-01	0	7	138	f	none	simulated	system_sim
2151	2026-07-14	WH-CHN-01	ITM-CBL-01	0	1	297	f	none	simulated	system_sim
2152	2026-07-14	WH-BOM-01	ITM-CPU-01	0	0	43	f	none	simulated	system_sim
2153	2026-07-14	WH-BOM-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
2154	2026-07-14	WH-BOM-01	ITM-RAM-01	0	1	64	f	none	simulated	system_sim
2155	2026-07-14	WH-BOM-01	ITM-SSD-01	0	3	84	f	none	simulated	system_sim
2156	2026-07-14	WH-BOM-01	ITM-HDD-01	0	0	59	f	none	simulated	system_sim
2157	2026-07-14	WH-BOM-01	ITM-CHG-01	0	8	138	f	none	simulated	system_sim
2158	2026-07-14	WH-BOM-01	ITM-CBL-01	0	1	289	f	none	simulated	system_sim
2159	2026-07-14	WH-DEL-01	ITM-CPU-01	0	1	44	f	none	simulated	system_sim
2160	2026-07-14	WH-DEL-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
2161	2026-07-14	WH-DEL-01	ITM-RAM-01	0	10	59	f	none	simulated	system_sim
2162	2026-07-14	WH-DEL-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
2163	2026-07-14	WH-DEL-01	ITM-HDD-01	0	2	58	f	none	simulated	system_sim
2164	2026-07-14	WH-DEL-01	ITM-CHG-01	0	10	130	f	none	simulated	system_sim
2165	2026-07-14	WH-DEL-01	ITM-CBL-01	0	1	297	f	none	simulated	system_sim
2166	2026-07-14	WH-CCU-01	ITM-CPU-01	0	2	40	f	none	simulated	system_sim
2167	2026-07-14	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
2168	2026-07-14	WH-CCU-01	ITM-RAM-01	0	3	69	f	none	simulated	system_sim
2169	2026-07-14	WH-CCU-01	ITM-SSD-01	0	3	87	f	none	simulated	system_sim
2170	2026-07-14	WH-CCU-01	ITM-HDD-01	0	1	58	f	none	simulated	system_sim
2171	2026-07-14	WH-CCU-01	ITM-CHG-01	0	5	138	f	none	simulated	system_sim
2172	2026-07-14	WH-CCU-01	ITM-CBL-01	0	4	291	f	none	simulated	system_sim
2173	2026-07-15	WH-BLR-01	ITM-CPU-01	0	3	39	f	none	simulated	system_sim
2174	2026-07-15	WH-BLR-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
2175	2026-07-15	WH-BLR-01	ITM-RAM-01	0	10	50	f	none	simulated	system_sim
2176	2026-07-15	WH-BLR-01	ITM-SSD-01	0	2	86	f	none	simulated	system_sim
2177	2026-07-15	WH-BLR-01	ITM-HDD-01	0	1	58	f	none	simulated	system_sim
2178	2026-07-15	WH-BLR-01	ITM-CHG-01	0	9	124	f	none	simulated	system_sim
2179	2026-07-15	WH-BLR-01	ITM-CBL-01	0	10	280	f	none	simulated	system_sim
2180	2026-07-15	WH-CHN-01	ITM-CPU-01	0	2	40	f	none	simulated	system_sim
2181	2026-07-15	WH-CHN-01	ITM-GPU-01	0	1	28	f	none	simulated	system_sim
2182	2026-07-15	WH-CHN-01	ITM-RAM-01	0	4	62	f	none	simulated	system_sim
2183	2026-07-15	WH-CHN-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
2184	2026-07-15	WH-CHN-01	ITM-HDD-01	0	0	57	f	none	simulated	system_sim
2185	2026-07-15	WH-CHN-01	ITM-CHG-01	0	5	133	f	none	simulated	system_sim
2186	2026-07-15	WH-CHN-01	ITM-CBL-01	0	5	292	f	none	simulated	system_sim
2187	2026-07-15	WH-BOM-01	ITM-CPU-01	0	0	43	f	none	simulated	system_sim
2188	2026-07-15	WH-BOM-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
2189	2026-07-15	WH-BOM-01	ITM-RAM-01	0	1	63	f	none	simulated	system_sim
2190	2026-07-15	WH-BOM-01	ITM-SSD-01	0	3	81	f	none	simulated	system_sim
2191	2026-07-15	WH-BOM-01	ITM-HDD-01	0	1	58	f	none	simulated	system_sim
2192	2026-07-15	WH-BOM-01	ITM-CHG-01	0	4	134	f	none	simulated	system_sim
2193	2026-07-15	WH-BOM-01	ITM-CBL-01	0	3	286	f	none	simulated	system_sim
2194	2026-07-15	WH-DEL-01	ITM-CPU-01	0	0	44	f	none	simulated	system_sim
2195	2026-07-15	WH-DEL-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
2196	2026-07-15	WH-DEL-01	ITM-RAM-01	0	5	54	f	none	simulated	system_sim
2197	2026-07-15	WH-DEL-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
2198	2026-07-15	WH-DEL-01	ITM-HDD-01	0	2	56	f	none	simulated	system_sim
2199	2026-07-15	WH-DEL-01	ITM-CHG-01	0	10	120	f	none	simulated	system_sim
2200	2026-07-15	WH-DEL-01	ITM-CBL-01	0	10	287	f	none	simulated	system_sim
2201	2026-07-15	WH-CCU-01	ITM-CPU-01	0	0	40	f	none	simulated	system_sim
2202	2026-07-15	WH-CCU-01	ITM-GPU-01	0	2	27	f	none	simulated	system_sim
2203	2026-07-15	WH-CCU-01	ITM-RAM-01	0	6	63	f	none	simulated	system_sim
2204	2026-07-15	WH-CCU-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
2205	2026-07-15	WH-CCU-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
2206	2026-07-15	WH-CCU-01	ITM-CHG-01	0	5	133	f	none	simulated	system_sim
2207	2026-07-15	WH-CCU-01	ITM-CBL-01	0	1	290	f	none	simulated	system_sim
2208	2026-07-16	WH-BLR-01	ITM-CPU-01	0	1	38	f	none	simulated	system_sim
2209	2026-07-16	WH-BLR-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
2210	2026-07-16	WH-BLR-01	ITM-RAM-01	0	8	42	f	none	simulated	system_sim
2211	2026-07-16	WH-BLR-01	ITM-SSD-01	0	0	86	f	none	simulated	system_sim
2212	2026-07-16	WH-BLR-01	ITM-HDD-01	0	2	56	f	none	simulated	system_sim
2213	2026-07-16	WH-BLR-01	ITM-CHG-01	0	5	119	f	none	simulated	system_sim
2214	2026-07-16	WH-BLR-01	ITM-CBL-01	0	5	275	f	none	simulated	system_sim
2215	2026-07-16	WH-CHN-01	ITM-CPU-01	0	3	37	f	none	simulated	system_sim
2216	2026-07-16	WH-CHN-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
2217	2026-07-16	WH-CHN-01	ITM-RAM-01	0	10	52	f	none	simulated	system_sim
2218	2026-07-16	WH-CHN-01	ITM-SSD-01	0	2	85	f	none	simulated	system_sim
2219	2026-07-16	WH-CHN-01	ITM-HDD-01	0	0	57	f	none	simulated	system_sim
2220	2026-07-16	WH-CHN-01	ITM-CHG-01	0	2	131	f	none	simulated	system_sim
2221	2026-07-16	WH-CHN-01	ITM-CBL-01	0	2	290	f	none	simulated	system_sim
2222	2026-07-16	WH-BOM-01	ITM-CPU-01	0	0	43	f	none	simulated	system_sim
2223	2026-07-16	WH-BOM-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
2224	2026-07-16	WH-BOM-01	ITM-RAM-01	0	3	60	f	none	simulated	system_sim
2225	2026-07-16	WH-BOM-01	ITM-SSD-01	0	0	81	f	none	simulated	system_sim
2226	2026-07-16	WH-BOM-01	ITM-HDD-01	0	3	55	f	none	simulated	system_sim
2227	2026-07-16	WH-BOM-01	ITM-CHG-01	0	5	129	f	none	simulated	system_sim
2228	2026-07-16	WH-BOM-01	ITM-CBL-01	0	6	280	f	none	simulated	system_sim
2229	2026-07-16	WH-DEL-01	ITM-CPU-01	0	1	43	f	none	simulated	system_sim
2230	2026-07-16	WH-DEL-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
2231	2026-07-16	WH-DEL-01	ITM-RAM-01	0	5	49	f	none	simulated	system_sim
2232	2026-07-16	WH-DEL-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
2233	2026-07-16	WH-DEL-01	ITM-HDD-01	0	0	56	f	none	simulated	system_sim
2234	2026-07-16	WH-DEL-01	ITM-CHG-01	0	4	116	f	none	simulated	system_sim
2235	2026-07-16	WH-DEL-01	ITM-CBL-01	0	3	284	f	none	simulated	system_sim
2236	2026-07-16	WH-CCU-01	ITM-CPU-01	0	2	38	f	none	simulated	system_sim
2237	2026-07-16	WH-CCU-01	ITM-GPU-01	0	1	26	f	none	simulated	system_sim
2238	2026-07-16	WH-CCU-01	ITM-RAM-01	0	4	59	f	none	simulated	system_sim
2239	2026-07-16	WH-CCU-01	ITM-SSD-01	0	2	85	f	none	simulated	system_sim
2240	2026-07-16	WH-CCU-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
2241	2026-07-16	WH-CCU-01	ITM-CHG-01	0	1	132	f	none	simulated	system_sim
2242	2026-07-16	WH-CCU-01	ITM-CBL-01	0	10	280	f	none	simulated	system_sim
2243	2026-07-17	WH-BLR-01	ITM-CPU-01	0	1	37	f	none	simulated	system_sim
2244	2026-07-17	WH-BLR-01	ITM-GPU-01	0	1	28	f	none	simulated	system_sim
2245	2026-07-17	WH-BLR-01	ITM-RAM-01	0	7	35	f	none	simulated	system_sim
2246	2026-07-17	WH-BLR-01	ITM-SSD-01	0	2	84	f	none	simulated	system_sim
2247	2026-07-17	WH-BLR-01	ITM-HDD-01	0	1	55	f	none	simulated	system_sim
2248	2026-07-17	WH-BLR-01	ITM-CHG-01	0	8	111	f	none	simulated	system_sim
2249	2026-07-17	WH-BLR-01	ITM-CBL-01	0	1	274	f	none	simulated	system_sim
2250	2026-07-17	WH-CHN-01	ITM-CPU-01	0	3	34	f	none	simulated	system_sim
2251	2026-07-17	WH-CHN-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
2252	2026-07-17	WH-CHN-01	ITM-RAM-01	0	1	51	f	none	simulated	system_sim
2253	2026-07-17	WH-CHN-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
2254	2026-07-17	WH-CHN-01	ITM-HDD-01	0	3	54	f	none	simulated	system_sim
2255	2026-07-17	WH-CHN-01	ITM-CHG-01	0	4	127	f	none	simulated	system_sim
2256	2026-07-17	WH-CHN-01	ITM-CBL-01	0	2	288	f	none	simulated	system_sim
2257	2026-07-17	WH-BOM-01	ITM-CPU-01	0	0	43	f	none	simulated	system_sim
2258	2026-07-17	WH-BOM-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
2259	2026-07-17	WH-BOM-01	ITM-RAM-01	0	8	52	f	none	simulated	system_sim
2260	2026-07-17	WH-BOM-01	ITM-SSD-01	0	1	80	f	none	simulated	system_sim
2261	2026-07-17	WH-BOM-01	ITM-HDD-01	0	2	53	f	none	simulated	system_sim
2262	2026-07-17	WH-BOM-01	ITM-CHG-01	0	9	120	f	none	simulated	system_sim
2263	2026-07-17	WH-BOM-01	ITM-CBL-01	0	10	270	f	none	simulated	system_sim
2264	2026-07-17	WH-DEL-01	ITM-CPU-01	0	2	41	f	none	simulated	system_sim
2265	2026-07-17	WH-DEL-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
2266	2026-07-17	WH-DEL-01	ITM-RAM-01	0	3	46	f	none	simulated	system_sim
2267	2026-07-17	WH-DEL-01	ITM-SSD-01	0	2	86	f	none	simulated	system_sim
2268	2026-07-17	WH-DEL-01	ITM-HDD-01	0	2	54	f	none	simulated	system_sim
2269	2026-07-17	WH-DEL-01	ITM-CHG-01	0	9	107	f	none	simulated	system_sim
2270	2026-07-17	WH-DEL-01	ITM-CBL-01	0	9	275	f	none	simulated	system_sim
2271	2026-07-17	WH-CCU-01	ITM-CPU-01	0	0	38	f	none	simulated	system_sim
2272	2026-07-17	WH-CCU-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
2273	2026-07-17	WH-CCU-01	ITM-RAM-01	0	7	52	f	none	simulated	system_sim
2274	2026-07-17	WH-CCU-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
2275	2026-07-17	WH-CCU-01	ITM-HDD-01	0	2	56	f	none	simulated	system_sim
2276	2026-07-17	WH-CCU-01	ITM-CHG-01	0	2	130	f	none	simulated	system_sim
2277	2026-07-17	WH-CCU-01	ITM-CBL-01	0	4	276	f	none	simulated	system_sim
2278	2026-07-18	WH-BLR-01	ITM-CPU-01	0	0	37	f	none	simulated	system_sim
2279	2026-07-18	WH-BLR-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
2280	2026-07-18	WH-BLR-01	ITM-RAM-01	75	9	101	f	none	simulated	system_sim
2281	2026-07-18	WH-BLR-01	ITM-SSD-01	0	1	83	f	none	simulated	system_sim
2282	2026-07-18	WH-BLR-01	ITM-HDD-01	0	0	55	f	none	simulated	system_sim
2283	2026-07-18	WH-BLR-01	ITM-CHG-01	0	10	101	f	none	simulated	system_sim
2284	2026-07-18	WH-BLR-01	ITM-CBL-01	0	8	266	f	none	simulated	system_sim
2285	2026-07-18	WH-CHN-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
2286	2026-07-18	WH-CHN-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
2287	2026-07-18	WH-CHN-01	ITM-RAM-01	0	5	46	f	none	simulated	system_sim
2288	2026-07-18	WH-CHN-01	ITM-SSD-01	0	1	84	f	none	simulated	system_sim
2289	2026-07-18	WH-CHN-01	ITM-HDD-01	0	2	52	f	none	simulated	system_sim
2290	2026-07-18	WH-CHN-01	ITM-CHG-01	0	4	123	f	none	simulated	system_sim
2291	2026-07-18	WH-CHN-01	ITM-CBL-01	0	6	282	f	none	simulated	system_sim
2292	2026-07-18	WH-BOM-01	ITM-CPU-01	0	1	42	f	none	simulated	system_sim
2293	2026-07-18	WH-BOM-01	ITM-GPU-01	0	2	27	f	none	simulated	system_sim
2294	2026-07-18	WH-BOM-01	ITM-RAM-01	0	2	50	f	none	simulated	system_sim
2295	2026-07-18	WH-BOM-01	ITM-SSD-01	0	1	79	f	none	simulated	system_sim
2296	2026-07-18	WH-BOM-01	ITM-HDD-01	0	0	53	f	none	simulated	system_sim
2297	2026-07-18	WH-BOM-01	ITM-CHG-01	0	10	110	f	none	simulated	system_sim
2298	2026-07-18	WH-BOM-01	ITM-CBL-01	0	1	269	f	none	simulated	system_sim
2299	2026-07-18	WH-DEL-01	ITM-CPU-01	0	3	38	f	none	simulated	system_sim
2300	2026-07-18	WH-DEL-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
2301	2026-07-18	WH-DEL-01	ITM-RAM-01	0	6	40	f	none	simulated	system_sim
2302	2026-07-18	WH-DEL-01	ITM-SSD-01	0	1	85	f	none	simulated	system_sim
2303	2026-07-18	WH-DEL-01	ITM-HDD-01	0	1	53	f	none	simulated	system_sim
2304	2026-07-18	WH-DEL-01	ITM-CHG-01	0	4	103	f	none	simulated	system_sim
2305	2026-07-18	WH-DEL-01	ITM-CBL-01	0	9	266	f	none	simulated	system_sim
2306	2026-07-18	WH-CCU-01	ITM-CPU-01	0	3	35	f	none	simulated	system_sim
2307	2026-07-18	WH-CCU-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
2308	2026-07-18	WH-CCU-01	ITM-RAM-01	0	6	46	f	none	simulated	system_sim
2309	2026-07-18	WH-CCU-01	ITM-SSD-01	0	2	83	f	none	simulated	system_sim
2310	2026-07-18	WH-CCU-01	ITM-HDD-01	0	2	54	f	none	simulated	system_sim
2311	2026-07-18	WH-CCU-01	ITM-CHG-01	0	9	121	f	none	simulated	system_sim
2312	2026-07-18	WH-CCU-01	ITM-CBL-01	0	7	269	f	none	simulated	system_sim
2313	2026-07-19	WH-BLR-01	ITM-CPU-01	0	2	35	f	none	simulated	system_sim
2314	2026-07-19	WH-BLR-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
2315	2026-07-19	WH-BLR-01	ITM-RAM-01	0	4	97	f	none	simulated	system_sim
2316	2026-07-19	WH-BLR-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
2317	2026-07-19	WH-BLR-01	ITM-HDD-01	0	2	53	f	none	simulated	system_sim
2318	2026-07-19	WH-BLR-01	ITM-CHG-01	0	1	100	f	none	simulated	system_sim
2319	2026-07-19	WH-BLR-01	ITM-CBL-01	0	7	259	f	none	simulated	system_sim
2320	2026-07-19	WH-CHN-01	ITM-CPU-01	0	1	33	f	none	simulated	system_sim
2321	2026-07-19	WH-CHN-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
2322	2026-07-19	WH-CHN-01	ITM-RAM-01	0	7	39	f	none	simulated	system_sim
2323	2026-07-19	WH-CHN-01	ITM-SSD-01	0	1	83	f	none	simulated	system_sim
2324	2026-07-19	WH-CHN-01	ITM-HDD-01	0	2	50	f	none	simulated	system_sim
2325	2026-07-19	WH-CHN-01	ITM-CHG-01	0	5	118	f	none	simulated	system_sim
2326	2026-07-19	WH-CHN-01	ITM-CBL-01	0	5	277	f	none	simulated	system_sim
2327	2026-07-19	WH-BOM-01	ITM-CPU-01	0	3	39	f	none	simulated	system_sim
2328	2026-07-19	WH-BOM-01	ITM-GPU-01	0	2	25	f	none	simulated	system_sim
2329	2026-07-19	WH-BOM-01	ITM-RAM-01	0	5	45	f	none	simulated	system_sim
2330	2026-07-19	WH-BOM-01	ITM-SSD-01	0	1	78	f	none	simulated	system_sim
2331	2026-07-19	WH-BOM-01	ITM-HDD-01	0	1	52	f	none	simulated	system_sim
2332	2026-07-19	WH-BOM-01	ITM-CHG-01	0	3	107	f	none	simulated	system_sim
2333	2026-07-19	WH-BOM-01	ITM-CBL-01	0	5	264	f	none	simulated	system_sim
2334	2026-07-19	WH-DEL-01	ITM-CPU-01	0	0	38	f	none	simulated	system_sim
2335	2026-07-19	WH-DEL-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
2336	2026-07-19	WH-DEL-01	ITM-RAM-01	0	7	33	f	none	simulated	system_sim
2337	2026-07-19	WH-DEL-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
2338	2026-07-19	WH-DEL-01	ITM-HDD-01	0	1	52	f	none	simulated	system_sim
2339	2026-07-19	WH-DEL-01	ITM-CHG-01	0	8	95	f	none	simulated	system_sim
2340	2026-07-19	WH-DEL-01	ITM-CBL-01	0	1	265	f	none	simulated	system_sim
2341	2026-07-19	WH-CCU-01	ITM-CPU-01	0	0	35	f	none	simulated	system_sim
2342	2026-07-19	WH-CCU-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
2343	2026-07-19	WH-CCU-01	ITM-RAM-01	0	5	41	f	none	simulated	system_sim
2344	2026-07-19	WH-CCU-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
2345	2026-07-19	WH-CCU-01	ITM-HDD-01	0	0	54	f	none	simulated	system_sim
2346	2026-07-19	WH-CCU-01	ITM-CHG-01	0	8	113	f	none	simulated	system_sim
2347	2026-07-19	WH-CCU-01	ITM-CBL-01	0	1	268	f	none	simulated	system_sim
2348	2026-07-20	WH-BLR-01	ITM-CPU-01	0	3	32	f	none	simulated	system_sim
2349	2026-07-20	WH-BLR-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
2350	2026-07-20	WH-BLR-01	ITM-RAM-01	0	3	94	f	none	simulated	system_sim
2351	2026-07-20	WH-BLR-01	ITM-SSD-01	0	3	80	f	none	simulated	system_sim
2352	2026-07-20	WH-BLR-01	ITM-HDD-01	0	0	53	f	none	simulated	system_sim
2353	2026-07-20	WH-BLR-01	ITM-CHG-01	0	5	95	f	none	simulated	system_sim
2354	2026-07-20	WH-BLR-01	ITM-CBL-01	0	8	251	f	none	simulated	system_sim
2355	2026-07-20	WH-CHN-01	ITM-CPU-01	0	0	33	f	none	simulated	system_sim
2356	2026-07-20	WH-CHN-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
2357	2026-07-20	WH-CHN-01	ITM-RAM-01	0	6	33	f	none	simulated	system_sim
2358	2026-07-20	WH-CHN-01	ITM-SSD-01	0	1	82	f	none	simulated	system_sim
2359	2026-07-20	WH-CHN-01	ITM-HDD-01	0	0	50	f	none	simulated	system_sim
2360	2026-07-20	WH-CHN-01	ITM-CHG-01	0	7	111	f	none	simulated	system_sim
2361	2026-07-20	WH-CHN-01	ITM-CBL-01	0	3	274	f	none	simulated	system_sim
2362	2026-07-20	WH-BOM-01	ITM-CPU-01	0	2	37	f	none	simulated	system_sim
2363	2026-07-20	WH-BOM-01	ITM-GPU-01	0	1	24	f	none	simulated	system_sim
2364	2026-07-20	WH-BOM-01	ITM-RAM-01	0	10	35	f	none	simulated	system_sim
2365	2026-07-20	WH-BOM-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
2366	2026-07-20	WH-BOM-01	ITM-HDD-01	0	1	51	f	none	simulated	system_sim
2367	2026-07-20	WH-BOM-01	ITM-CHG-01	0	3	104	f	none	simulated	system_sim
2368	2026-07-20	WH-BOM-01	ITM-CBL-01	0	7	257	f	none	simulated	system_sim
2369	2026-07-20	WH-DEL-01	ITM-CPU-01	0	3	35	f	none	simulated	system_sim
2370	2026-07-20	WH-DEL-01	ITM-GPU-01	0	1	28	f	none	simulated	system_sim
2371	2026-07-20	WH-DEL-01	ITM-RAM-01	75	4	104	f	none	simulated	system_sim
2372	2026-07-20	WH-DEL-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
2373	2026-07-20	WH-DEL-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
2374	2026-07-20	WH-DEL-01	ITM-CHG-01	0	8	87	f	none	simulated	system_sim
2375	2026-07-20	WH-DEL-01	ITM-CBL-01	0	4	261	f	none	simulated	system_sim
2376	2026-07-20	WH-CCU-01	ITM-CPU-01	0	3	32	f	none	simulated	system_sim
2377	2026-07-20	WH-CCU-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
2378	2026-07-20	WH-CCU-01	ITM-RAM-01	0	4	37	f	none	simulated	system_sim
2379	2026-07-20	WH-CCU-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
2380	2026-07-20	WH-CCU-01	ITM-HDD-01	0	3	51	f	none	simulated	system_sim
2381	2026-07-20	WH-CCU-01	ITM-CHG-01	0	9	104	f	none	simulated	system_sim
2382	2026-07-20	WH-CCU-01	ITM-CBL-01	0	3	265	f	none	simulated	system_sim
2383	2026-07-21	WH-BLR-01	ITM-CPU-01	0	0	32	f	none	simulated	system_sim
2384	2026-07-21	WH-BLR-01	ITM-GPU-01	0	2	25	f	none	simulated	system_sim
2385	2026-07-21	WH-BLR-01	ITM-RAM-01	0	8	86	f	none	simulated	system_sim
2386	2026-07-21	WH-BLR-01	ITM-SSD-01	0	0	80	f	none	simulated	system_sim
2387	2026-07-21	WH-BLR-01	ITM-HDD-01	0	1	52	f	none	simulated	system_sim
2388	2026-07-21	WH-BLR-01	ITM-CHG-01	0	6	89	f	none	simulated	system_sim
2389	2026-07-21	WH-BLR-01	ITM-CBL-01	0	5	246	f	none	simulated	system_sim
2390	2026-07-21	WH-CHN-01	ITM-CPU-01	0	3	30	f	none	simulated	system_sim
2391	2026-07-21	WH-CHN-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
2392	2026-07-21	WH-CHN-01	ITM-RAM-01	75	9	99	f	none	simulated	system_sim
2393	2026-07-21	WH-CHN-01	ITM-SSD-01	0	3	79	f	none	simulated	system_sim
2394	2026-07-21	WH-CHN-01	ITM-HDD-01	0	3	47	f	none	simulated	system_sim
2395	2026-07-21	WH-CHN-01	ITM-CHG-01	0	2	109	f	none	simulated	system_sim
2396	2026-07-21	WH-CHN-01	ITM-CBL-01	0	7	267	f	none	simulated	system_sim
2397	2026-07-21	WH-BOM-01	ITM-CPU-01	0	3	34	f	none	simulated	system_sim
2398	2026-07-21	WH-BOM-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
2399	2026-07-21	WH-BOM-01	ITM-RAM-01	75	9	101	f	none	simulated	system_sim
2400	2026-07-21	WH-BOM-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
2401	2026-07-21	WH-BOM-01	ITM-HDD-01	0	3	48	f	none	simulated	system_sim
2402	2026-07-21	WH-BOM-01	ITM-CHG-01	0	2	102	f	none	simulated	system_sim
2403	2026-07-21	WH-BOM-01	ITM-CBL-01	0	7	250	f	none	simulated	system_sim
2404	2026-07-21	WH-DEL-01	ITM-CPU-01	0	3	32	f	none	simulated	system_sim
2405	2026-07-21	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
2406	2026-07-21	WH-DEL-01	ITM-RAM-01	0	10	94	f	none	simulated	system_sim
2407	2026-07-21	WH-DEL-01	ITM-SSD-01	0	2	83	f	none	simulated	system_sim
2408	2026-07-21	WH-DEL-01	ITM-HDD-01	0	1	51	f	none	simulated	system_sim
2409	2026-07-21	WH-DEL-01	ITM-CHG-01	0	9	78	f	none	simulated	system_sim
2410	2026-07-21	WH-DEL-01	ITM-CBL-01	0	2	259	f	none	simulated	system_sim
2411	2026-07-21	WH-CCU-01	ITM-CPU-01	0	3	29	f	none	simulated	system_sim
2412	2026-07-21	WH-CCU-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
2413	2026-07-21	WH-CCU-01	ITM-RAM-01	75	4	108	f	none	simulated	system_sim
2414	2026-07-21	WH-CCU-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
2415	2026-07-21	WH-CCU-01	ITM-HDD-01	0	1	50	f	none	simulated	system_sim
2416	2026-07-21	WH-CCU-01	ITM-CHG-01	0	8	96	f	none	simulated	system_sim
2417	2026-07-21	WH-CCU-01	ITM-CBL-01	0	3	262	f	none	simulated	system_sim
2418	2026-07-22	WH-BLR-01	ITM-CPU-01	0	0	32	f	none	simulated	system_sim
2419	2026-07-22	WH-BLR-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
2420	2026-07-22	WH-BLR-01	ITM-RAM-01	0	1	85	f	none	simulated	system_sim
2421	2026-07-22	WH-BLR-01	ITM-SSD-01	0	2	78	f	none	simulated	system_sim
2422	2026-07-22	WH-BLR-01	ITM-HDD-01	0	3	49	f	none	simulated	system_sim
2423	2026-07-22	WH-BLR-01	ITM-CHG-01	0	6	83	f	none	simulated	system_sim
2424	2026-07-22	WH-BLR-01	ITM-CBL-01	0	4	242	f	none	simulated	system_sim
2425	2026-07-22	WH-CHN-01	ITM-CPU-01	0	0	30	f	none	simulated	system_sim
2426	2026-07-22	WH-CHN-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
2427	2026-07-22	WH-CHN-01	ITM-RAM-01	0	1	98	f	none	simulated	system_sim
2428	2026-07-22	WH-CHN-01	ITM-SSD-01	0	2	77	f	none	simulated	system_sim
2429	2026-07-22	WH-CHN-01	ITM-HDD-01	0	1	46	f	none	simulated	system_sim
2430	2026-07-22	WH-CHN-01	ITM-CHG-01	0	3	106	f	none	simulated	system_sim
2431	2026-07-22	WH-CHN-01	ITM-CBL-01	0	3	264	f	none	simulated	system_sim
2432	2026-07-22	WH-BOM-01	ITM-CPU-01	0	2	32	f	none	simulated	system_sim
2433	2026-07-22	WH-BOM-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
2434	2026-07-22	WH-BOM-01	ITM-RAM-01	0	8	93	f	none	simulated	system_sim
2435	2026-07-22	WH-BOM-01	ITM-SSD-01	0	3	75	f	none	simulated	system_sim
2436	2026-07-22	WH-BOM-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
2437	2026-07-22	WH-BOM-01	ITM-CHG-01	0	4	98	f	none	simulated	system_sim
2438	2026-07-22	WH-BOM-01	ITM-CBL-01	0	5	245	f	none	simulated	system_sim
2439	2026-07-22	WH-DEL-01	ITM-CPU-01	0	2	30	f	none	simulated	system_sim
2440	2026-07-22	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
2441	2026-07-22	WH-DEL-01	ITM-RAM-01	0	6	88	f	none	simulated	system_sim
2442	2026-07-22	WH-DEL-01	ITM-SSD-01	0	1	82	f	none	simulated	system_sim
2443	2026-07-22	WH-DEL-01	ITM-HDD-01	0	2	49	f	none	simulated	system_sim
2444	2026-07-22	WH-DEL-01	ITM-CHG-01	0	4	74	f	none	simulated	system_sim
2445	2026-07-22	WH-DEL-01	ITM-CBL-01	0	4	255	f	none	simulated	system_sim
2446	2026-07-22	WH-CCU-01	ITM-CPU-01	0	2	27	f	none	simulated	system_sim
2447	2026-07-22	WH-CCU-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
2448	2026-07-22	WH-CCU-01	ITM-RAM-01	0	2	106	f	none	simulated	system_sim
2449	2026-07-22	WH-CCU-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
2450	2026-07-22	WH-CCU-01	ITM-HDD-01	0	1	49	f	none	simulated	system_sim
2451	2026-07-22	WH-CCU-01	ITM-CHG-01	0	8	88	f	none	simulated	system_sim
2452	2026-07-22	WH-CCU-01	ITM-CBL-01	0	9	253	f	none	simulated	system_sim
2453	2026-07-23	WH-BLR-01	ITM-CPU-01	0	3	29	f	none	simulated	system_sim
2454	2026-07-23	WH-BLR-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
2455	2026-07-23	WH-BLR-01	ITM-RAM-01	0	1	84	f	none	simulated	system_sim
2456	2026-07-23	WH-BLR-01	ITM-SSD-01	0	3	75	f	none	simulated	system_sim
2457	2026-07-23	WH-BLR-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
2458	2026-07-23	WH-BLR-01	ITM-CHG-01	0	5	78	f	none	simulated	system_sim
2459	2026-07-23	WH-BLR-01	ITM-CBL-01	0	1	241	f	none	simulated	system_sim
2460	2026-07-23	WH-CHN-01	ITM-CPU-01	0	1	29	f	none	simulated	system_sim
2461	2026-07-23	WH-CHN-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
2462	2026-07-23	WH-CHN-01	ITM-RAM-01	0	9	89	f	none	simulated	system_sim
2463	2026-07-23	WH-CHN-01	ITM-SSD-01	0	1	76	f	none	simulated	system_sim
2464	2026-07-23	WH-CHN-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
2465	2026-07-23	WH-CHN-01	ITM-CHG-01	0	3	103	f	none	simulated	system_sim
2466	2026-07-23	WH-CHN-01	ITM-CBL-01	0	4	260	f	none	simulated	system_sim
2467	2026-07-23	WH-BOM-01	ITM-CPU-01	0	2	30	f	none	simulated	system_sim
2468	2026-07-23	WH-BOM-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
2469	2026-07-23	WH-BOM-01	ITM-RAM-01	0	1	92	f	none	simulated	system_sim
2470	2026-07-23	WH-BOM-01	ITM-SSD-01	0	2	73	f	none	simulated	system_sim
2471	2026-07-23	WH-BOM-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
2472	2026-07-23	WH-BOM-01	ITM-CHG-01	0	4	94	f	none	simulated	system_sim
2473	2026-07-23	WH-BOM-01	ITM-CBL-01	0	5	240	f	none	simulated	system_sim
2474	2026-07-23	WH-DEL-01	ITM-CPU-01	0	0	30	f	none	simulated	system_sim
2475	2026-07-23	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
2476	2026-07-23	WH-DEL-01	ITM-RAM-01	0	3	85	f	none	simulated	system_sim
2477	2026-07-23	WH-DEL-01	ITM-SSD-01	0	1	81	f	none	simulated	system_sim
2478	2026-07-23	WH-DEL-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
2479	2026-07-23	WH-DEL-01	ITM-CHG-01	150	2	222	f	none	simulated	system_sim
2480	2026-07-23	WH-DEL-01	ITM-CBL-01	0	10	245	f	none	simulated	system_sim
2481	2026-07-23	WH-CCU-01	ITM-CPU-01	0	2	25	f	none	simulated	system_sim
2482	2026-07-23	WH-CCU-01	ITM-GPU-01	0	2	21	f	none	simulated	system_sim
2483	2026-07-23	WH-CCU-01	ITM-RAM-01	0	4	102	f	none	simulated	system_sim
2484	2026-07-23	WH-CCU-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
2485	2026-07-23	WH-CCU-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
2486	2026-07-23	WH-CCU-01	ITM-CHG-01	0	7	81	f	none	simulated	system_sim
2487	2026-07-23	WH-CCU-01	ITM-CBL-01	0	6	247	f	none	simulated	system_sim
2488	2026-07-24	WH-BLR-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
2489	2026-07-24	WH-BLR-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
2490	2026-07-24	WH-BLR-01	ITM-RAM-01	0	10	74	f	none	simulated	system_sim
2491	2026-07-24	WH-BLR-01	ITM-SSD-01	0	2	73	f	none	simulated	system_sim
2492	2026-07-24	WH-BLR-01	ITM-HDD-01	0	3	46	f	none	simulated	system_sim
2493	2026-07-24	WH-BLR-01	ITM-CHG-01	0	10	68	f	none	simulated	system_sim
2494	2026-07-24	WH-BLR-01	ITM-CBL-01	0	1	240	f	none	simulated	system_sim
2495	2026-07-24	WH-CHN-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
2496	2026-07-24	WH-CHN-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
2497	2026-07-24	WH-CHN-01	ITM-RAM-01	0	8	81	f	none	simulated	system_sim
2498	2026-07-24	WH-CHN-01	ITM-SSD-01	0	3	73	f	none	simulated	system_sim
2499	2026-07-24	WH-CHN-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
2500	2026-07-24	WH-CHN-01	ITM-CHG-01	0	5	98	f	none	simulated	system_sim
2501	2026-07-24	WH-CHN-01	ITM-CBL-01	0	3	257	f	none	simulated	system_sim
2502	2026-07-24	WH-BOM-01	ITM-CPU-01	0	0	30	f	none	simulated	system_sim
2503	2026-07-24	WH-BOM-01	ITM-GPU-01	0	1	23	f	none	simulated	system_sim
2504	2026-07-24	WH-BOM-01	ITM-RAM-01	0	7	85	f	none	simulated	system_sim
2505	2026-07-24	WH-BOM-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
2506	2026-07-24	WH-BOM-01	ITM-HDD-01	0	1	47	f	none	simulated	system_sim
2507	2026-07-24	WH-BOM-01	ITM-CHG-01	0	3	91	f	none	simulated	system_sim
2508	2026-07-24	WH-BOM-01	ITM-CBL-01	0	3	237	f	none	simulated	system_sim
2509	2026-07-24	WH-DEL-01	ITM-CPU-01	0	0	30	f	none	simulated	system_sim
2510	2026-07-24	WH-DEL-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
2511	2026-07-24	WH-DEL-01	ITM-RAM-01	0	9	76	f	none	simulated	system_sim
2512	2026-07-24	WH-DEL-01	ITM-SSD-01	0	2	79	f	none	simulated	system_sim
2513	2026-07-24	WH-DEL-01	ITM-HDD-01	0	2	47	f	none	simulated	system_sim
2514	2026-07-24	WH-DEL-01	ITM-CHG-01	0	10	212	f	none	simulated	system_sim
2515	2026-07-24	WH-DEL-01	ITM-CBL-01	0	2	243	f	none	simulated	system_sim
2516	2026-07-24	WH-CCU-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
2517	2026-07-24	WH-CCU-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
2518	2026-07-24	WH-CCU-01	ITM-RAM-01	0	3	99	f	none	simulated	system_sim
2519	2026-07-24	WH-CCU-01	ITM-SSD-01	0	2	81	f	none	simulated	system_sim
2520	2026-07-24	WH-CCU-01	ITM-HDD-01	0	1	48	f	none	simulated	system_sim
2521	2026-07-24	WH-CCU-01	ITM-CHG-01	0	9	72	f	none	simulated	system_sim
2522	2026-07-24	WH-CCU-01	ITM-CBL-01	0	7	240	f	none	simulated	system_sim
2523	2026-07-25	WH-BLR-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
2524	2026-07-25	WH-BLR-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
2525	2026-07-25	WH-BLR-01	ITM-RAM-01	0	9	65	f	none	simulated	system_sim
2526	2026-07-25	WH-BLR-01	ITM-SSD-01	0	3	70	f	none	simulated	system_sim
2527	2026-07-25	WH-BLR-01	ITM-HDD-01	0	2	44	f	none	simulated	system_sim
2528	2026-07-25	WH-BLR-01	ITM-CHG-01	150	2	216	f	none	simulated	system_sim
2529	2026-07-25	WH-BLR-01	ITM-CBL-01	0	10	230	f	none	simulated	system_sim
2530	2026-07-25	WH-CHN-01	ITM-CPU-01	0	1	13	t	shrinkage	simulated	system_sim
2531	2026-07-25	WH-CHN-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
2532	2026-07-25	WH-CHN-01	ITM-RAM-01	0	3	78	f	none	simulated	system_sim
2533	2026-07-25	WH-CHN-01	ITM-SSD-01	0	3	70	f	none	simulated	system_sim
2534	2026-07-25	WH-CHN-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
2535	2026-07-25	WH-CHN-01	ITM-CHG-01	0	8	90	f	none	simulated	system_sim
2536	2026-07-25	WH-CHN-01	ITM-CBL-01	0	7	250	f	none	simulated	system_sim
2537	2026-07-25	WH-BOM-01	ITM-CPU-01	0	1	29	f	none	simulated	system_sim
2538	2026-07-25	WH-BOM-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
2539	2026-07-25	WH-BOM-01	ITM-RAM-01	0	4	81	f	none	simulated	system_sim
2540	2026-07-25	WH-BOM-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
2541	2026-07-25	WH-BOM-01	ITM-HDD-01	0	2	45	f	none	simulated	system_sim
2542	2026-07-25	WH-BOM-01	ITM-CHG-01	0	1	90	f	none	simulated	system_sim
2543	2026-07-25	WH-BOM-01	ITM-CBL-01	0	3	234	f	none	simulated	system_sim
2544	2026-07-25	WH-DEL-01	ITM-CPU-01	0	0	30	f	none	simulated	system_sim
2545	2026-07-25	WH-DEL-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
2546	2026-07-25	WH-DEL-01	ITM-RAM-01	0	3	73	f	none	simulated	system_sim
2547	2026-07-25	WH-DEL-01	ITM-SSD-01	0	3	76	f	none	simulated	system_sim
2548	2026-07-25	WH-DEL-01	ITM-HDD-01	0	2	45	f	none	simulated	system_sim
2549	2026-07-25	WH-DEL-01	ITM-CHG-01	0	10	202	f	none	simulated	system_sim
2550	2026-07-25	WH-DEL-01	ITM-CBL-01	0	1	242	f	none	simulated	system_sim
2551	2026-07-25	WH-CCU-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
2552	2026-07-25	WH-CCU-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
2553	2026-07-25	WH-CCU-01	ITM-RAM-01	0	7	92	f	none	simulated	system_sim
2554	2026-07-25	WH-CCU-01	ITM-SSD-01	0	1	80	f	none	simulated	system_sim
2555	2026-07-25	WH-CCU-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
2556	2026-07-25	WH-CCU-01	ITM-CHG-01	150	3	219	f	none	simulated	system_sim
2557	2026-07-25	WH-CCU-01	ITM-CBL-01	0	8	232	f	none	simulated	system_sim
2558	2026-07-26	WH-BLR-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
2559	2026-07-26	WH-BLR-01	ITM-GPU-01	0	1	22	f	none	simulated	system_sim
2560	2026-07-26	WH-BLR-01	ITM-RAM-01	0	2	63	f	none	simulated	system_sim
2561	2026-07-26	WH-BLR-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
2562	2026-07-26	WH-BLR-01	ITM-HDD-01	0	2	42	f	none	simulated	system_sim
2563	2026-07-26	WH-BLR-01	ITM-CHG-01	0	3	213	f	none	simulated	system_sim
2564	2026-07-26	WH-BLR-01	ITM-CBL-01	0	4	226	f	none	simulated	system_sim
2565	2026-07-26	WH-CHN-01	ITM-CPU-01	45	0	58	f	none	simulated	system_sim
2566	2026-07-26	WH-CHN-01	ITM-GPU-01	0	2	25	f	none	simulated	system_sim
2567	2026-07-26	WH-CHN-01	ITM-RAM-01	0	9	69	f	none	simulated	system_sim
2568	2026-07-26	WH-CHN-01	ITM-SSD-01	0	2	68	f	none	simulated	system_sim
2569	2026-07-26	WH-CHN-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
2570	2026-07-26	WH-CHN-01	ITM-CHG-01	0	1	89	f	none	simulated	system_sim
2571	2026-07-26	WH-CHN-01	ITM-CBL-01	0	9	241	f	none	simulated	system_sim
2572	2026-07-26	WH-BOM-01	ITM-CPU-01	0	3	26	f	none	simulated	system_sim
2573	2026-07-26	WH-BOM-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
2574	2026-07-26	WH-BOM-01	ITM-RAM-01	0	5	76	f	none	simulated	system_sim
2575	2026-07-26	WH-BOM-01	ITM-SSD-01	0	3	70	f	none	simulated	system_sim
2576	2026-07-26	WH-BOM-01	ITM-HDD-01	0	0	45	f	none	simulated	system_sim
2577	2026-07-26	WH-BOM-01	ITM-CHG-01	0	6	84	f	none	simulated	system_sim
2578	2026-07-26	WH-BOM-01	ITM-CBL-01	0	8	226	f	none	simulated	system_sim
2579	2026-07-26	WH-DEL-01	ITM-CPU-01	0	1	29	f	none	simulated	system_sim
2580	2026-07-26	WH-DEL-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
2581	2026-07-26	WH-DEL-01	ITM-RAM-01	0	1	72	f	none	simulated	system_sim
2582	2026-07-26	WH-DEL-01	ITM-SSD-01	0	2	74	f	none	simulated	system_sim
2583	2026-07-26	WH-DEL-01	ITM-HDD-01	0	2	43	f	none	simulated	system_sim
2584	2026-07-26	WH-DEL-01	ITM-CHG-01	0	5	197	f	none	simulated	system_sim
2585	2026-07-26	WH-DEL-01	ITM-CBL-01	0	2	240	f	none	simulated	system_sim
2586	2026-07-26	WH-CCU-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
2587	2026-07-26	WH-CCU-01	ITM-GPU-01	0	1	18	f	none	simulated	system_sim
2588	2026-07-26	WH-CCU-01	ITM-RAM-01	0	6	86	f	none	simulated	system_sim
2589	2026-07-26	WH-CCU-01	ITM-SSD-01	0	0	80	f	none	simulated	system_sim
2590	2026-07-26	WH-CCU-01	ITM-HDD-01	0	1	47	f	none	simulated	system_sim
2591	2026-07-26	WH-CCU-01	ITM-CHG-01	0	7	212	f	none	simulated	system_sim
2592	2026-07-26	WH-CCU-01	ITM-CBL-01	0	9	223	f	none	simulated	system_sim
2593	2026-07-27	WH-BLR-01	ITM-CPU-01	0	2	27	f	none	simulated	system_sim
2594	2026-07-27	WH-BLR-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
2595	2026-07-27	WH-BLR-01	ITM-RAM-01	0	2	61	f	none	simulated	system_sim
2596	2026-07-27	WH-BLR-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
2597	2026-07-27	WH-BLR-01	ITM-HDD-01	0	0	42	f	none	simulated	system_sim
2598	2026-07-27	WH-BLR-01	ITM-CHG-01	0	4	209	f	none	simulated	system_sim
2599	2026-07-27	WH-BLR-01	ITM-CBL-01	0	2	224	f	none	simulated	system_sim
2600	2026-07-27	WH-CHN-01	ITM-CPU-01	0	3	55	f	none	simulated	system_sim
2601	2026-07-27	WH-CHN-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
2602	2026-07-27	WH-CHN-01	ITM-RAM-01	0	8	61	f	none	simulated	system_sim
2603	2026-07-27	WH-CHN-01	ITM-SSD-01	0	0	68	f	none	simulated	system_sim
2604	2026-07-27	WH-CHN-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
2605	2026-07-27	WH-CHN-01	ITM-CHG-01	0	2	87	f	none	simulated	system_sim
2606	2026-07-27	WH-CHN-01	ITM-CBL-01	0	3	238	f	none	simulated	system_sim
2607	2026-07-27	WH-BOM-01	ITM-CPU-01	0	2	24	f	none	simulated	system_sim
2608	2026-07-27	WH-BOM-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
2609	2026-07-27	WH-BOM-01	ITM-RAM-01	0	9	67	f	none	simulated	system_sim
2610	2026-07-27	WH-BOM-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
2611	2026-07-27	WH-BOM-01	ITM-HDD-01	0	2	43	f	none	simulated	system_sim
2612	2026-07-27	WH-BOM-01	ITM-CHG-01	0	2	82	f	none	simulated	system_sim
2613	2026-07-27	WH-BOM-01	ITM-CBL-01	0	8	218	f	none	simulated	system_sim
2614	2026-07-27	WH-DEL-01	ITM-CPU-01	0	3	26	f	none	simulated	system_sim
2615	2026-07-27	WH-DEL-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
2616	2026-07-27	WH-DEL-01	ITM-RAM-01	0	8	64	f	none	simulated	system_sim
2617	2026-07-27	WH-DEL-01	ITM-SSD-01	0	0	74	f	none	simulated	system_sim
2618	2026-07-27	WH-DEL-01	ITM-HDD-01	0	2	41	f	none	simulated	system_sim
2619	2026-07-27	WH-DEL-01	ITM-CHG-01	0	6	191	f	none	simulated	system_sim
2620	2026-07-27	WH-DEL-01	ITM-CBL-01	0	8	232	f	none	simulated	system_sim
2621	2026-07-27	WH-CCU-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
2622	2026-07-27	WH-CCU-01	ITM-GPU-01	0	2	16	f	none	simulated	system_sim
2623	2026-07-27	WH-CCU-01	ITM-RAM-01	0	3	83	f	none	simulated	system_sim
2624	2026-07-27	WH-CCU-01	ITM-SSD-01	0	0	80	f	none	simulated	system_sim
2625	2026-07-27	WH-CCU-01	ITM-HDD-01	0	0	47	f	none	simulated	system_sim
2626	2026-07-27	WH-CCU-01	ITM-CHG-01	0	6	206	f	none	simulated	system_sim
2627	2026-07-27	WH-CCU-01	ITM-CBL-01	0	10	213	f	none	simulated	system_sim
2628	2026-07-28	WH-BLR-01	ITM-CPU-01	0	1	26	f	none	simulated	system_sim
2629	2026-07-28	WH-BLR-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
2630	2026-07-28	WH-BLR-01	ITM-RAM-01	0	2	59	f	none	simulated	system_sim
2631	2026-07-28	WH-BLR-01	ITM-SSD-01	0	2	68	f	none	simulated	system_sim
2632	2026-07-28	WH-BLR-01	ITM-HDD-01	0	3	39	f	none	simulated	system_sim
2633	2026-07-28	WH-BLR-01	ITM-CHG-01	0	7	202	f	none	simulated	system_sim
2634	2026-07-28	WH-BLR-01	ITM-CBL-01	0	8	216	f	none	simulated	system_sim
2635	2026-07-28	WH-CHN-01	ITM-CPU-01	0	3	52	f	none	simulated	system_sim
2636	2026-07-28	WH-CHN-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
2637	2026-07-28	WH-CHN-01	ITM-RAM-01	0	1	60	f	none	simulated	system_sim
2638	2026-07-28	WH-CHN-01	ITM-SSD-01	0	2	66	f	none	simulated	system_sim
2639	2026-07-28	WH-CHN-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
2640	2026-07-28	WH-CHN-01	ITM-CHG-01	0	5	82	f	none	simulated	system_sim
2641	2026-07-28	WH-CHN-01	ITM-CBL-01	0	8	230	f	none	simulated	system_sim
2642	2026-07-28	WH-BOM-01	ITM-CPU-01	0	1	23	f	none	simulated	system_sim
2643	2026-07-28	WH-BOM-01	ITM-GPU-01	0	1	22	f	none	simulated	system_sim
2644	2026-07-28	WH-BOM-01	ITM-RAM-01	0	1	66	f	none	simulated	system_sim
2645	2026-07-28	WH-BOM-01	ITM-SSD-01	0	1	69	f	none	simulated	system_sim
2646	2026-07-28	WH-BOM-01	ITM-HDD-01	0	2	41	f	none	simulated	system_sim
2647	2026-07-28	WH-BOM-01	ITM-CHG-01	0	8	74	f	none	simulated	system_sim
2648	2026-07-28	WH-BOM-01	ITM-CBL-01	0	9	209	f	none	simulated	system_sim
2649	2026-07-28	WH-DEL-01	ITM-CPU-01	0	1	25	f	none	simulated	system_sim
2650	2026-07-28	WH-DEL-01	ITM-GPU-01	0	2	25	f	none	simulated	system_sim
2651	2026-07-28	WH-DEL-01	ITM-RAM-01	0	3	61	f	none	simulated	system_sim
2652	2026-07-28	WH-DEL-01	ITM-SSD-01	0	3	71	f	none	simulated	system_sim
2653	2026-07-28	WH-DEL-01	ITM-HDD-01	0	0	41	f	none	simulated	system_sim
2654	2026-07-28	WH-DEL-01	ITM-CHG-01	0	6	185	f	none	simulated	system_sim
2655	2026-07-28	WH-DEL-01	ITM-CBL-01	0	2	230	f	none	simulated	system_sim
2656	2026-07-28	WH-CCU-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
2657	2026-07-28	WH-CCU-01	ITM-GPU-01	0	2	14	f	none	simulated	system_sim
2658	2026-07-28	WH-CCU-01	ITM-RAM-01	0	6	77	f	none	simulated	system_sim
2659	2026-07-28	WH-CCU-01	ITM-SSD-01	0	2	78	f	none	simulated	system_sim
2660	2026-07-28	WH-CCU-01	ITM-HDD-01	0	3	44	f	none	simulated	system_sim
2661	2026-07-28	WH-CCU-01	ITM-CHG-01	0	4	202	f	none	simulated	system_sim
2662	2026-07-28	WH-CCU-01	ITM-CBL-01	0	6	207	f	none	simulated	system_sim
2663	2026-07-29	WH-BLR-01	ITM-CPU-01	0	3	23	f	none	simulated	system_sim
2664	2026-07-29	WH-BLR-01	ITM-GPU-01	0	1	21	f	none	simulated	system_sim
2665	2026-07-29	WH-BLR-01	ITM-RAM-01	0	6	53	f	none	simulated	system_sim
2666	2026-07-29	WH-BLR-01	ITM-SSD-01	0	2	66	f	none	simulated	system_sim
2667	2026-07-29	WH-BLR-01	ITM-HDD-01	0	2	37	f	none	simulated	system_sim
2668	2026-07-29	WH-BLR-01	ITM-CHG-01	0	3	199	f	none	simulated	system_sim
2669	2026-07-29	WH-BLR-01	ITM-CBL-01	0	2	214	f	none	simulated	system_sim
2670	2026-07-29	WH-CHN-01	ITM-CPU-01	0	1	51	f	none	simulated	system_sim
2671	2026-07-29	WH-CHN-01	ITM-GPU-01	0	1	24	f	none	simulated	system_sim
2672	2026-07-29	WH-CHN-01	ITM-RAM-01	0	6	54	f	none	simulated	system_sim
2673	2026-07-29	WH-CHN-01	ITM-SSD-01	0	0	66	f	none	simulated	system_sim
2674	2026-07-29	WH-CHN-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
2675	2026-07-29	WH-CHN-01	ITM-CHG-01	0	5	77	f	none	simulated	system_sim
2676	2026-07-29	WH-CHN-01	ITM-CBL-01	0	10	220	f	none	simulated	system_sim
2677	2026-07-29	WH-BOM-01	ITM-CPU-01	0	1	22	f	none	simulated	system_sim
2678	2026-07-29	WH-BOM-01	ITM-GPU-01	0	1	21	f	none	simulated	system_sim
2679	2026-07-29	WH-BOM-01	ITM-RAM-01	0	1	65	f	none	simulated	system_sim
2680	2026-07-29	WH-BOM-01	ITM-SSD-01	0	0	69	f	none	simulated	system_sim
2681	2026-07-29	WH-BOM-01	ITM-HDD-01	0	2	39	f	none	simulated	system_sim
2682	2026-07-29	WH-BOM-01	ITM-CHG-01	150	5	219	f	none	simulated	system_sim
2683	2026-07-29	WH-BOM-01	ITM-CBL-01	0	5	204	f	none	simulated	system_sim
2684	2026-07-29	WH-DEL-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
2685	2026-07-29	WH-DEL-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
2686	2026-07-29	WH-DEL-01	ITM-RAM-01	0	4	57	f	none	simulated	system_sim
2687	2026-07-29	WH-DEL-01	ITM-SSD-01	0	1	70	f	none	simulated	system_sim
2688	2026-07-29	WH-DEL-01	ITM-HDD-01	0	3	38	f	none	simulated	system_sim
2689	2026-07-29	WH-DEL-01	ITM-CHG-01	0	4	181	f	none	simulated	system_sim
2690	2026-07-29	WH-DEL-01	ITM-CBL-01	0	1	229	f	none	simulated	system_sim
2691	2026-07-29	WH-CCU-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
2692	2026-07-29	WH-CCU-01	ITM-GPU-01	30	0	44	f	none	simulated	system_sim
2693	2026-07-29	WH-CCU-01	ITM-RAM-01	0	1	76	f	none	simulated	system_sim
2694	2026-07-29	WH-CCU-01	ITM-SSD-01	0	2	76	f	none	simulated	system_sim
2695	2026-07-29	WH-CCU-01	ITM-HDD-01	0	3	41	f	none	simulated	system_sim
2696	2026-07-29	WH-CCU-01	ITM-CHG-01	0	9	193	f	none	simulated	system_sim
2697	2026-07-29	WH-CCU-01	ITM-CBL-01	0	2	205	f	none	simulated	system_sim
2698	2026-07-30	WH-BLR-01	ITM-CPU-01	0	0	23	f	none	simulated	system_sim
2699	2026-07-30	WH-BLR-01	ITM-GPU-01	0	1	20	f	none	simulated	system_sim
2700	2026-07-30	WH-BLR-01	ITM-RAM-01	0	8	45	f	none	simulated	system_sim
2701	2026-07-30	WH-BLR-01	ITM-SSD-01	0	2	64	f	none	simulated	system_sim
2702	2026-07-30	WH-BLR-01	ITM-HDD-01	0	2	35	f	none	simulated	system_sim
2703	2026-07-30	WH-BLR-01	ITM-CHG-01	0	9	190	f	none	simulated	system_sim
2704	2026-07-30	WH-BLR-01	ITM-CBL-01	0	10	204	f	none	simulated	system_sim
2705	2026-07-30	WH-CHN-01	ITM-CPU-01	0	0	51	f	none	simulated	system_sim
2706	2026-07-30	WH-CHN-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
2707	2026-07-30	WH-CHN-01	ITM-RAM-01	0	4	50	f	none	simulated	system_sim
2708	2026-07-30	WH-CHN-01	ITM-SSD-01	0	0	66	f	none	simulated	system_sim
2709	2026-07-30	WH-CHN-01	ITM-HDD-01	0	1	45	f	none	simulated	system_sim
2710	2026-07-30	WH-CHN-01	ITM-CHG-01	0	1	76	f	none	simulated	system_sim
2711	2026-07-30	WH-CHN-01	ITM-CBL-01	0	9	211	f	none	simulated	system_sim
2712	2026-07-30	WH-BOM-01	ITM-CPU-01	45	2	65	f	none	simulated	system_sim
2713	2026-07-30	WH-BOM-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
2714	2026-07-30	WH-BOM-01	ITM-RAM-01	0	1	64	f	none	simulated	system_sim
2715	2026-07-30	WH-BOM-01	ITM-SSD-01	0	2	67	f	none	simulated	system_sim
2716	2026-07-30	WH-BOM-01	ITM-HDD-01	0	1	38	f	none	simulated	system_sim
2717	2026-07-30	WH-BOM-01	ITM-CHG-01	0	9	210	f	none	simulated	system_sim
2718	2026-07-30	WH-BOM-01	ITM-CBL-01	0	7	197	f	none	simulated	system_sim
2719	2026-07-30	WH-DEL-01	ITM-CPU-01	0	2	23	f	none	simulated	system_sim
2720	2026-07-30	WH-DEL-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
2721	2026-07-30	WH-DEL-01	ITM-RAM-01	0	2	55	f	none	simulated	system_sim
2722	2026-07-30	WH-DEL-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
2723	2026-07-30	WH-DEL-01	ITM-HDD-01	0	3	35	f	none	simulated	system_sim
2724	2026-07-30	WH-DEL-01	ITM-CHG-01	0	5	176	f	none	simulated	system_sim
2725	2026-07-30	WH-DEL-01	ITM-CBL-01	0	8	221	f	none	simulated	system_sim
2726	2026-07-30	WH-CCU-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
2727	2026-07-30	WH-CCU-01	ITM-GPU-01	0	0	44	f	none	simulated	system_sim
2728	2026-07-30	WH-CCU-01	ITM-RAM-01	0	5	71	f	none	simulated	system_sim
2729	2026-07-30	WH-CCU-01	ITM-SSD-01	0	0	76	f	none	simulated	system_sim
2730	2026-07-30	WH-CCU-01	ITM-HDD-01	0	1	40	f	none	simulated	system_sim
2731	2026-07-30	WH-CCU-01	ITM-CHG-01	0	5	188	f	none	simulated	system_sim
2732	2026-07-30	WH-CCU-01	ITM-CBL-01	0	5	200	f	none	simulated	system_sim
2733	2026-07-31	WH-BLR-01	ITM-CPU-01	0	3	20	f	none	simulated	system_sim
2734	2026-07-31	WH-BLR-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
2735	2026-07-31	WH-BLR-01	ITM-RAM-01	0	8	37	f	none	simulated	system_sim
2736	2026-07-31	WH-BLR-01	ITM-SSD-01	0	0	64	f	none	simulated	system_sim
2737	2026-07-31	WH-BLR-01	ITM-HDD-01	0	0	35	f	none	simulated	system_sim
2738	2026-07-31	WH-BLR-01	ITM-CHG-01	0	8	182	f	none	simulated	system_sim
2739	2026-07-31	WH-BLR-01	ITM-CBL-01	0	6	198	f	none	simulated	system_sim
2740	2026-07-31	WH-CHN-01	ITM-CPU-01	0	2	49	f	none	simulated	system_sim
2741	2026-07-31	WH-CHN-01	ITM-GPU-01	0	2	22	f	none	simulated	system_sim
2742	2026-07-31	WH-CHN-01	ITM-RAM-01	0	5	45	f	none	simulated	system_sim
2743	2026-07-31	WH-CHN-01	ITM-SSD-01	0	0	66	f	none	simulated	system_sim
2744	2026-07-31	WH-CHN-01	ITM-HDD-01	0	2	43	f	none	simulated	system_sim
2745	2026-07-31	WH-CHN-01	ITM-CHG-01	0	3	73	f	none	simulated	system_sim
2746	2026-07-31	WH-CHN-01	ITM-CBL-01	0	7	204	f	none	simulated	system_sim
2747	2026-07-31	WH-BOM-01	ITM-CPU-01	0	0	65	f	none	simulated	system_sim
2748	2026-07-31	WH-BOM-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
2749	2026-07-31	WH-BOM-01	ITM-RAM-01	0	6	58	f	none	simulated	system_sim
2750	2026-07-31	WH-BOM-01	ITM-SSD-01	0	1	66	f	none	simulated	system_sim
2751	2026-07-31	WH-BOM-01	ITM-HDD-01	0	3	35	f	none	simulated	system_sim
2752	2026-07-31	WH-BOM-01	ITM-CHG-01	0	7	203	f	none	simulated	system_sim
2753	2026-07-31	WH-BOM-01	ITM-CBL-01	0	1	196	f	none	simulated	system_sim
2754	2026-07-31	WH-DEL-01	ITM-CPU-01	0	2	21	f	none	simulated	system_sim
2755	2026-07-31	WH-DEL-01	ITM-GPU-01	0	2	21	f	none	simulated	system_sim
2756	2026-07-31	WH-DEL-01	ITM-RAM-01	0	4	51	f	none	simulated	system_sim
2757	2026-07-31	WH-DEL-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
2758	2026-07-31	WH-DEL-01	ITM-HDD-01	0	0	35	f	none	simulated	system_sim
2759	2026-07-31	WH-DEL-01	ITM-CHG-01	0	6	170	f	none	simulated	system_sim
2760	2026-07-31	WH-DEL-01	ITM-CBL-01	0	10	211	f	none	simulated	system_sim
2761	2026-07-31	WH-CCU-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
2762	2026-07-31	WH-CCU-01	ITM-GPU-01	0	2	42	f	none	simulated	system_sim
2763	2026-07-31	WH-CCU-01	ITM-RAM-01	0	1	70	f	none	simulated	system_sim
2764	2026-07-31	WH-CCU-01	ITM-SSD-01	0	0	76	f	none	simulated	system_sim
2765	2026-07-31	WH-CCU-01	ITM-HDD-01	0	0	40	f	none	simulated	system_sim
2766	2026-07-31	WH-CCU-01	ITM-CHG-01	0	8	180	f	none	simulated	system_sim
2767	2026-07-31	WH-CCU-01	ITM-CBL-01	0	5	195	f	none	simulated	system_sim
2768	2026-08-01	WH-BLR-01	ITM-CPU-01	45	3	62	f	none	simulated	system_sim
2769	2026-08-01	WH-BLR-01	ITM-GPU-01	0	1	19	f	none	simulated	system_sim
2770	2026-08-01	WH-BLR-01	ITM-RAM-01	75	8	104	f	none	simulated	system_sim
2771	2026-08-01	WH-BLR-01	ITM-SSD-01	0	2	62	f	none	simulated	system_sim
2772	2026-08-01	WH-BLR-01	ITM-HDD-01	0	1	34	f	none	simulated	system_sim
2773	2026-08-01	WH-BLR-01	ITM-CHG-01	0	7	175	f	none	simulated	system_sim
2774	2026-08-01	WH-BLR-01	ITM-CBL-01	0	3	195	f	none	simulated	system_sim
2775	2026-08-01	WH-CHN-01	ITM-CPU-01	0	1	48	f	none	simulated	system_sim
2776	2026-08-01	WH-CHN-01	ITM-GPU-01	0	2	20	f	none	simulated	system_sim
2777	2026-08-01	WH-CHN-01	ITM-RAM-01	0	2	43	f	none	simulated	system_sim
2778	2026-08-01	WH-CHN-01	ITM-SSD-01	0	1	65	f	none	simulated	system_sim
2779	2026-08-01	WH-CHN-01	ITM-HDD-01	0	2	41	f	none	simulated	system_sim
2780	2026-08-01	WH-CHN-01	ITM-CHG-01	150	7	216	f	none	simulated	system_sim
2781	2026-08-01	WH-CHN-01	ITM-CBL-01	0	8	196	f	none	simulated	system_sim
2782	2026-08-01	WH-BOM-01	ITM-CPU-01	0	1	64	f	none	simulated	system_sim
2783	2026-08-01	WH-BOM-01	ITM-GPU-01	0	1	18	f	none	simulated	system_sim
2784	2026-08-01	WH-BOM-01	ITM-RAM-01	0	8	50	f	none	simulated	system_sim
2785	2026-08-01	WH-BOM-01	ITM-SSD-01	0	2	64	f	none	simulated	system_sim
2786	2026-08-01	WH-BOM-01	ITM-HDD-01	0	0	35	f	none	simulated	system_sim
2787	2026-08-01	WH-BOM-01	ITM-CHG-01	0	8	195	f	none	simulated	system_sim
2788	2026-08-01	WH-BOM-01	ITM-CBL-01	0	1	195	f	none	simulated	system_sim
2789	2026-08-01	WH-DEL-01	ITM-CPU-01	45	2	64	f	none	simulated	system_sim
2790	2026-08-01	WH-DEL-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
2791	2026-08-01	WH-DEL-01	ITM-RAM-01	0	5	46	f	none	simulated	system_sim
2792	2026-08-01	WH-DEL-01	ITM-SSD-01	0	2	68	f	none	simulated	system_sim
2793	2026-08-01	WH-DEL-01	ITM-HDD-01	0	3	32	f	none	simulated	system_sim
2794	2026-08-01	WH-DEL-01	ITM-CHG-01	0	4	166	f	none	simulated	system_sim
2795	2026-08-01	WH-DEL-01	ITM-CBL-01	0	5	206	f	none	simulated	system_sim
2796	2026-08-01	WH-CCU-01	ITM-CPU-01	0	3	22	f	none	simulated	system_sim
2797	2026-08-01	WH-CCU-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
2798	2026-08-01	WH-CCU-01	ITM-RAM-01	0	1	69	f	none	simulated	system_sim
2799	2026-08-01	WH-CCU-01	ITM-SSD-01	0	2	74	f	none	simulated	system_sim
2800	2026-08-01	WH-CCU-01	ITM-HDD-01	0	2	38	f	none	simulated	system_sim
2801	2026-08-01	WH-CCU-01	ITM-CHG-01	0	8	172	f	none	simulated	system_sim
2802	2026-08-01	WH-CCU-01	ITM-CBL-01	0	6	189	f	none	simulated	system_sim
2803	2026-08-02	WH-BLR-01	ITM-CPU-01	0	0	62	f	none	simulated	system_sim
2804	2026-08-02	WH-BLR-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
2805	2026-08-02	WH-BLR-01	ITM-RAM-01	0	8	96	f	none	simulated	system_sim
2806	2026-08-02	WH-BLR-01	ITM-SSD-01	0	0	62	f	none	simulated	system_sim
2807	2026-08-02	WH-BLR-01	ITM-HDD-01	0	2	32	f	none	simulated	system_sim
2808	2026-08-02	WH-BLR-01	ITM-CHG-01	0	10	165	f	none	simulated	system_sim
2809	2026-08-02	WH-BLR-01	ITM-CBL-01	0	9	186	f	none	simulated	system_sim
2810	2026-08-02	WH-CHN-01	ITM-CPU-01	0	0	48	f	none	simulated	system_sim
2811	2026-08-02	WH-CHN-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
2812	2026-08-02	WH-CHN-01	ITM-RAM-01	0	7	36	f	none	simulated	system_sim
2813	2026-08-02	WH-CHN-01	ITM-SSD-01	0	2	63	f	none	simulated	system_sim
2814	2026-08-02	WH-CHN-01	ITM-HDD-01	0	2	39	f	none	simulated	system_sim
2815	2026-08-02	WH-CHN-01	ITM-CHG-01	0	10	206	f	none	simulated	system_sim
2816	2026-08-02	WH-CHN-01	ITM-CBL-01	0	2	194	f	none	simulated	system_sim
2817	2026-08-02	WH-BOM-01	ITM-CPU-01	0	0	64	f	none	simulated	system_sim
2818	2026-08-02	WH-BOM-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
2819	2026-08-02	WH-BOM-01	ITM-RAM-01	0	9	41	f	none	simulated	system_sim
2820	2026-08-02	WH-BOM-01	ITM-SSD-01	0	2	62	f	none	simulated	system_sim
2821	2026-08-02	WH-BOM-01	ITM-HDD-01	0	0	35	f	none	simulated	system_sim
2822	2026-08-02	WH-BOM-01	ITM-CHG-01	0	7	188	f	none	simulated	system_sim
2823	2026-08-02	WH-BOM-01	ITM-CBL-01	0	3	192	f	none	simulated	system_sim
2824	2026-08-02	WH-DEL-01	ITM-CPU-01	0	0	64	f	none	simulated	system_sim
2825	2026-08-02	WH-DEL-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
2826	2026-08-02	WH-DEL-01	ITM-RAM-01	0	4	42	f	none	simulated	system_sim
2827	2026-08-02	WH-DEL-01	ITM-SSD-01	0	1	67	f	none	simulated	system_sim
2828	2026-08-02	WH-DEL-01	ITM-HDD-01	0	0	32	f	none	simulated	system_sim
2829	2026-08-02	WH-DEL-01	ITM-CHG-01	0	5	161	f	none	simulated	system_sim
2830	2026-08-02	WH-DEL-01	ITM-CBL-01	0	6	200	f	none	simulated	system_sim
2831	2026-08-02	WH-CCU-01	ITM-CPU-01	45	3	64	f	none	simulated	system_sim
2832	2026-08-02	WH-CCU-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
2833	2026-08-02	WH-CCU-01	ITM-RAM-01	0	10	59	f	none	simulated	system_sim
2834	2026-08-02	WH-CCU-01	ITM-SSD-01	0	1	73	f	none	simulated	system_sim
2835	2026-08-02	WH-CCU-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
2836	2026-08-02	WH-CCU-01	ITM-CHG-01	0	7	165	f	none	simulated	system_sim
2837	2026-08-02	WH-CCU-01	ITM-CBL-01	0	6	183	f	none	simulated	system_sim
2838	2026-08-03	WH-BLR-01	ITM-CPU-01	0	1	61	f	none	simulated	system_sim
2839	2026-08-03	WH-BLR-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
2840	2026-08-03	WH-BLR-01	ITM-RAM-01	0	6	90	f	none	simulated	system_sim
2841	2026-08-03	WH-BLR-01	ITM-SSD-01	0	0	62	f	none	simulated	system_sim
2842	2026-08-03	WH-BLR-01	ITM-HDD-01	0	0	32	f	none	simulated	system_sim
2843	2026-08-03	WH-BLR-01	ITM-CHG-01	0	5	160	f	none	simulated	system_sim
2844	2026-08-03	WH-BLR-01	ITM-CBL-01	0	9	177	f	none	simulated	system_sim
2845	2026-08-03	WH-CHN-01	ITM-CPU-01	0	0	48	f	none	simulated	system_sim
2846	2026-08-03	WH-CHN-01	ITM-GPU-01	0	1	19	f	none	simulated	system_sim
2847	2026-08-03	WH-CHN-01	ITM-RAM-01	75	2	109	f	none	simulated	system_sim
2848	2026-08-03	WH-CHN-01	ITM-SSD-01	0	1	62	f	none	simulated	system_sim
2849	2026-08-03	WH-CHN-01	ITM-HDD-01	0	1	38	f	none	simulated	system_sim
2850	2026-08-03	WH-CHN-01	ITM-CHG-01	0	3	203	f	none	simulated	system_sim
2851	2026-08-03	WH-CHN-01	ITM-CBL-01	0	1	193	f	none	simulated	system_sim
2852	2026-08-03	WH-BOM-01	ITM-CPU-01	0	3	61	f	none	simulated	system_sim
2853	2026-08-03	WH-BOM-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
2854	2026-08-03	WH-BOM-01	ITM-RAM-01	0	9	32	f	none	simulated	system_sim
2855	2026-08-03	WH-BOM-01	ITM-SSD-01	0	2	60	f	none	simulated	system_sim
2856	2026-08-03	WH-BOM-01	ITM-HDD-01	0	3	32	f	none	simulated	system_sim
2857	2026-08-03	WH-BOM-01	ITM-CHG-01	0	4	184	f	none	simulated	system_sim
2858	2026-08-03	WH-BOM-01	ITM-CBL-01	0	2	190	f	none	simulated	system_sim
2859	2026-08-03	WH-DEL-01	ITM-CPU-01	0	1	63	f	none	simulated	system_sim
2860	2026-08-03	WH-DEL-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
2861	2026-08-03	WH-DEL-01	ITM-RAM-01	0	9	33	f	none	simulated	system_sim
2862	2026-08-03	WH-DEL-01	ITM-SSD-01	0	2	65	f	none	simulated	system_sim
2863	2026-08-03	WH-DEL-01	ITM-HDD-01	0	3	29	f	none	simulated	system_sim
2864	2026-08-03	WH-DEL-01	ITM-CHG-01	0	3	158	f	none	simulated	system_sim
2865	2026-08-03	WH-DEL-01	ITM-CBL-01	0	1	199	f	none	simulated	system_sim
2866	2026-08-03	WH-CCU-01	ITM-CPU-01	0	3	61	f	none	simulated	system_sim
2867	2026-08-03	WH-CCU-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
2868	2026-08-03	WH-CCU-01	ITM-RAM-01	0	3	56	f	none	simulated	system_sim
2869	2026-08-03	WH-CCU-01	ITM-SSD-01	0	3	70	f	none	simulated	system_sim
2870	2026-08-03	WH-CCU-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
2871	2026-08-03	WH-CCU-01	ITM-CHG-01	0	4	161	f	none	simulated	system_sim
2872	2026-08-03	WH-CCU-01	ITM-CBL-01	0	2	181	f	none	simulated	system_sim
2873	2026-08-04	WH-BLR-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
2874	2026-08-04	WH-BLR-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
2875	2026-08-04	WH-BLR-01	ITM-RAM-01	0	7	83	f	none	simulated	system_sim
2876	2026-08-04	WH-BLR-01	ITM-SSD-01	0	0	62	f	none	simulated	system_sim
2877	2026-08-04	WH-BLR-01	ITM-HDD-01	0	3	29	f	none	simulated	system_sim
2878	2026-08-04	WH-BLR-01	ITM-CHG-01	0	4	156	f	none	simulated	system_sim
2879	2026-08-04	WH-BLR-01	ITM-CBL-01	0	2	175	f	none	simulated	system_sim
2880	2026-08-04	WH-CHN-01	ITM-CPU-01	0	2	46	f	none	simulated	system_sim
2881	2026-08-04	WH-CHN-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
2882	2026-08-04	WH-CHN-01	ITM-RAM-01	0	9	100	f	none	simulated	system_sim
2883	2026-08-04	WH-CHN-01	ITM-SSD-01	0	2	60	f	none	simulated	system_sim
2884	2026-08-04	WH-CHN-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
2885	2026-08-04	WH-CHN-01	ITM-CHG-01	0	3	200	f	none	simulated	system_sim
2886	2026-08-04	WH-CHN-01	ITM-CBL-01	0	8	185	f	none	simulated	system_sim
2887	2026-08-04	WH-BOM-01	ITM-CPU-01	0	3	58	f	none	simulated	system_sim
2888	2026-08-04	WH-BOM-01	ITM-GPU-01	0	2	15	f	none	simulated	system_sim
2889	2026-08-04	WH-BOM-01	ITM-RAM-01	75	7	100	f	none	simulated	system_sim
2890	2026-08-04	WH-BOM-01	ITM-SSD-01	0	2	58	f	none	simulated	system_sim
2891	2026-08-04	WH-BOM-01	ITM-HDD-01	0	0	32	f	none	simulated	system_sim
2892	2026-08-04	WH-BOM-01	ITM-CHG-01	0	2	182	f	none	simulated	system_sim
2893	2026-08-04	WH-BOM-01	ITM-CBL-01	0	7	183	f	none	simulated	system_sim
2894	2026-08-04	WH-DEL-01	ITM-CPU-01	0	1	62	f	none	simulated	system_sim
2895	2026-08-04	WH-DEL-01	ITM-GPU-01	0	2	17	f	none	simulated	system_sim
2896	2026-08-04	WH-DEL-01	ITM-RAM-01	75	2	106	f	none	simulated	system_sim
2897	2026-08-04	WH-DEL-01	ITM-SSD-01	0	1	64	f	none	simulated	system_sim
2898	2026-08-04	WH-DEL-01	ITM-HDD-01	60	3	86	f	none	simulated	system_sim
2899	2026-08-04	WH-DEL-01	ITM-CHG-01	0	9	149	f	none	simulated	system_sim
2900	2026-08-04	WH-DEL-01	ITM-CBL-01	0	2	197	f	none	simulated	system_sim
2901	2026-08-04	WH-CCU-01	ITM-CPU-01	0	1	60	f	none	simulated	system_sim
2902	2026-08-04	WH-CCU-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
2903	2026-08-04	WH-CCU-01	ITM-RAM-01	0	7	49	f	none	simulated	system_sim
2904	2026-08-04	WH-CCU-01	ITM-SSD-01	0	1	69	f	none	simulated	system_sim
2905	2026-08-04	WH-CCU-01	ITM-HDD-01	0	3	35	f	none	simulated	system_sim
2906	2026-08-04	WH-CCU-01	ITM-CHG-01	0	7	154	f	none	simulated	system_sim
2907	2026-08-04	WH-CCU-01	ITM-CBL-01	0	10	171	f	none	simulated	system_sim
2908	2026-08-05	WH-BLR-01	ITM-CPU-01	0	2	59	f	none	simulated	system_sim
2909	2026-08-05	WH-BLR-01	ITM-GPU-01	0	0	9	t	shrinkage	simulated	system_sim
2910	2026-08-05	WH-BLR-01	ITM-RAM-01	0	8	75	f	none	simulated	system_sim
2911	2026-08-05	WH-BLR-01	ITM-SSD-01	0	3	59	f	none	simulated	system_sim
2912	2026-08-05	WH-BLR-01	ITM-HDD-01	60	0	89	f	none	simulated	system_sim
2913	2026-08-05	WH-BLR-01	ITM-CHG-01	0	2	154	f	none	simulated	system_sim
2914	2026-08-05	WH-BLR-01	ITM-CBL-01	0	10	165	f	none	simulated	system_sim
2915	2026-08-05	WH-CHN-01	ITM-CPU-01	0	0	46	f	none	simulated	system_sim
2916	2026-08-05	WH-CHN-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
2917	2026-08-05	WH-CHN-01	ITM-RAM-01	0	2	98	f	none	simulated	system_sim
2918	2026-08-05	WH-CHN-01	ITM-SSD-01	0	1	59	f	none	simulated	system_sim
2919	2026-08-05	WH-CHN-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
2920	2026-08-05	WH-CHN-01	ITM-CHG-01	0	7	193	f	none	simulated	system_sim
2921	2026-08-05	WH-CHN-01	ITM-CBL-01	0	1	184	f	none	simulated	system_sim
2922	2026-08-05	WH-BOM-01	ITM-CPU-01	0	0	58	f	none	simulated	system_sim
2923	2026-08-05	WH-BOM-01	ITM-GPU-01	0	0	15	f	none	simulated	system_sim
2924	2026-08-05	WH-BOM-01	ITM-RAM-01	0	4	96	f	none	simulated	system_sim
2925	2026-08-05	WH-BOM-01	ITM-SSD-01	0	0	58	f	none	simulated	system_sim
2926	2026-08-05	WH-BOM-01	ITM-HDD-01	0	1	31	f	none	simulated	system_sim
2927	2026-08-05	WH-BOM-01	ITM-CHG-01	0	1	181	f	none	simulated	system_sim
2928	2026-08-05	WH-BOM-01	ITM-CBL-01	0	2	181	f	none	simulated	system_sim
2929	2026-08-05	WH-DEL-01	ITM-CPU-01	0	2	60	f	none	simulated	system_sim
2930	2026-08-05	WH-DEL-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
2931	2026-08-05	WH-DEL-01	ITM-RAM-01	0	4	102	f	none	simulated	system_sim
2932	2026-08-05	WH-DEL-01	ITM-SSD-01	0	2	62	f	none	simulated	system_sim
2933	2026-08-05	WH-DEL-01	ITM-HDD-01	0	1	85	f	none	simulated	system_sim
2934	2026-08-05	WH-DEL-01	ITM-CHG-01	0	9	140	f	none	simulated	system_sim
2935	2026-08-05	WH-DEL-01	ITM-CBL-01	0	1	196	f	none	simulated	system_sim
2936	2026-08-05	WH-CCU-01	ITM-CPU-01	0	0	60	f	none	simulated	system_sim
2937	2026-08-05	WH-CCU-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
2938	2026-08-05	WH-CCU-01	ITM-RAM-01	0	1	48	f	none	simulated	system_sim
2939	2026-08-05	WH-CCU-01	ITM-SSD-01	0	1	68	f	none	simulated	system_sim
2940	2026-08-05	WH-CCU-01	ITM-HDD-01	0	1	34	f	none	simulated	system_sim
2941	2026-08-05	WH-CCU-01	ITM-CHG-01	0	1	153	f	none	simulated	system_sim
2942	2026-08-05	WH-CCU-01	ITM-CBL-01	0	5	166	f	none	simulated	system_sim
2943	2026-08-06	WH-BLR-01	ITM-CPU-01	0	0	59	f	none	simulated	system_sim
2944	2026-08-06	WH-BLR-01	ITM-GPU-01	30	1	38	f	none	simulated	system_sim
2945	2026-08-06	WH-BLR-01	ITM-RAM-01	0	6	69	f	none	simulated	system_sim
2946	2026-08-06	WH-BLR-01	ITM-SSD-01	0	1	58	f	none	simulated	system_sim
2947	2026-08-06	WH-BLR-01	ITM-HDD-01	0	0	89	f	none	simulated	system_sim
2948	2026-08-06	WH-BLR-01	ITM-CHG-01	0	4	150	f	none	simulated	system_sim
2949	2026-08-06	WH-BLR-01	ITM-CBL-01	0	8	157	f	none	simulated	system_sim
2950	2026-08-06	WH-CHN-01	ITM-CPU-01	0	3	43	f	none	simulated	system_sim
2951	2026-08-06	WH-CHN-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
2952	2026-08-06	WH-CHN-01	ITM-RAM-01	0	1	97	f	none	simulated	system_sim
2953	2026-08-06	WH-CHN-01	ITM-SSD-01	0	3	56	f	none	simulated	system_sim
2954	2026-08-06	WH-CHN-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
2955	2026-08-06	WH-CHN-01	ITM-CHG-01	0	8	185	f	none	simulated	system_sim
2956	2026-08-06	WH-CHN-01	ITM-CBL-01	0	10	174	f	none	simulated	system_sim
2957	2026-08-06	WH-BOM-01	ITM-CPU-01	0	3	55	f	none	simulated	system_sim
2958	2026-08-06	WH-BOM-01	ITM-GPU-01	0	1	14	f	none	simulated	system_sim
2959	2026-08-06	WH-BOM-01	ITM-RAM-01	0	10	86	f	none	simulated	system_sim
2960	2026-08-06	WH-BOM-01	ITM-SSD-01	0	0	58	f	none	simulated	system_sim
2961	2026-08-06	WH-BOM-01	ITM-HDD-01	0	2	29	f	none	simulated	system_sim
2962	2026-08-06	WH-BOM-01	ITM-CHG-01	0	4	177	f	none	simulated	system_sim
2963	2026-08-06	WH-BOM-01	ITM-CBL-01	0	10	171	f	none	simulated	system_sim
2964	2026-08-06	WH-DEL-01	ITM-CPU-01	0	2	58	f	none	simulated	system_sim
2965	2026-08-06	WH-DEL-01	ITM-GPU-01	0	2	15	f	none	simulated	system_sim
2966	2026-08-06	WH-DEL-01	ITM-RAM-01	0	5	97	f	none	simulated	system_sim
2967	2026-08-06	WH-DEL-01	ITM-SSD-01	0	1	61	f	none	simulated	system_sim
2968	2026-08-06	WH-DEL-01	ITM-HDD-01	0	3	82	f	none	simulated	system_sim
2969	2026-08-06	WH-DEL-01	ITM-CHG-01	0	4	136	f	none	simulated	system_sim
2970	2026-08-06	WH-DEL-01	ITM-CBL-01	0	5	191	f	none	simulated	system_sim
2971	2026-08-06	WH-CCU-01	ITM-CPU-01	0	0	60	f	none	simulated	system_sim
2972	2026-08-06	WH-CCU-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
2973	2026-08-06	WH-CCU-01	ITM-RAM-01	0	8	40	f	none	simulated	system_sim
2974	2026-08-06	WH-CCU-01	ITM-SSD-01	0	2	66	f	none	simulated	system_sim
2975	2026-08-06	WH-CCU-01	ITM-HDD-01	0	0	34	f	none	simulated	system_sim
2976	2026-08-06	WH-CCU-01	ITM-CHG-01	0	6	147	f	none	simulated	system_sim
2977	2026-08-06	WH-CCU-01	ITM-CBL-01	0	7	159	f	none	simulated	system_sim
2978	2026-08-07	WH-BLR-01	ITM-CPU-01	0	0	59	f	none	simulated	system_sim
2979	2026-08-07	WH-BLR-01	ITM-GPU-01	0	1	37	f	none	simulated	system_sim
2980	2026-08-07	WH-BLR-01	ITM-RAM-01	0	6	63	f	none	simulated	system_sim
2981	2026-08-07	WH-BLR-01	ITM-SSD-01	0	2	56	f	none	simulated	system_sim
2982	2026-08-07	WH-BLR-01	ITM-HDD-01	0	2	87	f	none	simulated	system_sim
2983	2026-08-07	WH-BLR-01	ITM-CHG-01	0	8	142	f	none	simulated	system_sim
2984	2026-08-07	WH-BLR-01	ITM-CBL-01	0	7	150	f	none	simulated	system_sim
2985	2026-08-07	WH-CHN-01	ITM-CPU-01	0	2	41	f	none	simulated	system_sim
2986	2026-08-07	WH-CHN-01	ITM-GPU-01	0	1	18	f	none	simulated	system_sim
2987	2026-08-07	WH-CHN-01	ITM-RAM-01	0	8	89	f	none	simulated	system_sim
2988	2026-08-07	WH-CHN-01	ITM-SSD-01	0	2	54	f	none	simulated	system_sim
2989	2026-08-07	WH-CHN-01	ITM-HDD-01	0	3	35	f	none	simulated	system_sim
2990	2026-08-07	WH-CHN-01	ITM-CHG-01	0	9	176	f	none	simulated	system_sim
2991	2026-08-07	WH-CHN-01	ITM-CBL-01	0	8	166	f	none	simulated	system_sim
2992	2026-08-07	WH-BOM-01	ITM-CPU-01	0	0	55	f	none	simulated	system_sim
2993	2026-08-07	WH-BOM-01	ITM-GPU-01	30	1	43	f	none	simulated	system_sim
2994	2026-08-07	WH-BOM-01	ITM-RAM-01	0	1	85	f	none	simulated	system_sim
2995	2026-08-07	WH-BOM-01	ITM-SSD-01	0	2	56	f	none	simulated	system_sim
2996	2026-08-07	WH-BOM-01	ITM-HDD-01	60	0	89	f	none	simulated	system_sim
2997	2026-08-07	WH-BOM-01	ITM-CHG-01	0	5	172	f	none	simulated	system_sim
2998	2026-08-07	WH-BOM-01	ITM-CBL-01	0	1	170	f	none	simulated	system_sim
2999	2026-08-07	WH-DEL-01	ITM-CPU-01	0	0	58	f	none	simulated	system_sim
3000	2026-08-07	WH-DEL-01	ITM-GPU-01	0	0	15	f	none	simulated	system_sim
3001	2026-08-07	WH-DEL-01	ITM-RAM-01	0	10	87	f	none	simulated	system_sim
3002	2026-08-07	WH-DEL-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
3003	2026-08-07	WH-DEL-01	ITM-HDD-01	0	0	82	f	none	simulated	system_sim
3004	2026-08-07	WH-DEL-01	ITM-CHG-01	0	3	133	f	none	simulated	system_sim
3005	2026-08-07	WH-DEL-01	ITM-CBL-01	0	3	188	f	none	simulated	system_sim
3006	2026-08-07	WH-CCU-01	ITM-CPU-01	0	1	59	f	none	simulated	system_sim
3007	2026-08-07	WH-CCU-01	ITM-GPU-01	0	2	40	f	none	simulated	system_sim
3008	2026-08-07	WH-CCU-01	ITM-RAM-01	0	2	38	f	none	simulated	system_sim
3009	2026-08-07	WH-CCU-01	ITM-SSD-01	0	2	64	f	none	simulated	system_sim
3010	2026-08-07	WH-CCU-01	ITM-HDD-01	0	0	34	f	none	simulated	system_sim
3011	2026-08-07	WH-CCU-01	ITM-CHG-01	0	5	142	f	none	simulated	system_sim
3012	2026-08-07	WH-CCU-01	ITM-CBL-01	0	1	158	f	none	simulated	system_sim
3013	2026-08-08	WH-BLR-01	ITM-CPU-01	0	2	57	f	none	simulated	system_sim
3014	2026-08-08	WH-BLR-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
3015	2026-08-08	WH-BLR-01	ITM-RAM-01	0	5	58	f	none	simulated	system_sim
3016	2026-08-08	WH-BLR-01	ITM-SSD-01	0	0	56	f	none	simulated	system_sim
3017	2026-08-08	WH-BLR-01	ITM-HDD-01	0	1	86	f	none	simulated	system_sim
3018	2026-08-08	WH-BLR-01	ITM-CHG-01	0	8	134	f	none	simulated	system_sim
3019	2026-08-08	WH-BLR-01	ITM-CBL-01	0	5	145	f	none	simulated	system_sim
3020	2026-08-08	WH-CHN-01	ITM-CPU-01	0	3	38	f	none	simulated	system_sim
3021	2026-08-08	WH-CHN-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
3022	2026-08-08	WH-CHN-01	ITM-RAM-01	0	5	84	f	none	simulated	system_sim
3023	2026-08-08	WH-CHN-01	ITM-SSD-01	0	0	54	f	none	simulated	system_sim
3024	2026-08-08	WH-CHN-01	ITM-HDD-01	0	2	33	f	none	simulated	system_sim
3025	2026-08-08	WH-CHN-01	ITM-CHG-01	0	3	173	f	none	simulated	system_sim
3026	2026-08-08	WH-CHN-01	ITM-CBL-01	0	6	160	f	none	simulated	system_sim
3027	2026-08-08	WH-BOM-01	ITM-CPU-01	0	1	54	f	none	simulated	system_sim
3028	2026-08-08	WH-BOM-01	ITM-GPU-01	0	2	41	f	none	simulated	system_sim
3029	2026-08-08	WH-BOM-01	ITM-RAM-01	0	9	76	f	none	simulated	system_sim
3030	2026-08-08	WH-BOM-01	ITM-SSD-01	0	0	56	f	none	simulated	system_sim
3031	2026-08-08	WH-BOM-01	ITM-HDD-01	0	3	86	f	none	simulated	system_sim
3032	2026-08-08	WH-BOM-01	ITM-CHG-01	0	3	169	f	none	simulated	system_sim
3033	2026-08-08	WH-BOM-01	ITM-CBL-01	0	2	168	f	none	simulated	system_sim
3034	2026-08-08	WH-DEL-01	ITM-CPU-01	0	2	56	f	none	simulated	system_sim
3035	2026-08-08	WH-DEL-01	ITM-GPU-01	0	2	13	f	none	simulated	system_sim
3036	2026-08-08	WH-DEL-01	ITM-RAM-01	0	2	85	f	none	simulated	system_sim
3037	2026-08-08	WH-DEL-01	ITM-SSD-01	0	2	59	f	none	simulated	system_sim
3038	2026-08-08	WH-DEL-01	ITM-HDD-01	0	3	79	f	none	simulated	system_sim
3039	2026-08-08	WH-DEL-01	ITM-CHG-01	0	1	132	f	none	simulated	system_sim
3040	2026-08-08	WH-DEL-01	ITM-CBL-01	0	9	179	f	none	simulated	system_sim
3041	2026-08-08	WH-CCU-01	ITM-CPU-01	0	0	59	f	none	simulated	system_sim
3042	2026-08-08	WH-CCU-01	ITM-GPU-01	0	2	38	f	none	simulated	system_sim
3043	2026-08-08	WH-CCU-01	ITM-RAM-01	0	3	35	f	none	simulated	system_sim
3044	2026-08-08	WH-CCU-01	ITM-SSD-01	0	0	64	f	none	simulated	system_sim
3045	2026-08-08	WH-CCU-01	ITM-HDD-01	0	2	32	f	none	simulated	system_sim
3046	2026-08-08	WH-CCU-01	ITM-CHG-01	0	3	139	f	none	simulated	system_sim
3047	2026-08-08	WH-CCU-01	ITM-CBL-01	0	9	149	f	none	simulated	system_sim
3048	2026-08-09	WH-BLR-01	ITM-CPU-01	0	0	57	f	none	simulated	system_sim
3049	2026-08-09	WH-BLR-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
3050	2026-08-09	WH-BLR-01	ITM-RAM-01	0	7	51	f	none	simulated	system_sim
3051	2026-08-09	WH-BLR-01	ITM-SSD-01	0	2	54	f	none	simulated	system_sim
3052	2026-08-09	WH-BLR-01	ITM-HDD-01	0	0	86	f	none	simulated	system_sim
3053	2026-08-09	WH-BLR-01	ITM-CHG-01	0	8	126	f	none	simulated	system_sim
3054	2026-08-09	WH-BLR-01	ITM-CBL-01	300	8	437	f	none	simulated	system_sim
3055	2026-08-09	WH-CHN-01	ITM-CPU-01	0	3	35	f	none	simulated	system_sim
3056	2026-08-09	WH-CHN-01	ITM-GPU-01	0	2	15	f	none	simulated	system_sim
3057	2026-08-09	WH-CHN-01	ITM-RAM-01	0	4	80	f	none	simulated	system_sim
3058	2026-08-09	WH-CHN-01	ITM-SSD-01	0	2	52	f	none	simulated	system_sim
3059	2026-08-09	WH-CHN-01	ITM-HDD-01	0	3	30	f	none	simulated	system_sim
3060	2026-08-09	WH-CHN-01	ITM-CHG-01	0	6	167	f	none	simulated	system_sim
3061	2026-08-09	WH-CHN-01	ITM-CBL-01	0	1	159	f	none	simulated	system_sim
3062	2026-08-09	WH-BOM-01	ITM-CPU-01	0	1	53	f	none	simulated	system_sim
3063	2026-08-09	WH-BOM-01	ITM-GPU-01	0	0	41	f	none	simulated	system_sim
3064	2026-08-09	WH-BOM-01	ITM-RAM-01	0	5	71	f	none	simulated	system_sim
3065	2026-08-09	WH-BOM-01	ITM-SSD-01	0	1	55	f	none	simulated	system_sim
3066	2026-08-09	WH-BOM-01	ITM-HDD-01	0	0	86	f	none	simulated	system_sim
3067	2026-08-09	WH-BOM-01	ITM-CHG-01	0	7	162	f	none	simulated	system_sim
3068	2026-08-09	WH-BOM-01	ITM-CBL-01	0	1	167	f	none	simulated	system_sim
3069	2026-08-09	WH-DEL-01	ITM-CPU-01	0	2	54	f	none	simulated	system_sim
3070	2026-08-09	WH-DEL-01	ITM-GPU-01	30	0	43	f	none	simulated	system_sim
3071	2026-08-09	WH-DEL-01	ITM-RAM-01	0	10	75	f	none	simulated	system_sim
3072	2026-08-09	WH-DEL-01	ITM-SSD-01	0	1	58	f	none	simulated	system_sim
3073	2026-08-09	WH-DEL-01	ITM-HDD-01	0	2	77	f	none	simulated	system_sim
3074	2026-08-09	WH-DEL-01	ITM-CHG-01	0	6	126	f	none	simulated	system_sim
3075	2026-08-09	WH-DEL-01	ITM-CBL-01	0	8	171	f	none	simulated	system_sim
3076	2026-08-09	WH-CCU-01	ITM-CPU-01	0	1	58	f	none	simulated	system_sim
3077	2026-08-09	WH-CCU-01	ITM-GPU-01	0	0	38	f	none	simulated	system_sim
3078	2026-08-09	WH-CCU-01	ITM-RAM-01	75	6	104	f	none	simulated	system_sim
3079	2026-08-09	WH-CCU-01	ITM-SSD-01	0	1	63	f	none	simulated	system_sim
3080	2026-08-09	WH-CCU-01	ITM-HDD-01	0	2	30	f	none	simulated	system_sim
3081	2026-08-09	WH-CCU-01	ITM-CHG-01	0	8	131	f	none	simulated	system_sim
3082	2026-08-09	WH-CCU-01	ITM-CBL-01	300	7	442	f	none	simulated	system_sim
3083	2026-08-10	WH-BLR-01	ITM-CPU-01	0	0	57	f	none	simulated	system_sim
3084	2026-08-10	WH-BLR-01	ITM-GPU-01	0	2	35	f	none	simulated	system_sim
3085	2026-08-10	WH-BLR-01	ITM-RAM-01	0	2	49	f	none	simulated	system_sim
3086	2026-08-10	WH-BLR-01	ITM-SSD-01	0	0	54	f	none	simulated	system_sim
3087	2026-08-10	WH-BLR-01	ITM-HDD-01	0	2	84	f	none	simulated	system_sim
3088	2026-08-10	WH-BLR-01	ITM-CHG-01	0	7	119	f	none	simulated	system_sim
3089	2026-08-10	WH-BLR-01	ITM-CBL-01	0	3	434	f	none	simulated	system_sim
3090	2026-08-10	WH-CHN-01	ITM-CPU-01	0	3	32	f	none	simulated	system_sim
3091	2026-08-10	WH-CHN-01	ITM-GPU-01	0	0	15	f	none	simulated	system_sim
3092	2026-08-10	WH-CHN-01	ITM-RAM-01	0	4	76	f	none	simulated	system_sim
3093	2026-08-10	WH-CHN-01	ITM-SSD-01	0	0	52	f	none	simulated	system_sim
3094	2026-08-10	WH-CHN-01	ITM-HDD-01	0	1	29	f	none	simulated	system_sim
3095	2026-08-10	WH-CHN-01	ITM-CHG-01	0	10	157	f	none	simulated	system_sim
3096	2026-08-10	WH-CHN-01	ITM-CBL-01	0	4	155	f	none	simulated	system_sim
3097	2026-08-10	WH-BOM-01	ITM-CPU-01	0	0	53	f	none	simulated	system_sim
3098	2026-08-10	WH-BOM-01	ITM-GPU-01	0	0	41	f	none	simulated	system_sim
3099	2026-08-10	WH-BOM-01	ITM-RAM-01	0	9	62	f	none	simulated	system_sim
3100	2026-08-10	WH-BOM-01	ITM-SSD-01	0	2	53	f	none	simulated	system_sim
3101	2026-08-10	WH-BOM-01	ITM-HDD-01	0	1	85	f	none	simulated	system_sim
3102	2026-08-10	WH-BOM-01	ITM-CHG-01	0	10	152	f	none	simulated	system_sim
3103	2026-08-10	WH-BOM-01	ITM-CBL-01	0	9	158	f	none	simulated	system_sim
3104	2026-08-10	WH-DEL-01	ITM-CPU-01	0	3	51	f	none	simulated	system_sim
3105	2026-08-10	WH-DEL-01	ITM-GPU-01	0	0	43	f	none	simulated	system_sim
3106	2026-08-10	WH-DEL-01	ITM-RAM-01	0	2	73	f	none	simulated	system_sim
3107	2026-08-10	WH-DEL-01	ITM-SSD-01	0	1	57	f	none	simulated	system_sim
3108	2026-08-10	WH-DEL-01	ITM-HDD-01	0	3	74	f	none	simulated	system_sim
3109	2026-08-10	WH-DEL-01	ITM-CHG-01	0	10	116	f	none	simulated	system_sim
3110	2026-08-10	WH-DEL-01	ITM-CBL-01	0	2	169	f	none	simulated	system_sim
3111	2026-08-10	WH-CCU-01	ITM-CPU-01	0	0	58	f	none	simulated	system_sim
3112	2026-08-10	WH-CCU-01	ITM-GPU-01	0	2	36	f	none	simulated	system_sim
3113	2026-08-10	WH-CCU-01	ITM-RAM-01	0	6	98	f	none	simulated	system_sim
3114	2026-08-10	WH-CCU-01	ITM-SSD-01	0	1	62	f	none	simulated	system_sim
3115	2026-08-10	WH-CCU-01	ITM-HDD-01	0	0	30	f	none	simulated	system_sim
3116	2026-08-10	WH-CCU-01	ITM-CHG-01	0	6	125	f	none	simulated	system_sim
3117	2026-08-10	WH-CCU-01	ITM-CBL-01	0	10	432	f	none	simulated	system_sim
3118	2026-08-11	WH-BLR-01	ITM-CPU-01	0	0	57	f	none	simulated	system_sim
3119	2026-08-11	WH-BLR-01	ITM-GPU-01	0	0	35	f	none	simulated	system_sim
3120	2026-08-11	WH-BLR-01	ITM-RAM-01	0	7	42	f	none	simulated	system_sim
3121	2026-08-11	WH-BLR-01	ITM-SSD-01	0	2	52	f	none	simulated	system_sim
3122	2026-08-11	WH-BLR-01	ITM-HDD-01	0	2	82	f	none	simulated	system_sim
3123	2026-08-11	WH-BLR-01	ITM-CHG-01	0	6	113	f	none	simulated	system_sim
3124	2026-08-11	WH-BLR-01	ITM-CBL-01	0	2	432	f	none	simulated	system_sim
3125	2026-08-11	WH-CHN-01	ITM-CPU-01	0	3	29	f	none	simulated	system_sim
3126	2026-08-11	WH-CHN-01	ITM-GPU-01	0	0	15	f	none	simulated	system_sim
3127	2026-08-11	WH-CHN-01	ITM-RAM-01	0	1	75	f	none	simulated	system_sim
3128	2026-08-11	WH-CHN-01	ITM-SSD-01	0	2	50	f	none	simulated	system_sim
3129	2026-08-11	WH-CHN-01	ITM-HDD-01	60	0	89	f	none	simulated	system_sim
3130	2026-08-11	WH-CHN-01	ITM-CHG-01	0	8	149	f	none	simulated	system_sim
3131	2026-08-11	WH-CHN-01	ITM-CBL-01	0	9	146	f	none	simulated	system_sim
3132	2026-08-11	WH-BOM-01	ITM-CPU-01	0	0	53	f	none	simulated	system_sim
3133	2026-08-11	WH-BOM-01	ITM-GPU-01	0	1	40	f	none	simulated	system_sim
3134	2026-08-11	WH-BOM-01	ITM-RAM-01	0	9	53	f	none	simulated	system_sim
3135	2026-08-11	WH-BOM-01	ITM-SSD-01	0	0	53	f	none	simulated	system_sim
3136	2026-08-11	WH-BOM-01	ITM-HDD-01	0	2	83	f	none	simulated	system_sim
3137	2026-08-11	WH-BOM-01	ITM-CHG-01	0	8	144	f	none	simulated	system_sim
3138	2026-08-11	WH-BOM-01	ITM-CBL-01	0	7	151	f	none	simulated	system_sim
3139	2026-08-11	WH-DEL-01	ITM-CPU-01	0	0	51	f	none	simulated	system_sim
3140	2026-08-11	WH-DEL-01	ITM-GPU-01	0	1	42	f	none	simulated	system_sim
3141	2026-08-11	WH-DEL-01	ITM-RAM-01	0	8	65	f	none	simulated	system_sim
3142	2026-08-11	WH-DEL-01	ITM-SSD-01	0	1	56	f	none	simulated	system_sim
3143	2026-08-11	WH-DEL-01	ITM-HDD-01	0	0	74	f	none	simulated	system_sim
3144	2026-08-11	WH-DEL-01	ITM-CHG-01	0	8	108	f	none	simulated	system_sim
3145	2026-08-11	WH-DEL-01	ITM-CBL-01	0	1	168	f	none	simulated	system_sim
3146	2026-08-11	WH-CCU-01	ITM-CPU-01	0	0	58	f	none	simulated	system_sim
3147	2026-08-11	WH-CCU-01	ITM-GPU-01	0	2	34	f	none	simulated	system_sim
3148	2026-08-11	WH-CCU-01	ITM-RAM-01	0	3	95	f	none	simulated	system_sim
3149	2026-08-11	WH-CCU-01	ITM-SSD-01	0	1	61	f	none	simulated	system_sim
3150	2026-08-11	WH-CCU-01	ITM-HDD-01	0	0	30	f	none	simulated	system_sim
3151	2026-08-11	WH-CCU-01	ITM-CHG-01	0	10	115	f	none	simulated	system_sim
3152	2026-08-11	WH-CCU-01	ITM-CBL-01	0	9	423	f	none	simulated	system_sim
\.


--
-- Data for Name: task_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_events (id, task_id, event_type, previous_status, new_status, user_id, created_at, reason, metadata) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, order_id, order_item_id, product_id, source_location_id, requested_quantity, completed_quantity, status, created_at, started_at, completed_at, notes, task_number, warehouse_id, task_type, priority, priority_score, source_type, source_id, destination_location_id, assigned_user_id, assigned_robot_id, prioritized_at, assigned_at, paused_at, failed_at, cancelled_at, due_at, retry_count, failure_reason, metadata, depends_on_task_id) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (id, user_id, session_token_hash, created_at, last_seen_at, expires_at, revoked_at, revoke_reason, login_method, ip_address, login_location, user_agent) FROM stdin;
\.


--
-- Data for Name: user_warehouse_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_warehouse_access (id, user_id, warehouse_id, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password_hash, role, full_name, google_subject_id, created_at, email, is_active, is_verified, last_login_at, last_logout_at, last_login_ip, login_location, login_method, failed_login_count, locked_until, email_verified_at, password_changed_at, updated_at) FROM stdin;
3	harsha200797+new@gmail.com	GOOGLE_OAUTH_ONLY	admin	Test Admin	\N	2026-08-14 11:06:06.740539	harsha200797+new@gmail.com	t	t	\N	\N	\N	\N	\N	0	\N	\N	\N	\N
4	testadmin_1786780003@gmail.com	GOOGLE_OAUTH_ONLY	admin	Test Administrator	\N	2026-08-15 07:46:48.142813	testadmin_1786780003@gmail.com	t	t	\N	\N	\N	\N	\N	0	\N	\N	\N	\N
5	testadmin_1786780047@gmail.com	GOOGLE_OAUTH_ONLY	admin	Test Administrator	\N	2026-08-15 07:47:32.710151	testadmin_1786780047@gmail.com	t	t	\N	\N	\N	\N	\N	0	\N	\N	\N	\N
2	harsha200797@gmail.com	$2b$12$NOlbO9fWjPIGklV.rRcGO.dcF/ILm3dBtwJ7XGdDU1QyVwOet23be	admin	Harsha Vardhan	117591730789469546962	2026-08-14 10:32:57.463364	harsha200797@gmail.com	t	t	2026-08-19 06:47:41.68374	\N	127.0.0.1	\N	password	0	\N	\N	\N	2026-08-19 06:47:41.687094
9	joyboy56211@gmail.com	GOOGLE_OAUTH_ONLY	admin	joyboy	\N	2026-08-15 15:52:47.166598	joyboy56211@gmail.com	t	t	\N	\N	\N	\N	\N	0	\N	\N	\N	2026-08-19 06:56:11.328857
1	admin	$2b$12$z7JVwvNuVk9ZWRNc4e1xAuf.UdaolPvtcZ5x4PG1QEvMD3C61/LQG	admin	System Administrator	\N	2026-08-14 10:31:22.459306	admin	t	t	2026-08-19 10:29:51.907173	\N	testclient	\N	password	0	\N	\N	\N	2026-08-19 10:29:51.912908
\.


--
-- Data for Name: warehouse_grid_cells; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_grid_cells (id, warehouse_id, x, y, cell_type, traversable, occupied, restricted, cost, metadata) FROM stdin;
\.


--
-- Data for Name: warehouse_locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_locations (id, warehouse_id, zone, aisle, rack, shelf, x, y, capacity, current_utilization, location_type, status, created_at) FROM stdin;
WH-WH-BLR-01-RECEIVING	WH-BLR-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-SHIPPING	WH-BLR-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-STAGING	WH-BLR-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-CHARGING-1	WH-BLR-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-CHARGING-2	WH-BLR-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-CPU-01-STORAGE	WH-BLR-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-GPU-01-STORAGE	WH-BLR-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-RAM-01-STORAGE	WH-BLR-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-SSD-01-STORAGE	WH-BLR-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-HDD-01-STORAGE	WH-BLR-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-CHG-01-STORAGE	WH-BLR-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-CBL-01-STORAGE	WH-BLR-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-CPU-01-PICKING	WH-BLR-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-GPU-01-PICKING	WH-BLR-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-RAM-01-PICKING	WH-BLR-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-SSD-01-PICKING	WH-BLR-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-HDD-01-PICKING	WH-BLR-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-CHG-01-PICKING	WH-BLR-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-LOC-ITM-CBL-01-PICKING	WH-BLR-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-1-1	WH-BLR-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-12-1	WH-BLR-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-1-2	WH-BLR-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-2-2	WH-BLR-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-3-2	WH-BLR-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-4-2	WH-BLR-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-5-2	WH-BLR-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-6-2	WH-BLR-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-7-2	WH-BLR-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-8-2	WH-BLR-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-9-2	WH-BLR-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-10-2	WH-BLR-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-11-2	WH-BLR-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-12-2	WH-BLR-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-1-3	WH-BLR-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-12-3	WH-BLR-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-1-4	WH-BLR-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-2-4	WH-BLR-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-3-4	WH-BLR-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-4-4	WH-BLR-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-5-4	WH-BLR-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-6-4	WH-BLR-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-7-4	WH-BLR-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-8-4	WH-BLR-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-9-4	WH-BLR-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-10-4	WH-BLR-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-11-4	WH-BLR-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-12-4	WH-BLR-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-3-5	WH-BLR-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-4-5	WH-BLR-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-5-5	WH-BLR-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-6-5	WH-BLR-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-7-5	WH-BLR-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-8-5	WH-BLR-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-9-5	WH-BLR-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BLR-01-AISLE-10-5	WH-BLR-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-RECEIVING	WH-CHN-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-SHIPPING	WH-CHN-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-STAGING	WH-CHN-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-CHARGING-1	WH-CHN-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-CHARGING-2	WH-CHN-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-CPU-01-STORAGE	WH-CHN-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-GPU-01-STORAGE	WH-CHN-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-RAM-01-STORAGE	WH-CHN-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-SSD-01-STORAGE	WH-CHN-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-HDD-01-STORAGE	WH-CHN-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-CHG-01-STORAGE	WH-CHN-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-CBL-01-STORAGE	WH-CHN-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-CPU-01-PICKING	WH-CHN-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-GPU-01-PICKING	WH-CHN-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-RAM-01-PICKING	WH-CHN-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-SSD-01-PICKING	WH-CHN-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-HDD-01-PICKING	WH-CHN-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-CHG-01-PICKING	WH-CHN-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-LOC-ITM-CBL-01-PICKING	WH-CHN-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-1-1	WH-CHN-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-12-1	WH-CHN-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-1-2	WH-CHN-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-2-2	WH-CHN-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-3-2	WH-CHN-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-4-2	WH-CHN-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-5-2	WH-CHN-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-6-2	WH-CHN-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-7-2	WH-CHN-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-8-2	WH-CHN-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-9-2	WH-CHN-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-10-2	WH-CHN-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-11-2	WH-CHN-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-12-2	WH-CHN-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-1-3	WH-CHN-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-12-3	WH-CHN-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-1-4	WH-CHN-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-2-4	WH-CHN-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-3-4	WH-CHN-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-4-4	WH-CHN-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-5-4	WH-CHN-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-6-4	WH-CHN-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-7-4	WH-CHN-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-8-4	WH-CHN-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-9-4	WH-CHN-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-10-4	WH-CHN-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-11-4	WH-CHN-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-12-4	WH-CHN-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-3-5	WH-CHN-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-4-5	WH-CHN-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-5-5	WH-CHN-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-6-5	WH-CHN-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-7-5	WH-CHN-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-8-5	WH-CHN-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-9-5	WH-CHN-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-CHN-01-AISLE-10-5	WH-CHN-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-RECEIVING	WH-BOM-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-SHIPPING	WH-BOM-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-STAGING	WH-BOM-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-CHARGING-1	WH-BOM-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-CHARGING-2	WH-BOM-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-CPU-01-STORAGE	WH-BOM-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-GPU-01-STORAGE	WH-BOM-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-RAM-01-STORAGE	WH-BOM-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-SSD-01-STORAGE	WH-BOM-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-HDD-01-STORAGE	WH-BOM-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-CHG-01-STORAGE	WH-BOM-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-CBL-01-STORAGE	WH-BOM-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-CPU-01-PICKING	WH-BOM-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-GPU-01-PICKING	WH-BOM-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-RAM-01-PICKING	WH-BOM-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-SSD-01-PICKING	WH-BOM-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-HDD-01-PICKING	WH-BOM-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-CHG-01-PICKING	WH-BOM-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-LOC-ITM-CBL-01-PICKING	WH-BOM-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-1-1	WH-BOM-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-12-1	WH-BOM-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-1-2	WH-BOM-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-2-2	WH-BOM-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-3-2	WH-BOM-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-4-2	WH-BOM-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-5-2	WH-BOM-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-6-2	WH-BOM-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-7-2	WH-BOM-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-8-2	WH-BOM-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-9-2	WH-BOM-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-10-2	WH-BOM-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-11-2	WH-BOM-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-12-2	WH-BOM-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-1-3	WH-BOM-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-12-3	WH-BOM-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-1-4	WH-BOM-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-2-4	WH-BOM-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.469453
WH-WH-BOM-01-AISLE-3-4	WH-BOM-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-4-4	WH-BOM-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-5-4	WH-BOM-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-6-4	WH-BOM-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-7-4	WH-BOM-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-8-4	WH-BOM-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-9-4	WH-BOM-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-10-4	WH-BOM-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-11-4	WH-BOM-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-12-4	WH-BOM-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-3-5	WH-BOM-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-4-5	WH-BOM-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-5-5	WH-BOM-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-6-5	WH-BOM-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-7-5	WH-BOM-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-8-5	WH-BOM-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-9-5	WH-BOM-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-BOM-01-AISLE-10-5	WH-BOM-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-RECEIVING	WH-DEL-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-SHIPPING	WH-DEL-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-STAGING	WH-DEL-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-CHARGING-1	WH-DEL-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-CHARGING-2	WH-DEL-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-CPU-01-STORAGE	WH-DEL-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-GPU-01-STORAGE	WH-DEL-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-RAM-01-STORAGE	WH-DEL-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-SSD-01-STORAGE	WH-DEL-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-HDD-01-STORAGE	WH-DEL-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-CHG-01-STORAGE	WH-DEL-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-CBL-01-STORAGE	WH-DEL-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-CPU-01-PICKING	WH-DEL-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-GPU-01-PICKING	WH-DEL-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-RAM-01-PICKING	WH-DEL-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-SSD-01-PICKING	WH-DEL-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-HDD-01-PICKING	WH-DEL-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-CHG-01-PICKING	WH-DEL-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-LOC-ITM-CBL-01-PICKING	WH-DEL-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-1-1	WH-DEL-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-12-1	WH-DEL-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-1-2	WH-DEL-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-2-2	WH-DEL-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-3-2	WH-DEL-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-4-2	WH-DEL-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-5-2	WH-DEL-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-6-2	WH-DEL-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-7-2	WH-DEL-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-8-2	WH-DEL-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-9-2	WH-DEL-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-10-2	WH-DEL-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-11-2	WH-DEL-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-12-2	WH-DEL-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-1-3	WH-DEL-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-12-3	WH-DEL-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-1-4	WH-DEL-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-2-4	WH-DEL-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-3-4	WH-DEL-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-4-4	WH-DEL-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-5-4	WH-DEL-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-6-4	WH-DEL-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-7-4	WH-DEL-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-8-4	WH-DEL-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-9-4	WH-DEL-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-10-4	WH-DEL-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-11-4	WH-DEL-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-12-4	WH-DEL-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-3-5	WH-DEL-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-4-5	WH-DEL-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-5-5	WH-DEL-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-6-5	WH-DEL-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-7-5	WH-DEL-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-8-5	WH-DEL-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-9-5	WH-DEL-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-DEL-01-AISLE-10-5	WH-DEL-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-RECEIVING	WH-CCU-01	RECEIVING	1	1	1	1	5	500	0	RECEIVING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-SHIPPING	WH-CCU-01	SHIPPING	1	1	1	2	5	500	0	SHIPPING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-STAGING	WH-CCU-01	STAGING	1	1	1	6	5	500	0	STAGING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-CHARGING-1	WH-CCU-01	CHARGING	1	1	1	11	5	500	0	CHARGING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-CHARGING-2	WH-CCU-01	CHARGING	1	2	1	12	5	500	0	CHARGING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-CPU-01-STORAGE	WH-CCU-01	ZONE-A	1	01	1	2	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-GPU-01-STORAGE	WH-CCU-01	ZONE-A	1	01	1	3	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-RAM-01-STORAGE	WH-CCU-01	ZONE-A	1	01	1	4	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-SSD-01-STORAGE	WH-CCU-01	ZONE-B	1	01	1	6	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-HDD-01-STORAGE	WH-CCU-01	ZONE-B	1	01	1	7	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-CHG-01-STORAGE	WH-CCU-01	ZONE-C	1	01	1	9	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-CBL-01-STORAGE	WH-CCU-01	ZONE-C	1	01	1	10	1	500	0	STORAGE	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-CPU-01-PICKING	WH-CCU-01	ZONE-A	1	01	1	2	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-GPU-01-PICKING	WH-CCU-01	ZONE-A	1	01	1	3	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-RAM-01-PICKING	WH-CCU-01	ZONE-A	1	01	1	4	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-SSD-01-PICKING	WH-CCU-01	ZONE-B	1	01	1	6	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-HDD-01-PICKING	WH-CCU-01	ZONE-B	1	01	1	7	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-CHG-01-PICKING	WH-CCU-01	ZONE-C	1	01	1	9	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-LOC-ITM-CBL-01-PICKING	WH-CCU-01	ZONE-C	1	01	1	10	3	500	0	PICKING	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-1-1	WH-CCU-01	AISLE	1	0	0	1	1	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-12-1	WH-CCU-01	AISLE	12	0	0	12	1	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-1-2	WH-CCU-01	AISLE	1	0	0	1	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-2-2	WH-CCU-01	AISLE	2	0	0	2	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-3-2	WH-CCU-01	AISLE	3	0	0	3	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-4-2	WH-CCU-01	AISLE	4	0	0	4	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-5-2	WH-CCU-01	AISLE	5	0	0	5	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-6-2	WH-CCU-01	AISLE	6	0	0	6	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-7-2	WH-CCU-01	AISLE	7	0	0	7	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-8-2	WH-CCU-01	AISLE	8	0	0	8	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-9-2	WH-CCU-01	AISLE	9	0	0	9	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-10-2	WH-CCU-01	AISLE	10	0	0	10	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-11-2	WH-CCU-01	AISLE	11	0	0	11	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-12-2	WH-CCU-01	AISLE	12	0	0	12	2	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-1-3	WH-CCU-01	AISLE	1	0	0	1	3	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-12-3	WH-CCU-01	AISLE	12	0	0	12	3	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-1-4	WH-CCU-01	AISLE	1	0	0	1	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-2-4	WH-CCU-01	AISLE	2	0	0	2	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-3-4	WH-CCU-01	AISLE	3	0	0	3	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-4-4	WH-CCU-01	AISLE	4	0	0	4	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-5-4	WH-CCU-01	AISLE	5	0	0	5	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-6-4	WH-CCU-01	AISLE	6	0	0	6	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-7-4	WH-CCU-01	AISLE	7	0	0	7	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-8-4	WH-CCU-01	AISLE	8	0	0	8	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-9-4	WH-CCU-01	AISLE	9	0	0	9	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-10-4	WH-CCU-01	AISLE	10	0	0	10	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-11-4	WH-CCU-01	AISLE	11	0	0	11	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-12-4	WH-CCU-01	AISLE	12	0	0	12	4	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-3-5	WH-CCU-01	AISLE	3	0	0	3	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-4-5	WH-CCU-01	AISLE	4	0	0	4	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-5-5	WH-CCU-01	AISLE	5	0	0	5	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-6-5	WH-CCU-01	AISLE	6	0	0	6	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-7-5	WH-CCU-01	AISLE	7	0	0	7	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-8-5	WH-CCU-01	AISLE	8	0	0	8	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-9-5	WH-CCU-01	AISLE	9	0	0	9	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
WH-WH-CCU-01-AISLE-10-5	WH-CCU-01	AISLE	10	0	0	10	5	500	0	BUFFER	ACTIVE	2026-08-19 09:05:20.470451
\.


--
-- Data for Name: warehouse_obstacles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_obstacles (id, warehouse_id, obstacle_type, x, y, width, height, active, severity, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouses (id, name, location, latitude, longitude, created_at) FROM stdin;
WH-BLR-01	Bangalore Fulfillment Center	Bangalore, Karnataka	12.971598	77.594566	2026-08-19 09:05:20.42075
WH-CHN-01	Chennai Port Logistics Hub	Chennai, Tamil Nadu	13.08268	80.270718	2026-08-19 09:05:20.433751
WH-BOM-01	Mumbai Container Terminal	Mumbai, Maharashtra	19.07609	72.877701	2026-08-19 09:05:20.439848
WH-DEL-01	Delhi NCR Logistics Park	Noida, Uttar Pradesh	28.535517	77.391029	2026-08-19 09:05:20.445936
WH-CCU-01	Kolkata Gateway Depot	Kolkata, West Bengal	22.572646	88.363895	2026-08-19 09:05:20.451443
\.


--
-- Name: access_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_log_id_seq', 263, true);


--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_recommendations_id_seq', 84, true);


--
-- Name: audit_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_ledger_id_seq', 226, true);


--
-- Name: backup_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.backup_records_id_seq', 33, true);


--
-- Name: digital_twin_simulations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.digital_twin_simulations_id_seq', 2, true);


--
-- Name: inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_id_seq', 35, true);


--
-- Name: inventory_reservations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_reservations_id_seq', 1, false);


--
-- Name: notification_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_preferences_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 12, true);


--
-- Name: order_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_events_id_seq', 1, false);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- Name: otp_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.otp_records_id_seq', 2, true);


--
-- Name: packing_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.packing_records_id_seq', 1, false);


--
-- Name: picking_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.picking_tasks_id_seq', 3, true);


--
-- Name: recovery_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recovery_codes_id_seq', 1, false);


--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recovery_credentials_id_seq', 1, false);


--
-- Name: robot_reservations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robot_reservations_id_seq', 1, false);


--
-- Name: robot_routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robot_routes_id_seq', 1, false);


--
-- Name: robot_telemetry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robot_telemetry_id_seq', 1, false);


--
-- Name: robots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robots_id_seq', 7, true);


--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shrinkage_flags_id_seq', 6, true);


--
-- Name: simulation_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.simulation_events_id_seq', 2, true);


--
-- Name: simulation_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.simulation_snapshots_id_seq', 2, true);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 3152, true);


--
-- Name: task_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_events_id_seq', 3, true);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 1, false);


--
-- Name: user_warehouse_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_warehouse_access_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 11, true);


--
-- Name: warehouse_grid_cells_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.warehouse_grid_cells_id_seq', 120, true);


--
-- Name: warehouse_obstacles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.warehouse_obstacles_id_seq', 1, false);


--
-- Name: access_log access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log
    ADD CONSTRAINT access_log_pkey PRIMARY KEY (id);


--
-- Name: ai_recommendations ai_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_recommendations
    ADD CONSTRAINT ai_recommendations_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_ledger audit_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_ledger
    ADD CONSTRAINT audit_ledger_pkey PRIMARY KEY (id);


--
-- Name: backup_records backup_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_records
    ADD CONSTRAINT backup_records_pkey PRIMARY KEY (id);


--
-- Name: digital_twin_simulations digital_twin_simulations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.digital_twin_simulations
    ADD CONSTRAINT digital_twin_simulations_pkey PRIMARY KEY (id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: inventory_reservations inventory_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_events order_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_events
    ADD CONSTRAINT order_events_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: otp_records otp_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_records
    ADD CONSTRAINT otp_records_pkey PRIMARY KEY (id);


--
-- Name: packing_records packing_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packing_records
    ADD CONSTRAINT packing_records_pkey PRIMARY KEY (id);


--
-- Name: tasks picking_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT picking_tasks_pkey PRIMARY KEY (id);


--
-- Name: recovery_codes recovery_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: recovery_credentials recovery_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials
    ADD CONSTRAINT recovery_credentials_pkey PRIMARY KEY (id);


--
-- Name: robot_reservations robot_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_reservations
    ADD CONSTRAINT robot_reservations_pkey PRIMARY KEY (id);


--
-- Name: robot_routes robot_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes
    ADD CONSTRAINT robot_routes_pkey PRIMARY KEY (id);


--
-- Name: robot_telemetry robot_telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_telemetry
    ADD CONSTRAINT robot_telemetry_pkey PRIMARY KEY (id);


--
-- Name: robots robots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: shrinkage_flags shrinkage_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shrinkage_flags
    ADD CONSTRAINT shrinkage_flags_pkey PRIMARY KEY (id);


--
-- Name: simulation_events simulation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_events
    ADD CONSTRAINT simulation_events_pkey PRIMARY KEY (id);


--
-- Name: simulation_snapshots simulation_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_snapshots
    ADD CONSTRAINT simulation_snapshots_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: task_events task_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_pkey PRIMARY KEY (id);


--
-- Name: warehouse_grid_cells uq_grid_cell; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_grid_cells
    ADD CONSTRAINT uq_grid_cell UNIQUE (warehouse_id, x, y);


--
-- Name: stock_movements uq_movement; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT uq_movement UNIQUE (date, warehouse_id, item_id);


--
-- Name: otp_records uq_otp_user_purpose; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_records
    ADD CONSTRAINT uq_otp_user_purpose UNIQUE (user_id, purpose);


--
-- Name: notification_preferences uq_user_category_preference; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT uq_user_category_preference UNIQUE (user_id, category);


--
-- Name: user_warehouse_access uq_user_warehouse; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access
    ADD CONSTRAINT uq_user_warehouse UNIQUE (user_id, warehouse_id);


--
-- Name: inventory uq_warehouse_item_location; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT uq_warehouse_item_location UNIQUE (warehouse_id, item_id, location_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_token_hash_key UNIQUE (session_token_hash);


--
-- Name: user_warehouse_access user_warehouse_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access
    ADD CONSTRAINT user_warehouse_access_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouse_grid_cells warehouse_grid_cells_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_grid_cells
    ADD CONSTRAINT warehouse_grid_cells_pkey PRIMARY KEY (id);


--
-- Name: warehouse_locations warehouse_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_pkey PRIMARY KEY (id);


--
-- Name: warehouse_obstacles warehouse_obstacles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_obstacles
    ADD CONSTRAINT warehouse_obstacles_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: ix_access_log_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_access_log_timestamp ON public.access_log USING btree ("timestamp");


--
-- Name: ix_ai_recommendations_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_recommendations_created_at ON public.ai_recommendations USING btree (created_at);


--
-- Name: ix_ai_recommendations_recommendation_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_recommendations_recommendation_type ON public.ai_recommendations USING btree (recommendation_type);


--
-- Name: ix_ai_recommendations_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_recommendations_timestamp ON public.ai_recommendations USING btree ("timestamp");


--
-- Name: ix_backup_records_backup_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_backup_records_backup_id ON public.backup_records USING btree (backup_id);


--
-- Name: ix_backup_records_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_backup_records_created_at ON public.backup_records USING btree (created_at);


--
-- Name: ix_digital_twin_simulations_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_digital_twin_simulations_created_at ON public.digital_twin_simulations USING btree (created_at);


--
-- Name: ix_digital_twin_simulations_simulation_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_digital_twin_simulations_simulation_status ON public.digital_twin_simulations USING btree (simulation_status);


--
-- Name: ix_digital_twin_simulations_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_digital_twin_simulations_warehouse_id ON public.digital_twin_simulations USING btree (warehouse_id);


--
-- Name: ix_inventory_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_item_id ON public.inventory USING btree (item_id);


--
-- Name: ix_inventory_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_location_id ON public.inventory USING btree (location_id);


--
-- Name: ix_inventory_reservations_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_reservations_created_at ON public.inventory_reservations USING btree (created_at);


--
-- Name: ix_inventory_reservations_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_reservations_item_id ON public.inventory_reservations USING btree (item_id);


--
-- Name: ix_inventory_reservations_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_reservations_location_id ON public.inventory_reservations USING btree (location_id);


--
-- Name: ix_inventory_reservations_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_reservations_order_id ON public.inventory_reservations USING btree (order_id);


--
-- Name: ix_inventory_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_warehouse_id ON public.inventory USING btree (warehouse_id);


--
-- Name: ix_items_sku; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_items_sku ON public.items USING btree (sku);


--
-- Name: ix_notification_preferences_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notification_preferences_category ON public.notification_preferences USING btree (category);


--
-- Name: ix_notification_preferences_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notification_preferences_user_id ON public.notification_preferences USING btree (user_id);


--
-- Name: ix_notifications_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_created_at ON public.notifications USING btree (created_at);


--
-- Name: ix_notifications_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_event_type ON public.notifications USING btree (event_type);


--
-- Name: ix_notifications_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_status ON public.notifications USING btree (status);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_notifications_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_warehouse_id ON public.notifications USING btree (warehouse_id);


--
-- Name: ix_order_events_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_events_order_id ON public.order_events USING btree (order_id);


--
-- Name: ix_order_events_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_events_timestamp ON public.order_events USING btree ("timestamp");


--
-- Name: ix_order_items_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_items_item_id ON public.order_items USING btree (item_id);


--
-- Name: ix_order_items_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_items_order_id ON public.order_items USING btree (order_id);


--
-- Name: ix_orders_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_created_at ON public.orders USING btree (created_at);


--
-- Name: ix_orders_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_status ON public.orders USING btree (status);


--
-- Name: ix_orders_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_warehouse_id ON public.orders USING btree (warehouse_id);


--
-- Name: ix_otp_records_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_otp_records_expires_at ON public.otp_records USING btree (expires_at);


--
-- Name: ix_otp_records_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_otp_records_user_id ON public.otp_records USING btree (user_id);


--
-- Name: ix_packing_records_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_packing_records_order_id ON public.packing_records USING btree (order_id);


--
-- Name: ix_recovery_codes_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_recovery_codes_user_id ON public.recovery_codes USING btree (user_id);


--
-- Name: ix_recovery_credentials_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_recovery_credentials_user_id ON public.recovery_credentials USING btree (user_id);


--
-- Name: ix_robot_reservations_robot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_reservations_robot_id ON public.robot_reservations USING btree (robot_id);


--
-- Name: ix_robot_reservations_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_reservations_warehouse_id ON public.robot_reservations USING btree (warehouse_id);


--
-- Name: ix_robot_routes_robot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_routes_robot_id ON public.robot_routes USING btree (robot_id);


--
-- Name: ix_robot_routes_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_routes_task_id ON public.robot_routes USING btree (task_id);


--
-- Name: ix_robot_routes_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_routes_warehouse_id ON public.robot_routes USING btree (warehouse_id);


--
-- Name: ix_robot_telemetry_robot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_telemetry_robot_id ON public.robot_telemetry USING btree (robot_id);


--
-- Name: ix_robot_telemetry_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robot_telemetry_timestamp ON public.robot_telemetry USING btree ("timestamp");


--
-- Name: ix_robots_assigned_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_assigned_task_id ON public.robots USING btree (assigned_task_id);


--
-- Name: ix_robots_current_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_current_location_id ON public.robots USING btree (current_location_id);


--
-- Name: ix_robots_robot_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_robots_robot_code ON public.robots USING btree (robot_code);


--
-- Name: ix_robots_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_status ON public.robots USING btree (status);


--
-- Name: ix_robots_target_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_target_location_id ON public.robots USING btree (target_location_id);


--
-- Name: ix_robots_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_robots_warehouse_id ON public.robots USING btree (warehouse_id);


--
-- Name: ix_shipments_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_shipments_order_id ON public.shipments USING btree (order_id);


--
-- Name: ix_simulation_events_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_event_type ON public.simulation_events USING btree (event_type);


--
-- Name: ix_simulation_events_real_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_real_timestamp ON public.simulation_events USING btree (real_timestamp);


--
-- Name: ix_simulation_events_robot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_robot_id ON public.simulation_events USING btree (robot_id);


--
-- Name: ix_simulation_events_simulation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_simulation_id ON public.simulation_events USING btree (simulation_id);


--
-- Name: ix_simulation_events_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_task_id ON public.simulation_events USING btree (task_id);


--
-- Name: ix_simulation_events_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_events_warehouse_id ON public.simulation_events USING btree (warehouse_id);


--
-- Name: ix_simulation_snapshots_simulation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_snapshots_simulation_id ON public.simulation_snapshots USING btree (simulation_id);


--
-- Name: ix_simulation_snapshots_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_simulation_snapshots_warehouse_id ON public.simulation_snapshots USING btree (warehouse_id);


--
-- Name: ix_stock_movements_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_date ON public.stock_movements USING btree (date);


--
-- Name: ix_stock_movements_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_item_id ON public.stock_movements USING btree (item_id);


--
-- Name: ix_stock_movements_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_warehouse_id ON public.stock_movements USING btree (warehouse_id);


--
-- Name: ix_task_events_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_events_task_id ON public.task_events USING btree (task_id);


--
-- Name: ix_tasks_assigned_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_assigned_user_id ON public.tasks USING btree (assigned_user_id);


--
-- Name: ix_tasks_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_created_at ON public.tasks USING btree (created_at);


--
-- Name: ix_tasks_destination_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_destination_location_id ON public.tasks USING btree (destination_location_id);


--
-- Name: ix_tasks_due_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_due_at ON public.tasks USING btree (due_at);


--
-- Name: ix_tasks_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_order_id ON public.tasks USING btree (order_id);


--
-- Name: ix_tasks_order_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_order_item_id ON public.tasks USING btree (order_item_id);


--
-- Name: ix_tasks_priority_score; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_priority_score ON public.tasks USING btree (priority_score);


--
-- Name: ix_tasks_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_product_id ON public.tasks USING btree (product_id);


--
-- Name: ix_tasks_source_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_source_location_id ON public.tasks USING btree (source_location_id);


--
-- Name: ix_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_status ON public.tasks USING btree (status);


--
-- Name: ix_tasks_task_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_tasks_task_number ON public.tasks USING btree (task_number);


--
-- Name: ix_tasks_task_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_task_type ON public.tasks USING btree (task_type);


--
-- Name: ix_tasks_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_warehouse_id ON public.tasks USING btree (warehouse_id);


--
-- Name: ix_user_sessions_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_sessions_expires_at ON public.user_sessions USING btree (expires_at);


--
-- Name: ix_user_sessions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: ix_user_warehouse_access_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_warehouse_access_user_id ON public.user_warehouse_access USING btree (user_id);


--
-- Name: ix_user_warehouse_access_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_warehouse_access_warehouse_id ON public.user_warehouse_access USING btree (warehouse_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_google_subject_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_google_subject_id ON public.users USING btree (google_subject_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_warehouse_grid_cells_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_grid_cells_warehouse_id ON public.warehouse_grid_cells USING btree (warehouse_id);


--
-- Name: ix_warehouse_locations_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_locations_warehouse_id ON public.warehouse_locations USING btree (warehouse_id);


--
-- Name: ix_warehouse_obstacles_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_obstacles_warehouse_id ON public.warehouse_obstacles USING btree (warehouse_id);


--
-- Name: digital_twin_simulations digital_twin_simulations_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.digital_twin_simulations
    ADD CONSTRAINT digital_twin_simulations_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: inventory inventory_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: inventory inventory_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: inventory_reservations inventory_reservations_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: inventory_reservations inventory_reservations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: inventory_reservations inventory_reservations_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: inventory inventory_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: order_events order_events_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_events
    ADD CONSTRAINT order_events_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders orders_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: otp_records otp_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_records
    ADD CONSTRAINT otp_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: packing_records packing_records_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packing_records
    ADD CONSTRAINT packing_records_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: tasks picking_tasks_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT picking_tasks_item_id_fkey FOREIGN KEY (product_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: tasks picking_tasks_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT picking_tasks_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: tasks picking_tasks_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT picking_tasks_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: tasks picking_tasks_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT picking_tasks_order_item_id_fkey FOREIGN KEY (order_item_id) REFERENCES public.order_items(id) ON DELETE CASCADE;


--
-- Name: recovery_codes recovery_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: recovery_credentials recovery_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials
    ADD CONSTRAINT recovery_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: robot_reservations robot_reservations_robot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_reservations
    ADD CONSTRAINT robot_reservations_robot_id_fkey FOREIGN KEY (robot_id) REFERENCES public.robots(id) ON DELETE CASCADE;


--
-- Name: robot_reservations robot_reservations_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_reservations
    ADD CONSTRAINT robot_reservations_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: robot_routes robot_routes_robot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes
    ADD CONSTRAINT robot_routes_robot_id_fkey FOREIGN KEY (robot_id) REFERENCES public.robots(id) ON DELETE CASCADE;


--
-- Name: robot_routes robot_routes_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes
    ADD CONSTRAINT robot_routes_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: robot_routes robot_routes_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_routes
    ADD CONSTRAINT robot_routes_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: robot_telemetry robot_telemetry_robot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_telemetry
    ADD CONSTRAINT robot_telemetry_robot_id_fkey FOREIGN KEY (robot_id) REFERENCES public.robots(id) ON DELETE CASCADE;


--
-- Name: robots robots_assigned_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_assigned_task_id_fkey FOREIGN KEY (assigned_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: robots robots_current_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_current_location_id_fkey FOREIGN KEY (current_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: robots robots_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: robots robots_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robots
    ADD CONSTRAINT robots_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: shipments shipments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: simulation_events simulation_events_simulation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_events
    ADD CONSTRAINT simulation_events_simulation_id_fkey FOREIGN KEY (simulation_id) REFERENCES public.digital_twin_simulations(id) ON DELETE CASCADE;


--
-- Name: simulation_events simulation_events_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_events
    ADD CONSTRAINT simulation_events_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: simulation_snapshots simulation_snapshots_simulation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_snapshots
    ADD CONSTRAINT simulation_snapshots_simulation_id_fkey FOREIGN KEY (simulation_id) REFERENCES public.digital_twin_simulations(id) ON DELETE CASCADE;


--
-- Name: simulation_snapshots simulation_snapshots_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.simulation_snapshots
    ADD CONSTRAINT simulation_snapshots_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id);


--
-- Name: stock_movements stock_movements_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: task_events task_events_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_events task_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_assigned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assigned_user_id_fkey FOREIGN KEY (assigned_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_depends_on_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_depends_on_task_id_fkey FOREIGN KEY (depends_on_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_destination_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_destination_location_id_fkey FOREIGN KEY (destination_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_warehouse_access user_warehouse_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access
    ADD CONSTRAINT user_warehouse_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_warehouse_access user_warehouse_access_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_warehouse_access
    ADD CONSTRAINT user_warehouse_access_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: warehouse_grid_cells warehouse_grid_cells_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_grid_cells
    ADD CONSTRAINT warehouse_grid_cells_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: warehouse_locations warehouse_locations_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: warehouse_obstacles warehouse_obstacles_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_obstacles
    ADD CONSTRAINT warehouse_obstacles_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict lLA3ki89phpmfBQ1v1ZJpWnFfWkwTYm9Rjh5RP4fnNMbhWHbKBPcokRdnyiYflL

