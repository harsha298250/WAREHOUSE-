--
-- PostgreSQL database dump
--

\restrict ld2lg8aJFfscCyjfdBBZS0ixsXtTdNjK2yM3pEKyxeA58ifNMrS1gS5fN6p5Jl5

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_log (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    username character varying(64) NOT NULL,
    warehouse_id character varying(20),
    action character varying(50) NOT NULL,
    ip_address character varying(45)
);


ALTER TABLE public.access_log OWNER TO postgres;

--
-- Name: access_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.access_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.access_log_id_seq OWNER TO postgres;

--
-- Name: access_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.access_log_id_seq OWNED BY public.access_log.id;


--
-- Name: ai_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_recommendations (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(50),
    title character varying(100) NOT NULL,
    risk_level character varying(20),
    action_recommended character varying(100) NOT NULL,
    confidence_score integer,
    input_factors text,
    status character varying(20),
    decision_by character varying(64),
    decision_time timestamp without time zone,
    notes text
);


ALTER TABLE public.ai_recommendations OWNER TO postgres;

--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_recommendations_id_seq OWNER TO postgres;

--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_recommendations_id_seq OWNED BY public.ai_recommendations.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: audit_ledger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_ledger (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    event_type character varying(50) NOT NULL,
    details text,
    prev_hash character varying(64) NOT NULL,
    hash character varying(64) NOT NULL
);


ALTER TABLE public.audit_ledger OWNER TO postgres;

--
-- Name: audit_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_ledger_id_seq OWNER TO postgres;

--
-- Name: audit_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_ledger_id_seq OWNED BY public.audit_ledger.id;


--
-- Name: backup_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_records (
    id integer NOT NULL,
    backup_id character varying(64) NOT NULL,
    filename character varying(255) NOT NULL,
    created_at timestamp without time zone,
    size_bytes integer,
    sha256 character varying(64),
    status character varying(20) NOT NULL,
    storage_key character varying(255),
    error_message text
);


ALTER TABLE public.backup_records OWNER TO postgres;

--
-- Name: backup_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.backup_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_records_id_seq OWNER TO postgres;

--
-- Name: backup_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.backup_records_id_seq OWNED BY public.backup_records.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id character varying(20) NOT NULL,
    name character varying(150) NOT NULL,
    category character varying(80),
    unit_cost double precision,
    lead_time_days integer,
    safety_stock integer,
    created_at timestamp without time zone
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: recovery_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recovery_codes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code_hash character varying(255) NOT NULL,
    used boolean NOT NULL,
    created_at timestamp without time zone,
    used_at timestamp without time zone
);


ALTER TABLE public.recovery_codes OWNER TO postgres;

--
-- Name: recovery_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recovery_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recovery_codes_id_seq OWNER TO postgres;

--
-- Name: recovery_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recovery_codes_id_seq OWNED BY public.recovery_codes.id;


--
-- Name: recovery_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recovery_credentials (
    id integer NOT NULL,
    user_id integer NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.recovery_credentials OWNER TO postgres;

--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recovery_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recovery_credentials_id_seq OWNER TO postgres;

--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recovery_credentials_id_seq OWNED BY public.recovery_credentials.id;


--
-- Name: shrinkage_flags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shrinkage_flags (
    id integer NOT NULL,
    date date NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    item_name character varying(150),
    deviation_score double precision,
    expected_quantity double precision,
    actual_quantity double precision,
    discrepancy_quantity double precision,
    estimated_exposure double precision,
    severity character varying(20),
    likely_cause character varying(80),
    explanation text
);


ALTER TABLE public.shrinkage_flags OWNER TO postgres;

--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shrinkage_flags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shrinkage_flags_id_seq OWNER TO postgres;

--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shrinkage_flags_id_seq OWNED BY public.shrinkage_flags.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    date date NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    stock_in integer,
    stock_out integer,
    closing_stock integer,
    is_anomaly boolean,
    anomaly_type character varying(30),
    entry_source character varying(20),
    entered_by character varying(64)
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_movements_id_seq OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    full_name character varying(120),
    google_subject_id character varying(128),
    created_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouses (
    id character varying(20) NOT NULL,
    name character varying(120) NOT NULL,
    location character varying(120),
    latitude double precision,
    longitude double precision,
    created_at timestamp without time zone
);


ALTER TABLE public.warehouses OWNER TO postgres;

--
-- Name: access_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log ALTER COLUMN id SET DEFAULT nextval('public.access_log_id_seq'::regclass);


--
-- Name: ai_recommendations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_recommendations ALTER COLUMN id SET DEFAULT nextval('public.ai_recommendations_id_seq'::regclass);


--
-- Name: audit_ledger id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_ledger ALTER COLUMN id SET DEFAULT nextval('public.audit_ledger_id_seq'::regclass);


--
-- Name: backup_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_records ALTER COLUMN id SET DEFAULT nextval('public.backup_records_id_seq'::regclass);


--
-- Name: recovery_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes ALTER COLUMN id SET DEFAULT nextval('public.recovery_codes_id_seq'::regclass);


--
-- Name: recovery_credentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials ALTER COLUMN id SET DEFAULT nextval('public.recovery_credentials_id_seq'::regclass);


--
-- Name: shrinkage_flags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shrinkage_flags ALTER COLUMN id SET DEFAULT nextval('public.shrinkage_flags_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: access_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access_log (id, "timestamp", username, warehouse_id, action, ip_address) FROM stdin;
167	2026-08-17 17:13:42.990287	harsha200797@gmail.com		login	127.0.0.1
169	2026-08-17 17:18:35.720146	admin		login	testclient
171	2026-08-17 17:19:34.308859	admin		request_admin_creation	testclient
173	2026-08-17 17:20:39.583423	admin		request_admin_creation	testclient
168	2026-08-17 17:18:03.263157	admin		login	testclient
170	2026-08-17 17:19:14.828381	admin		login	testclient
172	2026-08-17 17:20:21.045937	admin		login	testclient
117	2026-08-15 16:41:51.395629	admin	WH-BLR-01	view	192.168.1.30
118	2026-08-16 05:05:51.395629	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.132
119	2026-08-16 14:47:51.395629	admin	WH-CCU-01	view	192.168.1.178
120	2026-08-17 14:40:51.395629	admin	WH-BOM-01	add_stock	192.168.1.192
121	2026-08-17 06:43:51.395629	admin		login	192.168.1.50
122	2026-08-16 03:03:51.395629	admin	WH-CCU-01	add_stock	192.168.1.234
123	2026-08-16 11:22:51.395629	harsha200797@gmail.com	WH-BOM-01	add_stock	192.168.1.236
124	2026-08-14 06:23:51.395629	admin	WH-CCU-01	add_stock	192.168.1.45
125	2026-08-17 07:12:51.395629	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.8
126	2026-08-15 17:56:51.395629	admin		login	192.168.1.179
127	2026-08-16 16:00:51.395629	harsha200797@gmail.com	WH-DEL-01	add_stock	192.168.1.159
128	2026-08-14 06:03:51.395629	admin	WH-CHN-01	add_stock	192.168.1.229
129	2026-08-16 22:39:51.395629	harsha200797@gmail.com		login	192.168.1.61
130	2026-08-14 13:17:51.395629	admin	WH-CHN-01	view	192.168.1.12
131	2026-08-16 02:55:51.395629	admin	WH-CHN-01	view	192.168.1.73
132	2026-08-15 08:24:51.395629	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.134
133	2026-08-15 18:01:51.39663	admin	WH-BOM-01	view	192.168.1.32
134	2026-08-16 11:54:51.39663	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.240
135	2026-08-16 10:13:51.39663	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.111
136	2026-08-15 15:30:51.39663	admin	WH-CCU-01	view	192.168.1.216
137	2026-08-16 05:36:51.39663	admin	WH-DEL-01	view	192.168.1.94
138	2026-08-14 23:14:51.39663	admin		login	192.168.1.81
139	2026-08-15 11:32:51.39663	admin	WH-BOM-01	view	192.168.1.235
140	2026-08-17 14:59:51.39663	admin	WH-BLR-01	add_stock	192.168.1.219
141	2026-08-17 07:23:51.39663	harsha200797@gmail.com		login	192.168.1.159
142	2026-08-16 12:03:51.39663	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.46
143	2026-08-16 16:37:51.39663	harsha200797@gmail.com		login	192.168.1.36
144	2026-08-16 13:02:51.39663	admin	WH-CCU-01	view	192.168.1.150
145	2026-08-16 16:53:51.39663	admin		login	192.168.1.209
146	2026-08-15 06:59:51.39663	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.214
147	2026-08-16 23:55:51.39663	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.45
148	2026-08-17 07:08:51.39663	admin	WH-BLR-01	view	192.168.1.182
149	2026-08-16 02:05:51.39663	admin	WH-DEL-01	view	192.168.1.113
150	2026-08-14 06:06:51.39663	harsha200797@gmail.com		login	192.168.1.242
151	2026-08-16 09:45:51.39663	admin		login	192.168.1.165
152	2026-08-15 16:10:51.39663	admin	WH-CCU-01	view	192.168.1.154
153	2026-08-15 02:08:51.39663	admin	WH-DEL-01	view	192.168.1.162
154	2026-08-15 10:48:51.39663	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.100
155	2026-08-15 13:23:51.39663	harsha200797@gmail.com	WH-CCU-01	add_stock	192.168.1.216
156	2026-08-14 06:10:51.39663	harsha200797@gmail.com	WH-BOM-01	add_stock	192.168.1.84
157	2026-08-17 05:39:51.39663	harsha200797@gmail.com	WH-CCU-01	add_stock	192.168.1.247
158	2026-08-15 18:02:51.39663	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.21
159	2026-08-15 07:26:51.39663	admin	WH-CCU-01	view	192.168.1.89
160	2026-08-16 06:25:51.39663	admin	WH-CCU-01	view	192.168.1.102
161	2026-08-17 12:01:51.39663	admin		login	192.168.1.176
162	2026-08-17 14:18:51.39663	harsha200797@gmail.com	WH-CCU-01	add_stock	192.168.1.65
163	2026-08-15 08:43:51.39663	harsha200797@gmail.com		login	192.168.1.139
164	2026-08-15 15:06:51.39663	admin	WH-BLR-01	view	192.168.1.215
165	2026-08-15 21:52:51.39663	admin	WH-BLR-01	view	192.168.1.193
166	2026-08-16 19:39:51.39663	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.158
\.


--
-- Data for Name: ai_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_recommendations (id, "timestamp", warehouse_id, item_id, title, risk_level, action_recommended, confidence_score, input_factors, status, decision_by, decision_time, notes) FROM stdin;
1	2026-08-14 11:40:57.885343	WH-BLR-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01	MEDIUM	APPROVED	85	{}	APPROVED	harsha200797@gmail.com	2026-08-14 11:40:57.88252	Approved via AI Decision Center
2	2026-08-14 11:41:03.619137	WH-BLR-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01	MEDIUM	APPROVED	85	{}	APPROVED	harsha200797@gmail.com	2026-08-14 11:41:03.618171	Approved via AI Decision Center
3	2026-08-14 11:41:15.400552	WH-BLR-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01	MEDIUM	REJECTED	85	{}	REJECTED	harsha200797@gmail.com	2026-08-14 11:41:15.399727	Rejected via AI Decision Center
4	2026-08-15 15:57:11.312692	WH-BLR-01	ITM-CPU-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CPU-01	MEDIUM	APPROVED	85	{}	APPROVED	harsha200797@gmail.com	2026-08-15 15:57:11.309061	Approved via AI Decision Center
5	2026-08-15 15:57:19.281616	WH-BLR-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01	MEDIUM	REJECTED	85	{}	REJECTED	harsha200797@gmail.com	2026-08-15 15:57:19.280572	Rejected via AI Decision Center
6	2026-08-15 16:00:03.095474	WH-BLR-01	ITM-CPU-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CPU-01	MEDIUM	APPROVED	85	{}	APPROVED	harsha200797@gmail.com	2026-08-15 16:00:03.094625	Approved via AI Decision Center
7	2026-08-15 16:00:10.230423	WH-BLR-01	ITM-SSD-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-SSD-01	MEDIUM	REJECTED	85	{}	REJECTED	harsha200797@gmail.com	2026-08-15 16:00:10.229281	Rejected via AI Decision Center
8	2026-08-17 04:26:11.912743	WH-DEL-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-DEL-01-ITM-CBL-01	MEDIUM	APPROVED	85	{}	APPROVED	harsha200797@gmail.com	2026-08-17 04:26:11.908925	Approved via AI Decision Center
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
5724cd882171
\.


--
-- Data for Name: audit_ledger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_ledger (id, "timestamp", event_type, details, prev_hash, hash) FROM stdin;
1	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	0000000000000000000000000000000000000000000000000000000000000000	9fec238c3824e41f68ed3de9ecae4c1025d771291cb76fa2727bc3d051f02c5b
2	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	9fec238c3824e41f68ed3de9ecae4c1025d771291cb76fa2727bc3d051f02c5b	70ac5e917652707bb444acb6ba7eebdf396d0f41db50027871406eded265e12e
3	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	70ac5e917652707bb444acb6ba7eebdf396d0f41db50027871406eded265e12e	41c04983295fc4cb30fb3e48367ad952b896bb41daa561c37c05073e25a01afd
4	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	41c04983295fc4cb30fb3e48367ad952b896bb41daa561c37c05073e25a01afd	bcb583985e67bd010e93f5ab5d480a54aa7de8817faa7bccc7e68720c68830a2
5	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	bcb583985e67bd010e93f5ab5d480a54aa7de8817faa7bccc7e68720c68830a2	04207a1c67e2a2c68fce2ce9538ae241c1cfa88f3ec87aab3f171a5aba02f80e
6	2026-08-14 10:31:37	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	04207a1c67e2a2c68fce2ce9538ae241c1cfa88f3ec87aab3f171a5aba02f80e	b320925e2d8b0af062401faa74823151f3d2952093d10718d285dab58b296bb3
7	2026-08-14 10:31:37	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	b320925e2d8b0af062401faa74823151f3d2952093d10718d285dab58b296bb3	61aaf8fdb2a61b2d8d7cbaa9655365570e4af100146a1162b556c6307f846dbc
8	2026-08-14 10:31:37	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	61aaf8fdb2a61b2d8d7cbaa9655365570e4af100146a1162b556c6307f846dbc	f9bd686a14b0a4dc3e04a24cb08271861d495c4f72bf961ff25c77232940139e
9	2026-08-14 10:31:37	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	f9bd686a14b0a4dc3e04a24cb08271861d495c4f72bf961ff25c77232940139e	fd5b0e30a0ab87c482ae1e32f600779d0889b6e90cce2e8b342b81f6b02687d1
10	2026-08-14 10:31:37	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	fd5b0e30a0ab87c482ae1e32f600779d0889b6e90cce2e8b342b81f6b02687d1	bbc12990f7f200c4244c90c2f0dd1cf8a406949d8dc5cd3bd52a36355db6d46b
11	2026-08-14 10:31:37	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	bbc12990f7f200c4244c90c2f0dd1cf8a406949d8dc5cd3bd52a36355db6d46b	1a955f61e3af26f3faa7db37fbce37f01f9c72d5709eb38190f3633a7350a6d8
12	2026-08-14 10:31:37	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	1a955f61e3af26f3faa7db37fbce37f01f9c72d5709eb38190f3633a7350a6d8	ee5a288a1442804c3a1eabf5efcc8a1d867f2ae6633c6e1f12c112fc4b7c3827
13	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	ee5a288a1442804c3a1eabf5efcc8a1d867f2ae6633c6e1f12c112fc4b7c3827	14f822f6d1c985a3da215d00f64de67723f6b89ea5738054ed159972fccbed95
14	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	14f822f6d1c985a3da215d00f64de67723f6b89ea5738054ed159972fccbed95	01a9404c776d25feea768be630cadfe4b11e217987585e59a528c3a4391e8c3c
15	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	01a9404c776d25feea768be630cadfe4b11e217987585e59a528c3a4391e8c3c	a0c42a2dad02de4cc119c1902402af4f0db298324d28303c44fc3f4c8d940a8e
16	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	a0c42a2dad02de4cc119c1902402af4f0db298324d28303c44fc3f4c8d940a8e	6a51b6d87f206ac9865a4ddea922837c77f4fad5f371ee87ec966e90834359fa
17	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	6a51b6d87f206ac9865a4ddea922837c77f4fad5f371ee87ec966e90834359fa	0a3e06c8d46b0b776e85375f33e8a19906b45ca7fe4295bb45c5a87500a302e7
18	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-24"}	0a3e06c8d46b0b776e85375f33e8a19906b45ca7fe4295bb45c5a87500a302e7	019959356929a933447c793c1f96ea53fc09158d61fc969d7e5af0d4e2d67d7d
19	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-24"}	019959356929a933447c793c1f96ea53fc09158d61fc969d7e5af0d4e2d67d7d	05005d018a26a90823e8a7ed4babb2caeb9a3d9efbc22026b2362b22931d2015
20	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	05005d018a26a90823e8a7ed4babb2caeb9a3d9efbc22026b2362b22931d2015	b7c23dd7ce30dcd228dc3db26676f929fcc715f537b1ab428bcfda93228d8fe1
21	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	b7c23dd7ce30dcd228dc3db26676f929fcc715f537b1ab428bcfda93228d8fe1	590b9d95c80f69a07835e86e4087fd9916964ef5eaaf685d38acc2be66831b39
22	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	590b9d95c80f69a07835e86e4087fd9916964ef5eaaf685d38acc2be66831b39	496cdce558453e8a1d621aad955dd34952ad0fd137edf3ab9bc82d6eb52fd128
23	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-28"}	496cdce558453e8a1d621aad955dd34952ad0fd137edf3ab9bc82d6eb52fd128	ebf71bb236ad6166f1a795503b988e0891adfbbf10cdc03f2e1e9c924c21205f
24	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-30"}	ebf71bb236ad6166f1a795503b988e0891adfbbf10cdc03f2e1e9c924c21205f	0a584e1e318f990bc8b3968ec9939bc8f05842e414a358dbb70c84d6fba3b2ce
25	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-30"}	0a584e1e318f990bc8b3968ec9939bc8f05842e414a358dbb70c84d6fba3b2ce	ecccde25b9796f65448ebc7757dc8ca652651c624a16fe8b9225f9fcbd1f5524
26	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-31"}	ecccde25b9796f65448ebc7757dc8ca652651c624a16fe8b9225f9fcbd1f5524	d905f0e78c3d1163e777b397522f6ac0a38fdfe1bb5af7f29023c8e403284a72
27	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-31"}	d905f0e78c3d1163e777b397522f6ac0a38fdfe1bb5af7f29023c8e403284a72	907448bac3c94ea38e85697cbdf724116a1a5bc0b69dda126ac55e55a7cc84c3
28	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-01"}	907448bac3c94ea38e85697cbdf724116a1a5bc0b69dda126ac55e55a7cc84c3	a3dc43f283cb582819bfb5f2d4d8e5853e3367d19fbf38b3d00e928b2ff1b069
29	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-01"}	a3dc43f283cb582819bfb5f2d4d8e5853e3367d19fbf38b3d00e928b2ff1b069	a035d1cd8fb439ce8cf4dd3c1c0750585331a665360e09ac66ad5f980f9d1022
30	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-01"}	a035d1cd8fb439ce8cf4dd3c1c0750585331a665360e09ac66ad5f980f9d1022	524ed4e2747b77a4701ecd630d0fc04a02232529fe780db4761048c887df23ef
31	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	524ed4e2747b77a4701ecd630d0fc04a02232529fe780db4761048c887df23ef	d3036f07d5bd572f6211de766368b8f6f936c9092b00563d00bc7d9d3bde734d
32	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-04"}	d3036f07d5bd572f6211de766368b8f6f936c9092b00563d00bc7d9d3bde734d	cf3410d974ae9d1b26473e4291faf9f27ff82dfc8cbdcb3db29e0a59ae9520b0
33	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-05"}	cf3410d974ae9d1b26473e4291faf9f27ff82dfc8cbdcb3db29e0a59ae9520b0	b64754ed00c65777a0a5bb8a8abeec94d172efdf5f0956d57acd924c9cae3feb
34	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	b64754ed00c65777a0a5bb8a8abeec94d172efdf5f0956d57acd924c9cae3feb	cbfc65687a9ea840423f7df28d52ac22872c4255b7de8dd910118aeec7404430
35	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-06"}	cbfc65687a9ea840423f7df28d52ac22872c4255b7de8dd910118aeec7404430	d2e404b8f350e5710d1ff24dd7687e356751467b358d0477f8fef41f54513539
36	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-07"}	d2e404b8f350e5710d1ff24dd7687e356751467b358d0477f8fef41f54513539	078996631a214b1b8a0435c95ca1b089448cb7f5c7119de9d208dd15cfca1be5
37	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-07"}	078996631a214b1b8a0435c95ca1b089448cb7f5c7119de9d208dd15cfca1be5	e3130764a25f7259ac48df031561f38f2a112f01c64e5af2cb9cf691c131e202
38	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-07"}	e3130764a25f7259ac48df031561f38f2a112f01c64e5af2cb9cf691c131e202	e8a91e2cf4f5e1494ff61306017843039dae3e870af7a5a12766e20db808ed11
39	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-09"}	e8a91e2cf4f5e1494ff61306017843039dae3e870af7a5a12766e20db808ed11	ed9c25f919f06d7f9d77e0e16ee0e437957bd2a50663d4623e49e3212133cad9
40	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	ed9c25f919f06d7f9d77e0e16ee0e437957bd2a50663d4623e49e3212133cad9	b78371424c6357301427a32b9dc7c29fd0a665285e283b644eeb401b41adcf15
41	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	b78371424c6357301427a32b9dc7c29fd0a665285e283b644eeb401b41adcf15	49a55e93c11a9fd0e6f6462cb97f0698d004467b39b181f72ce7efda21002970
42	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-11"}	49a55e93c11a9fd0e6f6462cb97f0698d004467b39b181f72ce7efda21002970	955576c3caaba3bc4cf8f80883b60569f9ce039823866cbe4119e99011824335
43	2026-08-14 10:31:37	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	955576c3caaba3bc4cf8f80883b60569f9ce039823866cbe4119e99011824335	b47d7ff2cb2ac7b245648de47de23fe4c46ad572edcb735f39b13d1354a2a15f
44	2026-08-14 10:31:37	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	b47d7ff2cb2ac7b245648de47de23fe4c46ad572edcb735f39b13d1354a2a15f	e818753abb0920c08a2bf30256ff6085f795fb4fb95d6375c778873d9e678e04
45	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	e818753abb0920c08a2bf30256ff6085f795fb4fb95d6375c778873d9e678e04	eefc04076a7e6df54e04259d388ba8be345636b10781eaa6e0e13c6bd43f4d24
46	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	eefc04076a7e6df54e04259d388ba8be345636b10781eaa6e0e13c6bd43f4d24	d17dd23b71b8f78510b3fb518d3d774ea15cc8a9d94ec676ff154b2317712e1d
47	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	d17dd23b71b8f78510b3fb518d3d774ea15cc8a9d94ec676ff154b2317712e1d	be1486b6ba41658865a5851c4913f4670a9c213c339541d51b1e5a3a6c807a4d
48	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	be1486b6ba41658865a5851c4913f4670a9c213c339541d51b1e5a3a6c807a4d	bd1f5abcf03b937803b2a319d10fd69606b4e1f89bbd3757305d8934a761fa4e
49	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	bd1f5abcf03b937803b2a319d10fd69606b4e1f89bbd3757305d8934a761fa4e	43b35a517d273cdd250d13c675c7f2eaa93382417967bca0901f1594a20f7ad1
50	2026-08-14 10:32:16	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	43b35a517d273cdd250d13c675c7f2eaa93382417967bca0901f1594a20f7ad1	49c08f15a6617d7b5303d50be1cd13b681453289044a778d29b61d7a16db46bd
51	2026-08-14 10:32:16	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	49c08f15a6617d7b5303d50be1cd13b681453289044a778d29b61d7a16db46bd	28190f3523bf6fdf04f9f302f2dbcb05353be16604c8517c91b77d7b7c3a65fa
52	2026-08-14 10:32:16	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	28190f3523bf6fdf04f9f302f2dbcb05353be16604c8517c91b77d7b7c3a65fa	af955d7ffdafa661cef81e7a21446852e89fb8fcdc0a98f8ec84746427635f0f
53	2026-08-14 10:32:16	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	af955d7ffdafa661cef81e7a21446852e89fb8fcdc0a98f8ec84746427635f0f	3408cb75e19fe589168ae245d24682d38de950a6149028118a9161bfd37479a1
54	2026-08-14 10:32:16	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	3408cb75e19fe589168ae245d24682d38de950a6149028118a9161bfd37479a1	3c164f761278bc8ae6057a8bf9a2f5bd1892bdaada0a83611a909d2fa210c9cf
55	2026-08-14 10:32:16	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	3c164f761278bc8ae6057a8bf9a2f5bd1892bdaada0a83611a909d2fa210c9cf	a17dd3ee11cbd8527d35b7fd1fe0efc884a5feb12265b7e0b287d11e0cf1b6ab
56	2026-08-14 10:32:16	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	a17dd3ee11cbd8527d35b7fd1fe0efc884a5feb12265b7e0b287d11e0cf1b6ab	8cbeae454d22a1d79003bb8a29f4c3bdb2b1a72e1c6a2f11034f2df0792d196d
57	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	8cbeae454d22a1d79003bb8a29f4c3bdb2b1a72e1c6a2f11034f2df0792d196d	d947a151ac0b85661ca780713fb0f62bf0c94256f338d8a8d9dcd46bef5d8767
58	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	d947a151ac0b85661ca780713fb0f62bf0c94256f338d8a8d9dcd46bef5d8767	8c6ee87d1b34f5396689156a7ff4f242b930d61642121c93e90413fe7dddc153
59	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	8c6ee87d1b34f5396689156a7ff4f242b930d61642121c93e90413fe7dddc153	2663c6cc775172465d9d05d855f32fb5d273f61a3e64be65686453ecb340d90b
60	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	2663c6cc775172465d9d05d855f32fb5d273f61a3e64be65686453ecb340d90b	4644663a5d063468fb4bf2f9d3c54f6b99862a5e9b5868d137c2d830445f1e18
61	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	4644663a5d063468fb4bf2f9d3c54f6b99862a5e9b5868d137c2d830445f1e18	47727baa00800e51e760af268062651aa0bca98d234336d770d1fdb93e0e5770
62	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-25"}	47727baa00800e51e760af268062651aa0bca98d234336d770d1fdb93e0e5770	29b86809adc9278699f43465ad6d6486625da184970e7f56fa320fe85fef4d1b
63	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	29b86809adc9278699f43465ad6d6486625da184970e7f56fa320fe85fef4d1b	3f7322dad5e5a8a0dc0c27bd3a698999605c8cc537926e0dab92854a31b3b34c
64	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	3f7322dad5e5a8a0dc0c27bd3a698999605c8cc537926e0dab92854a31b3b34c	4e3baeb7afbf0380112666ffb34911f0243e0452c6b6d303990cd9b2ad8af378
65	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-28"}	4e3baeb7afbf0380112666ffb34911f0243e0452c6b6d303990cd9b2ad8af378	f49dad9fbbd91066b6660b8586ad3411111dcb9e038dfa37a8c86c8cf12263a6
66	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-29"}	f49dad9fbbd91066b6660b8586ad3411111dcb9e038dfa37a8c86c8cf12263a6	46cc90c2ff611fa17ee4ff236ba4c68b68e99eb05abd306c1295a28914d79d80
67	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-29"}	46cc90c2ff611fa17ee4ff236ba4c68b68e99eb05abd306c1295a28914d79d80	d3d8d8772c8dfd7edba5863c5d8d8479f3ecb7340da599cd871804a803de09a4
68	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-07-30"}	d3d8d8772c8dfd7edba5863c5d8d8479f3ecb7340da599cd871804a803de09a4	dfe65919c3b64766b0cf4d7b1496835222303c2715b59a1677708070841bd019
69	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-30"}	dfe65919c3b64766b0cf4d7b1496835222303c2715b59a1677708070841bd019	fb4006725e3b6f742b7258fcad67adee50cc036e1c225ce7fde29951465bc03d
70	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-31"}	fb4006725e3b6f742b7258fcad67adee50cc036e1c225ce7fde29951465bc03d	f36cd3cd9772543e7a70cd558e6d2905fe9ea91f6c8cc78fe176f6f59af00b38
71	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-01"}	f36cd3cd9772543e7a70cd558e6d2905fe9ea91f6c8cc78fe176f6f59af00b38	0e66dab4135c358542cfc51a0d45dc5bcf56f6b7a5e81f543669873316709142
72	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	0e66dab4135c358542cfc51a0d45dc5bcf56f6b7a5e81f543669873316709142	b48cb8cfd477cd885183d09266dd26edfea7d188030eefe1a9c6b54958b5c2c4
73	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	b48cb8cfd477cd885183d09266dd26edfea7d188030eefe1a9c6b54958b5c2c4	e45a909683be5a9ff9f10fb29203b52c1af073aaf9b0708b03778887e39d624e
74	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-02"}	e45a909683be5a9ff9f10fb29203b52c1af073aaf9b0708b03778887e39d624e	b718755102fc5dfea1183713c4d015c7acf4e254f5cb922bfcf24062ec6378d4
75	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	b718755102fc5dfea1183713c4d015c7acf4e254f5cb922bfcf24062ec6378d4	86bded208d02467281a864babc35a4fb26a61d0bd3ee5b3c094db54a08db166c
76	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-02"}	86bded208d02467281a864babc35a4fb26a61d0bd3ee5b3c094db54a08db166c	0b5eee4514c9510ac18f9d366fef6032cb727e9c80740fa796c13678211da2f7
77	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-03"}	0b5eee4514c9510ac18f9d366fef6032cb727e9c80740fa796c13678211da2f7	1f8a7565c151c5cc33c6477550a99d5ff54487670180ca25e88bd7910aab5cf6
78	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	1f8a7565c151c5cc33c6477550a99d5ff54487670180ca25e88bd7910aab5cf6	67113fed3f5ccb664841cc0a4621b81e9b789935eca2fc3e3f78ff7596ddfd66
79	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-05"}	67113fed3f5ccb664841cc0a4621b81e9b789935eca2fc3e3f78ff7596ddfd66	2b639d1de5a11cac8fdf6e6f4f6a54e50134dadfefb647795dc9b4de823787d8
80	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-06"}	2b639d1de5a11cac8fdf6e6f4f6a54e50134dadfefb647795dc9b4de823787d8	7fa0d4c49ca0175eff3b30e7b813a95d9d323c2fc6dae048802dbd7753ca5a39
81	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-07"}	7fa0d4c49ca0175eff3b30e7b813a95d9d323c2fc6dae048802dbd7753ca5a39	93711097f215f5df5eb6db8dd9b0258d7d37edf3a60bc455b00fbbbd56f19525
82	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-08"}	93711097f215f5df5eb6db8dd9b0258d7d37edf3a60bc455b00fbbbd56f19525	c6c385e16b596ba610830009900b208dca4d19e38e51f2d422623adefdfb23dc
83	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-08"}	c6c385e16b596ba610830009900b208dca4d19e38e51f2d422623adefdfb23dc	14f60b107d484617fa754896e6d3d2c8bdd9f93c7d8481d2036c4aa8ef4ce670
84	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-08"}	14f60b107d484617fa754896e6d3d2c8bdd9f93c7d8481d2036c4aa8ef4ce670	31d10c862268308465dc09d529e03f3c97e0babce3a26c2b73a64133c6b806d9
85	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	31d10c862268308465dc09d529e03f3c97e0babce3a26c2b73a64133c6b806d9	a6add784e9e907c9d95a5aa7f6e08217be94112edb8bbbae183997c94ade938f
86	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	a6add784e9e907c9d95a5aa7f6e08217be94112edb8bbbae183997c94ade938f	4c83de7d66cba340f1237e630a52d647018e61667f5cfb83412fc9ca0730e40d
87	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-10"}	4c83de7d66cba340f1237e630a52d647018e61667f5cfb83412fc9ca0730e40d	52b513610a81bdd38252953810d4878330c46f871482e8deb4ff83f537200213
88	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-11"}	52b513610a81bdd38252953810d4878330c46f871482e8deb4ff83f537200213	f281129f8a1a92ba24e46ff233ea87823a37fa7d6c90ea5dfc3f447b95e54cfa
89	2026-08-14 10:32:16	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	f281129f8a1a92ba24e46ff233ea87823a37fa7d6c90ea5dfc3f447b95e54cfa	7daa064abcef2e925a498b4d8582ae0c9fc16f4484044840ad295c92ad99ea9e
90	2026-08-14 10:32:16	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	7daa064abcef2e925a498b4d8582ae0c9fc16f4484044840ad295c92ad99ea9e	512a1f6c2bddbe8a1de2d737f9cb2e9f5a66f3c453a1708bd7f720ca571e5904
91	2026-08-14 10:32:30	auto_cloud_backup	{"day": 1, "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-103230.json", "size_kb": 373.1, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-103230.json"}	512a1f6c2bddbe8a1de2d737f9cb2e9f5a66f3c453a1708bd7f720ca571e5904	de363723090a193ff54cca0fb77ae7e6900d961e5fd27d3f1816d88737021479
92	2026-08-14 11:06:06	admin_created	{"new_admin_username": "harsha200797+new@gmail.com", "full_name": "Test Admin", "created_by": "admin", "timestamp": "2026-08-14"}	de363723090a193ff54cca0fb77ae7e6900d961e5fd27d3f1816d88737021479	f68241e54ae977d79172ffeaccb40c7ebf9fcf1a6f8c9ded32a24b4c3940d74d
93	2026-08-14 11:10:47	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-111047.json", "size_kb": 375.6, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-111047.json"}	f68241e54ae977d79172ffeaccb40c7ebf9fcf1a6f8c9ded32a24b4c3940d74d	21ef4459852dc8e584b563bf43c1bdeb576b6dabec27e6dd7a46553088800808
94	2026-08-14 11:10:54	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-111054.json", "size_kb": 376.2, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-111054.json"}	21ef4459852dc8e584b563bf43c1bdeb576b6dabec27e6dd7a46553088800808	6ec1ef20e83af2c58b0a5f3e3086944d3275358e468990bca1424a5cc8600eed
95	2026-08-14 11:33:31	password_changed	{"username": "admin", "time": "2026-08-14"}	6ec1ef20e83af2c58b0a5f3e3086944d3275358e468990bca1424a5cc8600eed	b74a392ff372fc25304635e8f306d1114c99a0f91c17cd8c7f0f8fd353de355c
96	2026-08-14 11:40:57	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-14T11:40:57.900905"}	b74a392ff372fc25304635e8f306d1114c99a0f91c17cd8c7f0f8fd353de355c	a15baf8f62b736db2847d593a10f61bdb43c85e1f2048f1eedef170cd3f6d177
97	2026-08-14 11:41:03	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-14T11:41:03.675684"}	a15baf8f62b736db2847d593a10f61bdb43c85e1f2048f1eedef170cd3f6d177	a87f4aaafe3969158aacb0c1098044ef2dd369a6d34de7b94eadfdc89c95eb30
98	2026-08-14 11:41:15	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "REJECTED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Rejected via AI Decision Center", "timestamp": "2026-08-14T11:41:15.432149"}	a87f4aaafe3969158aacb0c1098044ef2dd369a6d34de7b94eadfdc89c95eb30	0606dd498e75406491d52028b12d87b9d0d387f582b23c1adbdfb00b60549196
99	2026-08-14 11:45:45	password_changed	{"username": "harsha200797@gmail.com", "time": "2026-08-14"}	0606dd498e75406491d52028b12d87b9d0d387f582b23c1adbdfb00b60549196	6e2a3e708743536e4b6169d955bbf9a20950343502d38d4509f1750653b4bde0
100	2026-08-14 12:08:06	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-120806.json", "size_kb": 381.0, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-120806.json"}	6e2a3e708743536e4b6169d955bbf9a20950343502d38d4509f1750653b4bde0	e6f66b3914b13908374db2e8d3e618157fd1c53bd3ef2a6683c8e84c120efd4b
101	2026-08-14 12:08:16	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-120816.json", "size_kb": 381.7, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-120816.json"}	e6f66b3914b13908374db2e8d3e618157fd1c53bd3ef2a6683c8e84c120efd4b	2561ce2e0a24827fff7867bbb359b9f4bfa35fd85a5316f310ddec84a261a2a7
102	2026-08-14 12:25:18	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-122518.json", "size_kb": 382.7, "mode": "Local Fallback (Demo)", "message": "Cloud keys unconfigured/invalid. Saved local backup: data/backups/backup-20260814-122518.json"}	2561ce2e0a24827fff7867bbb359b9f4bfa35fd85a5316f310ddec84a261a2a7	6c64e2f16151bf67805b34e34064e92523b2000507f8c454e8f32c726b705a03
103	2026-08-14 12:38:20	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-123805.json", "size_kb": 383.5, "mode": "Local Fallback (Demo)", "message": "Cloud keys unconfigured/invalid. Saved local backup: data/backups/backup-20260814-123805.json"}	6c64e2f16151bf67805b34e34064e92523b2000507f8c454e8f32c726b705a03	446c656ffee74615e54be8ac52e9c12d9c5e83d9c0d2afd391341d5e5b4cc531
104	2026-08-15 07:02:39	auto_cloud_backup	{"day": 2, "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260815-070212.json", "size_kb": 384.5, "mode": "Local Fallback (Demo)", "message": "Cloud keys unconfigured/invalid. Saved local backup: data/backups/backup-20260815-070212.json"}	446c656ffee74615e54be8ac52e9c12d9c5e83d9c0d2afd391341d5e5b4cc531	dd5d0e8f377b6fe7445c6329d12849fa1d9605882bf35d648dc21f5f0b9cf46f
105	2026-08-15 07:46:48	admin_created	{"new_admin_username": "testadmin_1786780003@gmail.com", "full_name": "Test Administrator", "created_by": "admin", "timestamp": "2026-08-15"}	dd5d0e8f377b6fe7445c6329d12849fa1d9605882bf35d648dc21f5f0b9cf46f	e69c4570d4781be51d327b6d16eaa65ca8ef99848968565b90feb4e0e9e09e24
106	2026-08-15 07:47:32	admin_created	{"new_admin_username": "testadmin_1786780047@gmail.com", "full_name": "Test Administrator", "created_by": "admin", "timestamp": "2026-08-15"}	e69c4570d4781be51d327b6d16eaa65ca8ef99848968565b90feb4e0e9e09e24	4bd2228f0bfde8ed7d12a73ba7561425a07ad0be743e8108f6a93e796b8f8327
107	2026-08-15 08:28:10	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260815-082759.json", "size_kb": 389.0, "mode": "Local Fallback (Demo)", "message": "Cloud keys unconfigured/invalid. Saved local backup: data/backups/backup-20260815-082759.json"}	4bd2228f0bfde8ed7d12a73ba7561425a07ad0be743e8108f6a93e796b8f8327	4fd605456925b5c9aff8cf35f2ab7e228b58a464673405ef3132e3c8cb440857
108	2026-08-15 13:10:08	stock_entry	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "date": "2026-08-15", "stock_in": 10, "stock_out": 10, "entered_by": "harsha200797@gmail.com"}	4fd605456925b5c9aff8cf35f2ab7e228b58a464673405ef3132e3c8cb440857	0d578b7bbf6c7317975239cf780a733abe69ec7a333ada1a7c15835b5f677f6b
109	2026-08-15 14:03:01	stock_entry	{"warehouse_id": "WH-BLR-01", "item_id": "ITM005", "date": "2026-08-15", "stock_in": 50, "stock_out": 100, "entered_by": "harsha200797@gmail.com"}	0d578b7bbf6c7317975239cf780a733abe69ec7a333ada1a7c15835b5f677f6b	5cd85a3e5b70ddeee37768fdf1044d84c5207cbb321aa54e248e8b508aff3889
110	2026-08-15 15:51:30	password_changed	{"username": "harsha200797@gmail.com", "time": "2026-08-15"}	5cd85a3e5b70ddeee37768fdf1044d84c5207cbb321aa54e248e8b508aff3889	3ce437ea24e16734005a6cf8dfce2004f0895138be3ad574abeed2b39ec13e29
111	2026-08-15 15:52:47	admin_created	{"new_admin_username": "joyboy56211@gmail.com", "full_name": "joyboy", "created_by": "harsha200797@gmail.com", "timestamp": "2026-08-15"}	3ce437ea24e16734005a6cf8dfce2004f0895138be3ad574abeed2b39ec13e29	893da12539424b2e78e96fee8a866f0dc57d5912b4581527e542f4cb0ac05ade
112	2026-08-15 15:57:11	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CPU-01", "item_id": "ITM-CPU-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-15T15:57:11.325021"}	893da12539424b2e78e96fee8a866f0dc57d5912b4581527e542f4cb0ac05ade	4d17ecdbf11420983f1b32789ddcd4ee32d705d563dfffeedc2f95f8707c3155
113	2026-08-15 15:57:19	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "REJECTED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Rejected via AI Decision Center", "timestamp": "2026-08-15T15:57:19.295618"}	4d17ecdbf11420983f1b32789ddcd4ee32d705d563dfffeedc2f95f8707c3155	7c16120b3afab45f5c479106cf6e04c5e7c8c91cc6d74512979397df1e9412af
114	2026-08-15 16:00:03	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CPU-01", "item_id": "ITM-CPU-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-15T16:00:03.103583"}	7c16120b3afab45f5c479106cf6e04c5e7c8c91cc6d74512979397df1e9412af	f97b0d767ccb8c52014d23d0a0403e5201705b62a4cba15074cb3936189b406c
115	2026-08-15 16:00:10	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-SSD-01", "item_id": "ITM-SSD-01", "action": "REJECTED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Rejected via AI Decision Center", "timestamp": "2026-08-15T16:00:10.267032"}	f97b0d767ccb8c52014d23d0a0403e5201705b62a4cba15074cb3936189b406c	a907e28be5b32cae08436f40b1ec9251836ddf5ee438779a18549f3c23d6a5dc
116	2026-08-17 04:26:11	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-DEL-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-17T04:26:11.921406"}	a907e28be5b32cae08436f40b1ec9251836ddf5ee438779a18549f3c23d6a5dc	3a11abe2365e0f3b2dfb42fe37dd2681990686a58c251b48ff3224023311e4bc
117	2026-08-17 17:12:50	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	3a11abe2365e0f3b2dfb42fe37dd2681990686a58c251b48ff3224023311e4bc	66062465c9c2c575f5e80b7490b044b304b5b36948414254b6353acd08548a96
118	2026-08-17 17:12:50	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	66062465c9c2c575f5e80b7490b044b304b5b36948414254b6353acd08548a96	ac4a1f0949fc9c177eab18d9eae02dd1c6bd7104491a2e12b8ae4c7d73bb6d03
119	2026-08-17 17:12:50	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	ac4a1f0949fc9c177eab18d9eae02dd1c6bd7104491a2e12b8ae4c7d73bb6d03	8cd4d240b61e78139d0d76af3710296345401259b51e850dd627735dcc6ee552
120	2026-08-17 17:12:50	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	8cd4d240b61e78139d0d76af3710296345401259b51e850dd627735dcc6ee552	d1a02f8147edea89d12212c8dd2824ba4eb1191df3d110f5a8c2e60e92384eae
121	2026-08-17 17:12:50	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	d1a02f8147edea89d12212c8dd2824ba4eb1191df3d110f5a8c2e60e92384eae	d7482aa74f49612c9253a9001dcb6efa66f3fe74a6566bb3d68bd837ba9825ee
122	2026-08-17 17:12:51	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	d7482aa74f49612c9253a9001dcb6efa66f3fe74a6566bb3d68bd837ba9825ee	fe02da0a45957de98523c232ead54f90541e2abf3b08304caa80c31a26e8d7ff
123	2026-08-17 17:12:51	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	fe02da0a45957de98523c232ead54f90541e2abf3b08304caa80c31a26e8d7ff	0e17e291f9b3f66832afb60d2d9b79b16b731942d01c843d01c527e8d6873df6
124	2026-08-17 17:12:51	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	0e17e291f9b3f66832afb60d2d9b79b16b731942d01c843d01c527e8d6873df6	75feab0c9b891814ee0ffa5902c9cd8488212c0146d637a3757332e30f25133e
125	2026-08-17 17:12:51	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	75feab0c9b891814ee0ffa5902c9cd8488212c0146d637a3757332e30f25133e	b46851bf1c082a806769f1a6bc64f8cce39221d9f5d1ab3b80d8f01235965e99
126	2026-08-17 17:12:51	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	b46851bf1c082a806769f1a6bc64f8cce39221d9f5d1ab3b80d8f01235965e99	2f3f4f0cb30b4f7a1fdc534764b4e1a07a035c0bf0b8fd6063bbb45a54abf07a
127	2026-08-17 17:12:51	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	2f3f4f0cb30b4f7a1fdc534764b4e1a07a035c0bf0b8fd6063bbb45a54abf07a	c2632523c0c762c7db6bfb83f6da046951b170ab0ad5bffa047ef03f7cc80b3d
128	2026-08-17 17:12:51	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	c2632523c0c762c7db6bfb83f6da046951b170ab0ad5bffa047ef03f7cc80b3d	caea482f43a79ab6afcd34af7ff34ffff161b9af6cdbbe2e32c865f4c5b80c21
129	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	caea482f43a79ab6afcd34af7ff34ffff161b9af6cdbbe2e32c865f4c5b80c21	934c160c5328990efe55549845313ce2546b61b66fcabaa15156d936d9ae3039
130	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	934c160c5328990efe55549845313ce2546b61b66fcabaa15156d936d9ae3039	d817d655b2cd3cc0ffdf2b982d81984eaf3ec77cb1fa0f2f1b233580bbf9dae6
131	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	d817d655b2cd3cc0ffdf2b982d81984eaf3ec77cb1fa0f2f1b233580bbf9dae6	2606df344b018d86f1d9a5199a95f309c4f66ee758f72451b31743f08b173a51
132	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	2606df344b018d86f1d9a5199a95f309c4f66ee758f72451b31743f08b173a51	104ab57cd50ac85db08799b878d1e124e052733ee7221ebe81fd7c535373faf2
133	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	104ab57cd50ac85db08799b878d1e124e052733ee7221ebe81fd7c535373faf2	a06dca47b13cfb5c46943d25ac94597d7600b210378e3238d464e4287677a4e6
134	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	a06dca47b13cfb5c46943d25ac94597d7600b210378e3238d464e4287677a4e6	244e3ca6d930e56fc9617d3843456113f62606c2dada8c348284c6ad6f058678
135	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	244e3ca6d930e56fc9617d3843456113f62606c2dada8c348284c6ad6f058678	c0d0d8ffec901aae9455406c6b2e8c2eaa884811001be190c2f41fac9f78dd06
136	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	c0d0d8ffec901aae9455406c6b2e8c2eaa884811001be190c2f41fac9f78dd06	686d0927db6923f09bcd45991ce5eb5f72c544900656a0ecb8f43acf619ffbe3
137	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-26"}	686d0927db6923f09bcd45991ce5eb5f72c544900656a0ecb8f43acf619ffbe3	6dfa886ed2e4d75ae6004a2d9c78a8056267a75abd468a4837284f8a779a17a4
138	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	6dfa886ed2e4d75ae6004a2d9c78a8056267a75abd468a4837284f8a779a17a4	b7e5765ad53adedc0ee62b6995f5c9b339166cc4ddb5951a4fb0a458bbcebbda
139	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-27"}	b7e5765ad53adedc0ee62b6995f5c9b339166cc4ddb5951a4fb0a458bbcebbda	e3b106953ab3541bb71bfd530fc4a01da4175a70774a2401678049e31086a3e7
140	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	e3b106953ab3541bb71bfd530fc4a01da4175a70774a2401678049e31086a3e7	454ff446883cd830c6a154804ee4a70b9c2c3da72d7f859ebe0b8113ea6c376f
141	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-28"}	454ff446883cd830c6a154804ee4a70b9c2c3da72d7f859ebe0b8113ea6c376f	169b14d7fa81882ac7e69341e2370927f7134ecab2811fa8478d5130c4d88d17
142	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-30"}	169b14d7fa81882ac7e69341e2370927f7134ecab2811fa8478d5130c4d88d17	cdd641de4df2f3bab339ae9cd181a0e63876c643c9e643a29a93227995709083
143	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	cdd641de4df2f3bab339ae9cd181a0e63876c643c9e643a29a93227995709083	e39522e16e91d21e8a4a80778fe12462e053ec390f6b5c3216e85d03fa31ca21
144	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	e39522e16e91d21e8a4a80778fe12462e053ec390f6b5c3216e85d03fa31ca21	7e849f57079394da50c7417d8ad14b943e115c6547fe5274c849a9093796140f
145	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-02"}	7e849f57079394da50c7417d8ad14b943e115c6547fe5274c849a9093796140f	059c145dfcb78472bc9b4da19dd442724899a05315ca822f30ca04b4967a8c33
146	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	059c145dfcb78472bc9b4da19dd442724899a05315ca822f30ca04b4967a8c33	a3ffc065f8b0c2ab707f2f71a1cfe9d4c1ff3ac6518dd9e2ce9e31b27d5466ff
147	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	a3ffc065f8b0c2ab707f2f71a1cfe9d4c1ff3ac6518dd9e2ce9e31b27d5466ff	8ff22aab00c27f7a8015c35719043fd23d45c543068f2ac790f30fd04b4bdfbc
148	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-04"}	8ff22aab00c27f7a8015c35719043fd23d45c543068f2ac790f30fd04b4bdfbc	415ce6c64dcf5f0351128891d0868c08c965d07d00dcf6e443ac77771f309254
149	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-04"}	415ce6c64dcf5f0351128891d0868c08c965d07d00dcf6e443ac77771f309254	c2b196406ac8c8ea6b9ae18c2620bad6e61c8629bf5632dd7e20012ada43f270
150	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-05"}	c2b196406ac8c8ea6b9ae18c2620bad6e61c8629bf5632dd7e20012ada43f270	3493a622ba881b928fdb4a108291590e7073bea957869b9e08754ecc0519618c
151	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	3493a622ba881b928fdb4a108291590e7073bea957869b9e08754ecc0519618c	75c26b4132486f26e48e7284a50012df1417bc3372c1dae9bdccb5d702022ce8
152	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-06"}	75c26b4132486f26e48e7284a50012df1417bc3372c1dae9bdccb5d702022ce8	2d215df23f4bb7b135623e4a91d98a95f65d4f73e4ab56c273a3d6f2a771b9f1
153	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-07"}	2d215df23f4bb7b135623e4a91d98a95f65d4f73e4ab56c273a3d6f2a771b9f1	8b41b613d3bd2d5498a0bfd3d531ef9370140f2115a3b1ab55edabac2f1b112e
154	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-08"}	8b41b613d3bd2d5498a0bfd3d531ef9370140f2115a3b1ab55edabac2f1b112e	b9d9cfa0f5ad56784ebc098fffa90bd1499efb457254868699b485ae99bb2285
155	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-08"}	b9d9cfa0f5ad56784ebc098fffa90bd1499efb457254868699b485ae99bb2285	1ed2275c43ff89111a7cf06caaf63b384c6d5cb833bf3c2ec2b266894a9764ac
156	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-SSD-01", "quantity": 90, "date": "2026-08-08"}	1ed2275c43ff89111a7cf06caaf63b384c6d5cb833bf3c2ec2b266894a9764ac	51046ac25b499ce787f4977beef55c87d464a314ac0b691cd0e2567e1269bf48
157	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-08"}	51046ac25b499ce787f4977beef55c87d464a314ac0b691cd0e2567e1269bf48	50cd75e28d64a6d6bfbf0810cc62a46b2dfcfa401368ba842ed267755f607a95
158	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	50cd75e28d64a6d6bfbf0810cc62a46b2dfcfa401368ba842ed267755f607a95	08bd2233e752e078d1a7261f6da5924217a655378decf82fb2fe01398037c967
159	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-10"}	08bd2233e752e078d1a7261f6da5924217a655378decf82fb2fe01398037c967	e226c35ae0726db5fe1e17adecf913384d87d2c2669a15cfa9075ca0b1fed5be
160	2026-08-17 17:12:51	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	e226c35ae0726db5fe1e17adecf913384d87d2c2669a15cfa9075ca0b1fed5be	8fb05c18d8f65b9ccdf5b9ff6107ba6fccc6b51d679a67a37d9554d4bb4afca5
161	2026-08-17 17:12:51	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	8fb05c18d8f65b9ccdf5b9ff6107ba6fccc6b51d679a67a37d9554d4bb4afca5	8ba2e7e8bcf29f525150214716de087532e7214a33c5cea3e9aa35606d994b43
162	2026-08-17 17:12:51	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	8ba2e7e8bcf29f525150214716de087532e7214a33c5cea3e9aa35606d994b43	feacd6a24069190efc752b878c50984d93d6c1b85033b056b376058aa05a5f2d
\.


--
-- Data for Name: backup_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_records (id, backup_id, filename, created_at, size_bytes, sha256, status, storage_key, error_message) FROM stdin;
1	BK-DA049020A9ED7691	warehouse_sqlite_2026-08-15_12-52-33.db.gz	2026-08-15 12:52:37.900197	57591	2cb59143d8b46715acce3bee8c68a47dd4c2f59e8cf38140799770a06db5350b	FAILED	data/backups/warehouse_sqlite_2026-08-15_12-52-33.db.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
2	BK-503EA0B0E548C2B0	warehouse_sqlite_2026-08-15_13-40-26.db.gz	2026-08-15 13:40:30.907048	58321	b7ade5907b2aea645956bb369ebe9a224ce714295e3c2b61f1ac27ee599803a0	FAILED	data/backups/warehouse_sqlite_2026-08-15_13-40-26.db.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
3	BK-734D48994FBE3917	warehouse_postgres_2026-08-15_15-01-04.sql.gz	2026-08-15 15:01:04.033906	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
4	BK-53D1D7EEB12EA011	warehouse_postgres_2026-08-15_15-01-33.sql.gz	2026-08-15 15:01:37.588028	23045	5fd661b39e81acf7396ff4bc17a66e3e027e57eb02b366724090563da99b489b	FAILED	data/backups/warehouse_postgres_2026-08-15_15-01-33.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
5	BK-C056B388ED2B06C5	warehouse_postgres_2026-08-15_18-46-58.sql.gz	2026-08-15 18:46:58.433478	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
6	BK-084687BC03958C21	warehouse_postgres_2026-08-15_19-46-58.sql.gz	2026-08-15 19:46:58.721681	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
7	BK-80BE0EC4957801A0	warehouse_postgres_2026-08-15_20-46-59.sql.gz	2026-08-15 20:46:59.063067	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
8	BK-27491D98F44844E0	warehouse_postgres_2026-08-16_05-07-36.sql.gz	2026-08-16 05:07:36.369377	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
9	BK-B2C72394440D78AE	warehouse_postgres_2026-08-16_07-09-22.sql.gz	2026-08-16 07:09:22.333943	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
10	BK-14B768057DB11134	warehouse_postgres_2026-08-16_10-41-41.sql.gz	2026-08-16 10:41:41.290469	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
11	BK-89E471803E5E2F61	warehouse_postgres_2026-08-16_14-27-00.sql.gz	2026-08-16 14:27:00.874889	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
12	BK-91A3A46EB7FE2660	warehouse_postgres_2026-08-17_04-38-44.sql.gz	2026-08-17 04:38:44.303452	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
13	BK-CB69B4B642BCAE40	warehouse_postgres_2026-08-17_05-18-30.sql.gz	2026-08-17 05:18:30.601088	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
14	BK-F48D842423DE2A68	warehouse_postgres_2026-08-17_05-18-33.sql.gz	2026-08-17 05:18:33.044259	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
15	BK-626EC2DEF95FDB50	warehouse_postgres_2026-08-17_05-38-44.sql.gz	2026-08-17 05:38:44.47845	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
16	BK-0E8C51C58B69888D	warehouse_postgres_2026-08-17_07-46-31.sql.gz	2026-08-17 07:46:31.673242	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
17	BK-3E1F80FA693E6618	warehouse_postgres_2026-08-17_17-13-07.sql.gz	2026-08-17 17:13:10.736201	25463	2787adc6c92099bb65db355d6eb84b0fc02698d810b0e0bf099c3db38ef00dec	FAILED	data/backups/warehouse_postgres_2026-08-17_17-13-07.sql.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id, name, category, unit_cost, lead_time_days, safety_stock, created_at) FROM stdin;
ITM-CPU-01	AMD Ryzen 9 7900X Processor	Electronics	38000	5	15	2026-08-17 17:12:51.003725
ITM-GPU-01	Nvidia RTX 4080 Founders Edition	Electronics	95000	7	10	2026-08-17 17:12:51.007725
ITM-RAM-01	Corsair DDR5 32GB 6000MHz RAM	Electronics	8500	4	25	2026-08-17 17:12:51.012722
ITM-SSD-01	Samsung 990 Pro 2TB NVMe SSD	Storage	12000	3	30	2026-08-17 17:12:51.016727
ITM-HDD-01	WD Red Pro 8TB NAS Hard Drive	Storage	16500	5	20	2026-08-17 17:12:51.019723
ITM-CHG-01	Anker 100W GaN Wall Charger	Accessories	2500	2	50	2026-08-17 17:12:51.022722
ITM-CBL-01	Apple USB-C Braided Cable 2m	Accessories	800	1	100	2026-08-17 17:12:51.027723
\.


--
-- Data for Name: recovery_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recovery_codes (id, user_id, code_hash, used, created_at, used_at) FROM stdin;
\.


--
-- Data for Name: recovery_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recovery_credentials (id, user_id, password_hash, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shrinkage_flags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shrinkage_flags (id, date, warehouse_id, item_id, item_name, deviation_score, expected_quantity, actual_quantity, discrepancy_quantity, estimated_exposure, severity, likely_cause, explanation) FROM stdin;
3	2026-08-05	WH-BLR-01	ITM-GPU-01	Nvidia RTX 4080 Founders Edition	0.85	15	5	-10	950000	CRITICAL	UNUSUAL_OUTBOUND_ACTIVITY	Sudden unrecorded drop of 10 units (Valued at ₹9,50,000) occurred outside regular stock-out operations.
4	2026-07-25	WH-CHN-01	ITM-CPU-01	AMD Ryzen 9 7900X Processor	0.72	20	5	-15	570000	HIGH	POSSIBLE_DAMAGE_OR_WASTAGE	Discrepancy of 15 units (Valued at ₹5,70,000) reported at the dock. Unrecorded scraping suspected.
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, date, warehouse_id, item_id, stock_in, stock_out, closing_stock, is_anomaly, anomaly_type, entry_source, entered_by) FROM stdin;
1053	2026-07-13	WH-BLR-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
1054	2026-07-13	WH-BLR-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
1055	2026-07-13	WH-BLR-01	ITM-RAM-01	0	10	65	f	none	simulated	system_sim
1056	2026-07-13	WH-BLR-01	ITM-SSD-01	0	3	87	f	none	simulated	system_sim
1057	2026-07-13	WH-BLR-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
1058	2026-07-13	WH-BLR-01	ITM-CHG-01	0	1	149	f	none	simulated	system_sim
1059	2026-07-13	WH-BLR-01	ITM-CBL-01	0	8	292	f	none	simulated	system_sim
1060	2026-07-13	WH-CHN-01	ITM-CPU-01	0	1	44	f	none	simulated	system_sim
1061	2026-07-13	WH-CHN-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
1062	2026-07-13	WH-CHN-01	ITM-RAM-01	0	2	73	f	none	simulated	system_sim
1063	2026-07-13	WH-CHN-01	ITM-SSD-01	0	2	88	f	none	simulated	system_sim
1064	2026-07-13	WH-CHN-01	ITM-HDD-01	0	3	57	f	none	simulated	system_sim
1065	2026-07-13	WH-CHN-01	ITM-CHG-01	0	9	141	f	none	simulated	system_sim
1066	2026-07-13	WH-CHN-01	ITM-CBL-01	0	7	293	f	none	simulated	system_sim
1067	2026-07-13	WH-BOM-01	ITM-CPU-01	0	1	44	f	none	simulated	system_sim
1068	2026-07-13	WH-BOM-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
1069	2026-07-13	WH-BOM-01	ITM-RAM-01	0	6	69	f	none	simulated	system_sim
1070	2026-07-13	WH-BOM-01	ITM-SSD-01	0	1	89	f	none	simulated	system_sim
1071	2026-07-13	WH-BOM-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
1072	2026-07-13	WH-BOM-01	ITM-CHG-01	0	7	143	f	none	simulated	system_sim
1073	2026-07-13	WH-BOM-01	ITM-CBL-01	0	2	298	f	none	simulated	system_sim
1074	2026-07-13	WH-DEL-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
1075	2026-07-13	WH-DEL-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
1076	2026-07-13	WH-DEL-01	ITM-RAM-01	0	4	71	f	none	simulated	system_sim
1077	2026-07-13	WH-DEL-01	ITM-SSD-01	0	3	87	f	none	simulated	system_sim
1078	2026-07-13	WH-DEL-01	ITM-HDD-01	0	1	59	f	none	simulated	system_sim
1079	2026-07-13	WH-DEL-01	ITM-CHG-01	0	8	142	f	none	simulated	system_sim
1080	2026-07-13	WH-DEL-01	ITM-CBL-01	0	1	299	f	none	simulated	system_sim
1081	2026-07-13	WH-CCU-01	ITM-CPU-01	0	2	43	f	none	simulated	system_sim
1082	2026-07-13	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
1083	2026-07-13	WH-CCU-01	ITM-RAM-01	0	6	69	f	none	simulated	system_sim
1084	2026-07-13	WH-CCU-01	ITM-SSD-01	0	2	88	f	none	simulated	system_sim
1085	2026-07-13	WH-CCU-01	ITM-HDD-01	0	2	58	f	none	simulated	system_sim
1086	2026-07-13	WH-CCU-01	ITM-CHG-01	0	3	147	f	none	simulated	system_sim
1087	2026-07-13	WH-CCU-01	ITM-CBL-01	0	9	291	f	none	simulated	system_sim
1088	2026-07-14	WH-BLR-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
1089	2026-07-14	WH-BLR-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
1090	2026-07-14	WH-BLR-01	ITM-RAM-01	0	6	59	f	none	simulated	system_sim
1091	2026-07-14	WH-BLR-01	ITM-SSD-01	0	2	85	f	none	simulated	system_sim
1092	2026-07-14	WH-BLR-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
1093	2026-07-14	WH-BLR-01	ITM-CHG-01	0	5	144	f	none	simulated	system_sim
1094	2026-07-14	WH-BLR-01	ITM-CBL-01	0	3	289	f	none	simulated	system_sim
1095	2026-07-14	WH-CHN-01	ITM-CPU-01	0	2	42	f	none	simulated	system_sim
1096	2026-07-14	WH-CHN-01	ITM-GPU-01	0	2	28	f	none	simulated	system_sim
1097	2026-07-14	WH-CHN-01	ITM-RAM-01	0	3	70	f	none	simulated	system_sim
1098	2026-07-14	WH-CHN-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
1099	2026-07-14	WH-CHN-01	ITM-HDD-01	0	0	57	f	none	simulated	system_sim
1100	2026-07-14	WH-CHN-01	ITM-CHG-01	0	1	140	f	none	simulated	system_sim
1101	2026-07-14	WH-CHN-01	ITM-CBL-01	0	3	290	f	none	simulated	system_sim
1102	2026-07-14	WH-BOM-01	ITM-CPU-01	0	2	42	f	none	simulated	system_sim
1103	2026-07-14	WH-BOM-01	ITM-GPU-01	0	2	27	f	none	simulated	system_sim
1104	2026-07-14	WH-BOM-01	ITM-RAM-01	0	5	64	f	none	simulated	system_sim
1105	2026-07-14	WH-BOM-01	ITM-SSD-01	0	0	89	f	none	simulated	system_sim
1106	2026-07-14	WH-BOM-01	ITM-HDD-01	0	2	58	f	none	simulated	system_sim
1107	2026-07-14	WH-BOM-01	ITM-CHG-01	0	8	135	f	none	simulated	system_sim
1108	2026-07-14	WH-BOM-01	ITM-CBL-01	0	8	290	f	none	simulated	system_sim
1109	2026-07-14	WH-DEL-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
1110	2026-07-14	WH-DEL-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
1111	2026-07-14	WH-DEL-01	ITM-RAM-01	0	1	70	f	none	simulated	system_sim
1112	2026-07-14	WH-DEL-01	ITM-SSD-01	0	3	84	f	none	simulated	system_sim
1113	2026-07-14	WH-DEL-01	ITM-HDD-01	0	2	57	f	none	simulated	system_sim
1114	2026-07-14	WH-DEL-01	ITM-CHG-01	0	7	135	f	none	simulated	system_sim
1115	2026-07-14	WH-DEL-01	ITM-CBL-01	0	6	293	f	none	simulated	system_sim
1116	2026-07-14	WH-CCU-01	ITM-CPU-01	0	3	40	f	none	simulated	system_sim
1117	2026-07-14	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
1118	2026-07-14	WH-CCU-01	ITM-RAM-01	0	4	65	f	none	simulated	system_sim
1119	2026-07-14	WH-CCU-01	ITM-SSD-01	0	1	87	f	none	simulated	system_sim
1120	2026-07-14	WH-CCU-01	ITM-HDD-01	0	1	57	f	none	simulated	system_sim
1121	2026-07-14	WH-CCU-01	ITM-CHG-01	0	2	145	f	none	simulated	system_sim
1122	2026-07-14	WH-CCU-01	ITM-CBL-01	0	4	287	f	none	simulated	system_sim
1123	2026-07-15	WH-BLR-01	ITM-CPU-01	0	3	39	f	none	simulated	system_sim
1124	2026-07-15	WH-BLR-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
1125	2026-07-15	WH-BLR-01	ITM-RAM-01	0	5	54	f	none	simulated	system_sim
1126	2026-07-15	WH-BLR-01	ITM-SSD-01	0	1	84	f	none	simulated	system_sim
1127	2026-07-15	WH-BLR-01	ITM-HDD-01	0	1	59	f	none	simulated	system_sim
1128	2026-07-15	WH-BLR-01	ITM-CHG-01	0	5	139	f	none	simulated	system_sim
1129	2026-07-15	WH-BLR-01	ITM-CBL-01	0	8	281	f	none	simulated	system_sim
1130	2026-07-15	WH-CHN-01	ITM-CPU-01	0	1	41	f	none	simulated	system_sim
1131	2026-07-15	WH-CHN-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
1132	2026-07-15	WH-CHN-01	ITM-RAM-01	0	9	61	f	none	simulated	system_sim
1133	2026-07-15	WH-CHN-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
1134	2026-07-15	WH-CHN-01	ITM-HDD-01	0	2	55	f	none	simulated	system_sim
1135	2026-07-15	WH-CHN-01	ITM-CHG-01	0	2	138	f	none	simulated	system_sim
1136	2026-07-15	WH-CHN-01	ITM-CBL-01	0	4	286	f	none	simulated	system_sim
1137	2026-07-15	WH-BOM-01	ITM-CPU-01	0	3	39	f	none	simulated	system_sim
1138	2026-07-15	WH-BOM-01	ITM-GPU-01	0	1	26	f	none	simulated	system_sim
1139	2026-07-15	WH-BOM-01	ITM-RAM-01	0	10	54	f	none	simulated	system_sim
1140	2026-07-15	WH-BOM-01	ITM-SSD-01	0	0	89	f	none	simulated	system_sim
1141	2026-07-15	WH-BOM-01	ITM-HDD-01	0	1	57	f	none	simulated	system_sim
1142	2026-07-15	WH-BOM-01	ITM-CHG-01	0	4	131	f	none	simulated	system_sim
1143	2026-07-15	WH-BOM-01	ITM-CBL-01	0	6	284	f	none	simulated	system_sim
1144	2026-07-15	WH-DEL-01	ITM-CPU-01	0	1	41	f	none	simulated	system_sim
1145	2026-07-15	WH-DEL-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
1146	2026-07-15	WH-DEL-01	ITM-RAM-01	0	8	62	f	none	simulated	system_sim
1147	2026-07-15	WH-DEL-01	ITM-SSD-01	0	1	83	f	none	simulated	system_sim
1148	2026-07-15	WH-DEL-01	ITM-HDD-01	0	3	54	f	none	simulated	system_sim
1149	2026-07-15	WH-DEL-01	ITM-CHG-01	0	5	130	f	none	simulated	system_sim
1150	2026-07-15	WH-DEL-01	ITM-CBL-01	0	10	283	f	none	simulated	system_sim
1151	2026-07-15	WH-CCU-01	ITM-CPU-01	0	3	37	f	none	simulated	system_sim
1152	2026-07-15	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
1153	2026-07-15	WH-CCU-01	ITM-RAM-01	0	6	59	f	none	simulated	system_sim
1154	2026-07-15	WH-CCU-01	ITM-SSD-01	0	1	86	f	none	simulated	system_sim
1155	2026-07-15	WH-CCU-01	ITM-HDD-01	0	0	57	f	none	simulated	system_sim
1156	2026-07-15	WH-CCU-01	ITM-CHG-01	0	1	144	f	none	simulated	system_sim
1157	2026-07-15	WH-CCU-01	ITM-CBL-01	0	8	279	f	none	simulated	system_sim
1158	2026-07-16	WH-BLR-01	ITM-CPU-01	0	3	36	f	none	simulated	system_sim
1159	2026-07-16	WH-BLR-01	ITM-GPU-01	0	1	28	f	none	simulated	system_sim
1160	2026-07-16	WH-BLR-01	ITM-RAM-01	0	4	50	f	none	simulated	system_sim
1161	2026-07-16	WH-BLR-01	ITM-SSD-01	0	0	84	f	none	simulated	system_sim
1162	2026-07-16	WH-BLR-01	ITM-HDD-01	0	0	59	f	none	simulated	system_sim
1163	2026-07-16	WH-BLR-01	ITM-CHG-01	0	6	133	f	none	simulated	system_sim
1164	2026-07-16	WH-BLR-01	ITM-CBL-01	0	5	276	f	none	simulated	system_sim
1165	2026-07-16	WH-CHN-01	ITM-CPU-01	0	0	41	f	none	simulated	system_sim
1166	2026-07-16	WH-CHN-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
1167	2026-07-16	WH-CHN-01	ITM-RAM-01	0	8	53	f	none	simulated	system_sim
1168	2026-07-16	WH-CHN-01	ITM-SSD-01	0	3	85	f	none	simulated	system_sim
1169	2026-07-16	WH-CHN-01	ITM-HDD-01	0	0	55	f	none	simulated	system_sim
1170	2026-07-16	WH-CHN-01	ITM-CHG-01	0	3	135	f	none	simulated	system_sim
1171	2026-07-16	WH-CHN-01	ITM-CBL-01	0	6	280	f	none	simulated	system_sim
1172	2026-07-16	WH-BOM-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
1173	2026-07-16	WH-BOM-01	ITM-GPU-01	0	2	24	f	none	simulated	system_sim
1174	2026-07-16	WH-BOM-01	ITM-RAM-01	0	4	50	f	none	simulated	system_sim
1175	2026-07-16	WH-BOM-01	ITM-SSD-01	0	3	86	f	none	simulated	system_sim
1176	2026-07-16	WH-BOM-01	ITM-HDD-01	0	1	56	f	none	simulated	system_sim
1177	2026-07-16	WH-BOM-01	ITM-CHG-01	0	3	128	f	none	simulated	system_sim
1178	2026-07-16	WH-BOM-01	ITM-CBL-01	0	8	276	f	none	simulated	system_sim
1179	2026-07-16	WH-DEL-01	ITM-CPU-01	0	0	41	f	none	simulated	system_sim
1180	2026-07-16	WH-DEL-01	ITM-GPU-01	0	1	28	f	none	simulated	system_sim
1181	2026-07-16	WH-DEL-01	ITM-RAM-01	0	10	52	f	none	simulated	system_sim
1182	2026-07-16	WH-DEL-01	ITM-SSD-01	0	3	80	f	none	simulated	system_sim
1183	2026-07-16	WH-DEL-01	ITM-HDD-01	0	1	53	f	none	simulated	system_sim
1184	2026-07-16	WH-DEL-01	ITM-CHG-01	0	10	120	f	none	simulated	system_sim
1185	2026-07-16	WH-DEL-01	ITM-CBL-01	0	6	277	f	none	simulated	system_sim
1186	2026-07-16	WH-CCU-01	ITM-CPU-01	0	0	37	f	none	simulated	system_sim
1187	2026-07-16	WH-CCU-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
1188	2026-07-16	WH-CCU-01	ITM-RAM-01	0	2	57	f	none	simulated	system_sim
1189	2026-07-16	WH-CCU-01	ITM-SSD-01	0	0	86	f	none	simulated	system_sim
1190	2026-07-16	WH-CCU-01	ITM-HDD-01	0	0	57	f	none	simulated	system_sim
1191	2026-07-16	WH-CCU-01	ITM-CHG-01	0	7	137	f	none	simulated	system_sim
1192	2026-07-16	WH-CCU-01	ITM-CBL-01	0	1	278	f	none	simulated	system_sim
1193	2026-07-17	WH-BLR-01	ITM-CPU-01	0	2	34	f	none	simulated	system_sim
1194	2026-07-17	WH-BLR-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
1195	2026-07-17	WH-BLR-01	ITM-RAM-01	0	5	45	f	none	simulated	system_sim
1196	2026-07-17	WH-BLR-01	ITM-SSD-01	0	1	83	f	none	simulated	system_sim
1197	2026-07-17	WH-BLR-01	ITM-HDD-01	0	0	59	f	none	simulated	system_sim
1198	2026-07-17	WH-BLR-01	ITM-CHG-01	0	10	123	f	none	simulated	system_sim
1199	2026-07-17	WH-BLR-01	ITM-CBL-01	0	5	271	f	none	simulated	system_sim
1200	2026-07-17	WH-CHN-01	ITM-CPU-01	0	2	39	f	none	simulated	system_sim
1201	2026-07-17	WH-CHN-01	ITM-GPU-01	0	2	26	f	none	simulated	system_sim
1202	2026-07-17	WH-CHN-01	ITM-RAM-01	0	8	45	f	none	simulated	system_sim
1203	2026-07-17	WH-CHN-01	ITM-SSD-01	0	1	84	f	none	simulated	system_sim
1204	2026-07-17	WH-CHN-01	ITM-HDD-01	0	0	55	f	none	simulated	system_sim
1205	2026-07-17	WH-CHN-01	ITM-CHG-01	0	5	130	f	none	simulated	system_sim
1206	2026-07-17	WH-CHN-01	ITM-CBL-01	0	2	278	f	none	simulated	system_sim
1207	2026-07-17	WH-BOM-01	ITM-CPU-01	0	3	36	f	none	simulated	system_sim
1208	2026-07-17	WH-BOM-01	ITM-GPU-01	0	1	23	f	none	simulated	system_sim
1209	2026-07-17	WH-BOM-01	ITM-RAM-01	0	7	43	f	none	simulated	system_sim
1210	2026-07-17	WH-BOM-01	ITM-SSD-01	0	2	84	f	none	simulated	system_sim
1211	2026-07-17	WH-BOM-01	ITM-HDD-01	0	1	55	f	none	simulated	system_sim
1212	2026-07-17	WH-BOM-01	ITM-CHG-01	0	2	126	f	none	simulated	system_sim
1213	2026-07-17	WH-BOM-01	ITM-CBL-01	0	8	268	f	none	simulated	system_sim
1214	2026-07-17	WH-DEL-01	ITM-CPU-01	0	0	41	f	none	simulated	system_sim
1215	2026-07-17	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
1216	2026-07-17	WH-DEL-01	ITM-RAM-01	0	1	51	f	none	simulated	system_sim
1217	2026-07-17	WH-DEL-01	ITM-SSD-01	0	3	77	f	none	simulated	system_sim
1218	2026-07-17	WH-DEL-01	ITM-HDD-01	0	1	52	f	none	simulated	system_sim
1219	2026-07-17	WH-DEL-01	ITM-CHG-01	0	7	113	f	none	simulated	system_sim
1220	2026-07-17	WH-DEL-01	ITM-CBL-01	0	6	271	f	none	simulated	system_sim
1221	2026-07-17	WH-CCU-01	ITM-CPU-01	0	2	35	f	none	simulated	system_sim
1222	2026-07-17	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
1223	2026-07-17	WH-CCU-01	ITM-RAM-01	0	4	53	f	none	simulated	system_sim
1224	2026-07-17	WH-CCU-01	ITM-SSD-01	0	2	84	f	none	simulated	system_sim
1225	2026-07-17	WH-CCU-01	ITM-HDD-01	0	1	56	f	none	simulated	system_sim
1226	2026-07-17	WH-CCU-01	ITM-CHG-01	0	6	131	f	none	simulated	system_sim
1227	2026-07-17	WH-CCU-01	ITM-CBL-01	0	9	269	f	none	simulated	system_sim
1228	2026-07-18	WH-BLR-01	ITM-CPU-01	0	2	32	f	none	simulated	system_sim
1229	2026-07-18	WH-BLR-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
1230	2026-07-18	WH-BLR-01	ITM-RAM-01	0	10	35	f	none	simulated	system_sim
1231	2026-07-18	WH-BLR-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
1232	2026-07-18	WH-BLR-01	ITM-HDD-01	0	0	59	f	none	simulated	system_sim
1233	2026-07-18	WH-BLR-01	ITM-CHG-01	0	10	113	f	none	simulated	system_sim
1234	2026-07-18	WH-BLR-01	ITM-CBL-01	0	5	266	f	none	simulated	system_sim
1235	2026-07-18	WH-CHN-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
1236	2026-07-18	WH-CHN-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
1237	2026-07-18	WH-CHN-01	ITM-RAM-01	0	2	43	f	none	simulated	system_sim
1238	2026-07-18	WH-CHN-01	ITM-SSD-01	0	3	81	f	none	simulated	system_sim
1239	2026-07-18	WH-CHN-01	ITM-HDD-01	0	1	54	f	none	simulated	system_sim
1240	2026-07-18	WH-CHN-01	ITM-CHG-01	0	8	122	f	none	simulated	system_sim
1241	2026-07-18	WH-CHN-01	ITM-CBL-01	0	8	270	f	none	simulated	system_sim
1242	2026-07-18	WH-BOM-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
1243	2026-07-18	WH-BOM-01	ITM-GPU-01	0	2	21	f	none	simulated	system_sim
1244	2026-07-18	WH-BOM-01	ITM-RAM-01	0	5	38	f	none	simulated	system_sim
1245	2026-07-18	WH-BOM-01	ITM-SSD-01	0	3	81	f	none	simulated	system_sim
1246	2026-07-18	WH-BOM-01	ITM-HDD-01	0	0	55	f	none	simulated	system_sim
1247	2026-07-18	WH-BOM-01	ITM-CHG-01	0	1	125	f	none	simulated	system_sim
1248	2026-07-18	WH-BOM-01	ITM-CBL-01	0	4	264	f	none	simulated	system_sim
1249	2026-07-18	WH-DEL-01	ITM-CPU-01	0	0	41	f	none	simulated	system_sim
1250	2026-07-18	WH-DEL-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
1251	2026-07-18	WH-DEL-01	ITM-RAM-01	0	5	46	f	none	simulated	system_sim
1252	2026-07-18	WH-DEL-01	ITM-SSD-01	0	1	76	f	none	simulated	system_sim
1253	2026-07-18	WH-DEL-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
1254	2026-07-18	WH-DEL-01	ITM-CHG-01	0	6	107	f	none	simulated	system_sim
1255	2026-07-18	WH-DEL-01	ITM-CBL-01	0	1	270	f	none	simulated	system_sim
1256	2026-07-18	WH-CCU-01	ITM-CPU-01	0	1	34	f	none	simulated	system_sim
1257	2026-07-18	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
1258	2026-07-18	WH-CCU-01	ITM-RAM-01	0	2	51	f	none	simulated	system_sim
1259	2026-07-18	WH-CCU-01	ITM-SSD-01	0	0	84	f	none	simulated	system_sim
1260	2026-07-18	WH-CCU-01	ITM-HDD-01	0	2	54	f	none	simulated	system_sim
1261	2026-07-18	WH-CCU-01	ITM-CHG-01	0	10	121	f	none	simulated	system_sim
1262	2026-07-18	WH-CCU-01	ITM-CBL-01	0	8	261	f	none	simulated	system_sim
1263	2026-07-19	WH-BLR-01	ITM-CPU-01	0	0	32	f	none	simulated	system_sim
1264	2026-07-19	WH-BLR-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
1265	2026-07-19	WH-BLR-01	ITM-RAM-01	75	4	106	f	none	simulated	system_sim
1266	2026-07-19	WH-BLR-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
1267	2026-07-19	WH-BLR-01	ITM-HDD-01	0	0	59	f	none	simulated	system_sim
1268	2026-07-19	WH-BLR-01	ITM-CHG-01	0	7	106	f	none	simulated	system_sim
1269	2026-07-19	WH-BLR-01	ITM-CBL-01	0	3	263	f	none	simulated	system_sim
1270	2026-07-19	WH-CHN-01	ITM-CPU-01	0	1	38	f	none	simulated	system_sim
1271	2026-07-19	WH-CHN-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
1272	2026-07-19	WH-CHN-01	ITM-RAM-01	0	9	34	f	none	simulated	system_sim
1273	2026-07-19	WH-CHN-01	ITM-SSD-01	0	2	79	f	none	simulated	system_sim
1274	2026-07-19	WH-CHN-01	ITM-HDD-01	0	2	52	f	none	simulated	system_sim
1275	2026-07-19	WH-CHN-01	ITM-CHG-01	0	7	115	f	none	simulated	system_sim
1276	2026-07-19	WH-CHN-01	ITM-CBL-01	0	4	266	f	none	simulated	system_sim
1277	2026-07-19	WH-BOM-01	ITM-CPU-01	0	2	34	f	none	simulated	system_sim
1278	2026-07-19	WH-BOM-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
1279	2026-07-19	WH-BOM-01	ITM-RAM-01	0	4	34	f	none	simulated	system_sim
1280	2026-07-19	WH-BOM-01	ITM-SSD-01	0	3	78	f	none	simulated	system_sim
1281	2026-07-19	WH-BOM-01	ITM-HDD-01	0	1	54	f	none	simulated	system_sim
1282	2026-07-19	WH-BOM-01	ITM-CHG-01	0	1	124	f	none	simulated	system_sim
1283	2026-07-19	WH-BOM-01	ITM-CBL-01	0	3	261	f	none	simulated	system_sim
1284	2026-07-19	WH-DEL-01	ITM-CPU-01	0	3	38	f	none	simulated	system_sim
1285	2026-07-19	WH-DEL-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
1286	2026-07-19	WH-DEL-01	ITM-RAM-01	0	9	37	f	none	simulated	system_sim
1287	2026-07-19	WH-DEL-01	ITM-SSD-01	0	0	76	f	none	simulated	system_sim
1288	2026-07-19	WH-DEL-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
1289	2026-07-19	WH-DEL-01	ITM-CHG-01	0	5	102	f	none	simulated	system_sim
1290	2026-07-19	WH-DEL-01	ITM-CBL-01	0	1	269	f	none	simulated	system_sim
1291	2026-07-19	WH-CCU-01	ITM-CPU-01	0	2	32	f	none	simulated	system_sim
1292	2026-07-19	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
1293	2026-07-19	WH-CCU-01	ITM-RAM-01	0	3	48	f	none	simulated	system_sim
1294	2026-07-19	WH-CCU-01	ITM-SSD-01	0	2	82	f	none	simulated	system_sim
1295	2026-07-19	WH-CCU-01	ITM-HDD-01	0	3	51	f	none	simulated	system_sim
1296	2026-07-19	WH-CCU-01	ITM-CHG-01	0	8	113	f	none	simulated	system_sim
1297	2026-07-19	WH-CCU-01	ITM-CBL-01	0	1	260	f	none	simulated	system_sim
1298	2026-07-20	WH-BLR-01	ITM-CPU-01	0	0	32	f	none	simulated	system_sim
1299	2026-07-20	WH-BLR-01	ITM-GPU-01	0	2	26	f	none	simulated	system_sim
1300	2026-07-20	WH-BLR-01	ITM-RAM-01	0	4	102	f	none	simulated	system_sim
1301	2026-07-20	WH-BLR-01	ITM-SSD-01	0	1	82	f	none	simulated	system_sim
1302	2026-07-20	WH-BLR-01	ITM-HDD-01	0	1	58	f	none	simulated	system_sim
1303	2026-07-20	WH-BLR-01	ITM-CHG-01	0	7	99	f	none	simulated	system_sim
1304	2026-07-20	WH-BLR-01	ITM-CBL-01	0	5	258	f	none	simulated	system_sim
1305	2026-07-20	WH-CHN-01	ITM-CPU-01	0	2	36	f	none	simulated	system_sim
1306	2026-07-20	WH-CHN-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
1307	2026-07-20	WH-CHN-01	ITM-RAM-01	75	8	101	f	none	simulated	system_sim
1308	2026-07-20	WH-CHN-01	ITM-SSD-01	0	1	78	f	none	simulated	system_sim
1309	2026-07-20	WH-CHN-01	ITM-HDD-01	0	2	50	f	none	simulated	system_sim
1310	2026-07-20	WH-CHN-01	ITM-CHG-01	0	7	108	f	none	simulated	system_sim
1311	2026-07-20	WH-CHN-01	ITM-CBL-01	0	5	261	f	none	simulated	system_sim
1312	2026-07-20	WH-BOM-01	ITM-CPU-01	0	1	33	f	none	simulated	system_sim
1313	2026-07-20	WH-BOM-01	ITM-GPU-01	0	1	20	f	none	simulated	system_sim
1314	2026-07-20	WH-BOM-01	ITM-RAM-01	75	1	108	f	none	simulated	system_sim
1315	2026-07-20	WH-BOM-01	ITM-SSD-01	0	2	76	f	none	simulated	system_sim
1316	2026-07-20	WH-BOM-01	ITM-HDD-01	0	2	52	f	none	simulated	system_sim
1317	2026-07-20	WH-BOM-01	ITM-CHG-01	0	5	119	f	none	simulated	system_sim
1318	2026-07-20	WH-BOM-01	ITM-CBL-01	0	10	251	f	none	simulated	system_sim
1319	2026-07-20	WH-DEL-01	ITM-CPU-01	0	0	38	f	none	simulated	system_sim
1320	2026-07-20	WH-DEL-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
1321	2026-07-20	WH-DEL-01	ITM-RAM-01	75	9	103	f	none	simulated	system_sim
1322	2026-07-20	WH-DEL-01	ITM-SSD-01	0	1	75	f	none	simulated	system_sim
1323	2026-07-20	WH-DEL-01	ITM-HDD-01	0	3	49	f	none	simulated	system_sim
1324	2026-07-20	WH-DEL-01	ITM-CHG-01	0	6	96	f	none	simulated	system_sim
1325	2026-07-20	WH-DEL-01	ITM-CBL-01	0	4	265	f	none	simulated	system_sim
1326	2026-07-20	WH-CCU-01	ITM-CPU-01	0	1	31	f	none	simulated	system_sim
1327	2026-07-20	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
1328	2026-07-20	WH-CCU-01	ITM-RAM-01	0	1	47	f	none	simulated	system_sim
1329	2026-07-20	WH-CCU-01	ITM-SSD-01	0	1	81	f	none	simulated	system_sim
1330	2026-07-20	WH-CCU-01	ITM-HDD-01	0	1	50	f	none	simulated	system_sim
1331	2026-07-20	WH-CCU-01	ITM-CHG-01	0	4	109	f	none	simulated	system_sim
1332	2026-07-20	WH-CCU-01	ITM-CBL-01	0	9	251	f	none	simulated	system_sim
1333	2026-07-21	WH-BLR-01	ITM-CPU-01	0	0	32	f	none	simulated	system_sim
1334	2026-07-21	WH-BLR-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
1335	2026-07-21	WH-BLR-01	ITM-RAM-01	0	1	101	f	none	simulated	system_sim
1336	2026-07-21	WH-BLR-01	ITM-SSD-01	0	3	79	f	none	simulated	system_sim
1337	2026-07-21	WH-BLR-01	ITM-HDD-01	0	1	57	f	none	simulated	system_sim
1338	2026-07-21	WH-BLR-01	ITM-CHG-01	0	5	94	f	none	simulated	system_sim
1339	2026-07-21	WH-BLR-01	ITM-CBL-01	0	3	255	f	none	simulated	system_sim
1340	2026-07-21	WH-CHN-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
1341	2026-07-21	WH-CHN-01	ITM-GPU-01	0	1	24	f	none	simulated	system_sim
1342	2026-07-21	WH-CHN-01	ITM-RAM-01	0	2	99	f	none	simulated	system_sim
1343	2026-07-21	WH-CHN-01	ITM-SSD-01	0	2	76	f	none	simulated	system_sim
1344	2026-07-21	WH-CHN-01	ITM-HDD-01	0	1	49	f	none	simulated	system_sim
1345	2026-07-21	WH-CHN-01	ITM-CHG-01	0	5	103	f	none	simulated	system_sim
1346	2026-07-21	WH-CHN-01	ITM-CBL-01	0	7	254	f	none	simulated	system_sim
1347	2026-07-21	WH-BOM-01	ITM-CPU-01	0	0	33	f	none	simulated	system_sim
1348	2026-07-21	WH-BOM-01	ITM-GPU-01	0	2	18	f	none	simulated	system_sim
1349	2026-07-21	WH-BOM-01	ITM-RAM-01	0	2	106	f	none	simulated	system_sim
1350	2026-07-21	WH-BOM-01	ITM-SSD-01	0	2	74	f	none	simulated	system_sim
1351	2026-07-21	WH-BOM-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
1352	2026-07-21	WH-BOM-01	ITM-CHG-01	0	7	112	f	none	simulated	system_sim
1353	2026-07-21	WH-BOM-01	ITM-CBL-01	0	9	242	f	none	simulated	system_sim
1354	2026-07-21	WH-DEL-01	ITM-CPU-01	0	1	37	f	none	simulated	system_sim
1355	2026-07-21	WH-DEL-01	ITM-GPU-01	0	1	26	f	none	simulated	system_sim
1356	2026-07-21	WH-DEL-01	ITM-RAM-01	0	6	97	f	none	simulated	system_sim
1357	2026-07-21	WH-DEL-01	ITM-SSD-01	0	2	73	f	none	simulated	system_sim
1358	2026-07-21	WH-DEL-01	ITM-HDD-01	0	0	49	f	none	simulated	system_sim
1359	2026-07-21	WH-DEL-01	ITM-CHG-01	0	3	93	f	none	simulated	system_sim
1360	2026-07-21	WH-DEL-01	ITM-CBL-01	0	1	264	f	none	simulated	system_sim
1361	2026-07-21	WH-CCU-01	ITM-CPU-01	0	2	29	f	none	simulated	system_sim
1362	2026-07-21	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
1363	2026-07-21	WH-CCU-01	ITM-RAM-01	0	10	37	f	none	simulated	system_sim
1364	2026-07-21	WH-CCU-01	ITM-SSD-01	0	3	78	f	none	simulated	system_sim
1365	2026-07-21	WH-CCU-01	ITM-HDD-01	0	1	49	f	none	simulated	system_sim
1366	2026-07-21	WH-CCU-01	ITM-CHG-01	0	9	100	f	none	simulated	system_sim
1367	2026-07-21	WH-CCU-01	ITM-CBL-01	0	1	250	f	none	simulated	system_sim
1368	2026-07-22	WH-BLR-01	ITM-CPU-01	0	0	32	f	none	simulated	system_sim
1369	2026-07-22	WH-BLR-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
1370	2026-07-22	WH-BLR-01	ITM-RAM-01	0	5	96	f	none	simulated	system_sim
1371	2026-07-22	WH-BLR-01	ITM-SSD-01	0	3	76	f	none	simulated	system_sim
1372	2026-07-22	WH-BLR-01	ITM-HDD-01	0	0	57	f	none	simulated	system_sim
1373	2026-07-22	WH-BLR-01	ITM-CHG-01	0	3	91	f	none	simulated	system_sim
1374	2026-07-22	WH-BLR-01	ITM-CBL-01	0	1	254	f	none	simulated	system_sim
1375	2026-07-22	WH-CHN-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
1376	2026-07-22	WH-CHN-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
1377	2026-07-22	WH-CHN-01	ITM-RAM-01	0	5	94	f	none	simulated	system_sim
1378	2026-07-22	WH-CHN-01	ITM-SSD-01	0	1	75	f	none	simulated	system_sim
1379	2026-07-22	WH-CHN-01	ITM-HDD-01	0	2	47	f	none	simulated	system_sim
1380	2026-07-22	WH-CHN-01	ITM-CHG-01	0	8	95	f	none	simulated	system_sim
1381	2026-07-22	WH-CHN-01	ITM-CBL-01	0	9	245	f	none	simulated	system_sim
1382	2026-07-22	WH-BOM-01	ITM-CPU-01	0	2	31	f	none	simulated	system_sim
1383	2026-07-22	WH-BOM-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
1384	2026-07-22	WH-BOM-01	ITM-RAM-01	0	4	102	f	none	simulated	system_sim
1385	2026-07-22	WH-BOM-01	ITM-SSD-01	0	0	74	f	none	simulated	system_sim
1386	2026-07-22	WH-BOM-01	ITM-HDD-01	0	1	51	f	none	simulated	system_sim
1387	2026-07-22	WH-BOM-01	ITM-CHG-01	0	7	105	f	none	simulated	system_sim
1388	2026-07-22	WH-BOM-01	ITM-CBL-01	0	4	238	f	none	simulated	system_sim
1389	2026-07-22	WH-DEL-01	ITM-CPU-01	0	3	34	f	none	simulated	system_sim
1390	2026-07-22	WH-DEL-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
1391	2026-07-22	WH-DEL-01	ITM-RAM-01	0	3	94	f	none	simulated	system_sim
1392	2026-07-22	WH-DEL-01	ITM-SSD-01	0	1	72	f	none	simulated	system_sim
1393	2026-07-22	WH-DEL-01	ITM-HDD-01	0	3	46	f	none	simulated	system_sim
1394	2026-07-22	WH-DEL-01	ITM-CHG-01	0	1	92	f	none	simulated	system_sim
1395	2026-07-22	WH-DEL-01	ITM-CBL-01	0	10	254	f	none	simulated	system_sim
1396	2026-07-22	WH-CCU-01	ITM-CPU-01	0	3	26	f	none	simulated	system_sim
1397	2026-07-22	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
1398	2026-07-22	WH-CCU-01	ITM-RAM-01	75	9	103	f	none	simulated	system_sim
1399	2026-07-22	WH-CCU-01	ITM-SSD-01	0	2	76	f	none	simulated	system_sim
1400	2026-07-22	WH-CCU-01	ITM-HDD-01	0	2	47	f	none	simulated	system_sim
1401	2026-07-22	WH-CCU-01	ITM-CHG-01	0	10	90	f	none	simulated	system_sim
1402	2026-07-22	WH-CCU-01	ITM-CBL-01	0	3	247	f	none	simulated	system_sim
1403	2026-07-23	WH-BLR-01	ITM-CPU-01	0	0	32	f	none	simulated	system_sim
1404	2026-07-23	WH-BLR-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
1405	2026-07-23	WH-BLR-01	ITM-RAM-01	0	5	91	f	none	simulated	system_sim
1406	2026-07-23	WH-BLR-01	ITM-SSD-01	0	2	74	f	none	simulated	system_sim
1407	2026-07-23	WH-BLR-01	ITM-HDD-01	0	0	57	f	none	simulated	system_sim
1408	2026-07-23	WH-BLR-01	ITM-CHG-01	0	3	88	f	none	simulated	system_sim
1409	2026-07-23	WH-BLR-01	ITM-CBL-01	0	7	247	f	none	simulated	system_sim
1410	2026-07-23	WH-CHN-01	ITM-CPU-01	0	0	36	f	none	simulated	system_sim
1411	2026-07-23	WH-CHN-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
1412	2026-07-23	WH-CHN-01	ITM-RAM-01	0	6	88	f	none	simulated	system_sim
1413	2026-07-23	WH-CHN-01	ITM-SSD-01	0	1	74	f	none	simulated	system_sim
1414	2026-07-23	WH-CHN-01	ITM-HDD-01	0	0	47	f	none	simulated	system_sim
1415	2026-07-23	WH-CHN-01	ITM-CHG-01	0	10	85	f	none	simulated	system_sim
1416	2026-07-23	WH-CHN-01	ITM-CBL-01	0	6	239	f	none	simulated	system_sim
1417	2026-07-23	WH-BOM-01	ITM-CPU-01	0	1	30	f	none	simulated	system_sim
1418	2026-07-23	WH-BOM-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
1419	2026-07-23	WH-BOM-01	ITM-RAM-01	0	1	101	f	none	simulated	system_sim
1420	2026-07-23	WH-BOM-01	ITM-SSD-01	0	3	71	f	none	simulated	system_sim
1421	2026-07-23	WH-BOM-01	ITM-HDD-01	0	0	51	f	none	simulated	system_sim
1422	2026-07-23	WH-BOM-01	ITM-CHG-01	0	4	101	f	none	simulated	system_sim
1423	2026-07-23	WH-BOM-01	ITM-CBL-01	0	9	229	f	none	simulated	system_sim
1424	2026-07-23	WH-DEL-01	ITM-CPU-01	0	1	33	f	none	simulated	system_sim
1425	2026-07-23	WH-DEL-01	ITM-GPU-01	0	2	24	f	none	simulated	system_sim
1426	2026-07-23	WH-DEL-01	ITM-RAM-01	0	2	92	f	none	simulated	system_sim
1427	2026-07-23	WH-DEL-01	ITM-SSD-01	0	3	69	f	none	simulated	system_sim
1428	2026-07-23	WH-DEL-01	ITM-HDD-01	0	3	43	f	none	simulated	system_sim
1429	2026-07-23	WH-DEL-01	ITM-CHG-01	0	2	90	f	none	simulated	system_sim
1430	2026-07-23	WH-DEL-01	ITM-CBL-01	0	3	251	f	none	simulated	system_sim
1431	2026-07-23	WH-CCU-01	ITM-CPU-01	0	2	24	f	none	simulated	system_sim
1432	2026-07-23	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
1433	2026-07-23	WH-CCU-01	ITM-RAM-01	0	7	96	f	none	simulated	system_sim
1434	2026-07-23	WH-CCU-01	ITM-SSD-01	0	0	76	f	none	simulated	system_sim
1435	2026-07-23	WH-CCU-01	ITM-HDD-01	0	3	44	f	none	simulated	system_sim
1436	2026-07-23	WH-CCU-01	ITM-CHG-01	0	2	88	f	none	simulated	system_sim
1437	2026-07-23	WH-CCU-01	ITM-CBL-01	0	7	240	f	none	simulated	system_sim
1438	2026-07-24	WH-BLR-01	ITM-CPU-01	0	3	29	f	none	simulated	system_sim
1439	2026-07-24	WH-BLR-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
1440	2026-07-24	WH-BLR-01	ITM-RAM-01	0	2	89	f	none	simulated	system_sim
1441	2026-07-24	WH-BLR-01	ITM-SSD-01	0	0	74	f	none	simulated	system_sim
1442	2026-07-24	WH-BLR-01	ITM-HDD-01	0	0	57	f	none	simulated	system_sim
1443	2026-07-24	WH-BLR-01	ITM-CHG-01	0	8	80	f	none	simulated	system_sim
1444	2026-07-24	WH-BLR-01	ITM-CBL-01	0	2	245	f	none	simulated	system_sim
1445	2026-07-24	WH-CHN-01	ITM-CPU-01	0	1	35	f	none	simulated	system_sim
1446	2026-07-24	WH-CHN-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
1447	2026-07-24	WH-CHN-01	ITM-RAM-01	0	3	85	f	none	simulated	system_sim
1448	2026-07-24	WH-CHN-01	ITM-SSD-01	0	0	74	f	none	simulated	system_sim
1449	2026-07-24	WH-CHN-01	ITM-HDD-01	0	2	45	f	none	simulated	system_sim
1450	2026-07-24	WH-CHN-01	ITM-CHG-01	0	3	82	f	none	simulated	system_sim
1451	2026-07-24	WH-CHN-01	ITM-CBL-01	0	4	235	f	none	simulated	system_sim
1452	2026-07-24	WH-BOM-01	ITM-CPU-01	0	3	27	f	none	simulated	system_sim
1453	2026-07-24	WH-BOM-01	ITM-GPU-01	0	1	16	f	none	simulated	system_sim
1454	2026-07-24	WH-BOM-01	ITM-RAM-01	0	8	93	f	none	simulated	system_sim
1455	2026-07-24	WH-BOM-01	ITM-SSD-01	0	0	71	f	none	simulated	system_sim
1456	2026-07-24	WH-BOM-01	ITM-HDD-01	0	1	50	f	none	simulated	system_sim
1457	2026-07-24	WH-BOM-01	ITM-CHG-01	0	6	95	f	none	simulated	system_sim
1458	2026-07-24	WH-BOM-01	ITM-CBL-01	0	2	227	f	none	simulated	system_sim
1459	2026-07-24	WH-DEL-01	ITM-CPU-01	0	1	32	f	none	simulated	system_sim
1460	2026-07-24	WH-DEL-01	ITM-GPU-01	0	1	23	f	none	simulated	system_sim
1461	2026-07-24	WH-DEL-01	ITM-RAM-01	0	7	85	f	none	simulated	system_sim
1462	2026-07-24	WH-DEL-01	ITM-SSD-01	0	3	66	f	none	simulated	system_sim
1463	2026-07-24	WH-DEL-01	ITM-HDD-01	0	0	43	f	none	simulated	system_sim
1464	2026-07-24	WH-DEL-01	ITM-CHG-01	0	9	81	f	none	simulated	system_sim
1465	2026-07-24	WH-DEL-01	ITM-CBL-01	0	2	249	f	none	simulated	system_sim
1466	2026-07-24	WH-CCU-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
1467	2026-07-24	WH-CCU-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
1468	2026-07-24	WH-CCU-01	ITM-RAM-01	0	7	89	f	none	simulated	system_sim
1469	2026-07-24	WH-CCU-01	ITM-SSD-01	0	2	74	f	none	simulated	system_sim
1470	2026-07-24	WH-CCU-01	ITM-HDD-01	0	0	44	f	none	simulated	system_sim
1471	2026-07-24	WH-CCU-01	ITM-CHG-01	0	2	86	f	none	simulated	system_sim
1472	2026-07-24	WH-CCU-01	ITM-CBL-01	0	8	232	f	none	simulated	system_sim
1473	2026-07-25	WH-BLR-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
1474	2026-07-25	WH-BLR-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
1475	2026-07-25	WH-BLR-01	ITM-RAM-01	0	7	82	f	none	simulated	system_sim
1476	2026-07-25	WH-BLR-01	ITM-SSD-01	0	1	73	f	none	simulated	system_sim
1477	2026-07-25	WH-BLR-01	ITM-HDD-01	0	0	57	f	none	simulated	system_sim
1478	2026-07-25	WH-BLR-01	ITM-CHG-01	0	10	70	f	none	simulated	system_sim
1479	2026-07-25	WH-BLR-01	ITM-CBL-01	0	7	238	f	none	simulated	system_sim
1480	2026-07-25	WH-CHN-01	ITM-CPU-01	0	0	20	t	shrinkage	simulated	system_sim
1481	2026-07-25	WH-CHN-01	ITM-GPU-01	0	1	23	f	none	simulated	system_sim
1482	2026-07-25	WH-CHN-01	ITM-RAM-01	0	10	75	f	none	simulated	system_sim
1483	2026-07-25	WH-CHN-01	ITM-SSD-01	0	2	72	f	none	simulated	system_sim
1484	2026-07-25	WH-CHN-01	ITM-HDD-01	0	0	45	f	none	simulated	system_sim
1485	2026-07-25	WH-CHN-01	ITM-CHG-01	0	9	73	f	none	simulated	system_sim
1486	2026-07-25	WH-CHN-01	ITM-CBL-01	0	4	231	f	none	simulated	system_sim
1487	2026-07-25	WH-BOM-01	ITM-CPU-01	0	1	26	f	none	simulated	system_sim
1488	2026-07-25	WH-BOM-01	ITM-GPU-01	0	2	14	f	none	simulated	system_sim
1489	2026-07-25	WH-BOM-01	ITM-RAM-01	0	4	89	f	none	simulated	system_sim
1490	2026-07-25	WH-BOM-01	ITM-SSD-01	0	1	70	f	none	simulated	system_sim
1491	2026-07-25	WH-BOM-01	ITM-HDD-01	0	0	50	f	none	simulated	system_sim
1492	2026-07-25	WH-BOM-01	ITM-CHG-01	0	7	88	f	none	simulated	system_sim
1493	2026-07-25	WH-BOM-01	ITM-CBL-01	0	8	219	f	none	simulated	system_sim
1494	2026-07-25	WH-DEL-01	ITM-CPU-01	0	3	29	f	none	simulated	system_sim
1495	2026-07-25	WH-DEL-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
1496	2026-07-25	WH-DEL-01	ITM-RAM-01	0	10	75	f	none	simulated	system_sim
1497	2026-07-25	WH-DEL-01	ITM-SSD-01	0	3	63	f	none	simulated	system_sim
1498	2026-07-25	WH-DEL-01	ITM-HDD-01	0	2	41	f	none	simulated	system_sim
1499	2026-07-25	WH-DEL-01	ITM-CHG-01	0	3	78	f	none	simulated	system_sim
1500	2026-07-25	WH-DEL-01	ITM-CBL-01	0	1	248	f	none	simulated	system_sim
1501	2026-07-25	WH-CCU-01	ITM-CPU-01	0	1	23	f	none	simulated	system_sim
1502	2026-07-25	WH-CCU-01	ITM-GPU-01	0	1	28	f	none	simulated	system_sim
1503	2026-07-25	WH-CCU-01	ITM-RAM-01	0	4	85	f	none	simulated	system_sim
1504	2026-07-25	WH-CCU-01	ITM-SSD-01	0	3	71	f	none	simulated	system_sim
1505	2026-07-25	WH-CCU-01	ITM-HDD-01	0	3	41	f	none	simulated	system_sim
1506	2026-07-25	WH-CCU-01	ITM-CHG-01	0	6	80	f	none	simulated	system_sim
1507	2026-07-25	WH-CCU-01	ITM-CBL-01	0	1	231	f	none	simulated	system_sim
1508	2026-07-26	WH-BLR-01	ITM-CPU-01	0	2	27	f	none	simulated	system_sim
1509	2026-07-26	WH-BLR-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
1510	2026-07-26	WH-BLR-01	ITM-RAM-01	0	9	73	f	none	simulated	system_sim
1511	2026-07-26	WH-BLR-01	ITM-SSD-01	0	1	72	f	none	simulated	system_sim
1512	2026-07-26	WH-BLR-01	ITM-HDD-01	0	2	55	f	none	simulated	system_sim
1513	2026-07-26	WH-BLR-01	ITM-CHG-01	150	6	214	f	none	simulated	system_sim
1514	2026-07-26	WH-BLR-01	ITM-CBL-01	0	9	229	f	none	simulated	system_sim
1515	2026-07-26	WH-CHN-01	ITM-CPU-01	45	0	65	f	none	simulated	system_sim
1516	2026-07-26	WH-CHN-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
1517	2026-07-26	WH-CHN-01	ITM-RAM-01	0	10	65	f	none	simulated	system_sim
1518	2026-07-26	WH-CHN-01	ITM-SSD-01	0	0	72	f	none	simulated	system_sim
1519	2026-07-26	WH-CHN-01	ITM-HDD-01	0	3	42	f	none	simulated	system_sim
1520	2026-07-26	WH-CHN-01	ITM-CHG-01	150	4	219	f	none	simulated	system_sim
1521	2026-07-26	WH-CHN-01	ITM-CBL-01	0	5	226	f	none	simulated	system_sim
1522	2026-07-26	WH-BOM-01	ITM-CPU-01	0	0	26	f	none	simulated	system_sim
1523	2026-07-26	WH-BOM-01	ITM-GPU-01	30	2	42	f	none	simulated	system_sim
1524	2026-07-26	WH-BOM-01	ITM-RAM-01	0	9	80	f	none	simulated	system_sim
1525	2026-07-26	WH-BOM-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
1526	2026-07-26	WH-BOM-01	ITM-HDD-01	0	0	50	f	none	simulated	system_sim
1527	2026-07-26	WH-BOM-01	ITM-CHG-01	0	9	79	f	none	simulated	system_sim
1528	2026-07-26	WH-BOM-01	ITM-CBL-01	0	1	218	f	none	simulated	system_sim
1529	2026-07-26	WH-DEL-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
1530	2026-07-26	WH-DEL-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
1531	2026-07-26	WH-DEL-01	ITM-RAM-01	0	7	68	f	none	simulated	system_sim
1532	2026-07-26	WH-DEL-01	ITM-SSD-01	0	2	61	f	none	simulated	system_sim
1533	2026-07-26	WH-DEL-01	ITM-HDD-01	0	3	38	f	none	simulated	system_sim
1534	2026-07-26	WH-DEL-01	ITM-CHG-01	0	7	71	f	none	simulated	system_sim
1535	2026-07-26	WH-DEL-01	ITM-CBL-01	0	8	240	f	none	simulated	system_sim
1536	2026-07-26	WH-CCU-01	ITM-CPU-01	0	3	20	f	none	simulated	system_sim
1537	2026-07-26	WH-CCU-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
1538	2026-07-26	WH-CCU-01	ITM-RAM-01	0	7	78	f	none	simulated	system_sim
1539	2026-07-26	WH-CCU-01	ITM-SSD-01	0	1	70	f	none	simulated	system_sim
1540	2026-07-26	WH-CCU-01	ITM-HDD-01	0	0	41	f	none	simulated	system_sim
1541	2026-07-26	WH-CCU-01	ITM-CHG-01	0	8	72	f	none	simulated	system_sim
1542	2026-07-26	WH-CCU-01	ITM-CBL-01	0	10	221	f	none	simulated	system_sim
1543	2026-07-27	WH-BLR-01	ITM-CPU-01	0	3	24	f	none	simulated	system_sim
1544	2026-07-27	WH-BLR-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
1545	2026-07-27	WH-BLR-01	ITM-RAM-01	0	9	64	f	none	simulated	system_sim
1546	2026-07-27	WH-BLR-01	ITM-SSD-01	0	0	72	f	none	simulated	system_sim
1547	2026-07-27	WH-BLR-01	ITM-HDD-01	0	2	53	f	none	simulated	system_sim
1548	2026-07-27	WH-BLR-01	ITM-CHG-01	0	6	208	f	none	simulated	system_sim
1549	2026-07-27	WH-BLR-01	ITM-CBL-01	0	7	222	f	none	simulated	system_sim
1550	2026-07-27	WH-CHN-01	ITM-CPU-01	0	0	65	f	none	simulated	system_sim
1551	2026-07-27	WH-CHN-01	ITM-GPU-01	0	2	21	f	none	simulated	system_sim
1552	2026-07-27	WH-CHN-01	ITM-RAM-01	0	8	57	f	none	simulated	system_sim
1553	2026-07-27	WH-CHN-01	ITM-SSD-01	0	3	69	f	none	simulated	system_sim
1554	2026-07-27	WH-CHN-01	ITM-HDD-01	0	0	42	f	none	simulated	system_sim
1555	2026-07-27	WH-CHN-01	ITM-CHG-01	0	1	218	f	none	simulated	system_sim
1556	2026-07-27	WH-CHN-01	ITM-CBL-01	0	8	218	f	none	simulated	system_sim
1557	2026-07-27	WH-BOM-01	ITM-CPU-01	0	1	25	f	none	simulated	system_sim
1558	2026-07-27	WH-BOM-01	ITM-GPU-01	0	1	41	f	none	simulated	system_sim
1559	2026-07-27	WH-BOM-01	ITM-RAM-01	0	5	75	f	none	simulated	system_sim
1560	2026-07-27	WH-BOM-01	ITM-SSD-01	0	2	68	f	none	simulated	system_sim
1561	2026-07-27	WH-BOM-01	ITM-HDD-01	0	2	48	f	none	simulated	system_sim
1562	2026-07-27	WH-BOM-01	ITM-CHG-01	0	10	69	f	none	simulated	system_sim
1563	2026-07-27	WH-BOM-01	ITM-CBL-01	0	10	208	f	none	simulated	system_sim
1564	2026-07-27	WH-DEL-01	ITM-CPU-01	0	1	28	f	none	simulated	system_sim
1565	2026-07-27	WH-DEL-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
1566	2026-07-27	WH-DEL-01	ITM-RAM-01	0	5	63	f	none	simulated	system_sim
1567	2026-07-27	WH-DEL-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
1568	2026-07-27	WH-DEL-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
1569	2026-07-27	WH-DEL-01	ITM-CHG-01	150	1	220	f	none	simulated	system_sim
1570	2026-07-27	WH-DEL-01	ITM-CBL-01	0	4	236	f	none	simulated	system_sim
1571	2026-07-27	WH-CCU-01	ITM-CPU-01	45	3	62	f	none	simulated	system_sim
1572	2026-07-27	WH-CCU-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
1573	2026-07-27	WH-CCU-01	ITM-RAM-01	0	2	76	f	none	simulated	system_sim
1574	2026-07-27	WH-CCU-01	ITM-SSD-01	0	2	68	f	none	simulated	system_sim
1575	2026-07-27	WH-CCU-01	ITM-HDD-01	0	3	38	f	none	simulated	system_sim
1576	2026-07-27	WH-CCU-01	ITM-CHG-01	150	9	213	f	none	simulated	system_sim
1577	2026-07-27	WH-CCU-01	ITM-CBL-01	0	2	219	f	none	simulated	system_sim
1578	2026-07-28	WH-BLR-01	ITM-CPU-01	0	1	23	f	none	simulated	system_sim
1579	2026-07-28	WH-BLR-01	ITM-GPU-01	0	2	21	f	none	simulated	system_sim
1580	2026-07-28	WH-BLR-01	ITM-RAM-01	0	1	63	f	none	simulated	system_sim
1581	2026-07-28	WH-BLR-01	ITM-SSD-01	0	2	70	f	none	simulated	system_sim
1582	2026-07-28	WH-BLR-01	ITM-HDD-01	0	0	53	f	none	simulated	system_sim
1583	2026-07-28	WH-BLR-01	ITM-CHG-01	0	6	202	f	none	simulated	system_sim
1584	2026-07-28	WH-BLR-01	ITM-CBL-01	0	10	212	f	none	simulated	system_sim
1585	2026-07-28	WH-CHN-01	ITM-CPU-01	0	2	63	f	none	simulated	system_sim
1586	2026-07-28	WH-CHN-01	ITM-GPU-01	0	1	20	f	none	simulated	system_sim
1587	2026-07-28	WH-CHN-01	ITM-RAM-01	0	8	49	f	none	simulated	system_sim
1588	2026-07-28	WH-CHN-01	ITM-SSD-01	0	2	67	f	none	simulated	system_sim
1589	2026-07-28	WH-CHN-01	ITM-HDD-01	0	0	42	f	none	simulated	system_sim
1590	2026-07-28	WH-CHN-01	ITM-CHG-01	0	8	210	f	none	simulated	system_sim
1591	2026-07-28	WH-CHN-01	ITM-CBL-01	0	10	208	f	none	simulated	system_sim
1592	2026-07-28	WH-BOM-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
1593	2026-07-28	WH-BOM-01	ITM-GPU-01	0	2	39	f	none	simulated	system_sim
1594	2026-07-28	WH-BOM-01	ITM-RAM-01	0	1	74	f	none	simulated	system_sim
1595	2026-07-28	WH-BOM-01	ITM-SSD-01	0	0	68	f	none	simulated	system_sim
1596	2026-07-28	WH-BOM-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
1597	2026-07-28	WH-BOM-01	ITM-CHG-01	150	1	218	f	none	simulated	system_sim
1598	2026-07-28	WH-BOM-01	ITM-CBL-01	0	2	206	f	none	simulated	system_sim
1599	2026-07-28	WH-DEL-01	ITM-CPU-01	0	2	26	f	none	simulated	system_sim
1600	2026-07-28	WH-DEL-01	ITM-GPU-01	0	1	22	f	none	simulated	system_sim
1601	2026-07-28	WH-DEL-01	ITM-RAM-01	0	2	61	f	none	simulated	system_sim
1602	2026-07-28	WH-DEL-01	ITM-SSD-01	0	3	58	f	none	simulated	system_sim
1603	2026-07-28	WH-DEL-01	ITM-HDD-01	0	2	36	f	none	simulated	system_sim
1604	2026-07-28	WH-DEL-01	ITM-CHG-01	0	6	214	f	none	simulated	system_sim
1605	2026-07-28	WH-DEL-01	ITM-CBL-01	0	6	230	f	none	simulated	system_sim
1606	2026-07-28	WH-CCU-01	ITM-CPU-01	0	1	61	f	none	simulated	system_sim
1607	2026-07-28	WH-CCU-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
1608	2026-07-28	WH-CCU-01	ITM-RAM-01	0	3	73	f	none	simulated	system_sim
1609	2026-07-28	WH-CCU-01	ITM-SSD-01	0	2	66	f	none	simulated	system_sim
1610	2026-07-28	WH-CCU-01	ITM-HDD-01	0	2	36	f	none	simulated	system_sim
1611	2026-07-28	WH-CCU-01	ITM-CHG-01	0	7	206	f	none	simulated	system_sim
1612	2026-07-28	WH-CCU-01	ITM-CBL-01	0	3	216	f	none	simulated	system_sim
1613	2026-07-29	WH-BLR-01	ITM-CPU-01	0	1	22	f	none	simulated	system_sim
1614	2026-07-29	WH-BLR-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
1615	2026-07-29	WH-BLR-01	ITM-RAM-01	0	8	55	f	none	simulated	system_sim
1616	2026-07-29	WH-BLR-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
1617	2026-07-29	WH-BLR-01	ITM-HDD-01	0	0	53	f	none	simulated	system_sim
1618	2026-07-29	WH-BLR-01	ITM-CHG-01	0	8	194	f	none	simulated	system_sim
1619	2026-07-29	WH-BLR-01	ITM-CBL-01	0	6	206	f	none	simulated	system_sim
1620	2026-07-29	WH-CHN-01	ITM-CPU-01	0	2	61	f	none	simulated	system_sim
1621	2026-07-29	WH-CHN-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
1622	2026-07-29	WH-CHN-01	ITM-RAM-01	0	1	48	f	none	simulated	system_sim
1623	2026-07-29	WH-CHN-01	ITM-SSD-01	0	0	67	f	none	simulated	system_sim
1624	2026-07-29	WH-CHN-01	ITM-HDD-01	0	0	42	f	none	simulated	system_sim
1625	2026-07-29	WH-CHN-01	ITM-CHG-01	0	6	204	f	none	simulated	system_sim
1626	2026-07-29	WH-CHN-01	ITM-CBL-01	0	2	206	f	none	simulated	system_sim
1627	2026-07-29	WH-BOM-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
1628	2026-07-29	WH-BOM-01	ITM-GPU-01	0	0	39	f	none	simulated	system_sim
1629	2026-07-29	WH-BOM-01	ITM-RAM-01	0	2	72	f	none	simulated	system_sim
1630	2026-07-29	WH-BOM-01	ITM-SSD-01	0	2	66	f	none	simulated	system_sim
1631	2026-07-29	WH-BOM-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
1632	2026-07-29	WH-BOM-01	ITM-CHG-01	0	2	216	f	none	simulated	system_sim
1633	2026-07-29	WH-BOM-01	ITM-CBL-01	0	9	197	f	none	simulated	system_sim
1634	2026-07-29	WH-DEL-01	ITM-CPU-01	0	2	24	f	none	simulated	system_sim
1635	2026-07-29	WH-DEL-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
1636	2026-07-29	WH-DEL-01	ITM-RAM-01	0	2	59	f	none	simulated	system_sim
1637	2026-07-29	WH-DEL-01	ITM-SSD-01	0	0	58	f	none	simulated	system_sim
1638	2026-07-29	WH-DEL-01	ITM-HDD-01	0	0	36	f	none	simulated	system_sim
1639	2026-07-29	WH-DEL-01	ITM-CHG-01	0	7	207	f	none	simulated	system_sim
1640	2026-07-29	WH-DEL-01	ITM-CBL-01	0	6	224	f	none	simulated	system_sim
1641	2026-07-29	WH-CCU-01	ITM-CPU-01	0	1	60	f	none	simulated	system_sim
1642	2026-07-29	WH-CCU-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
1643	2026-07-29	WH-CCU-01	ITM-RAM-01	0	7	66	f	none	simulated	system_sim
1644	2026-07-29	WH-CCU-01	ITM-SSD-01	0	0	66	f	none	simulated	system_sim
1645	2026-07-29	WH-CCU-01	ITM-HDD-01	0	0	36	f	none	simulated	system_sim
1646	2026-07-29	WH-CCU-01	ITM-CHG-01	0	4	202	f	none	simulated	system_sim
1647	2026-07-29	WH-CCU-01	ITM-CBL-01	0	4	212	f	none	simulated	system_sim
1648	2026-07-30	WH-BLR-01	ITM-CPU-01	45	2	65	f	none	simulated	system_sim
1649	2026-07-30	WH-BLR-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
1650	2026-07-30	WH-BLR-01	ITM-RAM-01	0	8	47	f	none	simulated	system_sim
1651	2026-07-30	WH-BLR-01	ITM-SSD-01	0	3	67	f	none	simulated	system_sim
1652	2026-07-30	WH-BLR-01	ITM-HDD-01	0	0	53	f	none	simulated	system_sim
1653	2026-07-30	WH-BLR-01	ITM-CHG-01	0	5	189	f	none	simulated	system_sim
1654	2026-07-30	WH-BLR-01	ITM-CBL-01	0	6	200	f	none	simulated	system_sim
1655	2026-07-30	WH-CHN-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
1656	2026-07-30	WH-CHN-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
1657	2026-07-30	WH-CHN-01	ITM-RAM-01	0	4	44	f	none	simulated	system_sim
1658	2026-07-30	WH-CHN-01	ITM-SSD-01	0	1	66	f	none	simulated	system_sim
1659	2026-07-30	WH-CHN-01	ITM-HDD-01	0	3	39	f	none	simulated	system_sim
1660	2026-07-30	WH-CHN-01	ITM-CHG-01	0	2	202	f	none	simulated	system_sim
1661	2026-07-30	WH-CHN-01	ITM-CBL-01	0	8	198	f	none	simulated	system_sim
1662	2026-07-30	WH-BOM-01	ITM-CPU-01	0	0	25	f	none	simulated	system_sim
1663	2026-07-30	WH-BOM-01	ITM-GPU-01	0	2	37	f	none	simulated	system_sim
1664	2026-07-30	WH-BOM-01	ITM-RAM-01	0	7	65	f	none	simulated	system_sim
1665	2026-07-30	WH-BOM-01	ITM-SSD-01	0	0	66	f	none	simulated	system_sim
1666	2026-07-30	WH-BOM-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
1667	2026-07-30	WH-BOM-01	ITM-CHG-01	0	7	209	f	none	simulated	system_sim
1668	2026-07-30	WH-BOM-01	ITM-CBL-01	0	1	196	f	none	simulated	system_sim
1669	2026-07-30	WH-DEL-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
1670	2026-07-30	WH-DEL-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
1671	2026-07-30	WH-DEL-01	ITM-RAM-01	0	10	49	f	none	simulated	system_sim
1672	2026-07-30	WH-DEL-01	ITM-SSD-01	0	3	55	f	none	simulated	system_sim
1673	2026-07-30	WH-DEL-01	ITM-HDD-01	0	0	36	f	none	simulated	system_sim
1674	2026-07-30	WH-DEL-01	ITM-CHG-01	0	3	204	f	none	simulated	system_sim
1675	2026-07-30	WH-DEL-01	ITM-CBL-01	0	7	217	f	none	simulated	system_sim
1676	2026-07-30	WH-CCU-01	ITM-CPU-01	0	0	60	f	none	simulated	system_sim
1677	2026-07-30	WH-CCU-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
1678	2026-07-30	WH-CCU-01	ITM-RAM-01	0	2	64	f	none	simulated	system_sim
1679	2026-07-30	WH-CCU-01	ITM-SSD-01	0	2	64	f	none	simulated	system_sim
1680	2026-07-30	WH-CCU-01	ITM-HDD-01	0	0	36	f	none	simulated	system_sim
1681	2026-07-30	WH-CCU-01	ITM-CHG-01	0	7	195	f	none	simulated	system_sim
1682	2026-07-30	WH-CCU-01	ITM-CBL-01	0	7	205	f	none	simulated	system_sim
1683	2026-07-31	WH-BLR-01	ITM-CPU-01	0	1	64	f	none	simulated	system_sim
1684	2026-07-31	WH-BLR-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
1685	2026-07-31	WH-BLR-01	ITM-RAM-01	0	8	39	f	none	simulated	system_sim
1686	2026-07-31	WH-BLR-01	ITM-SSD-01	0	3	64	f	none	simulated	system_sim
1687	2026-07-31	WH-BLR-01	ITM-HDD-01	0	3	50	f	none	simulated	system_sim
1688	2026-07-31	WH-BLR-01	ITM-CHG-01	0	4	185	f	none	simulated	system_sim
1689	2026-07-31	WH-BLR-01	ITM-CBL-01	0	6	194	f	none	simulated	system_sim
1690	2026-07-31	WH-CHN-01	ITM-CPU-01	0	1	60	f	none	simulated	system_sim
1691	2026-07-31	WH-CHN-01	ITM-GPU-01	0	2	18	f	none	simulated	system_sim
1692	2026-07-31	WH-CHN-01	ITM-RAM-01	0	5	39	f	none	simulated	system_sim
1693	2026-07-31	WH-CHN-01	ITM-SSD-01	0	3	63	f	none	simulated	system_sim
1694	2026-07-31	WH-CHN-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
1695	2026-07-31	WH-CHN-01	ITM-CHG-01	0	4	198	f	none	simulated	system_sim
1696	2026-07-31	WH-CHN-01	ITM-CBL-01	0	10	188	f	none	simulated	system_sim
1697	2026-07-31	WH-BOM-01	ITM-CPU-01	0	1	24	f	none	simulated	system_sim
1698	2026-07-31	WH-BOM-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
1699	2026-07-31	WH-BOM-01	ITM-RAM-01	0	8	57	f	none	simulated	system_sim
1700	2026-07-31	WH-BOM-01	ITM-SSD-01	0	2	64	f	none	simulated	system_sim
1701	2026-07-31	WH-BOM-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
1702	2026-07-31	WH-BOM-01	ITM-CHG-01	0	8	201	f	none	simulated	system_sim
1703	2026-07-31	WH-BOM-01	ITM-CBL-01	0	6	190	f	none	simulated	system_sim
1704	2026-07-31	WH-DEL-01	ITM-CPU-01	0	3	21	f	none	simulated	system_sim
1705	2026-07-31	WH-DEL-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
1706	2026-07-31	WH-DEL-01	ITM-RAM-01	0	9	40	f	none	simulated	system_sim
1707	2026-07-31	WH-DEL-01	ITM-SSD-01	0	3	52	f	none	simulated	system_sim
1708	2026-07-31	WH-DEL-01	ITM-HDD-01	0	2	34	f	none	simulated	system_sim
1709	2026-07-31	WH-DEL-01	ITM-CHG-01	0	6	198	f	none	simulated	system_sim
1710	2026-07-31	WH-DEL-01	ITM-CBL-01	0	1	216	f	none	simulated	system_sim
1711	2026-07-31	WH-CCU-01	ITM-CPU-01	0	0	60	f	none	simulated	system_sim
1712	2026-07-31	WH-CCU-01	ITM-GPU-01	0	1	26	f	none	simulated	system_sim
1713	2026-07-31	WH-CCU-01	ITM-RAM-01	0	7	57	f	none	simulated	system_sim
1714	2026-07-31	WH-CCU-01	ITM-SSD-01	0	0	64	f	none	simulated	system_sim
1715	2026-07-31	WH-CCU-01	ITM-HDD-01	0	0	36	f	none	simulated	system_sim
1716	2026-07-31	WH-CCU-01	ITM-CHG-01	0	8	187	f	none	simulated	system_sim
1717	2026-07-31	WH-CCU-01	ITM-CBL-01	0	7	198	f	none	simulated	system_sim
1718	2026-08-01	WH-BLR-01	ITM-CPU-01	0	3	61	f	none	simulated	system_sim
1719	2026-08-01	WH-BLR-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
1720	2026-08-01	WH-BLR-01	ITM-RAM-01	0	5	34	f	none	simulated	system_sim
1721	2026-08-01	WH-BLR-01	ITM-SSD-01	0	0	64	f	none	simulated	system_sim
1722	2026-08-01	WH-BLR-01	ITM-HDD-01	0	2	48	f	none	simulated	system_sim
1723	2026-08-01	WH-BLR-01	ITM-CHG-01	0	8	177	f	none	simulated	system_sim
1724	2026-08-01	WH-BLR-01	ITM-CBL-01	0	9	185	f	none	simulated	system_sim
1725	2026-08-01	WH-CHN-01	ITM-CPU-01	0	0	60	f	none	simulated	system_sim
1726	2026-08-01	WH-CHN-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
1727	2026-08-01	WH-CHN-01	ITM-RAM-01	0	1	38	f	none	simulated	system_sim
1728	2026-08-01	WH-CHN-01	ITM-SSD-01	0	1	62	f	none	simulated	system_sim
1729	2026-08-01	WH-CHN-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
1730	2026-08-01	WH-CHN-01	ITM-CHG-01	0	2	196	f	none	simulated	system_sim
1731	2026-08-01	WH-CHN-01	ITM-CBL-01	0	1	187	f	none	simulated	system_sim
1732	2026-08-01	WH-BOM-01	ITM-CPU-01	0	3	21	f	none	simulated	system_sim
1733	2026-08-01	WH-BOM-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
1734	2026-08-01	WH-BOM-01	ITM-RAM-01	0	10	47	f	none	simulated	system_sim
1735	2026-08-01	WH-BOM-01	ITM-SSD-01	0	3	61	f	none	simulated	system_sim
1736	2026-08-01	WH-BOM-01	ITM-HDD-01	0	3	45	f	none	simulated	system_sim
1737	2026-08-01	WH-BOM-01	ITM-CHG-01	0	8	193	f	none	simulated	system_sim
1738	2026-08-01	WH-BOM-01	ITM-CBL-01	0	10	180	f	none	simulated	system_sim
1739	2026-08-01	WH-DEL-01	ITM-CPU-01	45	0	66	f	none	simulated	system_sim
1740	2026-08-01	WH-DEL-01	ITM-GPU-01	0	1	21	f	none	simulated	system_sim
1741	2026-08-01	WH-DEL-01	ITM-RAM-01	0	8	32	f	none	simulated	system_sim
1742	2026-08-01	WH-DEL-01	ITM-SSD-01	0	1	51	f	none	simulated	system_sim
1743	2026-08-01	WH-DEL-01	ITM-HDD-01	0	0	34	f	none	simulated	system_sim
1744	2026-08-01	WH-DEL-01	ITM-CHG-01	0	7	191	f	none	simulated	system_sim
1745	2026-08-01	WH-DEL-01	ITM-CBL-01	0	6	210	f	none	simulated	system_sim
1746	2026-08-01	WH-CCU-01	ITM-CPU-01	0	1	59	f	none	simulated	system_sim
1747	2026-08-01	WH-CCU-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
1748	2026-08-01	WH-CCU-01	ITM-RAM-01	0	3	54	f	none	simulated	system_sim
1749	2026-08-01	WH-CCU-01	ITM-SSD-01	0	0	64	f	none	simulated	system_sim
1750	2026-08-01	WH-CCU-01	ITM-HDD-01	0	3	33	f	none	simulated	system_sim
1751	2026-08-01	WH-CCU-01	ITM-CHG-01	0	4	183	f	none	simulated	system_sim
1752	2026-08-01	WH-CCU-01	ITM-CBL-01	0	3	195	f	none	simulated	system_sim
1753	2026-08-02	WH-BLR-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
1754	2026-08-02	WH-BLR-01	ITM-GPU-01	0	1	18	f	none	simulated	system_sim
1755	2026-08-02	WH-BLR-01	ITM-RAM-01	75	5	104	f	none	simulated	system_sim
1756	2026-08-02	WH-BLR-01	ITM-SSD-01	0	1	63	f	none	simulated	system_sim
1757	2026-08-02	WH-BLR-01	ITM-HDD-01	0	0	48	f	none	simulated	system_sim
1758	2026-08-02	WH-BLR-01	ITM-CHG-01	0	1	176	f	none	simulated	system_sim
1759	2026-08-02	WH-BLR-01	ITM-CBL-01	0	10	175	f	none	simulated	system_sim
1760	2026-08-02	WH-CHN-01	ITM-CPU-01	0	2	58	f	none	simulated	system_sim
1761	2026-08-02	WH-CHN-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
1762	2026-08-02	WH-CHN-01	ITM-RAM-01	0	5	33	f	none	simulated	system_sim
1763	2026-08-02	WH-CHN-01	ITM-SSD-01	0	0	62	f	none	simulated	system_sim
1764	2026-08-02	WH-CHN-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
1765	2026-08-02	WH-CHN-01	ITM-CHG-01	0	7	189	f	none	simulated	system_sim
1766	2026-08-02	WH-CHN-01	ITM-CBL-01	0	7	180	f	none	simulated	system_sim
1767	2026-08-02	WH-BOM-01	ITM-CPU-01	45	2	64	f	none	simulated	system_sim
1768	2026-08-02	WH-BOM-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
1769	2026-08-02	WH-BOM-01	ITM-RAM-01	0	9	38	f	none	simulated	system_sim
1770	2026-08-02	WH-BOM-01	ITM-SSD-01	0	3	58	f	none	simulated	system_sim
1771	2026-08-02	WH-BOM-01	ITM-HDD-01	0	0	45	f	none	simulated	system_sim
1772	2026-08-02	WH-BOM-01	ITM-CHG-01	0	9	184	f	none	simulated	system_sim
1773	2026-08-02	WH-BOM-01	ITM-CBL-01	0	6	174	f	none	simulated	system_sim
1774	2026-08-02	WH-DEL-01	ITM-CPU-01	0	0	66	f	none	simulated	system_sim
1775	2026-08-02	WH-DEL-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
1776	2026-08-02	WH-DEL-01	ITM-RAM-01	75	1	106	f	none	simulated	system_sim
1777	2026-08-02	WH-DEL-01	ITM-SSD-01	0	0	51	f	none	simulated	system_sim
1778	2026-08-02	WH-DEL-01	ITM-HDD-01	0	0	34	f	none	simulated	system_sim
1779	2026-08-02	WH-DEL-01	ITM-CHG-01	0	8	183	f	none	simulated	system_sim
1780	2026-08-02	WH-DEL-01	ITM-CBL-01	0	8	202	f	none	simulated	system_sim
1781	2026-08-02	WH-CCU-01	ITM-CPU-01	0	3	56	f	none	simulated	system_sim
1782	2026-08-02	WH-CCU-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
1783	2026-08-02	WH-CCU-01	ITM-RAM-01	0	2	52	f	none	simulated	system_sim
1784	2026-08-02	WH-CCU-01	ITM-SSD-01	0	2	62	f	none	simulated	system_sim
1785	2026-08-02	WH-CCU-01	ITM-HDD-01	0	1	32	f	none	simulated	system_sim
1786	2026-08-02	WH-CCU-01	ITM-CHG-01	0	9	174	f	none	simulated	system_sim
1787	2026-08-02	WH-CCU-01	ITM-CBL-01	0	8	187	f	none	simulated	system_sim
1788	2026-08-03	WH-BLR-01	ITM-CPU-01	0	3	58	f	none	simulated	system_sim
1789	2026-08-03	WH-BLR-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
1790	2026-08-03	WH-BLR-01	ITM-RAM-01	0	10	94	f	none	simulated	system_sim
1791	2026-08-03	WH-BLR-01	ITM-SSD-01	0	0	63	f	none	simulated	system_sim
1792	2026-08-03	WH-BLR-01	ITM-HDD-01	0	2	46	f	none	simulated	system_sim
1793	2026-08-03	WH-BLR-01	ITM-CHG-01	0	8	168	f	none	simulated	system_sim
1794	2026-08-03	WH-BLR-01	ITM-CBL-01	0	7	168	f	none	simulated	system_sim
1795	2026-08-03	WH-CHN-01	ITM-CPU-01	0	0	58	f	none	simulated	system_sim
1796	2026-08-03	WH-CHN-01	ITM-GPU-01	0	2	15	f	none	simulated	system_sim
1797	2026-08-03	WH-CHN-01	ITM-RAM-01	75	2	106	f	none	simulated	system_sim
1798	2026-08-03	WH-CHN-01	ITM-SSD-01	0	2	60	f	none	simulated	system_sim
1799	2026-08-03	WH-CHN-01	ITM-HDD-01	0	1	38	f	none	simulated	system_sim
1800	2026-08-03	WH-CHN-01	ITM-CHG-01	0	10	179	f	none	simulated	system_sim
1801	2026-08-03	WH-CHN-01	ITM-CBL-01	0	6	174	f	none	simulated	system_sim
1802	2026-08-03	WH-BOM-01	ITM-CPU-01	0	0	64	f	none	simulated	system_sim
1803	2026-08-03	WH-BOM-01	ITM-GPU-01	0	2	35	f	none	simulated	system_sim
1804	2026-08-03	WH-BOM-01	ITM-RAM-01	0	4	34	f	none	simulated	system_sim
1805	2026-08-03	WH-BOM-01	ITM-SSD-01	0	1	57	f	none	simulated	system_sim
1806	2026-08-03	WH-BOM-01	ITM-HDD-01	0	2	43	f	none	simulated	system_sim
1807	2026-08-03	WH-BOM-01	ITM-CHG-01	0	4	180	f	none	simulated	system_sim
1808	2026-08-03	WH-BOM-01	ITM-CBL-01	0	2	172	f	none	simulated	system_sim
1809	2026-08-03	WH-DEL-01	ITM-CPU-01	0	2	64	f	none	simulated	system_sim
1810	2026-08-03	WH-DEL-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
1811	2026-08-03	WH-DEL-01	ITM-RAM-01	0	3	103	f	none	simulated	system_sim
1812	2026-08-03	WH-DEL-01	ITM-SSD-01	0	0	51	f	none	simulated	system_sim
1813	2026-08-03	WH-DEL-01	ITM-HDD-01	0	3	31	f	none	simulated	system_sim
1814	2026-08-03	WH-DEL-01	ITM-CHG-01	0	6	177	f	none	simulated	system_sim
1815	2026-08-03	WH-DEL-01	ITM-CBL-01	0	8	194	f	none	simulated	system_sim
1816	2026-08-03	WH-CCU-01	ITM-CPU-01	0	3	53	f	none	simulated	system_sim
1817	2026-08-03	WH-CCU-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
1818	2026-08-03	WH-CCU-01	ITM-RAM-01	0	1	51	f	none	simulated	system_sim
1819	2026-08-03	WH-CCU-01	ITM-SSD-01	0	0	62	f	none	simulated	system_sim
1820	2026-08-03	WH-CCU-01	ITM-HDD-01	0	3	29	f	none	simulated	system_sim
1821	2026-08-03	WH-CCU-01	ITM-CHG-01	0	4	170	f	none	simulated	system_sim
1822	2026-08-03	WH-CCU-01	ITM-CBL-01	0	10	177	f	none	simulated	system_sim
1823	2026-08-04	WH-BLR-01	ITM-CPU-01	0	1	57	f	none	simulated	system_sim
1824	2026-08-04	WH-BLR-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
1825	2026-08-04	WH-BLR-01	ITM-RAM-01	0	10	84	f	none	simulated	system_sim
1826	2026-08-04	WH-BLR-01	ITM-SSD-01	0	2	61	f	none	simulated	system_sim
1827	2026-08-04	WH-BLR-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
1828	2026-08-04	WH-BLR-01	ITM-CHG-01	0	5	163	f	none	simulated	system_sim
1829	2026-08-04	WH-BLR-01	ITM-CBL-01	0	5	163	f	none	simulated	system_sim
1830	2026-08-04	WH-CHN-01	ITM-CPU-01	0	0	58	f	none	simulated	system_sim
1831	2026-08-04	WH-CHN-01	ITM-GPU-01	0	2	13	f	none	simulated	system_sim
1832	2026-08-04	WH-CHN-01	ITM-RAM-01	0	7	99	f	none	simulated	system_sim
1833	2026-08-04	WH-CHN-01	ITM-SSD-01	0	0	60	f	none	simulated	system_sim
1834	2026-08-04	WH-CHN-01	ITM-HDD-01	0	2	36	f	none	simulated	system_sim
1835	2026-08-04	WH-CHN-01	ITM-CHG-01	0	7	172	f	none	simulated	system_sim
1836	2026-08-04	WH-CHN-01	ITM-CBL-01	0	10	164	f	none	simulated	system_sim
1837	2026-08-04	WH-BOM-01	ITM-CPU-01	0	2	62	f	none	simulated	system_sim
1838	2026-08-04	WH-BOM-01	ITM-GPU-01	0	0	35	f	none	simulated	system_sim
1839	2026-08-04	WH-BOM-01	ITM-RAM-01	75	5	104	f	none	simulated	system_sim
1840	2026-08-04	WH-BOM-01	ITM-SSD-01	0	3	54	f	none	simulated	system_sim
1841	2026-08-04	WH-BOM-01	ITM-HDD-01	0	0	43	f	none	simulated	system_sim
1842	2026-08-04	WH-BOM-01	ITM-CHG-01	0	2	178	f	none	simulated	system_sim
1843	2026-08-04	WH-BOM-01	ITM-CBL-01	0	7	165	f	none	simulated	system_sim
1844	2026-08-04	WH-DEL-01	ITM-CPU-01	0	2	62	f	none	simulated	system_sim
1845	2026-08-04	WH-DEL-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
1846	2026-08-04	WH-DEL-01	ITM-RAM-01	0	8	95	f	none	simulated	system_sim
1847	2026-08-04	WH-DEL-01	ITM-SSD-01	0	3	48	f	none	simulated	system_sim
1848	2026-08-04	WH-DEL-01	ITM-HDD-01	0	1	30	f	none	simulated	system_sim
1849	2026-08-04	WH-DEL-01	ITM-CHG-01	0	5	172	f	none	simulated	system_sim
1850	2026-08-04	WH-DEL-01	ITM-CBL-01	0	1	193	f	none	simulated	system_sim
1851	2026-08-04	WH-CCU-01	ITM-CPU-01	0	0	53	f	none	simulated	system_sim
1852	2026-08-04	WH-CCU-01	ITM-GPU-01	0	1	22	f	none	simulated	system_sim
1853	2026-08-04	WH-CCU-01	ITM-RAM-01	0	9	42	f	none	simulated	system_sim
1854	2026-08-04	WH-CCU-01	ITM-SSD-01	0	0	62	f	none	simulated	system_sim
1855	2026-08-04	WH-CCU-01	ITM-HDD-01	60	0	89	f	none	simulated	system_sim
1856	2026-08-04	WH-CCU-01	ITM-CHG-01	0	2	168	f	none	simulated	system_sim
1857	2026-08-04	WH-CCU-01	ITM-CBL-01	0	6	171	f	none	simulated	system_sim
1858	2026-08-05	WH-BLR-01	ITM-CPU-01	0	0	57	f	none	simulated	system_sim
1859	2026-08-05	WH-BLR-01	ITM-GPU-01	0	0	7	t	shrinkage	simulated	system_sim
1860	2026-08-05	WH-BLR-01	ITM-RAM-01	0	4	80	f	none	simulated	system_sim
1861	2026-08-05	WH-BLR-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
1862	2026-08-05	WH-BLR-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
1863	2026-08-05	WH-BLR-01	ITM-CHG-01	0	8	155	f	none	simulated	system_sim
1864	2026-08-05	WH-BLR-01	ITM-CBL-01	0	9	154	f	none	simulated	system_sim
1865	2026-08-05	WH-CHN-01	ITM-CPU-01	0	0	58	f	none	simulated	system_sim
1866	2026-08-05	WH-CHN-01	ITM-GPU-01	30	0	43	f	none	simulated	system_sim
1867	2026-08-05	WH-CHN-01	ITM-RAM-01	0	2	97	f	none	simulated	system_sim
1868	2026-08-05	WH-CHN-01	ITM-SSD-01	0	1	59	f	none	simulated	system_sim
1869	2026-08-05	WH-CHN-01	ITM-HDD-01	0	3	33	f	none	simulated	system_sim
1870	2026-08-05	WH-CHN-01	ITM-CHG-01	0	1	171	f	none	simulated	system_sim
1871	2026-08-05	WH-CHN-01	ITM-CBL-01	0	5	159	f	none	simulated	system_sim
1872	2026-08-05	WH-BOM-01	ITM-CPU-01	0	2	60	f	none	simulated	system_sim
1873	2026-08-05	WH-BOM-01	ITM-GPU-01	0	1	34	f	none	simulated	system_sim
1874	2026-08-05	WH-BOM-01	ITM-RAM-01	0	10	94	f	none	simulated	system_sim
1875	2026-08-05	WH-BOM-01	ITM-SSD-01	0	2	52	f	none	simulated	system_sim
1876	2026-08-05	WH-BOM-01	ITM-HDD-01	0	0	43	f	none	simulated	system_sim
1877	2026-08-05	WH-BOM-01	ITM-CHG-01	0	2	176	f	none	simulated	system_sim
1878	2026-08-05	WH-BOM-01	ITM-CBL-01	0	1	164	f	none	simulated	system_sim
1879	2026-08-05	WH-DEL-01	ITM-CPU-01	0	1	61	f	none	simulated	system_sim
1880	2026-08-05	WH-DEL-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
1881	2026-08-05	WH-DEL-01	ITM-RAM-01	0	4	91	f	none	simulated	system_sim
1882	2026-08-05	WH-DEL-01	ITM-SSD-01	0	3	45	f	none	simulated	system_sim
1883	2026-08-05	WH-DEL-01	ITM-HDD-01	0	3	27	f	none	simulated	system_sim
1884	2026-08-05	WH-DEL-01	ITM-CHG-01	0	8	164	f	none	simulated	system_sim
1885	2026-08-05	WH-DEL-01	ITM-CBL-01	0	6	187	f	none	simulated	system_sim
1886	2026-08-05	WH-CCU-01	ITM-CPU-01	0	1	52	f	none	simulated	system_sim
1887	2026-08-05	WH-CCU-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
1888	2026-08-05	WH-CCU-01	ITM-RAM-01	0	3	39	f	none	simulated	system_sim
1889	2026-08-05	WH-CCU-01	ITM-SSD-01	0	0	62	f	none	simulated	system_sim
1890	2026-08-05	WH-CCU-01	ITM-HDD-01	0	0	89	f	none	simulated	system_sim
1891	2026-08-05	WH-CCU-01	ITM-CHG-01	0	6	162	f	none	simulated	system_sim
1892	2026-08-05	WH-CCU-01	ITM-CBL-01	0	9	162	f	none	simulated	system_sim
1893	2026-08-06	WH-BLR-01	ITM-CPU-01	0	0	57	f	none	simulated	system_sim
1894	2026-08-06	WH-BLR-01	ITM-GPU-01	30	0	37	f	none	simulated	system_sim
1895	2026-08-06	WH-BLR-01	ITM-RAM-01	0	2	78	f	none	simulated	system_sim
1896	2026-08-06	WH-BLR-01	ITM-SSD-01	0	2	59	f	none	simulated	system_sim
1897	2026-08-06	WH-BLR-01	ITM-HDD-01	0	2	44	f	none	simulated	system_sim
1898	2026-08-06	WH-BLR-01	ITM-CHG-01	0	4	151	f	none	simulated	system_sim
1899	2026-08-06	WH-BLR-01	ITM-CBL-01	0	1	153	f	none	simulated	system_sim
1900	2026-08-06	WH-CHN-01	ITM-CPU-01	0	0	58	f	none	simulated	system_sim
1901	2026-08-06	WH-CHN-01	ITM-GPU-01	0	0	43	f	none	simulated	system_sim
1902	2026-08-06	WH-CHN-01	ITM-RAM-01	0	8	89	f	none	simulated	system_sim
1903	2026-08-06	WH-CHN-01	ITM-SSD-01	0	3	56	f	none	simulated	system_sim
1904	2026-08-06	WH-CHN-01	ITM-HDD-01	0	1	32	f	none	simulated	system_sim
1905	2026-08-06	WH-CHN-01	ITM-CHG-01	0	8	163	f	none	simulated	system_sim
1906	2026-08-06	WH-CHN-01	ITM-CBL-01	0	5	154	f	none	simulated	system_sim
1907	2026-08-06	WH-BOM-01	ITM-CPU-01	0	3	57	f	none	simulated	system_sim
1908	2026-08-06	WH-BOM-01	ITM-GPU-01	0	0	34	f	none	simulated	system_sim
1909	2026-08-06	WH-BOM-01	ITM-RAM-01	0	2	92	f	none	simulated	system_sim
1910	2026-08-06	WH-BOM-01	ITM-SSD-01	0	1	51	f	none	simulated	system_sim
1911	2026-08-06	WH-BOM-01	ITM-HDD-01	0	2	41	f	none	simulated	system_sim
1912	2026-08-06	WH-BOM-01	ITM-CHG-01	0	5	171	f	none	simulated	system_sim
1913	2026-08-06	WH-BOM-01	ITM-CBL-01	0	2	162	f	none	simulated	system_sim
1914	2026-08-06	WH-DEL-01	ITM-CPU-01	0	3	58	f	none	simulated	system_sim
1915	2026-08-06	WH-DEL-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
1916	2026-08-06	WH-DEL-01	ITM-RAM-01	0	2	89	f	none	simulated	system_sim
1917	2026-08-06	WH-DEL-01	ITM-SSD-01	0	0	45	f	none	simulated	system_sim
1918	2026-08-06	WH-DEL-01	ITM-HDD-01	60	1	86	f	none	simulated	system_sim
1919	2026-08-06	WH-DEL-01	ITM-CHG-01	0	7	157	f	none	simulated	system_sim
1920	2026-08-06	WH-DEL-01	ITM-CBL-01	0	3	184	f	none	simulated	system_sim
1921	2026-08-06	WH-CCU-01	ITM-CPU-01	0	3	49	f	none	simulated	system_sim
1922	2026-08-06	WH-CCU-01	ITM-GPU-01	0	1	21	f	none	simulated	system_sim
1923	2026-08-06	WH-CCU-01	ITM-RAM-01	0	4	35	f	none	simulated	system_sim
1924	2026-08-06	WH-CCU-01	ITM-SSD-01	0	3	59	f	none	simulated	system_sim
1925	2026-08-06	WH-CCU-01	ITM-HDD-01	0	2	87	f	none	simulated	system_sim
1926	2026-08-06	WH-CCU-01	ITM-CHG-01	0	7	155	f	none	simulated	system_sim
1927	2026-08-06	WH-CCU-01	ITM-CBL-01	0	5	157	f	none	simulated	system_sim
1928	2026-08-07	WH-BLR-01	ITM-CPU-01	0	0	57	f	none	simulated	system_sim
1929	2026-08-07	WH-BLR-01	ITM-GPU-01	0	1	36	f	none	simulated	system_sim
1930	2026-08-07	WH-BLR-01	ITM-RAM-01	0	6	72	f	none	simulated	system_sim
1931	2026-08-07	WH-BLR-01	ITM-SSD-01	0	0	59	f	none	simulated	system_sim
1932	2026-08-07	WH-BLR-01	ITM-HDD-01	0	3	41	f	none	simulated	system_sim
1933	2026-08-07	WH-BLR-01	ITM-CHG-01	0	9	142	f	none	simulated	system_sim
1934	2026-08-07	WH-BLR-01	ITM-CBL-01	0	8	145	f	none	simulated	system_sim
1935	2026-08-07	WH-CHN-01	ITM-CPU-01	0	2	56	f	none	simulated	system_sim
1936	2026-08-07	WH-CHN-01	ITM-GPU-01	0	0	43	f	none	simulated	system_sim
1937	2026-08-07	WH-CHN-01	ITM-RAM-01	0	6	83	f	none	simulated	system_sim
1938	2026-08-07	WH-CHN-01	ITM-SSD-01	0	0	56	f	none	simulated	system_sim
1939	2026-08-07	WH-CHN-01	ITM-HDD-01	0	0	32	f	none	simulated	system_sim
1940	2026-08-07	WH-CHN-01	ITM-CHG-01	0	3	160	f	none	simulated	system_sim
1941	2026-08-07	WH-CHN-01	ITM-CBL-01	0	7	147	f	none	simulated	system_sim
1942	2026-08-07	WH-BOM-01	ITM-CPU-01	0	3	54	f	none	simulated	system_sim
1943	2026-08-07	WH-BOM-01	ITM-GPU-01	0	0	34	f	none	simulated	system_sim
1944	2026-08-07	WH-BOM-01	ITM-RAM-01	0	1	91	f	none	simulated	system_sim
1945	2026-08-07	WH-BOM-01	ITM-SSD-01	0	3	48	f	none	simulated	system_sim
1946	2026-08-07	WH-BOM-01	ITM-HDD-01	0	0	41	f	none	simulated	system_sim
1947	2026-08-07	WH-BOM-01	ITM-CHG-01	0	8	163	f	none	simulated	system_sim
1948	2026-08-07	WH-BOM-01	ITM-CBL-01	0	4	158	f	none	simulated	system_sim
1949	2026-08-07	WH-DEL-01	ITM-CPU-01	0	0	58	f	none	simulated	system_sim
1950	2026-08-07	WH-DEL-01	ITM-GPU-01	0	2	17	f	none	simulated	system_sim
1951	2026-08-07	WH-DEL-01	ITM-RAM-01	0	1	88	f	none	simulated	system_sim
1952	2026-08-07	WH-DEL-01	ITM-SSD-01	0	3	42	f	none	simulated	system_sim
1953	2026-08-07	WH-DEL-01	ITM-HDD-01	0	1	85	f	none	simulated	system_sim
1954	2026-08-07	WH-DEL-01	ITM-CHG-01	0	9	148	f	none	simulated	system_sim
1955	2026-08-07	WH-DEL-01	ITM-CBL-01	0	10	174	f	none	simulated	system_sim
1956	2026-08-07	WH-CCU-01	ITM-CPU-01	0	3	46	f	none	simulated	system_sim
1957	2026-08-07	WH-CCU-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
1958	2026-08-07	WH-CCU-01	ITM-RAM-01	75	7	103	f	none	simulated	system_sim
1959	2026-08-07	WH-CCU-01	ITM-SSD-01	0	2	57	f	none	simulated	system_sim
1960	2026-08-07	WH-CCU-01	ITM-HDD-01	0	3	84	f	none	simulated	system_sim
1961	2026-08-07	WH-CCU-01	ITM-CHG-01	0	2	153	f	none	simulated	system_sim
1962	2026-08-07	WH-CCU-01	ITM-CBL-01	0	10	147	f	none	simulated	system_sim
1963	2026-08-08	WH-BLR-01	ITM-CPU-01	0	1	56	f	none	simulated	system_sim
1964	2026-08-08	WH-BLR-01	ITM-GPU-01	0	2	34	f	none	simulated	system_sim
1965	2026-08-08	WH-BLR-01	ITM-RAM-01	0	1	71	f	none	simulated	system_sim
1966	2026-08-08	WH-BLR-01	ITM-SSD-01	0	3	56	f	none	simulated	system_sim
1967	2026-08-08	WH-BLR-01	ITM-HDD-01	0	3	38	f	none	simulated	system_sim
1968	2026-08-08	WH-BLR-01	ITM-CHG-01	0	6	136	f	none	simulated	system_sim
1969	2026-08-08	WH-BLR-01	ITM-CBL-01	300	3	442	f	none	simulated	system_sim
1970	2026-08-08	WH-CHN-01	ITM-CPU-01	0	0	56	f	none	simulated	system_sim
1971	2026-08-08	WH-CHN-01	ITM-GPU-01	0	1	42	f	none	simulated	system_sim
1972	2026-08-08	WH-CHN-01	ITM-RAM-01	0	1	82	f	none	simulated	system_sim
1973	2026-08-08	WH-CHN-01	ITM-SSD-01	0	2	54	f	none	simulated	system_sim
1974	2026-08-08	WH-CHN-01	ITM-HDD-01	0	2	30	f	none	simulated	system_sim
1975	2026-08-08	WH-CHN-01	ITM-CHG-01	0	2	158	f	none	simulated	system_sim
1976	2026-08-08	WH-CHN-01	ITM-CBL-01	300	3	444	f	none	simulated	system_sim
1977	2026-08-08	WH-BOM-01	ITM-CPU-01	0	3	51	f	none	simulated	system_sim
1978	2026-08-08	WH-BOM-01	ITM-GPU-01	0	0	34	f	none	simulated	system_sim
1979	2026-08-08	WH-BOM-01	ITM-RAM-01	0	7	84	f	none	simulated	system_sim
1980	2026-08-08	WH-BOM-01	ITM-SSD-01	0	1	47	f	none	simulated	system_sim
1981	2026-08-08	WH-BOM-01	ITM-HDD-01	0	1	40	f	none	simulated	system_sim
1982	2026-08-08	WH-BOM-01	ITM-CHG-01	0	4	159	f	none	simulated	system_sim
1983	2026-08-08	WH-BOM-01	ITM-CBL-01	0	10	148	f	none	simulated	system_sim
1984	2026-08-08	WH-DEL-01	ITM-CPU-01	0	1	57	f	none	simulated	system_sim
1985	2026-08-08	WH-DEL-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
1986	2026-08-08	WH-DEL-01	ITM-RAM-01	0	9	79	f	none	simulated	system_sim
1987	2026-08-08	WH-DEL-01	ITM-SSD-01	90	1	131	f	none	simulated	system_sim
1988	2026-08-08	WH-DEL-01	ITM-HDD-01	0	0	85	f	none	simulated	system_sim
1989	2026-08-08	WH-DEL-01	ITM-CHG-01	0	1	147	f	none	simulated	system_sim
1990	2026-08-08	WH-DEL-01	ITM-CBL-01	0	10	164	f	none	simulated	system_sim
1991	2026-08-08	WH-CCU-01	ITM-CPU-01	0	0	46	f	none	simulated	system_sim
1992	2026-08-08	WH-CCU-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
1993	2026-08-08	WH-CCU-01	ITM-RAM-01	0	4	99	f	none	simulated	system_sim
1994	2026-08-08	WH-CCU-01	ITM-SSD-01	0	1	56	f	none	simulated	system_sim
1995	2026-08-08	WH-CCU-01	ITM-HDD-01	0	3	81	f	none	simulated	system_sim
1996	2026-08-08	WH-CCU-01	ITM-CHG-01	0	1	152	f	none	simulated	system_sim
1997	2026-08-08	WH-CCU-01	ITM-CBL-01	300	5	442	f	none	simulated	system_sim
1998	2026-08-09	WH-BLR-01	ITM-CPU-01	0	0	56	f	none	simulated	system_sim
1999	2026-08-09	WH-BLR-01	ITM-GPU-01	0	0	34	f	none	simulated	system_sim
2000	2026-08-09	WH-BLR-01	ITM-RAM-01	0	9	62	f	none	simulated	system_sim
2001	2026-08-09	WH-BLR-01	ITM-SSD-01	0	3	53	f	none	simulated	system_sim
2002	2026-08-09	WH-BLR-01	ITM-HDD-01	0	2	36	f	none	simulated	system_sim
2003	2026-08-09	WH-BLR-01	ITM-CHG-01	0	5	131	f	none	simulated	system_sim
2004	2026-08-09	WH-BLR-01	ITM-CBL-01	0	3	439	f	none	simulated	system_sim
2005	2026-08-09	WH-CHN-01	ITM-CPU-01	0	0	56	f	none	simulated	system_sim
2006	2026-08-09	WH-CHN-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
2007	2026-08-09	WH-CHN-01	ITM-RAM-01	0	8	74	f	none	simulated	system_sim
2008	2026-08-09	WH-CHN-01	ITM-SSD-01	0	0	54	f	none	simulated	system_sim
2009	2026-08-09	WH-CHN-01	ITM-HDD-01	0	1	29	f	none	simulated	system_sim
2010	2026-08-09	WH-CHN-01	ITM-CHG-01	0	4	154	f	none	simulated	system_sim
2011	2026-08-09	WH-CHN-01	ITM-CBL-01	0	7	437	f	none	simulated	system_sim
2012	2026-08-09	WH-BOM-01	ITM-CPU-01	0	0	51	f	none	simulated	system_sim
2013	2026-08-09	WH-BOM-01	ITM-GPU-01	0	0	34	f	none	simulated	system_sim
2014	2026-08-09	WH-BOM-01	ITM-RAM-01	0	10	74	f	none	simulated	system_sim
2015	2026-08-09	WH-BOM-01	ITM-SSD-01	0	0	47	f	none	simulated	system_sim
2016	2026-08-09	WH-BOM-01	ITM-HDD-01	0	3	37	f	none	simulated	system_sim
2017	2026-08-09	WH-BOM-01	ITM-CHG-01	0	2	157	f	none	simulated	system_sim
2018	2026-08-09	WH-BOM-01	ITM-CBL-01	300	8	440	f	none	simulated	system_sim
2019	2026-08-09	WH-DEL-01	ITM-CPU-01	0	0	57	f	none	simulated	system_sim
2020	2026-08-09	WH-DEL-01	ITM-GPU-01	0	2	15	f	none	simulated	system_sim
2021	2026-08-09	WH-DEL-01	ITM-RAM-01	0	9	70	f	none	simulated	system_sim
2022	2026-08-09	WH-DEL-01	ITM-SSD-01	0	2	129	f	none	simulated	system_sim
2023	2026-08-09	WH-DEL-01	ITM-HDD-01	0	2	83	f	none	simulated	system_sim
2024	2026-08-09	WH-DEL-01	ITM-CHG-01	0	8	139	f	none	simulated	system_sim
2025	2026-08-09	WH-DEL-01	ITM-CBL-01	0	9	155	f	none	simulated	system_sim
2026	2026-08-09	WH-CCU-01	ITM-CPU-01	0	3	43	f	none	simulated	system_sim
2027	2026-08-09	WH-CCU-01	ITM-GPU-01	0	1	18	f	none	simulated	system_sim
2028	2026-08-09	WH-CCU-01	ITM-RAM-01	0	2	97	f	none	simulated	system_sim
2029	2026-08-09	WH-CCU-01	ITM-SSD-01	0	2	54	f	none	simulated	system_sim
2030	2026-08-09	WH-CCU-01	ITM-HDD-01	0	0	81	f	none	simulated	system_sim
2031	2026-08-09	WH-CCU-01	ITM-CHG-01	0	4	148	f	none	simulated	system_sim
2032	2026-08-09	WH-CCU-01	ITM-CBL-01	0	2	440	f	none	simulated	system_sim
2033	2026-08-10	WH-BLR-01	ITM-CPU-01	0	0	56	f	none	simulated	system_sim
2034	2026-08-10	WH-BLR-01	ITM-GPU-01	0	1	33	f	none	simulated	system_sim
2035	2026-08-10	WH-BLR-01	ITM-RAM-01	0	2	60	f	none	simulated	system_sim
2036	2026-08-10	WH-BLR-01	ITM-SSD-01	0	2	51	f	none	simulated	system_sim
2037	2026-08-10	WH-BLR-01	ITM-HDD-01	0	3	33	f	none	simulated	system_sim
2038	2026-08-10	WH-BLR-01	ITM-CHG-01	0	7	124	f	none	simulated	system_sim
2039	2026-08-10	WH-BLR-01	ITM-CBL-01	0	5	434	f	none	simulated	system_sim
2040	2026-08-10	WH-CHN-01	ITM-CPU-01	0	3	53	f	none	simulated	system_sim
2041	2026-08-10	WH-CHN-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
2042	2026-08-10	WH-CHN-01	ITM-RAM-01	0	5	69	f	none	simulated	system_sim
2043	2026-08-10	WH-CHN-01	ITM-SSD-01	0	3	51	f	none	simulated	system_sim
2044	2026-08-10	WH-CHN-01	ITM-HDD-01	60	0	89	f	none	simulated	system_sim
2045	2026-08-10	WH-CHN-01	ITM-CHG-01	0	3	151	f	none	simulated	system_sim
2046	2026-08-10	WH-CHN-01	ITM-CBL-01	0	4	433	f	none	simulated	system_sim
2047	2026-08-10	WH-BOM-01	ITM-CPU-01	0	3	48	f	none	simulated	system_sim
2048	2026-08-10	WH-BOM-01	ITM-GPU-01	0	1	33	f	none	simulated	system_sim
2049	2026-08-10	WH-BOM-01	ITM-RAM-01	0	8	66	f	none	simulated	system_sim
2050	2026-08-10	WH-BOM-01	ITM-SSD-01	0	2	45	f	none	simulated	system_sim
2051	2026-08-10	WH-BOM-01	ITM-HDD-01	0	2	35	f	none	simulated	system_sim
2052	2026-08-10	WH-BOM-01	ITM-CHG-01	0	2	155	f	none	simulated	system_sim
2053	2026-08-10	WH-BOM-01	ITM-CBL-01	0	7	433	f	none	simulated	system_sim
2054	2026-08-10	WH-DEL-01	ITM-CPU-01	0	0	57	f	none	simulated	system_sim
2055	2026-08-10	WH-DEL-01	ITM-GPU-01	0	0	15	f	none	simulated	system_sim
2056	2026-08-10	WH-DEL-01	ITM-RAM-01	0	1	69	f	none	simulated	system_sim
2057	2026-08-10	WH-DEL-01	ITM-SSD-01	0	0	129	f	none	simulated	system_sim
2058	2026-08-10	WH-DEL-01	ITM-HDD-01	0	0	83	f	none	simulated	system_sim
2059	2026-08-10	WH-DEL-01	ITM-CHG-01	0	1	138	f	none	simulated	system_sim
2060	2026-08-10	WH-DEL-01	ITM-CBL-01	0	8	147	f	none	simulated	system_sim
2061	2026-08-10	WH-CCU-01	ITM-CPU-01	0	1	42	f	none	simulated	system_sim
2062	2026-08-10	WH-CCU-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
2063	2026-08-10	WH-CCU-01	ITM-RAM-01	0	9	88	f	none	simulated	system_sim
2064	2026-08-10	WH-CCU-01	ITM-SSD-01	0	3	51	f	none	simulated	system_sim
2065	2026-08-10	WH-CCU-01	ITM-HDD-01	0	1	80	f	none	simulated	system_sim
2066	2026-08-10	WH-CCU-01	ITM-CHG-01	0	6	142	f	none	simulated	system_sim
2067	2026-08-10	WH-CCU-01	ITM-CBL-01	0	6	434	f	none	simulated	system_sim
2068	2026-08-11	WH-BLR-01	ITM-CPU-01	0	0	56	f	none	simulated	system_sim
2069	2026-08-11	WH-BLR-01	ITM-GPU-01	0	2	31	f	none	simulated	system_sim
2070	2026-08-11	WH-BLR-01	ITM-RAM-01	0	6	54	f	none	simulated	system_sim
2071	2026-08-11	WH-BLR-01	ITM-SSD-01	0	1	50	f	none	simulated	system_sim
2072	2026-08-11	WH-BLR-01	ITM-HDD-01	0	2	31	f	none	simulated	system_sim
2073	2026-08-11	WH-BLR-01	ITM-CHG-01	0	6	118	f	none	simulated	system_sim
2074	2026-08-11	WH-BLR-01	ITM-CBL-01	0	3	431	f	none	simulated	system_sim
2075	2026-08-11	WH-CHN-01	ITM-CPU-01	0	0	53	f	none	simulated	system_sim
2076	2026-08-11	WH-CHN-01	ITM-GPU-01	0	0	42	f	none	simulated	system_sim
2077	2026-08-11	WH-CHN-01	ITM-RAM-01	0	8	61	f	none	simulated	system_sim
2078	2026-08-11	WH-CHN-01	ITM-SSD-01	0	0	51	f	none	simulated	system_sim
2079	2026-08-11	WH-CHN-01	ITM-HDD-01	0	1	88	f	none	simulated	system_sim
2080	2026-08-11	WH-CHN-01	ITM-CHG-01	0	2	149	f	none	simulated	system_sim
2081	2026-08-11	WH-CHN-01	ITM-CBL-01	0	3	430	f	none	simulated	system_sim
2082	2026-08-11	WH-BOM-01	ITM-CPU-01	0	0	48	f	none	simulated	system_sim
2083	2026-08-11	WH-BOM-01	ITM-GPU-01	0	2	31	f	none	simulated	system_sim
2084	2026-08-11	WH-BOM-01	ITM-RAM-01	0	8	58	f	none	simulated	system_sim
2085	2026-08-11	WH-BOM-01	ITM-SSD-01	0	3	42	f	none	simulated	system_sim
2086	2026-08-11	WH-BOM-01	ITM-HDD-01	0	2	33	f	none	simulated	system_sim
2087	2026-08-11	WH-BOM-01	ITM-CHG-01	0	6	149	f	none	simulated	system_sim
2088	2026-08-11	WH-BOM-01	ITM-CBL-01	0	6	427	f	none	simulated	system_sim
2089	2026-08-11	WH-DEL-01	ITM-CPU-01	0	0	57	f	none	simulated	system_sim
2090	2026-08-11	WH-DEL-01	ITM-GPU-01	0	1	14	f	none	simulated	system_sim
2091	2026-08-11	WH-DEL-01	ITM-RAM-01	0	2	67	f	none	simulated	system_sim
2092	2026-08-11	WH-DEL-01	ITM-SSD-01	0	0	129	f	none	simulated	system_sim
2093	2026-08-11	WH-DEL-01	ITM-HDD-01	0	3	80	f	none	simulated	system_sim
2094	2026-08-11	WH-DEL-01	ITM-CHG-01	0	4	134	f	none	simulated	system_sim
2095	2026-08-11	WH-DEL-01	ITM-CBL-01	300	10	437	f	none	simulated	system_sim
2096	2026-08-11	WH-CCU-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
2097	2026-08-11	WH-CCU-01	ITM-GPU-01	0	2	16	f	none	simulated	system_sim
2098	2026-08-11	WH-CCU-01	ITM-RAM-01	0	7	81	f	none	simulated	system_sim
2099	2026-08-11	WH-CCU-01	ITM-SSD-01	0	0	51	f	none	simulated	system_sim
2100	2026-08-11	WH-CCU-01	ITM-HDD-01	0	2	78	f	none	simulated	system_sim
2101	2026-08-11	WH-CCU-01	ITM-CHG-01	0	9	133	f	none	simulated	system_sim
2102	2026-08-11	WH-CCU-01	ITM-CBL-01	0	7	427	f	none	simulated	system_sim
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password_hash, role, full_name, google_subject_id, created_at) FROM stdin;
1	admin	$2b$12$z7JVwvNuVk9ZWRNc4e1xAuf.UdaolPvtcZ5x4PG1QEvMD3C61/LQG	admin	System Administrator	\N	2026-08-14 10:31:22.459306
3	harsha200797+new@gmail.com	GOOGLE_OAUTH_ONLY	admin	Test Admin	\N	2026-08-14 11:06:06.740539
4	testadmin_1786780003@gmail.com	GOOGLE_OAUTH_ONLY	admin	Test Administrator	\N	2026-08-15 07:46:48.142813
5	testadmin_1786780047@gmail.com	GOOGLE_OAUTH_ONLY	admin	Test Administrator	\N	2026-08-15 07:47:32.710151
2	harsha200797@gmail.com	$2b$12$NOlbO9fWjPIGklV.rRcGO.dcF/ILm3dBtwJ7XGdDU1QyVwOet23be	admin	Harsha Vardhan	117591730789469546962	2026-08-14 10:32:57.463364
9	joyboy56211@gmail.com	GOOGLE_OAUTH_ONLY	admin	joyboy	\N	2026-08-15 15:52:47.166598
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouses (id, name, location, latitude, longitude, created_at) FROM stdin;
WH-BLR-01	Bangalore Fulfillment Center	Bangalore, Karnataka	12.971598	77.594566	2026-08-17 17:12:50.9772
WH-CHN-01	Chennai Port Logistics Hub	Chennai, Tamil Nadu	13.08268	80.270718	2026-08-17 17:12:50.985741
WH-BOM-01	Mumbai Container Terminal	Mumbai, Maharashtra	19.07609	72.877701	2026-08-17 17:12:50.989726
WH-DEL-01	Delhi NCR Logistics Park	Noida, Uttar Pradesh	28.535517	77.391029	2026-08-17 17:12:50.995732
WH-CCU-01	Kolkata Gateway Depot	Kolkata, West Bengal	22.572646	88.363895	2026-08-17 17:12:50.998723
\.


--
-- Name: access_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_log_id_seq', 173, true);


--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_recommendations_id_seq', 8, true);


--
-- Name: audit_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_ledger_id_seq', 162, true);


--
-- Name: backup_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.backup_records_id_seq', 17, true);


--
-- Name: recovery_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recovery_codes_id_seq', 1, false);


--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recovery_credentials_id_seq', 1, false);


--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shrinkage_flags_id_seq', 4, true);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 2102, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 9, true);


--
-- Name: access_log access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log
    ADD CONSTRAINT access_log_pkey PRIMARY KEY (id);


--
-- Name: ai_recommendations ai_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_recommendations
    ADD CONSTRAINT ai_recommendations_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_ledger audit_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_ledger
    ADD CONSTRAINT audit_ledger_pkey PRIMARY KEY (id);


--
-- Name: backup_records backup_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_records
    ADD CONSTRAINT backup_records_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: recovery_codes recovery_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: recovery_credentials recovery_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials
    ADD CONSTRAINT recovery_credentials_pkey PRIMARY KEY (id);


--
-- Name: shrinkage_flags shrinkage_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shrinkage_flags
    ADD CONSTRAINT shrinkage_flags_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: stock_movements uq_movement; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT uq_movement UNIQUE (date, warehouse_id, item_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: ix_access_log_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_access_log_timestamp ON public.access_log USING btree ("timestamp");


--
-- Name: ix_ai_recommendations_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_recommendations_timestamp ON public.ai_recommendations USING btree ("timestamp");


--
-- Name: ix_backup_records_backup_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_backup_records_backup_id ON public.backup_records USING btree (backup_id);


--
-- Name: ix_backup_records_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_backup_records_created_at ON public.backup_records USING btree (created_at);


--
-- Name: ix_recovery_codes_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_recovery_codes_user_id ON public.recovery_codes USING btree (user_id);


--
-- Name: ix_recovery_credentials_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_recovery_credentials_user_id ON public.recovery_credentials USING btree (user_id);


--
-- Name: ix_stock_movements_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_date ON public.stock_movements USING btree (date);


--
-- Name: ix_stock_movements_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_item_id ON public.stock_movements USING btree (item_id);


--
-- Name: ix_stock_movements_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_warehouse_id ON public.stock_movements USING btree (warehouse_id);


--
-- Name: ix_users_google_subject_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_google_subject_id ON public.users USING btree (google_subject_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: recovery_codes recovery_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: recovery_credentials recovery_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials
    ADD CONSTRAINT recovery_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id);


--
-- Name: stock_movements stock_movements_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- PostgreSQL database dump complete
--

\unrestrict ld2lg8aJFfscCyjfdBBZS0ixsXtTdNjK2yM3pEKyxeA58ifNMrS1gS5fN6p5Jl5

