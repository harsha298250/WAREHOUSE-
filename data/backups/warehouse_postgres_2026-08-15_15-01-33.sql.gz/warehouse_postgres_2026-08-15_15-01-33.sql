--
-- PostgreSQL database dump
--

\restrict kc0bfHaMi9rWyj3CZQbkM9NOnqcUcVwaM29hZ8R1APcA38OkryselOYyE2AcmLz

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_log (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    username character varying(64) NOT NULL,
    warehouse_id character varying(20),
    action character varying(50) NOT NULL,
    ip_address character varying(45)
);


ALTER TABLE public.access_log OWNER TO postgres;

--
-- Name: access_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.access_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.access_log_id_seq OWNER TO postgres;

--
-- Name: access_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.access_log_id_seq OWNED BY public.access_log.id;


--
-- Name: ai_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_recommendations (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(50),
    title character varying(100) NOT NULL,
    risk_level character varying(20),
    action_recommended character varying(100) NOT NULL,
    confidence_score integer,
    input_factors text,
    status character varying(20),
    decision_by character varying(64),
    decision_time timestamp without time zone,
    notes text
);


ALTER TABLE public.ai_recommendations OWNER TO postgres;

--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_recommendations_id_seq OWNER TO postgres;

--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_recommendations_id_seq OWNED BY public.ai_recommendations.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: audit_ledger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_ledger (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    event_type character varying(50) NOT NULL,
    details text,
    prev_hash character varying(64) NOT NULL,
    hash character varying(64) NOT NULL
);


ALTER TABLE public.audit_ledger OWNER TO postgres;

--
-- Name: audit_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_ledger_id_seq OWNER TO postgres;

--
-- Name: audit_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_ledger_id_seq OWNED BY public.audit_ledger.id;


--
-- Name: backup_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_records (
    id integer NOT NULL,
    backup_id character varying(64) NOT NULL,
    filename character varying(255) NOT NULL,
    created_at timestamp without time zone,
    size_bytes integer,
    sha256 character varying(64),
    status character varying(20) NOT NULL,
    storage_key character varying(255),
    error_message text
);


ALTER TABLE public.backup_records OWNER TO postgres;

--
-- Name: backup_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.backup_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_records_id_seq OWNER TO postgres;

--
-- Name: backup_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.backup_records_id_seq OWNED BY public.backup_records.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id character varying(20) NOT NULL,
    name character varying(150) NOT NULL,
    category character varying(80),
    unit_cost double precision,
    lead_time_days integer,
    safety_stock integer,
    created_at timestamp without time zone
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: recovery_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recovery_codes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code_hash character varying(255) NOT NULL,
    used boolean NOT NULL,
    created_at timestamp without time zone,
    used_at timestamp without time zone
);


ALTER TABLE public.recovery_codes OWNER TO postgres;

--
-- Name: recovery_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recovery_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recovery_codes_id_seq OWNER TO postgres;

--
-- Name: recovery_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recovery_codes_id_seq OWNED BY public.recovery_codes.id;


--
-- Name: recovery_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recovery_credentials (
    id integer NOT NULL,
    user_id integer NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.recovery_credentials OWNER TO postgres;

--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recovery_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recovery_credentials_id_seq OWNER TO postgres;

--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recovery_credentials_id_seq OWNED BY public.recovery_credentials.id;


--
-- Name: shrinkage_flags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shrinkage_flags (
    id integer NOT NULL,
    date date NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    item_name character varying(150),
    deviation_score double precision,
    expected_quantity double precision,
    actual_quantity double precision,
    discrepancy_quantity double precision,
    estimated_exposure double precision,
    severity character varying(20),
    likely_cause character varying(80),
    explanation text
);


ALTER TABLE public.shrinkage_flags OWNER TO postgres;

--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shrinkage_flags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shrinkage_flags_id_seq OWNER TO postgres;

--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shrinkage_flags_id_seq OWNED BY public.shrinkage_flags.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    date date NOT NULL,
    warehouse_id character varying(20) NOT NULL,
    item_id character varying(20) NOT NULL,
    stock_in integer,
    stock_out integer,
    closing_stock integer,
    is_anomaly boolean,
    anomaly_type character varying(30),
    entry_source character varying(20),
    entered_by character varying(64)
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_movements_id_seq OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    full_name character varying(120),
    google_subject_id character varying(128),
    created_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouses (
    id character varying(20) NOT NULL,
    name character varying(120) NOT NULL,
    location character varying(120),
    latitude double precision,
    longitude double precision,
    created_at timestamp without time zone
);


ALTER TABLE public.warehouses OWNER TO postgres;

--
-- Name: access_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log ALTER COLUMN id SET DEFAULT nextval('public.access_log_id_seq'::regclass);


--
-- Name: ai_recommendations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_recommendations ALTER COLUMN id SET DEFAULT nextval('public.ai_recommendations_id_seq'::regclass);


--
-- Name: audit_ledger id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_ledger ALTER COLUMN id SET DEFAULT nextval('public.audit_ledger_id_seq'::regclass);


--
-- Name: backup_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_records ALTER COLUMN id SET DEFAULT nextval('public.backup_records_id_seq'::regclass);


--
-- Name: recovery_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes ALTER COLUMN id SET DEFAULT nextval('public.recovery_codes_id_seq'::regclass);


--
-- Name: recovery_credentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials ALTER COLUMN id SET DEFAULT nextval('public.recovery_credentials_id_seq'::regclass);


--
-- Name: shrinkage_flags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shrinkage_flags ALTER COLUMN id SET DEFAULT nextval('public.shrinkage_flags_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: access_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access_log (id, "timestamp", username, warehouse_id, action, ip_address) FROM stdin;
1	2026-08-13 05:22:16.71839	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.34
2	2026-08-11 06:12:16.718493	harsha200797@gmail.com	WH-CCU-01	add_stock	192.168.1.177
3	2026-08-14 08:53:16.718526	admin	WH-DEL-01	view	192.168.1.28
4	2026-08-12 16:10:16.71855	admin	WH-DEL-01	add_stock	192.168.1.29
5	2026-08-11 23:51:16.718571	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.73
6	2026-08-12 04:48:16.71859	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.230
7	2026-08-14 08:51:16.718609	harsha200797@gmail.com		login	192.168.1.18
8	2026-08-11 23:11:16.718626	harsha200797@gmail.com	WH-DEL-01	view	192.168.1.48
9	2026-08-12 13:41:16.718658	admin	WH-DEL-01	add_stock	192.168.1.28
10	2026-08-11 06:14:16.718678	admin		login	192.168.1.146
11	2026-08-13 20:48:16.718698	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.240
12	2026-08-12 08:18:16.718716	admin		login	192.168.1.154
13	2026-08-11 20:57:16.718733	harsha200797@gmail.com	WH-BOM-01	add_stock	192.168.1.203
14	2026-08-13 15:56:16.718751	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.52
15	2026-08-11 17:35:16.718769	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.47
16	2026-08-13 09:54:16.718786	admin	WH-BLR-01	add_stock	192.168.1.81
17	2026-08-13 20:15:16.718804	admin		login	192.168.1.147
18	2026-08-11 09:03:16.718821	harsha200797@gmail.com		login	192.168.1.123
19	2026-08-12 19:35:16.718839	harsha200797@gmail.com	WH-BOM-01	add_stock	192.168.1.227
20	2026-08-13 06:29:16.718856	admin	WH-BOM-01	view	192.168.1.7
21	2026-08-12 23:57:16.718873	harsha200797@gmail.com	WH-CHN-01	view	192.168.1.9
22	2026-08-11 02:03:16.71889	admin	WH-BLR-01	view	192.168.1.202
23	2026-08-12 17:39:16.718909	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.149
24	2026-08-13 01:45:16.718927	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.180
25	2026-08-14 01:00:16.718944	admin	WH-BOM-01	add_stock	192.168.1.96
26	2026-08-12 15:43:16.71896	admin		login	192.168.1.111
27	2026-08-13 14:24:16.718978	admin	WH-BLR-01	view	192.168.1.102
28	2026-08-13 06:08:16.718996	harsha200797@gmail.com	WH-CCU-01	add_stock	192.168.1.52
29	2026-08-13 19:51:16.719013	harsha200797@gmail.com		login	192.168.1.163
30	2026-08-13 16:30:16.719031	harsha200797@gmail.com		login	192.168.1.51
31	2026-08-12 11:30:16.719048	admin	WH-CHN-01	view	192.168.1.51
32	2026-08-11 18:39:16.719066	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.60
33	2026-08-12 03:50:16.719082	admin	WH-BLR-01	add_stock	192.168.1.205
34	2026-08-14 02:43:16.7191	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.109
35	2026-08-11 15:21:16.719116	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.238
36	2026-08-11 04:47:16.719133	admin	WH-DEL-01	view	192.168.1.3
37	2026-08-12 17:21:16.719152	admin	WH-CCU-01	view	192.168.1.142
38	2026-08-13 08:04:16.719169	admin	WH-DEL-01	view	192.168.1.154
39	2026-08-11 23:39:16.719186	harsha200797@gmail.com	WH-DEL-01	view	192.168.1.189
40	2026-08-14 01:26:16.719205	admin		login	192.168.1.251
41	2026-08-12 15:27:16.719225	harsha200797@gmail.com	WH-BLR-01	view	192.168.1.68
42	2026-08-11 10:25:16.719242	admin	WH-CCU-01	view	192.168.1.87
43	2026-08-11 17:35:16.719259	harsha200797@gmail.com	WH-DEL-01	view	192.168.1.140
44	2026-08-12 13:07:16.719277	harsha200797@gmail.com	WH-BOM-01	add_stock	192.168.1.60
45	2026-08-12 01:40:16.719296	admin		login	192.168.1.145
46	2026-08-12 04:29:16.719313	harsha200797@gmail.com	WH-BOM-01	view	192.168.1.233
47	2026-08-13 08:16:16.719329	harsha200797@gmail.com	WH-CCU-01	view	192.168.1.101
48	2026-08-12 06:25:16.719346	admin	WH-CHN-01	view	192.168.1.166
49	2026-08-12 09:53:16.719362	admin		login	192.168.1.211
50	2026-08-13 06:13:16.719377	harsha200797@gmail.com		login	192.168.1.202
51	2026-08-14 10:32:57.482425	harsha200797@gmail.com		google_oauth_login	127.0.0.1
52	2026-08-14 10:35:59.368604	harsha200797@gmail.com		google_oauth_login	127.0.0.1
53	2026-08-14 10:36:26.676679	harsha200797@gmail.com		request_admin_creation	127.0.0.1
54	2026-08-14 10:58:27.046036	admin		login	127.0.0.1
55	2026-08-14 11:00:14.182978	admin		request_admin_creation	127.0.0.1
56	2026-08-14 11:03:53.806741	admin		request_admin_creation	127.0.0.1
57	2026-08-14 11:06:06.851529	admin		created_admin_harsha200797+new@gmail.com	127.0.0.1
58	2026-08-14 11:17:30.647099	admin		login	127.0.0.1
59	2026-08-14 11:33:31.606436	admin		password_changed_securely	127.0.0.1
60	2026-08-14 11:37:29.063477	harsha200797@gmail.com		google_oauth_login	127.0.0.1
61	2026-08-14 11:40:57.92494	harsha200797@gmail.com	WH-BLR-01	ai_action_approved	127.0.0.1
62	2026-08-14 11:41:03.709936	harsha200797@gmail.com	WH-BLR-01	ai_action_approved	127.0.0.1
63	2026-08-14 11:41:15.480145	harsha200797@gmail.com	WH-BLR-01	ai_action_rejected	127.0.0.1
64	2026-08-14 11:45:45.934845	harsha200797@gmail.com		password_changed_securely	127.0.0.1
65	2026-08-14 11:47:57.115066	harsha200797@gmail.com		request_admin_creation	127.0.0.1
66	2026-08-14 12:16:07.879158	harsha200797@gmail.com	WH-BLR-01	update_coordinates	127.0.0.1
67	2026-08-14 12:16:46.174765	harsha200797@gmail.com	WH-BLR-01	update_coordinates	127.0.0.1
68	2026-08-14 12:37:59.614438	harsha200797@gmail.com		google_oauth_login	127.0.0.1
69	2026-08-14 16:33:34.180483	admin		login	127.0.0.1
70	2026-08-14 16:35:16.81298	admin		request_admin_creation	127.0.0.1
71	2026-08-15 07:03:48.526119	admin		login	127.0.0.1
72	2026-08-15 07:08:41.501438	admin		request_admin_creation	127.0.0.1
73	2026-08-15 07:12:52.606931	admin		request_admin_creation	127.0.0.1
74	2026-08-15 07:25:23.873049	admin		request_admin_creation	127.0.0.1
75	2026-08-15 07:34:09.809096	admin		request_admin_creation	127.0.0.1
76	2026-08-15 07:41:38.577457	admin		request_admin_creation	127.0.0.1
77	2026-08-15 07:46:43.061892	admin		login	127.0.0.1
78	2026-08-15 07:46:46.678939	admin		request_admin_creation	127.0.0.1
79	2026-08-15 07:46:48.169977	admin		created_admin_testadmin_1786780003@gmail.com	127.0.0.1
80	2026-08-15 07:47:27.451588	admin		login	127.0.0.1
81	2026-08-15 07:47:31.261126	admin		request_admin_creation	127.0.0.1
82	2026-08-15 07:47:32.729097	admin		created_admin_testadmin_1786780047@gmail.com	127.0.0.1
83	2026-08-15 07:54:45.316868	harsha200797@gmail.com		login	127.0.0.1
84	2026-08-15 07:55:15.734212	harsha200797@gmail.com		request_admin_creation	127.0.0.1
85	2026-08-15 08:27:05.926343	harsha200797@gmail.com		login	127.0.0.1
86	2026-08-15 12:49:14.662954	harsha200797@gmail.com		login	127.0.0.1
87	2026-08-15 13:08:08.773663	harsha200797@gmail.com	WH-CHN-02	add_warehouse	127.0.0.1
88	2026-08-15 13:09:24.528836	harsha200797@gmail.com	WH-CHN-02	update_coordinates	127.0.0.1
89	2026-08-15 13:10:07.994782	harsha200797@gmail.com	WH-BLR-01	add_stock	127.0.0.1
90	2026-08-15 13:10:36.017694	harsha200797@gmail.com		add_item	127.0.0.1
91	2026-08-15 13:32:14.957089	harsha200797@gmail.com		request_admin_creation	127.0.0.1
92	2026-08-15 13:51:06.877194	harsha200797@gmail.com		login	127.0.0.1
93	2026-08-15 14:00:37.122313	harsha200797@gmail.com		add_item	127.0.0.1
94	2026-08-15 14:03:01.539736	harsha200797@gmail.com	WH-BLR-01	add_stock	127.0.0.1
95	2026-08-15 15:00:00.11183	pg_smoke_admin		login	127.0.0.1
96	2026-08-15 15:00:00.160151	pg_smoke_admin	WH-SMOKE-99	add_warehouse	127.0.0.1
97	2026-08-15 15:00:13.673851	pg_smoke_admin	WH-SMOKE-99	update_coordinates	127.0.0.1
\.


--
-- Data for Name: ai_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_recommendations (id, "timestamp", warehouse_id, item_id, title, risk_level, action_recommended, confidence_score, input_factors, status, decision_by, decision_time, notes) FROM stdin;
1	2026-08-14 11:40:57.885343	WH-BLR-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01	MEDIUM	APPROVED	85	{}	APPROVED	harsha200797@gmail.com	2026-08-14 11:40:57.88252	Approved via AI Decision Center
2	2026-08-14 11:41:03.619137	WH-BLR-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01	MEDIUM	APPROVED	85	{}	APPROVED	harsha200797@gmail.com	2026-08-14 11:41:03.618171	Approved via AI Decision Center
3	2026-08-14 11:41:15.400552	WH-BLR-01	ITM-CBL-01	Action on REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01	MEDIUM	REJECTED	85	{}	REJECTED	harsha200797@gmail.com	2026-08-14 11:41:15.399727	Rejected via AI Decision Center
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
5724cd882171
\.


--
-- Data for Name: audit_ledger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_ledger (id, "timestamp", event_type, details, prev_hash, hash) FROM stdin;
1	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	0000000000000000000000000000000000000000000000000000000000000000	9fec238c3824e41f68ed3de9ecae4c1025d771291cb76fa2727bc3d051f02c5b
2	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	9fec238c3824e41f68ed3de9ecae4c1025d771291cb76fa2727bc3d051f02c5b	70ac5e917652707bb444acb6ba7eebdf396d0f41db50027871406eded265e12e
3	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	70ac5e917652707bb444acb6ba7eebdf396d0f41db50027871406eded265e12e	41c04983295fc4cb30fb3e48367ad952b896bb41daa561c37c05073e25a01afd
4	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	41c04983295fc4cb30fb3e48367ad952b896bb41daa561c37c05073e25a01afd	bcb583985e67bd010e93f5ab5d480a54aa7de8817faa7bccc7e68720c68830a2
5	2026-08-14 10:31:37	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	bcb583985e67bd010e93f5ab5d480a54aa7de8817faa7bccc7e68720c68830a2	04207a1c67e2a2c68fce2ce9538ae241c1cfa88f3ec87aab3f171a5aba02f80e
6	2026-08-14 10:31:37	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	04207a1c67e2a2c68fce2ce9538ae241c1cfa88f3ec87aab3f171a5aba02f80e	b320925e2d8b0af062401faa74823151f3d2952093d10718d285dab58b296bb3
7	2026-08-14 10:31:37	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	b320925e2d8b0af062401faa74823151f3d2952093d10718d285dab58b296bb3	61aaf8fdb2a61b2d8d7cbaa9655365570e4af100146a1162b556c6307f846dbc
8	2026-08-14 10:31:37	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	61aaf8fdb2a61b2d8d7cbaa9655365570e4af100146a1162b556c6307f846dbc	f9bd686a14b0a4dc3e04a24cb08271861d495c4f72bf961ff25c77232940139e
9	2026-08-14 10:31:37	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	f9bd686a14b0a4dc3e04a24cb08271861d495c4f72bf961ff25c77232940139e	fd5b0e30a0ab87c482ae1e32f600779d0889b6e90cce2e8b342b81f6b02687d1
10	2026-08-14 10:31:37	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	fd5b0e30a0ab87c482ae1e32f600779d0889b6e90cce2e8b342b81f6b02687d1	bbc12990f7f200c4244c90c2f0dd1cf8a406949d8dc5cd3bd52a36355db6d46b
11	2026-08-14 10:31:37	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	bbc12990f7f200c4244c90c2f0dd1cf8a406949d8dc5cd3bd52a36355db6d46b	1a955f61e3af26f3faa7db37fbce37f01f9c72d5709eb38190f3633a7350a6d8
12	2026-08-14 10:31:37	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	1a955f61e3af26f3faa7db37fbce37f01f9c72d5709eb38190f3633a7350a6d8	ee5a288a1442804c3a1eabf5efcc8a1d867f2ae6633c6e1f12c112fc4b7c3827
13	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	ee5a288a1442804c3a1eabf5efcc8a1d867f2ae6633c6e1f12c112fc4b7c3827	14f822f6d1c985a3da215d00f64de67723f6b89ea5738054ed159972fccbed95
14	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	14f822f6d1c985a3da215d00f64de67723f6b89ea5738054ed159972fccbed95	01a9404c776d25feea768be630cadfe4b11e217987585e59a528c3a4391e8c3c
15	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	01a9404c776d25feea768be630cadfe4b11e217987585e59a528c3a4391e8c3c	a0c42a2dad02de4cc119c1902402af4f0db298324d28303c44fc3f4c8d940a8e
16	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	a0c42a2dad02de4cc119c1902402af4f0db298324d28303c44fc3f4c8d940a8e	6a51b6d87f206ac9865a4ddea922837c77f4fad5f371ee87ec966e90834359fa
17	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	6a51b6d87f206ac9865a4ddea922837c77f4fad5f371ee87ec966e90834359fa	0a3e06c8d46b0b776e85375f33e8a19906b45ca7fe4295bb45c5a87500a302e7
18	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-24"}	0a3e06c8d46b0b776e85375f33e8a19906b45ca7fe4295bb45c5a87500a302e7	019959356929a933447c793c1f96ea53fc09158d61fc969d7e5af0d4e2d67d7d
19	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-24"}	019959356929a933447c793c1f96ea53fc09158d61fc969d7e5af0d4e2d67d7d	05005d018a26a90823e8a7ed4babb2caeb9a3d9efbc22026b2362b22931d2015
20	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	05005d018a26a90823e8a7ed4babb2caeb9a3d9efbc22026b2362b22931d2015	b7c23dd7ce30dcd228dc3db26676f929fcc715f537b1ab428bcfda93228d8fe1
21	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	b7c23dd7ce30dcd228dc3db26676f929fcc715f537b1ab428bcfda93228d8fe1	590b9d95c80f69a07835e86e4087fd9916964ef5eaaf685d38acc2be66831b39
22	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-27"}	590b9d95c80f69a07835e86e4087fd9916964ef5eaaf685d38acc2be66831b39	496cdce558453e8a1d621aad955dd34952ad0fd137edf3ab9bc82d6eb52fd128
23	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-28"}	496cdce558453e8a1d621aad955dd34952ad0fd137edf3ab9bc82d6eb52fd128	ebf71bb236ad6166f1a795503b988e0891adfbbf10cdc03f2e1e9c924c21205f
24	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-30"}	ebf71bb236ad6166f1a795503b988e0891adfbbf10cdc03f2e1e9c924c21205f	0a584e1e318f990bc8b3968ec9939bc8f05842e414a358dbb70c84d6fba3b2ce
25	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-30"}	0a584e1e318f990bc8b3968ec9939bc8f05842e414a358dbb70c84d6fba3b2ce	ecccde25b9796f65448ebc7757dc8ca652651c624a16fe8b9225f9fcbd1f5524
26	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-31"}	ecccde25b9796f65448ebc7757dc8ca652651c624a16fe8b9225f9fcbd1f5524	d905f0e78c3d1163e777b397522f6ac0a38fdfe1bb5af7f29023c8e403284a72
27	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-07-31"}	d905f0e78c3d1163e777b397522f6ac0a38fdfe1bb5af7f29023c8e403284a72	907448bac3c94ea38e85697cbdf724116a1a5bc0b69dda126ac55e55a7cc84c3
28	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-01"}	907448bac3c94ea38e85697cbdf724116a1a5bc0b69dda126ac55e55a7cc84c3	a3dc43f283cb582819bfb5f2d4d8e5853e3367d19fbf38b3d00e928b2ff1b069
29	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-01"}	a3dc43f283cb582819bfb5f2d4d8e5853e3367d19fbf38b3d00e928b2ff1b069	a035d1cd8fb439ce8cf4dd3c1c0750585331a665360e09ac66ad5f980f9d1022
30	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-01"}	a035d1cd8fb439ce8cf4dd3c1c0750585331a665360e09ac66ad5f980f9d1022	524ed4e2747b77a4701ecd630d0fc04a02232529fe780db4761048c887df23ef
31	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	524ed4e2747b77a4701ecd630d0fc04a02232529fe780db4761048c887df23ef	d3036f07d5bd572f6211de766368b8f6f936c9092b00563d00bc7d9d3bde734d
32	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-04"}	d3036f07d5bd572f6211de766368b8f6f936c9092b00563d00bc7d9d3bde734d	cf3410d974ae9d1b26473e4291faf9f27ff82dfc8cbdcb3db29e0a59ae9520b0
33	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-05"}	cf3410d974ae9d1b26473e4291faf9f27ff82dfc8cbdcb3db29e0a59ae9520b0	b64754ed00c65777a0a5bb8a8abeec94d172efdf5f0956d57acd924c9cae3feb
34	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-06"}	b64754ed00c65777a0a5bb8a8abeec94d172efdf5f0956d57acd924c9cae3feb	cbfc65687a9ea840423f7df28d52ac22872c4255b7de8dd910118aeec7404430
35	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-06"}	cbfc65687a9ea840423f7df28d52ac22872c4255b7de8dd910118aeec7404430	d2e404b8f350e5710d1ff24dd7687e356751467b358d0477f8fef41f54513539
36	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-07"}	d2e404b8f350e5710d1ff24dd7687e356751467b358d0477f8fef41f54513539	078996631a214b1b8a0435c95ca1b089448cb7f5c7119de9d208dd15cfca1be5
37	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-07"}	078996631a214b1b8a0435c95ca1b089448cb7f5c7119de9d208dd15cfca1be5	e3130764a25f7259ac48df031561f38f2a112f01c64e5af2cb9cf691c131e202
38	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-07"}	e3130764a25f7259ac48df031561f38f2a112f01c64e5af2cb9cf691c131e202	e8a91e2cf4f5e1494ff61306017843039dae3e870af7a5a12766e20db808ed11
39	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-09"}	e8a91e2cf4f5e1494ff61306017843039dae3e870af7a5a12766e20db808ed11	ed9c25f919f06d7f9d77e0e16ee0e437957bd2a50663d4623e49e3212133cad9
40	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	ed9c25f919f06d7f9d77e0e16ee0e437957bd2a50663d4623e49e3212133cad9	b78371424c6357301427a32b9dc7c29fd0a665285e283b644eeb401b41adcf15
41	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-11"}	b78371424c6357301427a32b9dc7c29fd0a665285e283b644eeb401b41adcf15	49a55e93c11a9fd0e6f6462cb97f0698d004467b39b181f72ce7efda21002970
42	2026-08-14 10:31:37	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-11"}	49a55e93c11a9fd0e6f6462cb97f0698d004467b39b181f72ce7efda21002970	955576c3caaba3bc4cf8f80883b60569f9ce039823866cbe4119e99011824335
43	2026-08-14 10:31:37	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	955576c3caaba3bc4cf8f80883b60569f9ce039823866cbe4119e99011824335	b47d7ff2cb2ac7b245648de47de23fe4c46ad572edcb735f39b13d1354a2a15f
44	2026-08-14 10:31:37	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	b47d7ff2cb2ac7b245648de47de23fe4c46ad572edcb735f39b13d1354a2a15f	e818753abb0920c08a2bf30256ff6085f795fb4fb95d6375c778873d9e678e04
45	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-BLR-01", "name": "Bangalore Fulfillment Center"}	e818753abb0920c08a2bf30256ff6085f795fb4fb95d6375c778873d9e678e04	eefc04076a7e6df54e04259d388ba8be345636b10781eaa6e0e13c6bd43f4d24
46	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-CHN-01", "name": "Chennai Port Logistics Hub"}	eefc04076a7e6df54e04259d388ba8be345636b10781eaa6e0e13c6bd43f4d24	d17dd23b71b8f78510b3fb518d3d774ea15cc8a9d94ec676ff154b2317712e1d
47	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-BOM-01", "name": "Mumbai Container Terminal"}	d17dd23b71b8f78510b3fb518d3d774ea15cc8a9d94ec676ff154b2317712e1d	be1486b6ba41658865a5851c4913f4670a9c213c339541d51b1e5a3a6c807a4d
48	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-DEL-01", "name": "Delhi NCR Logistics Park"}	be1486b6ba41658865a5851c4913f4670a9c213c339541d51b1e5a3a6c807a4d	bd1f5abcf03b937803b2a319d10fd69606b4e1f89bbd3757305d8934a761fa4e
49	2026-08-14 10:32:16	warehouse_created	{"warehouse_id": "WH-CCU-01", "name": "Kolkata Gateway Depot"}	bd1f5abcf03b937803b2a319d10fd69606b4e1f89bbd3757305d8934a761fa4e	43b35a517d273cdd250d13c675c7f2eaa93382417967bca0901f1594a20f7ad1
50	2026-08-14 10:32:16	item_created	{"item_id": "ITM-CPU-01", "name": "AMD Ryzen 9 7900X Processor"}	43b35a517d273cdd250d13c675c7f2eaa93382417967bca0901f1594a20f7ad1	49c08f15a6617d7b5303d50be1cd13b681453289044a778d29b61d7a16db46bd
51	2026-08-14 10:32:16	item_created	{"item_id": "ITM-GPU-01", "name": "Nvidia RTX 4080 Founders Edition"}	49c08f15a6617d7b5303d50be1cd13b681453289044a778d29b61d7a16db46bd	28190f3523bf6fdf04f9f302f2dbcb05353be16604c8517c91b77d7b7c3a65fa
52	2026-08-14 10:32:16	item_created	{"item_id": "ITM-RAM-01", "name": "Corsair DDR5 32GB 6000MHz RAM"}	28190f3523bf6fdf04f9f302f2dbcb05353be16604c8517c91b77d7b7c3a65fa	af955d7ffdafa661cef81e7a21446852e89fb8fcdc0a98f8ec84746427635f0f
53	2026-08-14 10:32:16	item_created	{"item_id": "ITM-SSD-01", "name": "Samsung 990 Pro 2TB NVMe SSD"}	af955d7ffdafa661cef81e7a21446852e89fb8fcdc0a98f8ec84746427635f0f	3408cb75e19fe589168ae245d24682d38de950a6149028118a9161bfd37479a1
54	2026-08-14 10:32:16	item_created	{"item_id": "ITM-HDD-01", "name": "WD Red Pro 8TB NAS Hard Drive"}	3408cb75e19fe589168ae245d24682d38de950a6149028118a9161bfd37479a1	3c164f761278bc8ae6057a8bf9a2f5bd1892bdaada0a83611a909d2fa210c9cf
55	2026-08-14 10:32:16	item_created	{"item_id": "ITM-CHG-01", "name": "Anker 100W GaN Wall Charger"}	3c164f761278bc8ae6057a8bf9a2f5bd1892bdaada0a83611a909d2fa210c9cf	a17dd3ee11cbd8527d35b7fd1fe0efc884a5feb12265b7e0b287d11e0cf1b6ab
56	2026-08-14 10:32:16	item_created	{"item_id": "ITM-CBL-01", "name": "Apple USB-C Braided Cable 2m"}	a17dd3ee11cbd8527d35b7fd1fe0efc884a5feb12265b7e0b287d11e0cf1b6ab	8cbeae454d22a1d79003bb8a29f4c3bdb2b1a72e1c6a2f11034f2df0792d196d
57	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-19"}	8cbeae454d22a1d79003bb8a29f4c3bdb2b1a72e1c6a2f11034f2df0792d196d	d947a151ac0b85661ca780713fb0f62bf0c94256f338d8a8d9dcd46bef5d8767
58	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-20"}	d947a151ac0b85661ca780713fb0f62bf0c94256f338d8a8d9dcd46bef5d8767	8c6ee87d1b34f5396689156a7ff4f242b930d61642121c93e90413fe7dddc153
59	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-21"}	8c6ee87d1b34f5396689156a7ff4f242b930d61642121c93e90413fe7dddc153	2663c6cc775172465d9d05d855f32fb5d273f61a3e64be65686453ecb340d90b
60	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	2663c6cc775172465d9d05d855f32fb5d273f61a3e64be65686453ecb340d90b	4644663a5d063468fb4bf2f9d3c54f6b99862a5e9b5868d137c2d830445f1e18
61	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-07-22"}	4644663a5d063468fb4bf2f9d3c54f6b99862a5e9b5868d137c2d830445f1e18	47727baa00800e51e760af268062651aa0bca98d234336d770d1fdb93e0e5770
62	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-25"}	47727baa00800e51e760af268062651aa0bca98d234336d770d1fdb93e0e5770	29b86809adc9278699f43465ad6d6486625da184970e7f56fa320fe85fef4d1b
63	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-26"}	29b86809adc9278699f43465ad6d6486625da184970e7f56fa320fe85fef4d1b	3f7322dad5e5a8a0dc0c27bd3a698999605c8cc537926e0dab92854a31b3b34c
64	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-26"}	3f7322dad5e5a8a0dc0c27bd3a698999605c8cc537926e0dab92854a31b3b34c	4e3baeb7afbf0380112666ffb34911f0243e0452c6b6d303990cd9b2ad8af378
65	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-28"}	4e3baeb7afbf0380112666ffb34911f0243e0452c6b6d303990cd9b2ad8af378	f49dad9fbbd91066b6660b8586ad3411111dcb9e038dfa37a8c86c8cf12263a6
66	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-29"}	f49dad9fbbd91066b6660b8586ad3411111dcb9e038dfa37a8c86c8cf12263a6	46cc90c2ff611fa17ee4ff236ba4c68b68e99eb05abd306c1295a28914d79d80
67	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-29"}	46cc90c2ff611fa17ee4ff236ba4c68b68e99eb05abd306c1295a28914d79d80	d3d8d8772c8dfd7edba5863c5d8d8479f3ecb7340da599cd871804a803de09a4
68	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-07-30"}	d3d8d8772c8dfd7edba5863c5d8d8479f3ecb7340da599cd871804a803de09a4	dfe65919c3b64766b0cf4d7b1496835222303c2715b59a1677708070841bd019
69	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CHG-01", "quantity": 150, "date": "2026-07-30"}	dfe65919c3b64766b0cf4d7b1496835222303c2715b59a1677708070841bd019	fb4006725e3b6f742b7258fcad67adee50cc036e1c225ce7fde29951465bc03d
70	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-07-31"}	fb4006725e3b6f742b7258fcad67adee50cc036e1c225ce7fde29951465bc03d	f36cd3cd9772543e7a70cd558e6d2905fe9ea91f6c8cc78fe176f6f59af00b38
71	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-01"}	f36cd3cd9772543e7a70cd558e6d2905fe9ea91f6c8cc78fe176f6f59af00b38	0e66dab4135c358542cfc51a0d45dc5bcf56f6b7a5e81f543669873316709142
72	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	0e66dab4135c358542cfc51a0d45dc5bcf56f6b7a5e81f543669873316709142	b48cb8cfd477cd885183d09266dd26edfea7d188030eefe1a9c6b54958b5c2c4
73	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CPU-01", "quantity": 45, "date": "2026-08-01"}	b48cb8cfd477cd885183d09266dd26edfea7d188030eefe1a9c6b54958b5c2c4	e45a909683be5a9ff9f10fb29203b52c1af073aaf9b0708b03778887e39d624e
74	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-02"}	e45a909683be5a9ff9f10fb29203b52c1af073aaf9b0708b03778887e39d624e	b718755102fc5dfea1183713c4d015c7acf4e254f5cb922bfcf24062ec6378d4
75	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-02"}	b718755102fc5dfea1183713c4d015c7acf4e254f5cb922bfcf24062ec6378d4	86bded208d02467281a864babc35a4fb26a61d0bd3ee5b3c094db54a08db166c
76	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-02"}	86bded208d02467281a864babc35a4fb26a61d0bd3ee5b3c094db54a08db166c	0b5eee4514c9510ac18f9d366fef6032cb727e9c80740fa796c13678211da2f7
77	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-03"}	0b5eee4514c9510ac18f9d366fef6032cb727e9c80740fa796c13678211da2f7	1f8a7565c151c5cc33c6477550a99d5ff54487670180ca25e88bd7910aab5cf6
78	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-03"}	1f8a7565c151c5cc33c6477550a99d5ff54487670180ca25e88bd7910aab5cf6	67113fed3f5ccb664841cc0a4621b81e9b789935eca2fc3e3f78ff7596ddfd66
79	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-05"}	67113fed3f5ccb664841cc0a4621b81e9b789935eca2fc3e3f78ff7596ddfd66	2b639d1de5a11cac8fdf6e6f4f6a54e50134dadfefb647795dc9b4de823787d8
80	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-06"}	2b639d1de5a11cac8fdf6e6f4f6a54e50134dadfefb647795dc9b4de823787d8	7fa0d4c49ca0175eff3b30e7b813a95d9d323c2fc6dae048802dbd7753ca5a39
81	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-07"}	7fa0d4c49ca0175eff3b30e7b813a95d9d323c2fc6dae048802dbd7753ca5a39	93711097f215f5df5eb6db8dd9b0258d7d37edf3a60bc455b00fbbbd56f19525
82	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-RAM-01", "quantity": 75, "date": "2026-08-08"}	93711097f215f5df5eb6db8dd9b0258d7d37edf3a60bc455b00fbbbd56f19525	c6c385e16b596ba610830009900b208dca4d19e38e51f2d422623adefdfb23dc
83	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-HDD-01", "quantity": 60, "date": "2026-08-08"}	c6c385e16b596ba610830009900b208dca4d19e38e51f2d422623adefdfb23dc	14f60b107d484617fa754896e6d3d2c8bdd9f93c7d8481d2036c4aa8ef4ce670
84	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BOM-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-08"}	14f60b107d484617fa754896e6d3d2c8bdd9f93c7d8481d2036c4aa8ef4ce670	31d10c862268308465dc09d529e03f3c97e0babce3a26c2b73a64133c6b806d9
85	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-DEL-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	31d10c862268308465dc09d529e03f3c97e0babce3a26c2b73a64133c6b806d9	a6add784e9e907c9d95a5aa7f6e08217be94112edb8bbbae183997c94ade938f
86	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-09"}	a6add784e9e907c9d95a5aa7f6e08217be94112edb8bbbae183997c94ade938f	4c83de7d66cba340f1237e630a52d647018e61667f5cfb83412fc9ca0730e40d
87	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CBL-01", "quantity": 300, "date": "2026-08-10"}	4c83de7d66cba340f1237e630a52d647018e61667f5cfb83412fc9ca0730e40d	52b513610a81bdd38252953810d4878330c46f871482e8deb4ff83f537200213
88	2026-08-14 10:32:16	simulated_restock	{"warehouse_id": "WH-CCU-01", "item_id": "ITM-GPU-01", "quantity": 30, "date": "2026-08-11"}	52b513610a81bdd38252953810d4878330c46f871482e8deb4ff83f537200213	f281129f8a1a92ba24e46ff233ea87823a37fa7d6c90ea5dfc3f447b95e54cfa
89	2026-08-14 10:32:16	shrinkage_flag	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-GPU-01", "likely_cause": "UNUSUAL_OUTBOUND_ACTIVITY"}	f281129f8a1a92ba24e46ff233ea87823a37fa7d6c90ea5dfc3f447b95e54cfa	7daa064abcef2e925a498b4d8582ae0c9fc16f4484044840ad295c92ad99ea9e
90	2026-08-14 10:32:16	shrinkage_flag	{"warehouse_id": "WH-CHN-01", "item_id": "ITM-CPU-01", "likely_cause": "POSSIBLE_DAMAGE_OR_WASTAGE"}	7daa064abcef2e925a498b4d8582ae0c9fc16f4484044840ad295c92ad99ea9e	512a1f6c2bddbe8a1de2d737f9cb2e9f5a66f3c453a1708bd7f720ca571e5904
91	2026-08-14 10:32:30	auto_cloud_backup	{"day": 1, "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-103230.json", "size_kb": 373.1, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-103230.json"}	512a1f6c2bddbe8a1de2d737f9cb2e9f5a66f3c453a1708bd7f720ca571e5904	de363723090a193ff54cca0fb77ae7e6900d961e5fd27d3f1816d88737021479
92	2026-08-14 11:06:06	admin_created	{"new_admin_username": "harsha200797+new@gmail.com", "full_name": "Test Admin", "created_by": "admin", "timestamp": "2026-08-14"}	de363723090a193ff54cca0fb77ae7e6900d961e5fd27d3f1816d88737021479	f68241e54ae977d79172ffeaccb40c7ebf9fcf1a6f8c9ded32a24b4c3940d74d
93	2026-08-14 11:10:47	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-111047.json", "size_kb": 375.6, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-111047.json"}	f68241e54ae977d79172ffeaccb40c7ebf9fcf1a6f8c9ded32a24b4c3940d74d	21ef4459852dc8e584b563bf43c1bdeb576b6dabec27e6dd7a46553088800808
94	2026-08-14 11:10:54	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-111054.json", "size_kb": 376.2, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-111054.json"}	21ef4459852dc8e584b563bf43c1bdeb576b6dabec27e6dd7a46553088800808	6ec1ef20e83af2c58b0a5f3e3086944d3275358e468990bca1424a5cc8600eed
95	2026-08-14 11:33:31	password_changed	{"username": "admin", "time": "2026-08-14"}	6ec1ef20e83af2c58b0a5f3e3086944d3275358e468990bca1424a5cc8600eed	b74a392ff372fc25304635e8f306d1114c99a0f91c17cd8c7f0f8fd353de355c
96	2026-08-14 11:40:57	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-14T11:40:57.900905"}	b74a392ff372fc25304635e8f306d1114c99a0f91c17cd8c7f0f8fd353de355c	a15baf8f62b736db2847d593a10f61bdb43c85e1f2048f1eedef170cd3f6d177
97	2026-08-14 11:41:03	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "APPROVED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Approved via AI Decision Center", "timestamp": "2026-08-14T11:41:03.675684"}	a15baf8f62b736db2847d593a10f61bdb43c85e1f2048f1eedef170cd3f6d177	a87f4aaafe3969158aacb0c1098044ef2dd369a6d34de7b94eadfdc89c95eb30
98	2026-08-14 11:41:15	ai_recommendation_action	{"recommendation_id": "REC-SHRINKAGE-WH-BLR-01-ITM-CBL-01", "item_id": "ITM-CBL-01", "action": "REJECTED", "decided_by": "harsha200797@gmail.com", "manager": "harsha200797@gmail.com", "notes": "Rejected via AI Decision Center", "timestamp": "2026-08-14T11:41:15.432149"}	a87f4aaafe3969158aacb0c1098044ef2dd369a6d34de7b94eadfdc89c95eb30	0606dd498e75406491d52028b12d87b9d0d387f582b23c1adbdfb00b60549196
99	2026-08-14 11:45:45	password_changed	{"username": "harsha200797@gmail.com", "time": "2026-08-14"}	0606dd498e75406491d52028b12d87b9d0d387f582b23c1adbdfb00b60549196	6e2a3e708743536e4b6169d955bbf9a20950343502d38d4509f1750653b4bde0
100	2026-08-14 12:08:06	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-120806.json", "size_kb": 381.0, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-120806.json"}	6e2a3e708743536e4b6169d955bbf9a20950343502d38d4509f1750653b4bde0	e6f66b3914b13908374db2e8d3e618157fd1c53bd3ef2a6683c8e84c120efd4b
101	2026-08-14 12:08:16	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-120816.json", "size_kb": 381.7, "mode": "Local Fallback (Demo)", "message": "AWS keys unconfigured/invalid. Saved local backup copy to project: data/backups/backup-20260814-120816.json"}	e6f66b3914b13908374db2e8d3e618157fd1c53bd3ef2a6683c8e84c120efd4b	2561ce2e0a24827fff7867bbb359b9f4bfa35fd85a5316f310ddec84a261a2a7
102	2026-08-14 12:25:18	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-122518.json", "size_kb": 382.7, "mode": "Local Fallback (Demo)", "message": "Cloud keys unconfigured/invalid. Saved local backup: data/backups/backup-20260814-122518.json"}	2561ce2e0a24827fff7867bbb359b9f4bfa35fd85a5316f310ddec84a261a2a7	6c64e2f16151bf67805b34e34064e92523b2000507f8c454e8f32c726b705a03
103	2026-08-14 12:38:20	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260814-123805.json", "size_kb": 383.5, "mode": "Local Fallback (Demo)", "message": "Cloud keys unconfigured/invalid. Saved local backup: data/backups/backup-20260814-123805.json"}	6c64e2f16151bf67805b34e34064e92523b2000507f8c454e8f32c726b705a03	446c656ffee74615e54be8ac52e9c12d9c5e83d9c0d2afd391341d5e5b4cc531
104	2026-08-15 07:02:39	auto_cloud_backup	{"day": 2, "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260815-070212.json", "size_kb": 384.5, "mode": "Local Fallback (Demo)", "message": "Cloud keys unconfigured/invalid. Saved local backup: data/backups/backup-20260815-070212.json"}	446c656ffee74615e54be8ac52e9c12d9c5e83d9c0d2afd391341d5e5b4cc531	dd5d0e8f377b6fe7445c6329d12849fa1d9605882bf35d648dc21f5f0b9cf46f
105	2026-08-15 07:46:48	admin_created	{"new_admin_username": "testadmin_1786780003@gmail.com", "full_name": "Test Administrator", "created_by": "admin", "timestamp": "2026-08-15"}	dd5d0e8f377b6fe7445c6329d12849fa1d9605882bf35d648dc21f5f0b9cf46f	e69c4570d4781be51d327b6d16eaa65ca8ef99848968565b90feb4e0e9e09e24
106	2026-08-15 07:47:32	admin_created	{"new_admin_username": "testadmin_1786780047@gmail.com", "full_name": "Test Administrator", "created_by": "admin", "timestamp": "2026-08-15"}	e69c4570d4781be51d327b6d16eaa65ca8ef99848968565b90feb4e0e9e09e24	4bd2228f0bfde8ed7d12a73ba7561425a07ad0be743e8108f6a93e796b8f8327
107	2026-08-15 08:28:10	cloud_backup	{"triggered_by": "harsha200797@gmail.com", "bucket": "Local storage (Fallback)", "file_key": "data/backups/backup-20260815-082759.json", "size_kb": 389.0, "mode": "Local Fallback (Demo)", "message": "Cloud keys unconfigured/invalid. Saved local backup: data/backups/backup-20260815-082759.json"}	4bd2228f0bfde8ed7d12a73ba7561425a07ad0be743e8108f6a93e796b8f8327	4fd605456925b5c9aff8cf35f2ab7e228b58a464673405ef3132e3c8cb440857
108	2026-08-15 13:10:08	stock_entry	{"warehouse_id": "WH-BLR-01", "item_id": "ITM-CPU-01", "date": "2026-08-15", "stock_in": 10, "stock_out": 10, "entered_by": "harsha200797@gmail.com"}	4fd605456925b5c9aff8cf35f2ab7e228b58a464673405ef3132e3c8cb440857	0d578b7bbf6c7317975239cf780a733abe69ec7a333ada1a7c15835b5f677f6b
109	2026-08-15 14:03:01	stock_entry	{"warehouse_id": "WH-BLR-01", "item_id": "ITM005", "date": "2026-08-15", "stock_in": 50, "stock_out": 100, "entered_by": "harsha200797@gmail.com"}	0d578b7bbf6c7317975239cf780a733abe69ec7a333ada1a7c15835b5f677f6b	5cd85a3e5b70ddeee37768fdf1044d84c5207cbb321aa54e248e8b508aff3889
\.


--
-- Data for Name: backup_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_records (id, backup_id, filename, created_at, size_bytes, sha256, status, storage_key, error_message) FROM stdin;
1	BK-DA049020A9ED7691	warehouse_sqlite_2026-08-15_12-52-33.db.gz	2026-08-15 12:52:37.900197	57591	2cb59143d8b46715acce3bee8c68a47dd4c2f59e8cf38140799770a06db5350b	FAILED	data/backups/warehouse_sqlite_2026-08-15_12-52-33.db.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
2	BK-503EA0B0E548C2B0	warehouse_sqlite_2026-08-15_13-40-26.db.gz	2026-08-15 13:40:30.907048	58321	b7ade5907b2aea645956bb369ebe9a224ce714295e3c2b61f1ac27ee599803a0	FAILED	data/backups/warehouse_sqlite_2026-08-15_13-40-26.db.gz	B2 Upload failed: An error occurred (UnauthorizedAccess) when calling the PutObject operation: Seed signature is invalid
3	BK-734D48994FBE3917	warehouse_postgres_2026-08-15_15-01-04.sql.gz	2026-08-15 15:01:04.033906	0		FAILED		Backup Dump Failed: pg_dump utility is not installed or not in system PATH.
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id, name, category, unit_cost, lead_time_days, safety_stock, created_at) FROM stdin;
ITM-CPU-01	AMD Ryzen 9 7900X Processor	Electronics	38000	5	15	2026-08-14 10:32:16.37645
ITM-GPU-01	Nvidia RTX 4080 Founders Edition	Electronics	95000	7	10	2026-08-14 10:32:16.381483
ITM-RAM-01	Corsair DDR5 32GB 6000MHz RAM	Electronics	8500	4	25	2026-08-14 10:32:16.385892
ITM-SSD-01	Samsung 990 Pro 2TB NVMe SSD	Storage	12000	3	30	2026-08-14 10:32:16.392356
ITM-HDD-01	WD Red Pro 8TB NAS Hard Drive	Storage	16500	5	20	2026-08-14 10:32:16.397473
ITM-CHG-01	Anker 100W GaN Wall Charger	Accessories	2500	2	50	2026-08-14 10:32:16.40165
ITM-CBL-01	Apple USB-C Braided Cable 2m	Accessories	800	1	100	2026-08-14 10:32:16.407314
ITM005	maggi	food	5000	2	200	2026-08-15 13:10:36.011195
ITM-food-05	maggi	food	1900	2	100	2026-08-15 14:00:37.114937
\.


--
-- Data for Name: recovery_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recovery_codes (id, user_id, code_hash, used, created_at, used_at) FROM stdin;
\.


--
-- Data for Name: recovery_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recovery_credentials (id, user_id, password_hash, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shrinkage_flags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shrinkage_flags (id, date, warehouse_id, item_id, item_name, deviation_score, expected_quantity, actual_quantity, discrepancy_quantity, estimated_exposure, severity, likely_cause, explanation) FROM stdin;
1	2026-08-05	WH-BLR-01	ITM-GPU-01	Nvidia RTX 4080 Founders Edition	0.85	15	5	-10	950000	CRITICAL	UNUSUAL_OUTBOUND_ACTIVITY	Sudden unrecorded drop of 10 units (Valued at ₹9,50,000) occurred outside regular stock-out operations.
2	2026-07-25	WH-CHN-01	ITM-CPU-01	AMD Ryzen 9 7900X Processor	0.72	20	5	-15	570000	HIGH	POSSIBLE_DAMAGE_OR_WASTAGE	Discrepancy of 15 units (Valued at ₹5,70,000) reported at the dock. Unrecorded scraping suspected.
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, date, warehouse_id, item_id, stock_in, stock_out, closing_stock, is_anomaly, anomaly_type, entry_source, entered_by) FROM stdin;
1	2026-07-13	WH-BLR-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
2	2026-07-13	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
3	2026-07-13	WH-BLR-01	ITM-RAM-01	0	6	69	f	none	simulated	system_sim
4	2026-07-13	WH-BLR-01	ITM-SSD-01	0	2	88	f	none	simulated	system_sim
5	2026-07-13	WH-BLR-01	ITM-HDD-01	0	2	58	f	none	simulated	system_sim
6	2026-07-13	WH-BLR-01	ITM-CHG-01	0	7	143	f	none	simulated	system_sim
7	2026-07-13	WH-BLR-01	ITM-CBL-01	0	8	292	f	none	simulated	system_sim
8	2026-07-13	WH-CHN-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
9	2026-07-13	WH-CHN-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
10	2026-07-13	WH-CHN-01	ITM-RAM-01	0	9	66	f	none	simulated	system_sim
11	2026-07-13	WH-CHN-01	ITM-SSD-01	0	2	88	f	none	simulated	system_sim
12	2026-07-13	WH-CHN-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
13	2026-07-13	WH-CHN-01	ITM-CHG-01	0	4	146	f	none	simulated	system_sim
14	2026-07-13	WH-CHN-01	ITM-CBL-01	0	1	299	f	none	simulated	system_sim
15	2026-07-13	WH-BOM-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
16	2026-07-13	WH-BOM-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
17	2026-07-13	WH-BOM-01	ITM-RAM-01	0	10	65	f	none	simulated	system_sim
18	2026-07-13	WH-BOM-01	ITM-SSD-01	0	2	88	f	none	simulated	system_sim
19	2026-07-13	WH-BOM-01	ITM-HDD-01	0	3	57	f	none	simulated	system_sim
20	2026-07-13	WH-BOM-01	ITM-CHG-01	0	4	146	f	none	simulated	system_sim
21	2026-07-13	WH-BOM-01	ITM-CBL-01	0	2	298	f	none	simulated	system_sim
22	2026-07-13	WH-DEL-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
23	2026-07-13	WH-DEL-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
24	2026-07-13	WH-DEL-01	ITM-RAM-01	0	6	69	f	none	simulated	system_sim
25	2026-07-13	WH-DEL-01	ITM-SSD-01	0	1	89	f	none	simulated	system_sim
26	2026-07-13	WH-DEL-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
27	2026-07-13	WH-DEL-01	ITM-CHG-01	0	4	146	f	none	simulated	system_sim
28	2026-07-13	WH-DEL-01	ITM-CBL-01	0	7	293	f	none	simulated	system_sim
29	2026-07-13	WH-CCU-01	ITM-CPU-01	0	0	45	f	none	simulated	system_sim
30	2026-07-13	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
31	2026-07-13	WH-CCU-01	ITM-RAM-01	0	1	74	f	none	simulated	system_sim
32	2026-07-13	WH-CCU-01	ITM-SSD-01	0	3	87	f	none	simulated	system_sim
33	2026-07-13	WH-CCU-01	ITM-HDD-01	0	3	57	f	none	simulated	system_sim
34	2026-07-13	WH-CCU-01	ITM-CHG-01	0	7	143	f	none	simulated	system_sim
35	2026-07-13	WH-CCU-01	ITM-CBL-01	0	1	299	f	none	simulated	system_sim
36	2026-07-14	WH-BLR-01	ITM-CPU-01	0	2	43	f	none	simulated	system_sim
37	2026-07-14	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
38	2026-07-14	WH-BLR-01	ITM-RAM-01	0	7	62	f	none	simulated	system_sim
39	2026-07-14	WH-BLR-01	ITM-SSD-01	0	2	86	f	none	simulated	system_sim
40	2026-07-14	WH-BLR-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
41	2026-07-14	WH-BLR-01	ITM-CHG-01	0	6	137	f	none	simulated	system_sim
42	2026-07-14	WH-BLR-01	ITM-CBL-01	0	7	285	f	none	simulated	system_sim
43	2026-07-14	WH-CHN-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
44	2026-07-14	WH-CHN-01	ITM-GPU-01	0	2	28	f	none	simulated	system_sim
45	2026-07-14	WH-CHN-01	ITM-RAM-01	0	7	59	f	none	simulated	system_sim
46	2026-07-14	WH-CHN-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
47	2026-07-14	WH-CHN-01	ITM-HDD-01	0	1	59	f	none	simulated	system_sim
48	2026-07-14	WH-CHN-01	ITM-CHG-01	0	7	139	f	none	simulated	system_sim
49	2026-07-14	WH-CHN-01	ITM-CBL-01	0	4	295	f	none	simulated	system_sim
50	2026-07-14	WH-BOM-01	ITM-CPU-01	0	1	44	f	none	simulated	system_sim
51	2026-07-14	WH-BOM-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
52	2026-07-14	WH-BOM-01	ITM-RAM-01	0	4	61	f	none	simulated	system_sim
53	2026-07-14	WH-BOM-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
54	2026-07-14	WH-BOM-01	ITM-HDD-01	0	3	54	f	none	simulated	system_sim
55	2026-07-14	WH-BOM-01	ITM-CHG-01	0	4	142	f	none	simulated	system_sim
56	2026-07-14	WH-BOM-01	ITM-CBL-01	0	3	295	f	none	simulated	system_sim
57	2026-07-14	WH-DEL-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
58	2026-07-14	WH-DEL-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
59	2026-07-14	WH-DEL-01	ITM-RAM-01	0	6	63	f	none	simulated	system_sim
60	2026-07-14	WH-DEL-01	ITM-SSD-01	0	0	89	f	none	simulated	system_sim
61	2026-07-14	WH-DEL-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
62	2026-07-14	WH-DEL-01	ITM-CHG-01	0	10	136	f	none	simulated	system_sim
63	2026-07-14	WH-DEL-01	ITM-CBL-01	0	7	286	f	none	simulated	system_sim
64	2026-07-14	WH-CCU-01	ITM-CPU-01	0	3	42	f	none	simulated	system_sim
65	2026-07-14	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
66	2026-07-14	WH-CCU-01	ITM-RAM-01	0	9	65	f	none	simulated	system_sim
67	2026-07-14	WH-CCU-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
68	2026-07-14	WH-CCU-01	ITM-HDD-01	0	3	54	f	none	simulated	system_sim
69	2026-07-14	WH-CCU-01	ITM-CHG-01	0	4	139	f	none	simulated	system_sim
70	2026-07-14	WH-CCU-01	ITM-CBL-01	0	7	292	f	none	simulated	system_sim
71	2026-07-15	WH-BLR-01	ITM-CPU-01	0	1	42	f	none	simulated	system_sim
72	2026-07-15	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
73	2026-07-15	WH-BLR-01	ITM-RAM-01	0	4	58	f	none	simulated	system_sim
74	2026-07-15	WH-BLR-01	ITM-SSD-01	0	3	83	f	none	simulated	system_sim
75	2026-07-15	WH-BLR-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
76	2026-07-15	WH-BLR-01	ITM-CHG-01	0	9	128	f	none	simulated	system_sim
77	2026-07-15	WH-BLR-01	ITM-CBL-01	0	4	281	f	none	simulated	system_sim
78	2026-07-15	WH-CHN-01	ITM-CPU-01	0	2	40	f	none	simulated	system_sim
79	2026-07-15	WH-CHN-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
80	2026-07-15	WH-CHN-01	ITM-RAM-01	0	1	58	f	none	simulated	system_sim
81	2026-07-15	WH-CHN-01	ITM-SSD-01	0	3	85	f	none	simulated	system_sim
82	2026-07-15	WH-CHN-01	ITM-HDD-01	0	3	56	f	none	simulated	system_sim
83	2026-07-15	WH-CHN-01	ITM-CHG-01	0	5	134	f	none	simulated	system_sim
84	2026-07-15	WH-CHN-01	ITM-CBL-01	0	9	286	f	none	simulated	system_sim
85	2026-07-15	WH-BOM-01	ITM-CPU-01	0	3	41	f	none	simulated	system_sim
86	2026-07-15	WH-BOM-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
87	2026-07-15	WH-BOM-01	ITM-RAM-01	0	3	58	f	none	simulated	system_sim
88	2026-07-15	WH-BOM-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
89	2026-07-15	WH-BOM-01	ITM-HDD-01	0	0	54	f	none	simulated	system_sim
90	2026-07-15	WH-BOM-01	ITM-CHG-01	0	5	137	f	none	simulated	system_sim
91	2026-07-15	WH-BOM-01	ITM-CBL-01	0	7	288	f	none	simulated	system_sim
92	2026-07-15	WH-DEL-01	ITM-CPU-01	0	3	39	f	none	simulated	system_sim
93	2026-07-15	WH-DEL-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
94	2026-07-15	WH-DEL-01	ITM-RAM-01	0	3	60	f	none	simulated	system_sim
95	2026-07-15	WH-DEL-01	ITM-SSD-01	0	1	88	f	none	simulated	system_sim
96	2026-07-15	WH-DEL-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
97	2026-07-15	WH-DEL-01	ITM-CHG-01	0	4	132	f	none	simulated	system_sim
98	2026-07-15	WH-DEL-01	ITM-CBL-01	0	4	282	f	none	simulated	system_sim
99	2026-07-15	WH-CCU-01	ITM-CPU-01	0	2	40	f	none	simulated	system_sim
100	2026-07-15	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
101	2026-07-15	WH-CCU-01	ITM-RAM-01	0	8	57	f	none	simulated	system_sim
102	2026-07-15	WH-CCU-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
103	2026-07-15	WH-CCU-01	ITM-HDD-01	0	2	52	f	none	simulated	system_sim
104	2026-07-15	WH-CCU-01	ITM-CHG-01	0	5	134	f	none	simulated	system_sim
105	2026-07-15	WH-CCU-01	ITM-CBL-01	0	1	291	f	none	simulated	system_sim
106	2026-07-16	WH-BLR-01	ITM-CPU-01	0	0	42	f	none	simulated	system_sim
107	2026-07-16	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
108	2026-07-16	WH-BLR-01	ITM-RAM-01	0	2	56	f	none	simulated	system_sim
109	2026-07-16	WH-BLR-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
110	2026-07-16	WH-BLR-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
111	2026-07-16	WH-BLR-01	ITM-CHG-01	0	7	121	f	none	simulated	system_sim
112	2026-07-16	WH-BLR-01	ITM-CBL-01	0	9	272	f	none	simulated	system_sim
113	2026-07-16	WH-CHN-01	ITM-CPU-01	0	0	40	f	none	simulated	system_sim
114	2026-07-16	WH-CHN-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
115	2026-07-16	WH-CHN-01	ITM-RAM-01	0	5	53	f	none	simulated	system_sim
116	2026-07-16	WH-CHN-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
117	2026-07-16	WH-CHN-01	ITM-HDD-01	0	1	55	f	none	simulated	system_sim
118	2026-07-16	WH-CHN-01	ITM-CHG-01	0	10	124	f	none	simulated	system_sim
119	2026-07-16	WH-CHN-01	ITM-CBL-01	0	3	283	f	none	simulated	system_sim
120	2026-07-16	WH-BOM-01	ITM-CPU-01	0	3	38	f	none	simulated	system_sim
121	2026-07-16	WH-BOM-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
122	2026-07-16	WH-BOM-01	ITM-RAM-01	0	3	55	f	none	simulated	system_sim
123	2026-07-16	WH-BOM-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
124	2026-07-16	WH-BOM-01	ITM-HDD-01	0	2	52	f	none	simulated	system_sim
125	2026-07-16	WH-BOM-01	ITM-CHG-01	0	4	133	f	none	simulated	system_sim
126	2026-07-16	WH-BOM-01	ITM-CBL-01	0	3	285	f	none	simulated	system_sim
127	2026-07-16	WH-DEL-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
128	2026-07-16	WH-DEL-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
129	2026-07-16	WH-DEL-01	ITM-RAM-01	0	1	59	f	none	simulated	system_sim
130	2026-07-16	WH-DEL-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
131	2026-07-16	WH-DEL-01	ITM-HDD-01	0	0	60	f	none	simulated	system_sim
132	2026-07-16	WH-DEL-01	ITM-CHG-01	0	6	126	f	none	simulated	system_sim
133	2026-07-16	WH-DEL-01	ITM-CBL-01	0	1	281	f	none	simulated	system_sim
134	2026-07-16	WH-CCU-01	ITM-CPU-01	0	2	38	f	none	simulated	system_sim
135	2026-07-16	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
136	2026-07-16	WH-CCU-01	ITM-RAM-01	0	7	50	f	none	simulated	system_sim
137	2026-07-16	WH-CCU-01	ITM-SSD-01	0	3	84	f	none	simulated	system_sim
138	2026-07-16	WH-CCU-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
139	2026-07-16	WH-CCU-01	ITM-CHG-01	0	5	129	f	none	simulated	system_sim
140	2026-07-16	WH-CCU-01	ITM-CBL-01	0	9	282	f	none	simulated	system_sim
141	2026-07-17	WH-BLR-01	ITM-CPU-01	0	3	39	f	none	simulated	system_sim
142	2026-07-17	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
143	2026-07-17	WH-BLR-01	ITM-RAM-01	0	5	51	f	none	simulated	system_sim
144	2026-07-17	WH-BLR-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
145	2026-07-17	WH-BLR-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
146	2026-07-17	WH-BLR-01	ITM-CHG-01	0	6	115	f	none	simulated	system_sim
147	2026-07-17	WH-BLR-01	ITM-CBL-01	0	10	262	f	none	simulated	system_sim
148	2026-07-17	WH-CHN-01	ITM-CPU-01	0	2	38	f	none	simulated	system_sim
149	2026-07-17	WH-CHN-01	ITM-GPU-01	0	1	26	f	none	simulated	system_sim
150	2026-07-17	WH-CHN-01	ITM-RAM-01	0	2	51	f	none	simulated	system_sim
151	2026-07-17	WH-CHN-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
152	2026-07-17	WH-CHN-01	ITM-HDD-01	0	0	55	f	none	simulated	system_sim
153	2026-07-17	WH-CHN-01	ITM-CHG-01	0	7	117	f	none	simulated	system_sim
154	2026-07-17	WH-CHN-01	ITM-CBL-01	0	9	274	f	none	simulated	system_sim
155	2026-07-17	WH-BOM-01	ITM-CPU-01	0	3	35	f	none	simulated	system_sim
156	2026-07-17	WH-BOM-01	ITM-GPU-01	0	1	28	f	none	simulated	system_sim
157	2026-07-17	WH-BOM-01	ITM-RAM-01	0	6	49	f	none	simulated	system_sim
158	2026-07-17	WH-BOM-01	ITM-SSD-01	0	0	88	f	none	simulated	system_sim
159	2026-07-17	WH-BOM-01	ITM-HDD-01	0	3	49	f	none	simulated	system_sim
160	2026-07-17	WH-BOM-01	ITM-CHG-01	0	9	124	f	none	simulated	system_sim
161	2026-07-17	WH-BOM-01	ITM-CBL-01	0	3	282	f	none	simulated	system_sim
162	2026-07-17	WH-DEL-01	ITM-CPU-01	0	0	39	f	none	simulated	system_sim
163	2026-07-17	WH-DEL-01	ITM-GPU-01	0	2	27	f	none	simulated	system_sim
164	2026-07-17	WH-DEL-01	ITM-RAM-01	0	10	49	f	none	simulated	system_sim
165	2026-07-17	WH-DEL-01	ITM-SSD-01	0	1	87	f	none	simulated	system_sim
166	2026-07-17	WH-DEL-01	ITM-HDD-01	0	1	59	f	none	simulated	system_sim
167	2026-07-17	WH-DEL-01	ITM-CHG-01	0	9	117	f	none	simulated	system_sim
168	2026-07-17	WH-DEL-01	ITM-CBL-01	0	5	276	f	none	simulated	system_sim
169	2026-07-17	WH-CCU-01	ITM-CPU-01	0	2	36	f	none	simulated	system_sim
170	2026-07-17	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
171	2026-07-17	WH-CCU-01	ITM-RAM-01	0	9	41	f	none	simulated	system_sim
172	2026-07-17	WH-CCU-01	ITM-SSD-01	0	1	83	f	none	simulated	system_sim
173	2026-07-17	WH-CCU-01	ITM-HDD-01	0	0	52	f	none	simulated	system_sim
174	2026-07-17	WH-CCU-01	ITM-CHG-01	0	2	127	f	none	simulated	system_sim
175	2026-07-17	WH-CCU-01	ITM-CBL-01	0	9	273	f	none	simulated	system_sim
176	2026-07-18	WH-BLR-01	ITM-CPU-01	0	2	37	f	none	simulated	system_sim
177	2026-07-18	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
178	2026-07-18	WH-BLR-01	ITM-RAM-01	0	7	44	f	none	simulated	system_sim
179	2026-07-18	WH-BLR-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
180	2026-07-18	WH-BLR-01	ITM-HDD-01	0	3	55	f	none	simulated	system_sim
181	2026-07-18	WH-BLR-01	ITM-CHG-01	0	4	111	f	none	simulated	system_sim
182	2026-07-18	WH-BLR-01	ITM-CBL-01	0	1	261	f	none	simulated	system_sim
183	2026-07-18	WH-CHN-01	ITM-CPU-01	0	2	36	f	none	simulated	system_sim
184	2026-07-18	WH-CHN-01	ITM-GPU-01	0	2	24	f	none	simulated	system_sim
185	2026-07-18	WH-CHN-01	ITM-RAM-01	0	5	46	f	none	simulated	system_sim
186	2026-07-18	WH-CHN-01	ITM-SSD-01	0	0	85	f	none	simulated	system_sim
187	2026-07-18	WH-CHN-01	ITM-HDD-01	0	1	54	f	none	simulated	system_sim
188	2026-07-18	WH-CHN-01	ITM-CHG-01	0	6	111	f	none	simulated	system_sim
189	2026-07-18	WH-CHN-01	ITM-CBL-01	0	4	270	f	none	simulated	system_sim
190	2026-07-18	WH-BOM-01	ITM-CPU-01	0	1	34	f	none	simulated	system_sim
191	2026-07-18	WH-BOM-01	ITM-GPU-01	0	0	28	f	none	simulated	system_sim
192	2026-07-18	WH-BOM-01	ITM-RAM-01	0	3	46	f	none	simulated	system_sim
193	2026-07-18	WH-BOM-01	ITM-SSD-01	0	2	86	f	none	simulated	system_sim
194	2026-07-18	WH-BOM-01	ITM-HDD-01	0	3	46	f	none	simulated	system_sim
195	2026-07-18	WH-BOM-01	ITM-CHG-01	0	5	119	f	none	simulated	system_sim
196	2026-07-18	WH-BOM-01	ITM-CBL-01	0	2	280	f	none	simulated	system_sim
197	2026-07-18	WH-DEL-01	ITM-CPU-01	0	2	37	f	none	simulated	system_sim
198	2026-07-18	WH-DEL-01	ITM-GPU-01	0	0	27	f	none	simulated	system_sim
199	2026-07-18	WH-DEL-01	ITM-RAM-01	0	6	43	f	none	simulated	system_sim
200	2026-07-18	WH-DEL-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
201	2026-07-18	WH-DEL-01	ITM-HDD-01	0	0	59	f	none	simulated	system_sim
202	2026-07-18	WH-DEL-01	ITM-CHG-01	0	6	111	f	none	simulated	system_sim
203	2026-07-18	WH-DEL-01	ITM-CBL-01	0	8	268	f	none	simulated	system_sim
204	2026-07-18	WH-CCU-01	ITM-CPU-01	0	2	34	f	none	simulated	system_sim
205	2026-07-18	WH-CCU-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
206	2026-07-18	WH-CCU-01	ITM-RAM-01	0	6	35	f	none	simulated	system_sim
207	2026-07-18	WH-CCU-01	ITM-SSD-01	0	1	82	f	none	simulated	system_sim
208	2026-07-18	WH-CCU-01	ITM-HDD-01	0	2	50	f	none	simulated	system_sim
209	2026-07-18	WH-CCU-01	ITM-CHG-01	0	9	118	f	none	simulated	system_sim
210	2026-07-18	WH-CCU-01	ITM-CBL-01	0	1	272	f	none	simulated	system_sim
211	2026-07-19	WH-BLR-01	ITM-CPU-01	0	1	36	f	none	simulated	system_sim
212	2026-07-19	WH-BLR-01	ITM-GPU-01	0	2	28	f	none	simulated	system_sim
213	2026-07-19	WH-BLR-01	ITM-RAM-01	0	2	42	f	none	simulated	system_sim
214	2026-07-19	WH-BLR-01	ITM-SSD-01	0	2	81	f	none	simulated	system_sim
215	2026-07-19	WH-BLR-01	ITM-HDD-01	0	3	52	f	none	simulated	system_sim
216	2026-07-19	WH-BLR-01	ITM-CHG-01	0	3	108	f	none	simulated	system_sim
217	2026-07-19	WH-BLR-01	ITM-CBL-01	0	5	256	f	none	simulated	system_sim
218	2026-07-19	WH-CHN-01	ITM-CPU-01	0	2	34	f	none	simulated	system_sim
219	2026-07-19	WH-CHN-01	ITM-GPU-01	0	2	22	f	none	simulated	system_sim
220	2026-07-19	WH-CHN-01	ITM-RAM-01	0	9	37	f	none	simulated	system_sim
221	2026-07-19	WH-CHN-01	ITM-SSD-01	0	1	84	f	none	simulated	system_sim
222	2026-07-19	WH-CHN-01	ITM-HDD-01	0	0	54	f	none	simulated	system_sim
223	2026-07-19	WH-CHN-01	ITM-CHG-01	0	1	110	f	none	simulated	system_sim
224	2026-07-19	WH-CHN-01	ITM-CBL-01	0	2	268	f	none	simulated	system_sim
225	2026-07-19	WH-BOM-01	ITM-CPU-01	0	3	31	f	none	simulated	system_sim
226	2026-07-19	WH-BOM-01	ITM-GPU-01	0	2	26	f	none	simulated	system_sim
227	2026-07-19	WH-BOM-01	ITM-RAM-01	0	7	39	f	none	simulated	system_sim
228	2026-07-19	WH-BOM-01	ITM-SSD-01	0	1	85	f	none	simulated	system_sim
229	2026-07-19	WH-BOM-01	ITM-HDD-01	0	0	46	f	none	simulated	system_sim
230	2026-07-19	WH-BOM-01	ITM-CHG-01	0	10	109	f	none	simulated	system_sim
231	2026-07-19	WH-BOM-01	ITM-CBL-01	0	2	278	f	none	simulated	system_sim
232	2026-07-19	WH-DEL-01	ITM-CPU-01	0	2	35	f	none	simulated	system_sim
233	2026-07-19	WH-DEL-01	ITM-GPU-01	0	1	26	f	none	simulated	system_sim
234	2026-07-19	WH-DEL-01	ITM-RAM-01	0	1	42	f	none	simulated	system_sim
235	2026-07-19	WH-DEL-01	ITM-SSD-01	0	0	87	f	none	simulated	system_sim
236	2026-07-19	WH-DEL-01	ITM-HDD-01	0	0	59	f	none	simulated	system_sim
237	2026-07-19	WH-DEL-01	ITM-CHG-01	0	7	104	f	none	simulated	system_sim
238	2026-07-19	WH-DEL-01	ITM-CBL-01	0	6	262	f	none	simulated	system_sim
239	2026-07-19	WH-CCU-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
240	2026-07-19	WH-CCU-01	ITM-GPU-01	0	2	28	f	none	simulated	system_sim
241	2026-07-19	WH-CCU-01	ITM-RAM-01	75	5	105	f	none	simulated	system_sim
242	2026-07-19	WH-CCU-01	ITM-SSD-01	0	0	82	f	none	simulated	system_sim
243	2026-07-19	WH-CCU-01	ITM-HDD-01	0	1	49	f	none	simulated	system_sim
244	2026-07-19	WH-CCU-01	ITM-CHG-01	0	10	108	f	none	simulated	system_sim
245	2026-07-19	WH-CCU-01	ITM-CBL-01	0	5	267	f	none	simulated	system_sim
246	2026-07-20	WH-BLR-01	ITM-CPU-01	0	2	34	f	none	simulated	system_sim
247	2026-07-20	WH-BLR-01	ITM-GPU-01	0	2	26	f	none	simulated	system_sim
248	2026-07-20	WH-BLR-01	ITM-RAM-01	0	5	37	f	none	simulated	system_sim
249	2026-07-20	WH-BLR-01	ITM-SSD-01	0	2	79	f	none	simulated	system_sim
250	2026-07-20	WH-BLR-01	ITM-HDD-01	0	2	50	f	none	simulated	system_sim
251	2026-07-20	WH-BLR-01	ITM-CHG-01	0	2	106	f	none	simulated	system_sim
252	2026-07-20	WH-BLR-01	ITM-CBL-01	0	9	247	f	none	simulated	system_sim
253	2026-07-20	WH-CHN-01	ITM-CPU-01	0	1	33	f	none	simulated	system_sim
254	2026-07-20	WH-CHN-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
255	2026-07-20	WH-CHN-01	ITM-RAM-01	75	3	109	f	none	simulated	system_sim
256	2026-07-20	WH-CHN-01	ITM-SSD-01	0	1	83	f	none	simulated	system_sim
257	2026-07-20	WH-CHN-01	ITM-HDD-01	0	1	53	f	none	simulated	system_sim
258	2026-07-20	WH-CHN-01	ITM-CHG-01	0	2	108	f	none	simulated	system_sim
259	2026-07-20	WH-CHN-01	ITM-CBL-01	0	3	265	f	none	simulated	system_sim
260	2026-07-20	WH-BOM-01	ITM-CPU-01	0	0	31	f	none	simulated	system_sim
261	2026-07-20	WH-BOM-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
262	2026-07-20	WH-BOM-01	ITM-RAM-01	0	1	38	f	none	simulated	system_sim
263	2026-07-20	WH-BOM-01	ITM-SSD-01	0	1	84	f	none	simulated	system_sim
264	2026-07-20	WH-BOM-01	ITM-HDD-01	0	2	44	f	none	simulated	system_sim
265	2026-07-20	WH-BOM-01	ITM-CHG-01	0	7	102	f	none	simulated	system_sim
266	2026-07-20	WH-BOM-01	ITM-CBL-01	0	4	274	f	none	simulated	system_sim
267	2026-07-20	WH-DEL-01	ITM-CPU-01	0	3	32	f	none	simulated	system_sim
268	2026-07-20	WH-DEL-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
269	2026-07-20	WH-DEL-01	ITM-RAM-01	0	4	38	f	none	simulated	system_sim
270	2026-07-20	WH-DEL-01	ITM-SSD-01	0	2	85	f	none	simulated	system_sim
271	2026-07-20	WH-DEL-01	ITM-HDD-01	0	1	58	f	none	simulated	system_sim
272	2026-07-20	WH-DEL-01	ITM-CHG-01	0	5	99	f	none	simulated	system_sim
273	2026-07-20	WH-DEL-01	ITM-CBL-01	0	9	253	f	none	simulated	system_sim
274	2026-07-20	WH-CCU-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
275	2026-07-20	WH-CCU-01	ITM-GPU-01	0	1	27	f	none	simulated	system_sim
276	2026-07-20	WH-CCU-01	ITM-RAM-01	0	10	95	f	none	simulated	system_sim
277	2026-07-20	WH-CCU-01	ITM-SSD-01	0	1	81	f	none	simulated	system_sim
278	2026-07-20	WH-CCU-01	ITM-HDD-01	0	2	47	f	none	simulated	system_sim
279	2026-07-20	WH-CCU-01	ITM-CHG-01	0	1	107	f	none	simulated	system_sim
280	2026-07-20	WH-CCU-01	ITM-CBL-01	0	7	260	f	none	simulated	system_sim
281	2026-07-21	WH-BLR-01	ITM-CPU-01	0	3	31	f	none	simulated	system_sim
282	2026-07-21	WH-BLR-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
283	2026-07-21	WH-BLR-01	ITM-RAM-01	75	4	108	f	none	simulated	system_sim
284	2026-07-21	WH-BLR-01	ITM-SSD-01	0	0	79	f	none	simulated	system_sim
285	2026-07-21	WH-BLR-01	ITM-HDD-01	0	0	50	f	none	simulated	system_sim
286	2026-07-21	WH-BLR-01	ITM-CHG-01	0	3	103	f	none	simulated	system_sim
287	2026-07-21	WH-BLR-01	ITM-CBL-01	0	1	246	f	none	simulated	system_sim
288	2026-07-21	WH-CHN-01	ITM-CPU-01	0	0	33	f	none	simulated	system_sim
289	2026-07-21	WH-CHN-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
290	2026-07-21	WH-CHN-01	ITM-RAM-01	0	7	102	f	none	simulated	system_sim
291	2026-07-21	WH-CHN-01	ITM-SSD-01	0	3	80	f	none	simulated	system_sim
292	2026-07-21	WH-CHN-01	ITM-HDD-01	0	0	53	f	none	simulated	system_sim
293	2026-07-21	WH-CHN-01	ITM-CHG-01	0	9	99	f	none	simulated	system_sim
294	2026-07-21	WH-CHN-01	ITM-CBL-01	0	3	262	f	none	simulated	system_sim
295	2026-07-21	WH-BOM-01	ITM-CPU-01	0	0	31	f	none	simulated	system_sim
296	2026-07-21	WH-BOM-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
297	2026-07-21	WH-BOM-01	ITM-RAM-01	0	2	36	f	none	simulated	system_sim
298	2026-07-21	WH-BOM-01	ITM-SSD-01	0	0	84	f	none	simulated	system_sim
299	2026-07-21	WH-BOM-01	ITM-HDD-01	0	1	43	f	none	simulated	system_sim
300	2026-07-21	WH-BOM-01	ITM-CHG-01	0	7	95	f	none	simulated	system_sim
301	2026-07-21	WH-BOM-01	ITM-CBL-01	0	3	271	f	none	simulated	system_sim
302	2026-07-21	WH-DEL-01	ITM-CPU-01	0	3	29	f	none	simulated	system_sim
303	2026-07-21	WH-DEL-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
304	2026-07-21	WH-DEL-01	ITM-RAM-01	0	9	29	f	none	simulated	system_sim
305	2026-07-21	WH-DEL-01	ITM-SSD-01	0	2	83	f	none	simulated	system_sim
306	2026-07-21	WH-DEL-01	ITM-HDD-01	0	0	58	f	none	simulated	system_sim
307	2026-07-21	WH-DEL-01	ITM-CHG-01	0	9	90	f	none	simulated	system_sim
308	2026-07-21	WH-DEL-01	ITM-CBL-01	0	10	243	f	none	simulated	system_sim
309	2026-07-21	WH-CCU-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
310	2026-07-21	WH-CCU-01	ITM-GPU-01	0	1	26	f	none	simulated	system_sim
311	2026-07-21	WH-CCU-01	ITM-RAM-01	0	6	89	f	none	simulated	system_sim
312	2026-07-21	WH-CCU-01	ITM-SSD-01	0	0	81	f	none	simulated	system_sim
313	2026-07-21	WH-CCU-01	ITM-HDD-01	0	2	45	f	none	simulated	system_sim
314	2026-07-21	WH-CCU-01	ITM-CHG-01	0	1	106	f	none	simulated	system_sim
315	2026-07-21	WH-CCU-01	ITM-CBL-01	0	9	251	f	none	simulated	system_sim
316	2026-07-22	WH-BLR-01	ITM-CPU-01	0	1	30	f	none	simulated	system_sim
317	2026-07-22	WH-BLR-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
318	2026-07-22	WH-BLR-01	ITM-RAM-01	0	2	106	f	none	simulated	system_sim
319	2026-07-22	WH-BLR-01	ITM-SSD-01	0	1	78	f	none	simulated	system_sim
320	2026-07-22	WH-BLR-01	ITM-HDD-01	0	2	48	f	none	simulated	system_sim
321	2026-07-22	WH-BLR-01	ITM-CHG-01	0	4	99	f	none	simulated	system_sim
322	2026-07-22	WH-BLR-01	ITM-CBL-01	0	4	242	f	none	simulated	system_sim
323	2026-07-22	WH-CHN-01	ITM-CPU-01	0	2	31	f	none	simulated	system_sim
324	2026-07-22	WH-CHN-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
325	2026-07-22	WH-CHN-01	ITM-RAM-01	0	4	98	f	none	simulated	system_sim
326	2026-07-22	WH-CHN-01	ITM-SSD-01	0	3	77	f	none	simulated	system_sim
327	2026-07-22	WH-CHN-01	ITM-HDD-01	0	2	51	f	none	simulated	system_sim
328	2026-07-22	WH-CHN-01	ITM-CHG-01	0	1	98	f	none	simulated	system_sim
329	2026-07-22	WH-CHN-01	ITM-CBL-01	0	8	254	f	none	simulated	system_sim
330	2026-07-22	WH-BOM-01	ITM-CPU-01	0	1	30	f	none	simulated	system_sim
331	2026-07-22	WH-BOM-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
332	2026-07-22	WH-BOM-01	ITM-RAM-01	75	9	102	f	none	simulated	system_sim
333	2026-07-22	WH-BOM-01	ITM-SSD-01	0	1	83	f	none	simulated	system_sim
334	2026-07-22	WH-BOM-01	ITM-HDD-01	0	0	43	f	none	simulated	system_sim
335	2026-07-22	WH-BOM-01	ITM-CHG-01	0	6	89	f	none	simulated	system_sim
336	2026-07-22	WH-BOM-01	ITM-CBL-01	0	7	264	f	none	simulated	system_sim
337	2026-07-22	WH-DEL-01	ITM-CPU-01	0	3	26	f	none	simulated	system_sim
338	2026-07-22	WH-DEL-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
339	2026-07-22	WH-DEL-01	ITM-RAM-01	75	3	101	f	none	simulated	system_sim
340	2026-07-22	WH-DEL-01	ITM-SSD-01	0	1	82	f	none	simulated	system_sim
341	2026-07-22	WH-DEL-01	ITM-HDD-01	0	2	56	f	none	simulated	system_sim
342	2026-07-22	WH-DEL-01	ITM-CHG-01	0	5	85	f	none	simulated	system_sim
343	2026-07-22	WH-DEL-01	ITM-CBL-01	0	3	240	f	none	simulated	system_sim
344	2026-07-22	WH-CCU-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
345	2026-07-22	WH-CCU-01	ITM-GPU-01	0	0	26	f	none	simulated	system_sim
346	2026-07-22	WH-CCU-01	ITM-RAM-01	0	9	80	f	none	simulated	system_sim
347	2026-07-22	WH-CCU-01	ITM-SSD-01	0	3	78	f	none	simulated	system_sim
348	2026-07-22	WH-CCU-01	ITM-HDD-01	0	3	42	f	none	simulated	system_sim
349	2026-07-22	WH-CCU-01	ITM-CHG-01	0	2	104	f	none	simulated	system_sim
350	2026-07-22	WH-CCU-01	ITM-CBL-01	0	3	248	f	none	simulated	system_sim
351	2026-07-23	WH-BLR-01	ITM-CPU-01	0	0	30	f	none	simulated	system_sim
352	2026-07-23	WH-BLR-01	ITM-GPU-01	0	2	21	f	none	simulated	system_sim
353	2026-07-23	WH-BLR-01	ITM-RAM-01	0	3	103	f	none	simulated	system_sim
354	2026-07-23	WH-BLR-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
355	2026-07-23	WH-BLR-01	ITM-HDD-01	0	2	46	f	none	simulated	system_sim
356	2026-07-23	WH-BLR-01	ITM-CHG-01	0	6	93	f	none	simulated	system_sim
357	2026-07-23	WH-BLR-01	ITM-CBL-01	0	5	237	f	none	simulated	system_sim
358	2026-07-23	WH-CHN-01	ITM-CPU-01	0	3	28	f	none	simulated	system_sim
359	2026-07-23	WH-CHN-01	ITM-GPU-01	0	0	22	f	none	simulated	system_sim
360	2026-07-23	WH-CHN-01	ITM-RAM-01	0	6	92	f	none	simulated	system_sim
361	2026-07-23	WH-CHN-01	ITM-SSD-01	0	2	75	f	none	simulated	system_sim
362	2026-07-23	WH-CHN-01	ITM-HDD-01	0	0	51	f	none	simulated	system_sim
363	2026-07-23	WH-CHN-01	ITM-CHG-01	0	1	97	f	none	simulated	system_sim
364	2026-07-23	WH-CHN-01	ITM-CBL-01	0	4	250	f	none	simulated	system_sim
365	2026-07-23	WH-BOM-01	ITM-CPU-01	0	0	30	f	none	simulated	system_sim
366	2026-07-23	WH-BOM-01	ITM-GPU-01	0	0	25	f	none	simulated	system_sim
367	2026-07-23	WH-BOM-01	ITM-RAM-01	0	2	100	f	none	simulated	system_sim
368	2026-07-23	WH-BOM-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
369	2026-07-23	WH-BOM-01	ITM-HDD-01	0	2	41	f	none	simulated	system_sim
370	2026-07-23	WH-BOM-01	ITM-CHG-01	0	10	79	f	none	simulated	system_sim
371	2026-07-23	WH-BOM-01	ITM-CBL-01	0	3	261	f	none	simulated	system_sim
372	2026-07-23	WH-DEL-01	ITM-CPU-01	0	0	26	f	none	simulated	system_sim
373	2026-07-23	WH-DEL-01	ITM-GPU-01	0	1	24	f	none	simulated	system_sim
374	2026-07-23	WH-DEL-01	ITM-RAM-01	0	2	99	f	none	simulated	system_sim
375	2026-07-23	WH-DEL-01	ITM-SSD-01	0	1	81	f	none	simulated	system_sim
376	2026-07-23	WH-DEL-01	ITM-HDD-01	0	0	56	f	none	simulated	system_sim
377	2026-07-23	WH-DEL-01	ITM-CHG-01	0	3	82	f	none	simulated	system_sim
378	2026-07-23	WH-DEL-01	ITM-CBL-01	0	2	238	f	none	simulated	system_sim
379	2026-07-23	WH-CCU-01	ITM-CPU-01	0	0	34	f	none	simulated	system_sim
380	2026-07-23	WH-CCU-01	ITM-GPU-01	0	1	25	f	none	simulated	system_sim
381	2026-07-23	WH-CCU-01	ITM-RAM-01	0	4	76	f	none	simulated	system_sim
382	2026-07-23	WH-CCU-01	ITM-SSD-01	0	3	75	f	none	simulated	system_sim
383	2026-07-23	WH-CCU-01	ITM-HDD-01	0	3	39	f	none	simulated	system_sim
384	2026-07-23	WH-CCU-01	ITM-CHG-01	0	4	100	f	none	simulated	system_sim
385	2026-07-23	WH-CCU-01	ITM-CBL-01	0	9	239	f	none	simulated	system_sim
386	2026-07-24	WH-BLR-01	ITM-CPU-01	0	3	27	f	none	simulated	system_sim
387	2026-07-24	WH-BLR-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
388	2026-07-24	WH-BLR-01	ITM-RAM-01	0	9	94	f	none	simulated	system_sim
389	2026-07-24	WH-BLR-01	ITM-SSD-01	0	0	78	f	none	simulated	system_sim
390	2026-07-24	WH-BLR-01	ITM-HDD-01	0	3	43	f	none	simulated	system_sim
391	2026-07-24	WH-BLR-01	ITM-CHG-01	0	10	83	f	none	simulated	system_sim
392	2026-07-24	WH-BLR-01	ITM-CBL-01	0	8	229	f	none	simulated	system_sim
393	2026-07-24	WH-CHN-01	ITM-CPU-01	0	0	28	f	none	simulated	system_sim
394	2026-07-24	WH-CHN-01	ITM-GPU-01	0	2	20	f	none	simulated	system_sim
395	2026-07-24	WH-CHN-01	ITM-RAM-01	0	6	86	f	none	simulated	system_sim
396	2026-07-24	WH-CHN-01	ITM-SSD-01	0	3	72	f	none	simulated	system_sim
397	2026-07-24	WH-CHN-01	ITM-HDD-01	0	3	48	f	none	simulated	system_sim
398	2026-07-24	WH-CHN-01	ITM-CHG-01	0	7	90	f	none	simulated	system_sim
399	2026-07-24	WH-CHN-01	ITM-CBL-01	0	7	243	f	none	simulated	system_sim
400	2026-07-24	WH-BOM-01	ITM-CPU-01	0	1	29	f	none	simulated	system_sim
401	2026-07-24	WH-BOM-01	ITM-GPU-01	0	2	23	f	none	simulated	system_sim
402	2026-07-24	WH-BOM-01	ITM-RAM-01	0	5	95	f	none	simulated	system_sim
403	2026-07-24	WH-BOM-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
404	2026-07-24	WH-BOM-01	ITM-HDD-01	0	1	40	f	none	simulated	system_sim
405	2026-07-24	WH-BOM-01	ITM-CHG-01	0	8	71	f	none	simulated	system_sim
406	2026-07-24	WH-BOM-01	ITM-CBL-01	0	7	254	f	none	simulated	system_sim
407	2026-07-24	WH-DEL-01	ITM-CPU-01	0	0	26	f	none	simulated	system_sim
408	2026-07-24	WH-DEL-01	ITM-GPU-01	0	2	22	f	none	simulated	system_sim
409	2026-07-24	WH-DEL-01	ITM-RAM-01	0	10	89	f	none	simulated	system_sim
410	2026-07-24	WH-DEL-01	ITM-SSD-01	0	2	79	f	none	simulated	system_sim
411	2026-07-24	WH-DEL-01	ITM-HDD-01	0	0	56	f	none	simulated	system_sim
412	2026-07-24	WH-DEL-01	ITM-CHG-01	0	3	79	f	none	simulated	system_sim
413	2026-07-24	WH-DEL-01	ITM-CBL-01	0	6	232	f	none	simulated	system_sim
414	2026-07-24	WH-CCU-01	ITM-CPU-01	0	3	31	f	none	simulated	system_sim
415	2026-07-24	WH-CCU-01	ITM-GPU-01	0	1	24	f	none	simulated	system_sim
416	2026-07-24	WH-CCU-01	ITM-RAM-01	0	3	73	f	none	simulated	system_sim
417	2026-07-24	WH-CCU-01	ITM-SSD-01	0	2	73	f	none	simulated	system_sim
418	2026-07-24	WH-CCU-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
419	2026-07-24	WH-CCU-01	ITM-CHG-01	0	5	95	f	none	simulated	system_sim
420	2026-07-24	WH-CCU-01	ITM-CBL-01	0	4	235	f	none	simulated	system_sim
421	2026-07-25	WH-BLR-01	ITM-CPU-01	0	0	27	f	none	simulated	system_sim
422	2026-07-25	WH-BLR-01	ITM-GPU-01	0	2	17	f	none	simulated	system_sim
423	2026-07-25	WH-BLR-01	ITM-RAM-01	0	1	93	f	none	simulated	system_sim
424	2026-07-25	WH-BLR-01	ITM-SSD-01	0	3	75	f	none	simulated	system_sim
425	2026-07-25	WH-BLR-01	ITM-HDD-01	0	0	43	f	none	simulated	system_sim
426	2026-07-25	WH-BLR-01	ITM-CHG-01	0	3	80	f	none	simulated	system_sim
427	2026-07-25	WH-BLR-01	ITM-CBL-01	0	2	227	f	none	simulated	system_sim
428	2026-07-25	WH-CHN-01	ITM-CPU-01	0	1	12	t	shrinkage	simulated	system_sim
429	2026-07-25	WH-CHN-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
430	2026-07-25	WH-CHN-01	ITM-RAM-01	0	3	83	f	none	simulated	system_sim
431	2026-07-25	WH-CHN-01	ITM-SSD-01	0	1	71	f	none	simulated	system_sim
432	2026-07-25	WH-CHN-01	ITM-HDD-01	0	3	45	f	none	simulated	system_sim
433	2026-07-25	WH-CHN-01	ITM-CHG-01	0	6	84	f	none	simulated	system_sim
434	2026-07-25	WH-CHN-01	ITM-CBL-01	0	4	239	f	none	simulated	system_sim
435	2026-07-25	WH-BOM-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
436	2026-07-25	WH-BOM-01	ITM-GPU-01	0	0	23	f	none	simulated	system_sim
437	2026-07-25	WH-BOM-01	ITM-RAM-01	0	10	85	f	none	simulated	system_sim
438	2026-07-25	WH-BOM-01	ITM-SSD-01	0	0	83	f	none	simulated	system_sim
439	2026-07-25	WH-BOM-01	ITM-HDD-01	0	2	38	f	none	simulated	system_sim
440	2026-07-25	WH-BOM-01	ITM-CHG-01	150	4	217	f	none	simulated	system_sim
441	2026-07-25	WH-BOM-01	ITM-CBL-01	0	7	247	f	none	simulated	system_sim
442	2026-07-25	WH-DEL-01	ITM-CPU-01	0	2	24	f	none	simulated	system_sim
443	2026-07-25	WH-DEL-01	ITM-GPU-01	0	2	20	f	none	simulated	system_sim
444	2026-07-25	WH-DEL-01	ITM-RAM-01	0	8	81	f	none	simulated	system_sim
445	2026-07-25	WH-DEL-01	ITM-SSD-01	0	0	79	f	none	simulated	system_sim
446	2026-07-25	WH-DEL-01	ITM-HDD-01	0	3	53	f	none	simulated	system_sim
447	2026-07-25	WH-DEL-01	ITM-CHG-01	0	10	69	f	none	simulated	system_sim
448	2026-07-25	WH-DEL-01	ITM-CBL-01	0	9	223	f	none	simulated	system_sim
449	2026-07-25	WH-CCU-01	ITM-CPU-01	0	0	31	f	none	simulated	system_sim
450	2026-07-25	WH-CCU-01	ITM-GPU-01	0	0	24	f	none	simulated	system_sim
451	2026-07-25	WH-CCU-01	ITM-RAM-01	0	5	68	f	none	simulated	system_sim
452	2026-07-25	WH-CCU-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
453	2026-07-25	WH-CCU-01	ITM-HDD-01	0	1	38	f	none	simulated	system_sim
454	2026-07-25	WH-CCU-01	ITM-CHG-01	0	5	90	f	none	simulated	system_sim
455	2026-07-25	WH-CCU-01	ITM-CBL-01	0	9	226	f	none	simulated	system_sim
456	2026-07-26	WH-BLR-01	ITM-CPU-01	0	3	24	f	none	simulated	system_sim
457	2026-07-26	WH-BLR-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
458	2026-07-26	WH-BLR-01	ITM-RAM-01	0	6	87	f	none	simulated	system_sim
459	2026-07-26	WH-BLR-01	ITM-SSD-01	0	3	72	f	none	simulated	system_sim
460	2026-07-26	WH-BLR-01	ITM-HDD-01	0	0	43	f	none	simulated	system_sim
461	2026-07-26	WH-BLR-01	ITM-CHG-01	0	1	79	f	none	simulated	system_sim
462	2026-07-26	WH-BLR-01	ITM-CBL-01	0	9	218	f	none	simulated	system_sim
463	2026-07-26	WH-CHN-01	ITM-CPU-01	45	1	56	f	none	simulated	system_sim
464	2026-07-26	WH-CHN-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
465	2026-07-26	WH-CHN-01	ITM-RAM-01	0	6	77	f	none	simulated	system_sim
466	2026-07-26	WH-CHN-01	ITM-SSD-01	0	1	70	f	none	simulated	system_sim
467	2026-07-26	WH-CHN-01	ITM-HDD-01	0	3	42	f	none	simulated	system_sim
468	2026-07-26	WH-CHN-01	ITM-CHG-01	0	2	82	f	none	simulated	system_sim
469	2026-07-26	WH-CHN-01	ITM-CBL-01	0	7	232	f	none	simulated	system_sim
470	2026-07-26	WH-BOM-01	ITM-CPU-01	0	0	29	f	none	simulated	system_sim
471	2026-07-26	WH-BOM-01	ITM-GPU-01	0	2	21	f	none	simulated	system_sim
472	2026-07-26	WH-BOM-01	ITM-RAM-01	0	7	78	f	none	simulated	system_sim
473	2026-07-26	WH-BOM-01	ITM-SSD-01	0	3	80	f	none	simulated	system_sim
474	2026-07-26	WH-BOM-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
475	2026-07-26	WH-BOM-01	ITM-CHG-01	0	9	208	f	none	simulated	system_sim
476	2026-07-26	WH-BOM-01	ITM-CBL-01	0	8	239	f	none	simulated	system_sim
477	2026-07-26	WH-DEL-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
478	2026-07-26	WH-DEL-01	ITM-GPU-01	0	0	20	f	none	simulated	system_sim
479	2026-07-26	WH-DEL-01	ITM-RAM-01	0	6	75	f	none	simulated	system_sim
480	2026-07-26	WH-DEL-01	ITM-SSD-01	0	0	79	f	none	simulated	system_sim
481	2026-07-26	WH-DEL-01	ITM-HDD-01	0	1	52	f	none	simulated	system_sim
482	2026-07-26	WH-DEL-01	ITM-CHG-01	150	10	209	f	none	simulated	system_sim
483	2026-07-26	WH-DEL-01	ITM-CBL-01	0	7	216	f	none	simulated	system_sim
484	2026-07-26	WH-CCU-01	ITM-CPU-01	0	0	31	f	none	simulated	system_sim
485	2026-07-26	WH-CCU-01	ITM-GPU-01	0	2	22	f	none	simulated	system_sim
486	2026-07-26	WH-CCU-01	ITM-RAM-01	0	1	67	f	none	simulated	system_sim
487	2026-07-26	WH-CCU-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
488	2026-07-26	WH-CCU-01	ITM-HDD-01	0	3	35	f	none	simulated	system_sim
489	2026-07-26	WH-CCU-01	ITM-CHG-01	0	4	86	f	none	simulated	system_sim
490	2026-07-26	WH-CCU-01	ITM-CBL-01	0	7	219	f	none	simulated	system_sim
491	2026-07-27	WH-BLR-01	ITM-CPU-01	0	2	22	f	none	simulated	system_sim
492	2026-07-27	WH-BLR-01	ITM-GPU-01	0	1	16	f	none	simulated	system_sim
493	2026-07-27	WH-BLR-01	ITM-RAM-01	0	10	77	f	none	simulated	system_sim
494	2026-07-27	WH-BLR-01	ITM-SSD-01	0	1	71	f	none	simulated	system_sim
495	2026-07-27	WH-BLR-01	ITM-HDD-01	0	2	41	f	none	simulated	system_sim
496	2026-07-27	WH-BLR-01	ITM-CHG-01	0	2	77	f	none	simulated	system_sim
497	2026-07-27	WH-BLR-01	ITM-CBL-01	0	6	212	f	none	simulated	system_sim
498	2026-07-27	WH-CHN-01	ITM-CPU-01	0	0	56	f	none	simulated	system_sim
499	2026-07-27	WH-CHN-01	ITM-GPU-01	0	2	18	f	none	simulated	system_sim
500	2026-07-27	WH-CHN-01	ITM-RAM-01	0	7	70	f	none	simulated	system_sim
501	2026-07-27	WH-CHN-01	ITM-SSD-01	0	3	67	f	none	simulated	system_sim
502	2026-07-27	WH-CHN-01	ITM-HDD-01	0	0	42	f	none	simulated	system_sim
503	2026-07-27	WH-CHN-01	ITM-CHG-01	0	1	81	f	none	simulated	system_sim
504	2026-07-27	WH-CHN-01	ITM-CBL-01	0	3	229	f	none	simulated	system_sim
505	2026-07-27	WH-BOM-01	ITM-CPU-01	0	1	28	f	none	simulated	system_sim
506	2026-07-27	WH-BOM-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
507	2026-07-27	WH-BOM-01	ITM-RAM-01	0	5	73	f	none	simulated	system_sim
508	2026-07-27	WH-BOM-01	ITM-SSD-01	0	0	80	f	none	simulated	system_sim
509	2026-07-27	WH-BOM-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
510	2026-07-27	WH-BOM-01	ITM-CHG-01	0	9	199	f	none	simulated	system_sim
511	2026-07-27	WH-BOM-01	ITM-CBL-01	0	6	233	f	none	simulated	system_sim
512	2026-07-27	WH-DEL-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
513	2026-07-27	WH-DEL-01	ITM-GPU-01	0	2	18	f	none	simulated	system_sim
514	2026-07-27	WH-DEL-01	ITM-RAM-01	0	5	70	f	none	simulated	system_sim
515	2026-07-27	WH-DEL-01	ITM-SSD-01	0	3	76	f	none	simulated	system_sim
516	2026-07-27	WH-DEL-01	ITM-HDD-01	0	2	50	f	none	simulated	system_sim
517	2026-07-27	WH-DEL-01	ITM-CHG-01	0	2	207	f	none	simulated	system_sim
518	2026-07-27	WH-DEL-01	ITM-CBL-01	0	3	213	f	none	simulated	system_sim
519	2026-07-27	WH-CCU-01	ITM-CPU-01	0	3	28	f	none	simulated	system_sim
520	2026-07-27	WH-CCU-01	ITM-GPU-01	0	1	21	f	none	simulated	system_sim
521	2026-07-27	WH-CCU-01	ITM-RAM-01	0	3	64	f	none	simulated	system_sim
522	2026-07-27	WH-CCU-01	ITM-SSD-01	0	3	70	f	none	simulated	system_sim
523	2026-07-27	WH-CCU-01	ITM-HDD-01	0	2	33	f	none	simulated	system_sim
524	2026-07-27	WH-CCU-01	ITM-CHG-01	0	1	85	f	none	simulated	system_sim
525	2026-07-27	WH-CCU-01	ITM-CBL-01	0	8	211	f	none	simulated	system_sim
526	2026-07-28	WH-BLR-01	ITM-CPU-01	45	1	66	f	none	simulated	system_sim
527	2026-07-28	WH-BLR-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
528	2026-07-28	WH-BLR-01	ITM-RAM-01	0	1	76	f	none	simulated	system_sim
529	2026-07-28	WH-BLR-01	ITM-SSD-01	0	1	70	f	none	simulated	system_sim
530	2026-07-28	WH-BLR-01	ITM-HDD-01	0	3	38	f	none	simulated	system_sim
531	2026-07-28	WH-BLR-01	ITM-CHG-01	0	7	70	f	none	simulated	system_sim
532	2026-07-28	WH-BLR-01	ITM-CBL-01	0	9	203	f	none	simulated	system_sim
533	2026-07-28	WH-CHN-01	ITM-CPU-01	0	3	53	f	none	simulated	system_sim
534	2026-07-28	WH-CHN-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
535	2026-07-28	WH-CHN-01	ITM-RAM-01	0	5	65	f	none	simulated	system_sim
536	2026-07-28	WH-CHN-01	ITM-SSD-01	0	2	65	f	none	simulated	system_sim
537	2026-07-28	WH-CHN-01	ITM-HDD-01	0	2	40	f	none	simulated	system_sim
538	2026-07-28	WH-CHN-01	ITM-CHG-01	0	9	72	f	none	simulated	system_sim
539	2026-07-28	WH-CHN-01	ITM-CBL-01	0	3	226	f	none	simulated	system_sim
540	2026-07-28	WH-BOM-01	ITM-CPU-01	0	2	26	f	none	simulated	system_sim
541	2026-07-28	WH-BOM-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
542	2026-07-28	WH-BOM-01	ITM-RAM-01	0	8	65	f	none	simulated	system_sim
543	2026-07-28	WH-BOM-01	ITM-SSD-01	0	3	77	f	none	simulated	system_sim
544	2026-07-28	WH-BOM-01	ITM-HDD-01	0	2	36	f	none	simulated	system_sim
545	2026-07-28	WH-BOM-01	ITM-CHG-01	0	2	197	f	none	simulated	system_sim
546	2026-07-28	WH-BOM-01	ITM-CBL-01	0	2	231	f	none	simulated	system_sim
547	2026-07-28	WH-DEL-01	ITM-CPU-01	0	0	24	f	none	simulated	system_sim
548	2026-07-28	WH-DEL-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
549	2026-07-28	WH-DEL-01	ITM-RAM-01	0	2	68	f	none	simulated	system_sim
550	2026-07-28	WH-DEL-01	ITM-SSD-01	0	3	73	f	none	simulated	system_sim
551	2026-07-28	WH-DEL-01	ITM-HDD-01	0	1	49	f	none	simulated	system_sim
552	2026-07-28	WH-DEL-01	ITM-CHG-01	0	10	197	f	none	simulated	system_sim
553	2026-07-28	WH-DEL-01	ITM-CBL-01	0	4	209	f	none	simulated	system_sim
554	2026-07-28	WH-CCU-01	ITM-CPU-01	0	0	28	f	none	simulated	system_sim
555	2026-07-28	WH-CCU-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
556	2026-07-28	WH-CCU-01	ITM-RAM-01	0	8	56	f	none	simulated	system_sim
557	2026-07-28	WH-CCU-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
558	2026-07-28	WH-CCU-01	ITM-HDD-01	0	1	32	f	none	simulated	system_sim
559	2026-07-28	WH-CCU-01	ITM-CHG-01	0	4	81	f	none	simulated	system_sim
560	2026-07-28	WH-CCU-01	ITM-CBL-01	0	3	208	f	none	simulated	system_sim
561	2026-07-29	WH-BLR-01	ITM-CPU-01	0	0	66	f	none	simulated	system_sim
562	2026-07-29	WH-BLR-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
563	2026-07-29	WH-BLR-01	ITM-RAM-01	0	3	73	f	none	simulated	system_sim
564	2026-07-29	WH-BLR-01	ITM-SSD-01	0	1	69	f	none	simulated	system_sim
565	2026-07-29	WH-BLR-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
566	2026-07-29	WH-BLR-01	ITM-CHG-01	150	8	212	f	none	simulated	system_sim
567	2026-07-29	WH-BLR-01	ITM-CBL-01	0	5	198	f	none	simulated	system_sim
568	2026-07-29	WH-CHN-01	ITM-CPU-01	0	3	50	f	none	simulated	system_sim
569	2026-07-29	WH-CHN-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
570	2026-07-29	WH-CHN-01	ITM-RAM-01	0	10	55	f	none	simulated	system_sim
571	2026-07-29	WH-CHN-01	ITM-SSD-01	0	1	64	f	none	simulated	system_sim
572	2026-07-29	WH-CHN-01	ITM-HDD-01	0	1	39	f	none	simulated	system_sim
573	2026-07-29	WH-CHN-01	ITM-CHG-01	150	3	219	f	none	simulated	system_sim
574	2026-07-29	WH-CHN-01	ITM-CBL-01	0	9	217	f	none	simulated	system_sim
575	2026-07-29	WH-BOM-01	ITM-CPU-01	0	2	24	f	none	simulated	system_sim
576	2026-07-29	WH-BOM-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
577	2026-07-29	WH-BOM-01	ITM-RAM-01	0	9	56	f	none	simulated	system_sim
578	2026-07-29	WH-BOM-01	ITM-SSD-01	0	1	76	f	none	simulated	system_sim
579	2026-07-29	WH-BOM-01	ITM-HDD-01	0	2	34	f	none	simulated	system_sim
580	2026-07-29	WH-BOM-01	ITM-CHG-01	0	8	189	f	none	simulated	system_sim
581	2026-07-29	WH-BOM-01	ITM-CBL-01	0	2	229	f	none	simulated	system_sim
582	2026-07-29	WH-DEL-01	ITM-CPU-01	0	1	23	f	none	simulated	system_sim
583	2026-07-29	WH-DEL-01	ITM-GPU-01	0	0	18	f	none	simulated	system_sim
584	2026-07-29	WH-DEL-01	ITM-RAM-01	0	3	65	f	none	simulated	system_sim
585	2026-07-29	WH-DEL-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
586	2026-07-29	WH-DEL-01	ITM-HDD-01	0	3	46	f	none	simulated	system_sim
587	2026-07-29	WH-DEL-01	ITM-CHG-01	0	4	193	f	none	simulated	system_sim
588	2026-07-29	WH-DEL-01	ITM-CBL-01	0	1	208	f	none	simulated	system_sim
589	2026-07-29	WH-CCU-01	ITM-CPU-01	0	0	28	f	none	simulated	system_sim
590	2026-07-29	WH-CCU-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
591	2026-07-29	WH-CCU-01	ITM-RAM-01	0	5	51	f	none	simulated	system_sim
592	2026-07-29	WH-CCU-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
593	2026-07-29	WH-CCU-01	ITM-HDD-01	0	3	29	f	none	simulated	system_sim
594	2026-07-29	WH-CCU-01	ITM-CHG-01	0	8	73	f	none	simulated	system_sim
595	2026-07-29	WH-CCU-01	ITM-CBL-01	0	4	204	f	none	simulated	system_sim
596	2026-07-30	WH-BLR-01	ITM-CPU-01	0	3	63	f	none	simulated	system_sim
597	2026-07-30	WH-BLR-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
598	2026-07-30	WH-BLR-01	ITM-RAM-01	0	7	66	f	none	simulated	system_sim
599	2026-07-30	WH-BLR-01	ITM-SSD-01	0	3	66	f	none	simulated	system_sim
600	2026-07-30	WH-BLR-01	ITM-HDD-01	0	0	38	f	none	simulated	system_sim
601	2026-07-30	WH-BLR-01	ITM-CHG-01	0	3	209	f	none	simulated	system_sim
602	2026-07-30	WH-BLR-01	ITM-CBL-01	0	6	192	f	none	simulated	system_sim
603	2026-07-30	WH-CHN-01	ITM-CPU-01	0	1	49	f	none	simulated	system_sim
604	2026-07-30	WH-CHN-01	ITM-GPU-01	0	0	17	f	none	simulated	system_sim
605	2026-07-30	WH-CHN-01	ITM-RAM-01	0	7	48	f	none	simulated	system_sim
606	2026-07-30	WH-CHN-01	ITM-SSD-01	0	1	63	f	none	simulated	system_sim
607	2026-07-30	WH-CHN-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
608	2026-07-30	WH-CHN-01	ITM-CHG-01	0	5	214	f	none	simulated	system_sim
609	2026-07-30	WH-CHN-01	ITM-CBL-01	0	5	212	f	none	simulated	system_sim
610	2026-07-30	WH-BOM-01	ITM-CPU-01	0	2	22	f	none	simulated	system_sim
611	2026-07-30	WH-BOM-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
612	2026-07-30	WH-BOM-01	ITM-RAM-01	0	2	54	f	none	simulated	system_sim
613	2026-07-30	WH-BOM-01	ITM-SSD-01	0	3	73	f	none	simulated	system_sim
614	2026-07-30	WH-BOM-01	ITM-HDD-01	0	1	33	f	none	simulated	system_sim
615	2026-07-30	WH-BOM-01	ITM-CHG-01	0	2	187	f	none	simulated	system_sim
616	2026-07-30	WH-BOM-01	ITM-CBL-01	0	3	226	f	none	simulated	system_sim
617	2026-07-30	WH-DEL-01	ITM-CPU-01	0	0	23	f	none	simulated	system_sim
618	2026-07-30	WH-DEL-01	ITM-GPU-01	0	2	16	f	none	simulated	system_sim
619	2026-07-30	WH-DEL-01	ITM-RAM-01	0	1	64	f	none	simulated	system_sim
620	2026-07-30	WH-DEL-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
621	2026-07-30	WH-DEL-01	ITM-HDD-01	0	3	43	f	none	simulated	system_sim
622	2026-07-30	WH-DEL-01	ITM-CHG-01	0	5	188	f	none	simulated	system_sim
623	2026-07-30	WH-DEL-01	ITM-CBL-01	0	10	198	f	none	simulated	system_sim
624	2026-07-30	WH-CCU-01	ITM-CPU-01	0	3	25	f	none	simulated	system_sim
625	2026-07-30	WH-CCU-01	ITM-GPU-01	0	0	21	f	none	simulated	system_sim
626	2026-07-30	WH-CCU-01	ITM-RAM-01	0	3	48	f	none	simulated	system_sim
627	2026-07-30	WH-CCU-01	ITM-SSD-01	0	0	70	f	none	simulated	system_sim
628	2026-07-30	WH-CCU-01	ITM-HDD-01	60	3	86	f	none	simulated	system_sim
629	2026-07-30	WH-CCU-01	ITM-CHG-01	150	2	221	f	none	simulated	system_sim
630	2026-07-30	WH-CCU-01	ITM-CBL-01	0	10	194	f	none	simulated	system_sim
631	2026-07-31	WH-BLR-01	ITM-CPU-01	0	0	63	f	none	simulated	system_sim
632	2026-07-31	WH-BLR-01	ITM-GPU-01	0	2	14	f	none	simulated	system_sim
633	2026-07-31	WH-BLR-01	ITM-RAM-01	0	9	57	f	none	simulated	system_sim
634	2026-07-31	WH-BLR-01	ITM-SSD-01	0	2	64	f	none	simulated	system_sim
635	2026-07-31	WH-BLR-01	ITM-HDD-01	0	1	37	f	none	simulated	system_sim
636	2026-07-31	WH-BLR-01	ITM-CHG-01	0	8	201	f	none	simulated	system_sim
637	2026-07-31	WH-BLR-01	ITM-CBL-01	0	5	187	f	none	simulated	system_sim
638	2026-07-31	WH-CHN-01	ITM-CPU-01	0	0	49	f	none	simulated	system_sim
639	2026-07-31	WH-CHN-01	ITM-GPU-01	0	2	15	f	none	simulated	system_sim
640	2026-07-31	WH-CHN-01	ITM-RAM-01	0	4	44	f	none	simulated	system_sim
641	2026-07-31	WH-CHN-01	ITM-SSD-01	0	3	60	f	none	simulated	system_sim
642	2026-07-31	WH-CHN-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
643	2026-07-31	WH-CHN-01	ITM-CHG-01	0	4	210	f	none	simulated	system_sim
644	2026-07-31	WH-CHN-01	ITM-CBL-01	0	4	208	f	none	simulated	system_sim
645	2026-07-31	WH-BOM-01	ITM-CPU-01	45	2	65	f	none	simulated	system_sim
646	2026-07-31	WH-BOM-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
647	2026-07-31	WH-BOM-01	ITM-RAM-01	0	1	53	f	none	simulated	system_sim
648	2026-07-31	WH-BOM-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
649	2026-07-31	WH-BOM-01	ITM-HDD-01	0	3	30	f	none	simulated	system_sim
650	2026-07-31	WH-BOM-01	ITM-CHG-01	0	5	182	f	none	simulated	system_sim
651	2026-07-31	WH-BOM-01	ITM-CBL-01	0	5	221	f	none	simulated	system_sim
652	2026-07-31	WH-DEL-01	ITM-CPU-01	0	2	21	f	none	simulated	system_sim
653	2026-07-31	WH-DEL-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
654	2026-07-31	WH-DEL-01	ITM-RAM-01	0	4	60	f	none	simulated	system_sim
655	2026-07-31	WH-DEL-01	ITM-SSD-01	0	0	73	f	none	simulated	system_sim
656	2026-07-31	WH-DEL-01	ITM-HDD-01	0	3	40	f	none	simulated	system_sim
657	2026-07-31	WH-DEL-01	ITM-CHG-01	0	5	183	f	none	simulated	system_sim
658	2026-07-31	WH-DEL-01	ITM-CBL-01	0	8	190	f	none	simulated	system_sim
659	2026-07-31	WH-CCU-01	ITM-CPU-01	0	3	22	f	none	simulated	system_sim
660	2026-07-31	WH-CCU-01	ITM-GPU-01	0	2	19	f	none	simulated	system_sim
661	2026-07-31	WH-CCU-01	ITM-RAM-01	0	1	47	f	none	simulated	system_sim
662	2026-07-31	WH-CCU-01	ITM-SSD-01	0	3	67	f	none	simulated	system_sim
663	2026-07-31	WH-CCU-01	ITM-HDD-01	0	2	84	f	none	simulated	system_sim
664	2026-07-31	WH-CCU-01	ITM-CHG-01	0	7	214	f	none	simulated	system_sim
665	2026-07-31	WH-CCU-01	ITM-CBL-01	0	6	188	f	none	simulated	system_sim
666	2026-08-01	WH-BLR-01	ITM-CPU-01	0	2	61	f	none	simulated	system_sim
667	2026-08-01	WH-BLR-01	ITM-GPU-01	30	1	43	f	none	simulated	system_sim
668	2026-08-01	WH-BLR-01	ITM-RAM-01	0	1	56	f	none	simulated	system_sim
669	2026-08-01	WH-BLR-01	ITM-SSD-01	0	3	61	f	none	simulated	system_sim
670	2026-08-01	WH-BLR-01	ITM-HDD-01	0	2	35	f	none	simulated	system_sim
671	2026-08-01	WH-BLR-01	ITM-CHG-01	0	6	195	f	none	simulated	system_sim
672	2026-08-01	WH-BLR-01	ITM-CBL-01	0	4	183	f	none	simulated	system_sim
673	2026-08-01	WH-CHN-01	ITM-CPU-01	0	1	48	f	none	simulated	system_sim
674	2026-08-01	WH-CHN-01	ITM-GPU-01	0	2	13	f	none	simulated	system_sim
675	2026-08-01	WH-CHN-01	ITM-RAM-01	0	9	35	f	none	simulated	system_sim
676	2026-08-01	WH-CHN-01	ITM-SSD-01	0	0	60	f	none	simulated	system_sim
677	2026-08-01	WH-CHN-01	ITM-HDD-01	0	0	39	f	none	simulated	system_sim
678	2026-08-01	WH-CHN-01	ITM-CHG-01	0	2	208	f	none	simulated	system_sim
679	2026-08-01	WH-CHN-01	ITM-CBL-01	0	2	206	f	none	simulated	system_sim
680	2026-08-01	WH-BOM-01	ITM-CPU-01	0	0	65	f	none	simulated	system_sim
681	2026-08-01	WH-BOM-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
682	2026-08-01	WH-BOM-01	ITM-RAM-01	0	5	48	f	none	simulated	system_sim
683	2026-08-01	WH-BOM-01	ITM-SSD-01	0	2	71	f	none	simulated	system_sim
684	2026-08-01	WH-BOM-01	ITM-HDD-01	0	2	28	f	none	simulated	system_sim
685	2026-08-01	WH-BOM-01	ITM-CHG-01	0	8	174	f	none	simulated	system_sim
686	2026-08-01	WH-BOM-01	ITM-CBL-01	0	2	219	f	none	simulated	system_sim
687	2026-08-01	WH-DEL-01	ITM-CPU-01	45	1	65	f	none	simulated	system_sim
688	2026-08-01	WH-DEL-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
689	2026-08-01	WH-DEL-01	ITM-RAM-01	0	3	57	f	none	simulated	system_sim
690	2026-08-01	WH-DEL-01	ITM-SSD-01	0	2	71	f	none	simulated	system_sim
691	2026-08-01	WH-DEL-01	ITM-HDD-01	0	1	39	f	none	simulated	system_sim
692	2026-08-01	WH-DEL-01	ITM-CHG-01	0	2	181	f	none	simulated	system_sim
693	2026-08-01	WH-DEL-01	ITM-CBL-01	0	10	180	f	none	simulated	system_sim
694	2026-08-01	WH-CCU-01	ITM-CPU-01	45	0	67	f	none	simulated	system_sim
695	2026-08-01	WH-CCU-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
696	2026-08-01	WH-CCU-01	ITM-RAM-01	0	9	38	f	none	simulated	system_sim
697	2026-08-01	WH-CCU-01	ITM-SSD-01	0	1	66	f	none	simulated	system_sim
698	2026-08-01	WH-CCU-01	ITM-HDD-01	0	3	81	f	none	simulated	system_sim
699	2026-08-01	WH-CCU-01	ITM-CHG-01	0	7	207	f	none	simulated	system_sim
700	2026-08-01	WH-CCU-01	ITM-CBL-01	0	6	182	f	none	simulated	system_sim
701	2026-08-02	WH-BLR-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
702	2026-08-02	WH-BLR-01	ITM-GPU-01	0	0	43	f	none	simulated	system_sim
703	2026-08-02	WH-BLR-01	ITM-RAM-01	0	2	54	f	none	simulated	system_sim
704	2026-08-02	WH-BLR-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
705	2026-08-02	WH-BLR-01	ITM-HDD-01	0	1	34	f	none	simulated	system_sim
706	2026-08-02	WH-BLR-01	ITM-CHG-01	0	10	185	f	none	simulated	system_sim
707	2026-08-02	WH-BLR-01	ITM-CBL-01	0	7	176	f	none	simulated	system_sim
708	2026-08-02	WH-CHN-01	ITM-CPU-01	0	3	45	f	none	simulated	system_sim
709	2026-08-02	WH-CHN-01	ITM-GPU-01	30	0	43	f	none	simulated	system_sim
710	2026-08-02	WH-CHN-01	ITM-RAM-01	75	7	103	f	none	simulated	system_sim
711	2026-08-02	WH-CHN-01	ITM-SSD-01	0	0	60	f	none	simulated	system_sim
712	2026-08-02	WH-CHN-01	ITM-HDD-01	0	3	36	f	none	simulated	system_sim
713	2026-08-02	WH-CHN-01	ITM-CHG-01	0	1	207	f	none	simulated	system_sim
714	2026-08-02	WH-CHN-01	ITM-CBL-01	0	1	205	f	none	simulated	system_sim
715	2026-08-02	WH-BOM-01	ITM-CPU-01	0	0	65	f	none	simulated	system_sim
716	2026-08-02	WH-BOM-01	ITM-GPU-01	0	1	18	f	none	simulated	system_sim
717	2026-08-02	WH-BOM-01	ITM-RAM-01	0	4	44	f	none	simulated	system_sim
718	2026-08-02	WH-BOM-01	ITM-SSD-01	0	2	69	f	none	simulated	system_sim
719	2026-08-02	WH-BOM-01	ITM-HDD-01	60	1	87	f	none	simulated	system_sim
720	2026-08-02	WH-BOM-01	ITM-CHG-01	0	6	168	f	none	simulated	system_sim
721	2026-08-02	WH-BOM-01	ITM-CBL-01	0	6	213	f	none	simulated	system_sim
722	2026-08-02	WH-DEL-01	ITM-CPU-01	0	3	62	f	none	simulated	system_sim
723	2026-08-02	WH-DEL-01	ITM-GPU-01	0	2	14	f	none	simulated	system_sim
724	2026-08-02	WH-DEL-01	ITM-RAM-01	0	6	51	f	none	simulated	system_sim
725	2026-08-02	WH-DEL-01	ITM-SSD-01	0	0	71	f	none	simulated	system_sim
726	2026-08-02	WH-DEL-01	ITM-HDD-01	0	3	36	f	none	simulated	system_sim
727	2026-08-02	WH-DEL-01	ITM-CHG-01	0	1	180	f	none	simulated	system_sim
728	2026-08-02	WH-DEL-01	ITM-CBL-01	0	8	172	f	none	simulated	system_sim
729	2026-08-02	WH-CCU-01	ITM-CPU-01	0	1	66	f	none	simulated	system_sim
730	2026-08-02	WH-CCU-01	ITM-GPU-01	0	0	19	f	none	simulated	system_sim
731	2026-08-02	WH-CCU-01	ITM-RAM-01	0	9	29	f	none	simulated	system_sim
732	2026-08-02	WH-CCU-01	ITM-SSD-01	0	1	65	f	none	simulated	system_sim
733	2026-08-02	WH-CCU-01	ITM-HDD-01	0	3	78	f	none	simulated	system_sim
734	2026-08-02	WH-CCU-01	ITM-CHG-01	0	5	202	f	none	simulated	system_sim
735	2026-08-02	WH-CCU-01	ITM-CBL-01	0	5	177	f	none	simulated	system_sim
736	2026-08-03	WH-BLR-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
737	2026-08-03	WH-BLR-01	ITM-GPU-01	0	0	43	f	none	simulated	system_sim
738	2026-08-03	WH-BLR-01	ITM-RAM-01	0	3	51	f	none	simulated	system_sim
739	2026-08-03	WH-BLR-01	ITM-SSD-01	0	3	58	f	none	simulated	system_sim
740	2026-08-03	WH-BLR-01	ITM-HDD-01	0	0	34	f	none	simulated	system_sim
741	2026-08-03	WH-BLR-01	ITM-CHG-01	0	6	179	f	none	simulated	system_sim
742	2026-08-03	WH-BLR-01	ITM-CBL-01	0	1	175	f	none	simulated	system_sim
743	2026-08-03	WH-CHN-01	ITM-CPU-01	0	1	44	f	none	simulated	system_sim
744	2026-08-03	WH-CHN-01	ITM-GPU-01	0	2	41	f	none	simulated	system_sim
745	2026-08-03	WH-CHN-01	ITM-RAM-01	0	6	97	f	none	simulated	system_sim
746	2026-08-03	WH-CHN-01	ITM-SSD-01	0	1	59	f	none	simulated	system_sim
747	2026-08-03	WH-CHN-01	ITM-HDD-01	0	0	36	f	none	simulated	system_sim
748	2026-08-03	WH-CHN-01	ITM-CHG-01	0	8	199	f	none	simulated	system_sim
749	2026-08-03	WH-CHN-01	ITM-CBL-01	0	6	199	f	none	simulated	system_sim
750	2026-08-03	WH-BOM-01	ITM-CPU-01	0	1	64	f	none	simulated	system_sim
751	2026-08-03	WH-BOM-01	ITM-GPU-01	0	1	17	f	none	simulated	system_sim
752	2026-08-03	WH-BOM-01	ITM-RAM-01	0	2	42	f	none	simulated	system_sim
753	2026-08-03	WH-BOM-01	ITM-SSD-01	0	3	66	f	none	simulated	system_sim
754	2026-08-03	WH-BOM-01	ITM-HDD-01	0	1	86	f	none	simulated	system_sim
755	2026-08-03	WH-BOM-01	ITM-CHG-01	0	6	162	f	none	simulated	system_sim
756	2026-08-03	WH-BOM-01	ITM-CBL-01	0	6	207	f	none	simulated	system_sim
757	2026-08-03	WH-DEL-01	ITM-CPU-01	0	2	60	f	none	simulated	system_sim
758	2026-08-03	WH-DEL-01	ITM-GPU-01	30	0	44	f	none	simulated	system_sim
759	2026-08-03	WH-DEL-01	ITM-RAM-01	0	10	41	f	none	simulated	system_sim
760	2026-08-03	WH-DEL-01	ITM-SSD-01	0	3	68	f	none	simulated	system_sim
761	2026-08-03	WH-DEL-01	ITM-HDD-01	0	1	35	f	none	simulated	system_sim
762	2026-08-03	WH-DEL-01	ITM-CHG-01	0	9	171	f	none	simulated	system_sim
763	2026-08-03	WH-DEL-01	ITM-CBL-01	0	1	171	f	none	simulated	system_sim
764	2026-08-03	WH-CCU-01	ITM-CPU-01	0	2	64	f	none	simulated	system_sim
765	2026-08-03	WH-CCU-01	ITM-GPU-01	0	1	18	f	none	simulated	system_sim
766	2026-08-03	WH-CCU-01	ITM-RAM-01	75	2	102	f	none	simulated	system_sim
767	2026-08-03	WH-CCU-01	ITM-SSD-01	0	1	64	f	none	simulated	system_sim
768	2026-08-03	WH-CCU-01	ITM-HDD-01	0	3	75	f	none	simulated	system_sim
769	2026-08-03	WH-CCU-01	ITM-CHG-01	0	5	197	f	none	simulated	system_sim
770	2026-08-03	WH-CCU-01	ITM-CBL-01	0	5	172	f	none	simulated	system_sim
771	2026-08-04	WH-BLR-01	ITM-CPU-01	0	1	60	f	none	simulated	system_sim
772	2026-08-04	WH-BLR-01	ITM-GPU-01	0	0	43	f	none	simulated	system_sim
773	2026-08-04	WH-BLR-01	ITM-RAM-01	0	4	47	f	none	simulated	system_sim
774	2026-08-04	WH-BLR-01	ITM-SSD-01	0	0	58	f	none	simulated	system_sim
775	2026-08-04	WH-BLR-01	ITM-HDD-01	0	1	33	f	none	simulated	system_sim
776	2026-08-04	WH-BLR-01	ITM-CHG-01	0	6	173	f	none	simulated	system_sim
777	2026-08-04	WH-BLR-01	ITM-CBL-01	0	9	166	f	none	simulated	system_sim
778	2026-08-04	WH-CHN-01	ITM-CPU-01	0	1	43	f	none	simulated	system_sim
779	2026-08-04	WH-CHN-01	ITM-GPU-01	0	0	41	f	none	simulated	system_sim
780	2026-08-04	WH-CHN-01	ITM-RAM-01	0	9	88	f	none	simulated	system_sim
781	2026-08-04	WH-CHN-01	ITM-SSD-01	0	2	57	f	none	simulated	system_sim
782	2026-08-04	WH-CHN-01	ITM-HDD-01	0	1	35	f	none	simulated	system_sim
783	2026-08-04	WH-CHN-01	ITM-CHG-01	0	10	189	f	none	simulated	system_sim
784	2026-08-04	WH-CHN-01	ITM-CBL-01	0	3	196	f	none	simulated	system_sim
785	2026-08-04	WH-BOM-01	ITM-CPU-01	0	0	64	f	none	simulated	system_sim
786	2026-08-04	WH-BOM-01	ITM-GPU-01	0	1	16	f	none	simulated	system_sim
787	2026-08-04	WH-BOM-01	ITM-RAM-01	0	3	39	f	none	simulated	system_sim
788	2026-08-04	WH-BOM-01	ITM-SSD-01	0	3	63	f	none	simulated	system_sim
789	2026-08-04	WH-BOM-01	ITM-HDD-01	0	0	86	f	none	simulated	system_sim
790	2026-08-04	WH-BOM-01	ITM-CHG-01	0	1	161	f	none	simulated	system_sim
791	2026-08-04	WH-BOM-01	ITM-CBL-01	0	7	200	f	none	simulated	system_sim
792	2026-08-04	WH-DEL-01	ITM-CPU-01	0	1	59	f	none	simulated	system_sim
793	2026-08-04	WH-DEL-01	ITM-GPU-01	0	2	42	f	none	simulated	system_sim
794	2026-08-04	WH-DEL-01	ITM-RAM-01	0	4	37	f	none	simulated	system_sim
795	2026-08-04	WH-DEL-01	ITM-SSD-01	0	0	68	f	none	simulated	system_sim
796	2026-08-04	WH-DEL-01	ITM-HDD-01	0	2	33	f	none	simulated	system_sim
797	2026-08-04	WH-DEL-01	ITM-CHG-01	0	8	163	f	none	simulated	system_sim
798	2026-08-04	WH-DEL-01	ITM-CBL-01	0	4	167	f	none	simulated	system_sim
799	2026-08-04	WH-CCU-01	ITM-CPU-01	0	2	62	f	none	simulated	system_sim
800	2026-08-04	WH-CCU-01	ITM-GPU-01	0	2	16	f	none	simulated	system_sim
801	2026-08-04	WH-CCU-01	ITM-RAM-01	0	8	94	f	none	simulated	system_sim
802	2026-08-04	WH-CCU-01	ITM-SSD-01	0	3	61	f	none	simulated	system_sim
803	2026-08-04	WH-CCU-01	ITM-HDD-01	0	2	73	f	none	simulated	system_sim
804	2026-08-04	WH-CCU-01	ITM-CHG-01	0	2	195	f	none	simulated	system_sim
805	2026-08-04	WH-CCU-01	ITM-CBL-01	0	2	170	f	none	simulated	system_sim
806	2026-08-05	WH-BLR-01	ITM-CPU-01	0	0	60	f	none	simulated	system_sim
807	2026-08-05	WH-BLR-01	ITM-GPU-01	0	0	33	t	shrinkage	simulated	system_sim
808	2026-08-05	WH-BLR-01	ITM-RAM-01	0	7	40	f	none	simulated	system_sim
809	2026-08-05	WH-BLR-01	ITM-SSD-01	0	2	56	f	none	simulated	system_sim
810	2026-08-05	WH-BLR-01	ITM-HDD-01	0	1	32	f	none	simulated	system_sim
811	2026-08-05	WH-BLR-01	ITM-CHG-01	0	4	169	f	none	simulated	system_sim
812	2026-08-05	WH-BLR-01	ITM-CBL-01	0	3	163	f	none	simulated	system_sim
813	2026-08-05	WH-CHN-01	ITM-CPU-01	0	0	43	f	none	simulated	system_sim
814	2026-08-05	WH-CHN-01	ITM-GPU-01	0	0	41	f	none	simulated	system_sim
815	2026-08-05	WH-CHN-01	ITM-RAM-01	0	3	85	f	none	simulated	system_sim
816	2026-08-05	WH-CHN-01	ITM-SSD-01	0	3	54	f	none	simulated	system_sim
817	2026-08-05	WH-CHN-01	ITM-HDD-01	0	0	35	f	none	simulated	system_sim
818	2026-08-05	WH-CHN-01	ITM-CHG-01	0	8	181	f	none	simulated	system_sim
819	2026-08-05	WH-CHN-01	ITM-CBL-01	0	6	190	f	none	simulated	system_sim
820	2026-08-05	WH-BOM-01	ITM-CPU-01	0	2	62	f	none	simulated	system_sim
821	2026-08-05	WH-BOM-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
822	2026-08-05	WH-BOM-01	ITM-RAM-01	0	10	29	f	none	simulated	system_sim
823	2026-08-05	WH-BOM-01	ITM-SSD-01	0	2	61	f	none	simulated	system_sim
824	2026-08-05	WH-BOM-01	ITM-HDD-01	0	1	85	f	none	simulated	system_sim
825	2026-08-05	WH-BOM-01	ITM-CHG-01	0	9	152	f	none	simulated	system_sim
826	2026-08-05	WH-BOM-01	ITM-CBL-01	0	9	191	f	none	simulated	system_sim
827	2026-08-05	WH-DEL-01	ITM-CPU-01	0	3	56	f	none	simulated	system_sim
828	2026-08-05	WH-DEL-01	ITM-GPU-01	0	2	40	f	none	simulated	system_sim
829	2026-08-05	WH-DEL-01	ITM-RAM-01	75	3	109	f	none	simulated	system_sim
830	2026-08-05	WH-DEL-01	ITM-SSD-01	0	0	68	f	none	simulated	system_sim
831	2026-08-05	WH-DEL-01	ITM-HDD-01	0	2	31	f	none	simulated	system_sim
832	2026-08-05	WH-DEL-01	ITM-CHG-01	0	4	159	f	none	simulated	system_sim
833	2026-08-05	WH-DEL-01	ITM-CBL-01	0	6	161	f	none	simulated	system_sim
834	2026-08-05	WH-CCU-01	ITM-CPU-01	0	0	62	f	none	simulated	system_sim
835	2026-08-05	WH-CCU-01	ITM-GPU-01	0	1	15	f	none	simulated	system_sim
836	2026-08-05	WH-CCU-01	ITM-RAM-01	0	1	93	f	none	simulated	system_sim
837	2026-08-05	WH-CCU-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
838	2026-08-05	WH-CCU-01	ITM-HDD-01	0	0	73	f	none	simulated	system_sim
839	2026-08-05	WH-CCU-01	ITM-CHG-01	0	7	188	f	none	simulated	system_sim
840	2026-08-05	WH-CCU-01	ITM-CBL-01	0	5	165	f	none	simulated	system_sim
841	2026-08-06	WH-BLR-01	ITM-CPU-01	0	1	59	f	none	simulated	system_sim
842	2026-08-06	WH-BLR-01	ITM-GPU-01	0	1	32	f	none	simulated	system_sim
843	2026-08-06	WH-BLR-01	ITM-RAM-01	0	1	39	f	none	simulated	system_sim
844	2026-08-06	WH-BLR-01	ITM-SSD-01	0	0	56	f	none	simulated	system_sim
845	2026-08-06	WH-BLR-01	ITM-HDD-01	0	2	30	f	none	simulated	system_sim
846	2026-08-06	WH-BLR-01	ITM-CHG-01	0	5	164	f	none	simulated	system_sim
847	2026-08-06	WH-BLR-01	ITM-CBL-01	0	2	161	f	none	simulated	system_sim
848	2026-08-06	WH-CHN-01	ITM-CPU-01	0	1	42	f	none	simulated	system_sim
849	2026-08-06	WH-CHN-01	ITM-GPU-01	0	0	41	f	none	simulated	system_sim
850	2026-08-06	WH-CHN-01	ITM-RAM-01	0	7	78	f	none	simulated	system_sim
851	2026-08-06	WH-CHN-01	ITM-SSD-01	0	0	54	f	none	simulated	system_sim
852	2026-08-06	WH-CHN-01	ITM-HDD-01	0	1	34	f	none	simulated	system_sim
853	2026-08-06	WH-CHN-01	ITM-CHG-01	0	2	179	f	none	simulated	system_sim
854	2026-08-06	WH-CHN-01	ITM-CBL-01	0	10	180	f	none	simulated	system_sim
855	2026-08-06	WH-BOM-01	ITM-CPU-01	0	3	59	f	none	simulated	system_sim
856	2026-08-06	WH-BOM-01	ITM-GPU-01	0	0	16	f	none	simulated	system_sim
857	2026-08-06	WH-BOM-01	ITM-RAM-01	75	5	99	f	none	simulated	system_sim
858	2026-08-06	WH-BOM-01	ITM-SSD-01	0	3	58	f	none	simulated	system_sim
859	2026-08-06	WH-BOM-01	ITM-HDD-01	0	0	85	f	none	simulated	system_sim
860	2026-08-06	WH-BOM-01	ITM-CHG-01	0	3	149	f	none	simulated	system_sim
861	2026-08-06	WH-BOM-01	ITM-CBL-01	0	3	188	f	none	simulated	system_sim
862	2026-08-06	WH-DEL-01	ITM-CPU-01	0	0	56	f	none	simulated	system_sim
863	2026-08-06	WH-DEL-01	ITM-GPU-01	0	2	38	f	none	simulated	system_sim
864	2026-08-06	WH-DEL-01	ITM-RAM-01	0	5	104	f	none	simulated	system_sim
865	2026-08-06	WH-DEL-01	ITM-SSD-01	0	0	68	f	none	simulated	system_sim
866	2026-08-06	WH-DEL-01	ITM-HDD-01	0	3	28	f	none	simulated	system_sim
867	2026-08-06	WH-DEL-01	ITM-CHG-01	0	6	153	f	none	simulated	system_sim
868	2026-08-06	WH-DEL-01	ITM-CBL-01	0	5	156	f	none	simulated	system_sim
869	2026-08-06	WH-CCU-01	ITM-CPU-01	0	1	61	f	none	simulated	system_sim
870	2026-08-06	WH-CCU-01	ITM-GPU-01	0	0	15	f	none	simulated	system_sim
871	2026-08-06	WH-CCU-01	ITM-RAM-01	0	5	88	f	none	simulated	system_sim
872	2026-08-06	WH-CCU-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
873	2026-08-06	WH-CCU-01	ITM-HDD-01	0	0	73	f	none	simulated	system_sim
874	2026-08-06	WH-CCU-01	ITM-CHG-01	0	2	186	f	none	simulated	system_sim
875	2026-08-06	WH-CCU-01	ITM-CBL-01	0	9	156	f	none	simulated	system_sim
876	2026-08-07	WH-BLR-01	ITM-CPU-01	0	0	59	f	none	simulated	system_sim
877	2026-08-07	WH-BLR-01	ITM-GPU-01	0	2	30	f	none	simulated	system_sim
878	2026-08-07	WH-BLR-01	ITM-RAM-01	0	7	32	f	none	simulated	system_sim
879	2026-08-07	WH-BLR-01	ITM-SSD-01	0	2	54	f	none	simulated	system_sim
880	2026-08-07	WH-BLR-01	ITM-HDD-01	0	3	27	f	none	simulated	system_sim
881	2026-08-07	WH-BLR-01	ITM-CHG-01	0	1	163	f	none	simulated	system_sim
882	2026-08-07	WH-BLR-01	ITM-CBL-01	0	9	152	f	none	simulated	system_sim
883	2026-08-07	WH-CHN-01	ITM-CPU-01	0	2	40	f	none	simulated	system_sim
884	2026-08-07	WH-CHN-01	ITM-GPU-01	0	1	40	f	none	simulated	system_sim
885	2026-08-07	WH-CHN-01	ITM-RAM-01	0	1	77	f	none	simulated	system_sim
886	2026-08-07	WH-CHN-01	ITM-SSD-01	0	0	54	f	none	simulated	system_sim
887	2026-08-07	WH-CHN-01	ITM-HDD-01	0	0	34	f	none	simulated	system_sim
888	2026-08-07	WH-CHN-01	ITM-CHG-01	0	1	178	f	none	simulated	system_sim
889	2026-08-07	WH-CHN-01	ITM-CBL-01	0	4	176	f	none	simulated	system_sim
890	2026-08-07	WH-BOM-01	ITM-CPU-01	0	2	57	f	none	simulated	system_sim
891	2026-08-07	WH-BOM-01	ITM-GPU-01	0	2	14	f	none	simulated	system_sim
892	2026-08-07	WH-BOM-01	ITM-RAM-01	0	10	89	f	none	simulated	system_sim
893	2026-08-07	WH-BOM-01	ITM-SSD-01	0	3	55	f	none	simulated	system_sim
894	2026-08-07	WH-BOM-01	ITM-HDD-01	0	3	82	f	none	simulated	system_sim
895	2026-08-07	WH-BOM-01	ITM-CHG-01	0	1	148	f	none	simulated	system_sim
896	2026-08-07	WH-BOM-01	ITM-CBL-01	0	7	181	f	none	simulated	system_sim
897	2026-08-07	WH-DEL-01	ITM-CPU-01	0	1	55	f	none	simulated	system_sim
898	2026-08-07	WH-DEL-01	ITM-GPU-01	0	0	38	f	none	simulated	system_sim
899	2026-08-07	WH-DEL-01	ITM-RAM-01	0	4	100	f	none	simulated	system_sim
900	2026-08-07	WH-DEL-01	ITM-SSD-01	0	0	68	f	none	simulated	system_sim
901	2026-08-07	WH-DEL-01	ITM-HDD-01	60	2	86	f	none	simulated	system_sim
902	2026-08-07	WH-DEL-01	ITM-CHG-01	0	10	143	f	none	simulated	system_sim
903	2026-08-07	WH-DEL-01	ITM-CBL-01	0	6	150	f	none	simulated	system_sim
904	2026-08-07	WH-CCU-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
905	2026-08-07	WH-CCU-01	ITM-GPU-01	0	0	15	f	none	simulated	system_sim
906	2026-08-07	WH-CCU-01	ITM-RAM-01	0	8	80	f	none	simulated	system_sim
907	2026-08-07	WH-CCU-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
908	2026-08-07	WH-CCU-01	ITM-HDD-01	0	0	73	f	none	simulated	system_sim
909	2026-08-07	WH-CCU-01	ITM-CHG-01	0	10	176	f	none	simulated	system_sim
910	2026-08-07	WH-CCU-01	ITM-CBL-01	0	3	153	f	none	simulated	system_sim
911	2026-08-08	WH-BLR-01	ITM-CPU-01	0	1	58	f	none	simulated	system_sim
912	2026-08-08	WH-BLR-01	ITM-GPU-01	0	0	30	f	none	simulated	system_sim
913	2026-08-08	WH-BLR-01	ITM-RAM-01	75	6	101	f	none	simulated	system_sim
914	2026-08-08	WH-BLR-01	ITM-SSD-01	0	0	54	f	none	simulated	system_sim
915	2026-08-08	WH-BLR-01	ITM-HDD-01	60	0	87	f	none	simulated	system_sim
916	2026-08-08	WH-BLR-01	ITM-CHG-01	0	6	157	f	none	simulated	system_sim
917	2026-08-08	WH-BLR-01	ITM-CBL-01	0	2	150	f	none	simulated	system_sim
918	2026-08-08	WH-CHN-01	ITM-CPU-01	0	2	38	f	none	simulated	system_sim
919	2026-08-08	WH-CHN-01	ITM-GPU-01	0	0	40	f	none	simulated	system_sim
920	2026-08-08	WH-CHN-01	ITM-RAM-01	0	3	74	f	none	simulated	system_sim
921	2026-08-08	WH-CHN-01	ITM-SSD-01	0	0	54	f	none	simulated	system_sim
922	2026-08-08	WH-CHN-01	ITM-HDD-01	0	0	34	f	none	simulated	system_sim
923	2026-08-08	WH-CHN-01	ITM-CHG-01	0	4	174	f	none	simulated	system_sim
924	2026-08-08	WH-CHN-01	ITM-CBL-01	0	1	175	f	none	simulated	system_sim
925	2026-08-08	WH-BOM-01	ITM-CPU-01	0	2	55	f	none	simulated	system_sim
926	2026-08-08	WH-BOM-01	ITM-GPU-01	30	0	44	f	none	simulated	system_sim
927	2026-08-08	WH-BOM-01	ITM-RAM-01	0	8	81	f	none	simulated	system_sim
928	2026-08-08	WH-BOM-01	ITM-SSD-01	0	1	54	f	none	simulated	system_sim
929	2026-08-08	WH-BOM-01	ITM-HDD-01	0	0	82	f	none	simulated	system_sim
930	2026-08-08	WH-BOM-01	ITM-CHG-01	0	8	140	f	none	simulated	system_sim
931	2026-08-08	WH-BOM-01	ITM-CBL-01	0	7	174	f	none	simulated	system_sim
932	2026-08-08	WH-DEL-01	ITM-CPU-01	0	1	54	f	none	simulated	system_sim
933	2026-08-08	WH-DEL-01	ITM-GPU-01	0	1	37	f	none	simulated	system_sim
934	2026-08-08	WH-DEL-01	ITM-RAM-01	0	9	91	f	none	simulated	system_sim
935	2026-08-08	WH-DEL-01	ITM-SSD-01	0	2	66	f	none	simulated	system_sim
936	2026-08-08	WH-DEL-01	ITM-HDD-01	0	3	83	f	none	simulated	system_sim
937	2026-08-08	WH-DEL-01	ITM-CHG-01	0	10	133	f	none	simulated	system_sim
938	2026-08-08	WH-DEL-01	ITM-CBL-01	0	10	140	f	none	simulated	system_sim
939	2026-08-08	WH-CCU-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
940	2026-08-08	WH-CCU-01	ITM-GPU-01	0	0	15	f	none	simulated	system_sim
941	2026-08-08	WH-CCU-01	ITM-RAM-01	0	9	71	f	none	simulated	system_sim
942	2026-08-08	WH-CCU-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
943	2026-08-08	WH-CCU-01	ITM-HDD-01	0	1	72	f	none	simulated	system_sim
944	2026-08-08	WH-CCU-01	ITM-CHG-01	0	1	175	f	none	simulated	system_sim
945	2026-08-08	WH-CCU-01	ITM-CBL-01	0	4	149	f	none	simulated	system_sim
946	2026-08-09	WH-BLR-01	ITM-CPU-01	0	3	55	f	none	simulated	system_sim
947	2026-08-09	WH-BLR-01	ITM-GPU-01	0	1	29	f	none	simulated	system_sim
948	2026-08-09	WH-BLR-01	ITM-RAM-01	0	8	93	f	none	simulated	system_sim
949	2026-08-09	WH-BLR-01	ITM-SSD-01	0	1	53	f	none	simulated	system_sim
950	2026-08-09	WH-BLR-01	ITM-HDD-01	0	0	87	f	none	simulated	system_sim
951	2026-08-09	WH-BLR-01	ITM-CHG-01	0	4	153	f	none	simulated	system_sim
952	2026-08-09	WH-BLR-01	ITM-CBL-01	0	1	149	f	none	simulated	system_sim
953	2026-08-09	WH-CHN-01	ITM-CPU-01	0	3	35	f	none	simulated	system_sim
954	2026-08-09	WH-CHN-01	ITM-GPU-01	0	0	40	f	none	simulated	system_sim
955	2026-08-09	WH-CHN-01	ITM-RAM-01	0	7	67	f	none	simulated	system_sim
956	2026-08-09	WH-CHN-01	ITM-SSD-01	0	3	51	f	none	simulated	system_sim
957	2026-08-09	WH-CHN-01	ITM-HDD-01	0	2	32	f	none	simulated	system_sim
958	2026-08-09	WH-CHN-01	ITM-CHG-01	0	5	169	f	none	simulated	system_sim
959	2026-08-09	WH-CHN-01	ITM-CBL-01	0	6	169	f	none	simulated	system_sim
960	2026-08-09	WH-BOM-01	ITM-CPU-01	0	0	55	f	none	simulated	system_sim
961	2026-08-09	WH-BOM-01	ITM-GPU-01	0	0	44	f	none	simulated	system_sim
962	2026-08-09	WH-BOM-01	ITM-RAM-01	0	6	75	f	none	simulated	system_sim
963	2026-08-09	WH-BOM-01	ITM-SSD-01	0	1	53	f	none	simulated	system_sim
964	2026-08-09	WH-BOM-01	ITM-HDD-01	0	0	82	f	none	simulated	system_sim
965	2026-08-09	WH-BOM-01	ITM-CHG-01	0	2	138	f	none	simulated	system_sim
966	2026-08-09	WH-BOM-01	ITM-CBL-01	0	4	170	f	none	simulated	system_sim
967	2026-08-09	WH-DEL-01	ITM-CPU-01	0	2	52	f	none	simulated	system_sim
968	2026-08-09	WH-DEL-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
969	2026-08-09	WH-DEL-01	ITM-RAM-01	0	3	88	f	none	simulated	system_sim
970	2026-08-09	WH-DEL-01	ITM-SSD-01	0	0	66	f	none	simulated	system_sim
971	2026-08-09	WH-DEL-01	ITM-HDD-01	0	3	80	f	none	simulated	system_sim
972	2026-08-09	WH-DEL-01	ITM-CHG-01	0	3	130	f	none	simulated	system_sim
973	2026-08-09	WH-DEL-01	ITM-CBL-01	300	9	431	f	none	simulated	system_sim
974	2026-08-09	WH-CCU-01	ITM-CPU-01	0	0	61	f	none	simulated	system_sim
975	2026-08-09	WH-CCU-01	ITM-GPU-01	0	0	15	f	none	simulated	system_sim
976	2026-08-09	WH-CCU-01	ITM-RAM-01	0	7	64	f	none	simulated	system_sim
977	2026-08-09	WH-CCU-01	ITM-SSD-01	0	0	61	f	none	simulated	system_sim
978	2026-08-09	WH-CCU-01	ITM-HDD-01	0	2	70	f	none	simulated	system_sim
979	2026-08-09	WH-CCU-01	ITM-CHG-01	0	9	166	f	none	simulated	system_sim
980	2026-08-09	WH-CCU-01	ITM-CBL-01	300	10	439	f	none	simulated	system_sim
981	2026-08-10	WH-BLR-01	ITM-CPU-01	0	2	53	f	none	simulated	system_sim
982	2026-08-10	WH-BLR-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
983	2026-08-10	WH-BLR-01	ITM-RAM-01	0	1	92	f	none	simulated	system_sim
984	2026-08-10	WH-BLR-01	ITM-SSD-01	0	0	53	f	none	simulated	system_sim
985	2026-08-10	WH-BLR-01	ITM-HDD-01	0	2	85	f	none	simulated	system_sim
986	2026-08-10	WH-BLR-01	ITM-CHG-01	0	1	152	f	none	simulated	system_sim
987	2026-08-10	WH-BLR-01	ITM-CBL-01	300	4	445	f	none	simulated	system_sim
988	2026-08-10	WH-CHN-01	ITM-CPU-01	0	0	35	f	none	simulated	system_sim
989	2026-08-10	WH-CHN-01	ITM-GPU-01	0	0	40	f	none	simulated	system_sim
990	2026-08-10	WH-CHN-01	ITM-RAM-01	0	2	65	f	none	simulated	system_sim
991	2026-08-10	WH-CHN-01	ITM-SSD-01	0	0	51	f	none	simulated	system_sim
992	2026-08-10	WH-CHN-01	ITM-HDD-01	0	1	31	f	none	simulated	system_sim
993	2026-08-10	WH-CHN-01	ITM-CHG-01	0	5	164	f	none	simulated	system_sim
994	2026-08-10	WH-CHN-01	ITM-CBL-01	0	5	164	f	none	simulated	system_sim
995	2026-08-10	WH-BOM-01	ITM-CPU-01	0	2	53	f	none	simulated	system_sim
996	2026-08-10	WH-BOM-01	ITM-GPU-01	0	2	42	f	none	simulated	system_sim
997	2026-08-10	WH-BOM-01	ITM-RAM-01	0	1	74	f	none	simulated	system_sim
998	2026-08-10	WH-BOM-01	ITM-SSD-01	0	0	53	f	none	simulated	system_sim
999	2026-08-10	WH-BOM-01	ITM-HDD-01	0	3	79	f	none	simulated	system_sim
1000	2026-08-10	WH-BOM-01	ITM-CHG-01	0	3	135	f	none	simulated	system_sim
1001	2026-08-10	WH-BOM-01	ITM-CBL-01	0	3	167	f	none	simulated	system_sim
1002	2026-08-10	WH-DEL-01	ITM-CPU-01	0	1	51	f	none	simulated	system_sim
1003	2026-08-10	WH-DEL-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
1004	2026-08-10	WH-DEL-01	ITM-RAM-01	0	7	81	f	none	simulated	system_sim
1005	2026-08-10	WH-DEL-01	ITM-SSD-01	0	3	63	f	none	simulated	system_sim
1006	2026-08-10	WH-DEL-01	ITM-HDD-01	0	0	80	f	none	simulated	system_sim
1007	2026-08-10	WH-DEL-01	ITM-CHG-01	0	8	122	f	none	simulated	system_sim
1008	2026-08-10	WH-DEL-01	ITM-CBL-01	0	8	423	f	none	simulated	system_sim
1009	2026-08-10	WH-CCU-01	ITM-CPU-01	0	1	60	f	none	simulated	system_sim
1010	2026-08-10	WH-CCU-01	ITM-GPU-01	0	2	13	f	none	simulated	system_sim
1011	2026-08-10	WH-CCU-01	ITM-RAM-01	0	10	54	f	none	simulated	system_sim
1012	2026-08-10	WH-CCU-01	ITM-SSD-01	0	2	59	f	none	simulated	system_sim
1013	2026-08-10	WH-CCU-01	ITM-HDD-01	0	2	68	f	none	simulated	system_sim
1014	2026-08-10	WH-CCU-01	ITM-CHG-01	0	6	160	f	none	simulated	system_sim
1015	2026-08-10	WH-CCU-01	ITM-CBL-01	0	2	437	f	none	simulated	system_sim
1016	2026-08-11	WH-BLR-01	ITM-CPU-01	0	3	50	f	none	simulated	system_sim
1017	2026-08-11	WH-BLR-01	ITM-GPU-01	0	0	29	f	none	simulated	system_sim
1018	2026-08-11	WH-BLR-01	ITM-RAM-01	0	2	90	f	none	simulated	system_sim
1019	2026-08-11	WH-BLR-01	ITM-SSD-01	0	3	50	f	none	simulated	system_sim
1020	2026-08-11	WH-BLR-01	ITM-HDD-01	0	1	84	f	none	simulated	system_sim
1021	2026-08-11	WH-BLR-01	ITM-CHG-01	0	9	143	f	none	simulated	system_sim
1022	2026-08-11	WH-BLR-01	ITM-CBL-01	0	6	439	f	none	simulated	system_sim
1023	2026-08-11	WH-CHN-01	ITM-CPU-01	0	0	35	f	none	simulated	system_sim
1024	2026-08-11	WH-CHN-01	ITM-GPU-01	0	1	39	f	none	simulated	system_sim
1025	2026-08-11	WH-CHN-01	ITM-RAM-01	0	9	56	f	none	simulated	system_sim
1026	2026-08-11	WH-CHN-01	ITM-SSD-01	0	0	51	f	none	simulated	system_sim
1027	2026-08-11	WH-CHN-01	ITM-HDD-01	0	3	28	f	none	simulated	system_sim
1028	2026-08-11	WH-CHN-01	ITM-CHG-01	0	6	158	f	none	simulated	system_sim
1029	2026-08-11	WH-CHN-01	ITM-CBL-01	0	4	160	f	none	simulated	system_sim
1030	2026-08-11	WH-BOM-01	ITM-CPU-01	0	0	53	f	none	simulated	system_sim
1031	2026-08-11	WH-BOM-01	ITM-GPU-01	0	2	40	f	none	simulated	system_sim
1032	2026-08-11	WH-BOM-01	ITM-RAM-01	0	3	71	f	none	simulated	system_sim
1033	2026-08-11	WH-BOM-01	ITM-SSD-01	0	0	53	f	none	simulated	system_sim
1034	2026-08-11	WH-BOM-01	ITM-HDD-01	0	3	76	f	none	simulated	system_sim
1035	2026-08-11	WH-BOM-01	ITM-CHG-01	0	6	129	f	none	simulated	system_sim
1036	2026-08-11	WH-BOM-01	ITM-CBL-01	0	10	157	f	none	simulated	system_sim
1037	2026-08-11	WH-DEL-01	ITM-CPU-01	0	0	51	f	none	simulated	system_sim
1038	2026-08-11	WH-DEL-01	ITM-GPU-01	0	0	37	f	none	simulated	system_sim
1039	2026-08-11	WH-DEL-01	ITM-RAM-01	0	7	74	f	none	simulated	system_sim
1040	2026-08-11	WH-DEL-01	ITM-SSD-01	0	0	63	f	none	simulated	system_sim
1041	2026-08-11	WH-DEL-01	ITM-HDD-01	0	0	80	f	none	simulated	system_sim
1042	2026-08-11	WH-DEL-01	ITM-CHG-01	0	10	112	f	none	simulated	system_sim
1043	2026-08-11	WH-DEL-01	ITM-CBL-01	0	6	417	f	none	simulated	system_sim
1044	2026-08-11	WH-CCU-01	ITM-CPU-01	0	2	58	f	none	simulated	system_sim
1045	2026-08-11	WH-CCU-01	ITM-GPU-01	30	1	42	f	none	simulated	system_sim
1046	2026-08-11	WH-CCU-01	ITM-RAM-01	0	2	52	f	none	simulated	system_sim
1047	2026-08-11	WH-CCU-01	ITM-SSD-01	0	1	58	f	none	simulated	system_sim
1048	2026-08-11	WH-CCU-01	ITM-HDD-01	0	3	65	f	none	simulated	system_sim
1049	2026-08-11	WH-CCU-01	ITM-CHG-01	0	6	154	f	none	simulated	system_sim
1050	2026-08-11	WH-CCU-01	ITM-CBL-01	0	9	428	f	none	simulated	system_sim
1051	2026-08-15	WH-BLR-01	ITM-CPU-01	10	10	50	f	none	manual	harsha200797@gmail.com
1052	2026-08-15	WH-BLR-01	ITM005	50	100	0	f	none	manual	harsha200797@gmail.com
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password_hash, role, full_name, google_subject_id, created_at) FROM stdin;
1	admin	$2b$12$z7JVwvNuVk9ZWRNc4e1xAuf.UdaolPvtcZ5x4PG1QEvMD3C61/LQG	admin	System Administrator	\N	2026-08-14 10:31:22.459306
2	harsha200797@gmail.com	$2b$12$YOkReDXodxeHYb/qP4O6.ub9TEiDawHNUDiItVclQbeQpYAKb6sBe	admin	Harsha Vardhan	117591730789469546962	2026-08-14 10:32:57.463364
3	harsha200797+new@gmail.com	GOOGLE_OAUTH_ONLY	admin	Test Admin	\N	2026-08-14 11:06:06.740539
4	testadmin_1786780003@gmail.com	GOOGLE_OAUTH_ONLY	admin	Test Administrator	\N	2026-08-15 07:46:48.142813
5	testadmin_1786780047@gmail.com	GOOGLE_OAUTH_ONLY	admin	Test Administrator	\N	2026-08-15 07:47:32.710151
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouses (id, name, location, latitude, longitude, created_at) FROM stdin;
WH-BLR-01	Bangalore Fulfillment Center	Bangalore, Karnataka	12.983147716796578	77.55352398621709	2026-08-14 10:32:16.345804
WH-CHN-01	Chennai Port Logistics Hub	Chennai, Tamil Nadu	13.08268	80.270718	2026-08-14 10:32:16.351656
WH-BOM-01	Mumbai Container Terminal	Mumbai, Maharashtra	19.07609	72.877701	2026-08-14 10:32:16.357709
WH-DEL-01	Delhi NCR Logistics Park	Noida, Uttar Pradesh	28.535517	77.391029	2026-08-14 10:32:16.364336
WH-CCU-01	Kolkata Gateway Depot	Kolkata, West Bengal	22.572646	88.363895	2026-08-14 10:32:16.368505
WH-CHN-02	chennai central	chennai,tamilnadu	13.08101658661373	80.27077306483645	2026-08-15 13:08:08.756029
\.


--
-- Name: access_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_log_id_seq', 97, true);


--
-- Name: ai_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_recommendations_id_seq', 3, true);


--
-- Name: audit_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_ledger_id_seq', 109, true);


--
-- Name: backup_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.backup_records_id_seq', 3, true);


--
-- Name: recovery_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recovery_codes_id_seq', 1, false);


--
-- Name: recovery_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recovery_credentials_id_seq', 1, false);


--
-- Name: shrinkage_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shrinkage_flags_id_seq', 2, true);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 1052, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 7, true);


--
-- Name: access_log access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log
    ADD CONSTRAINT access_log_pkey PRIMARY KEY (id);


--
-- Name: ai_recommendations ai_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_recommendations
    ADD CONSTRAINT ai_recommendations_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_ledger audit_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_ledger
    ADD CONSTRAINT audit_ledger_pkey PRIMARY KEY (id);


--
-- Name: backup_records backup_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_records
    ADD CONSTRAINT backup_records_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: recovery_codes recovery_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: recovery_credentials recovery_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials
    ADD CONSTRAINT recovery_credentials_pkey PRIMARY KEY (id);


--
-- Name: shrinkage_flags shrinkage_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shrinkage_flags
    ADD CONSTRAINT shrinkage_flags_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: stock_movements uq_movement; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT uq_movement UNIQUE (date, warehouse_id, item_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: ix_access_log_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_access_log_timestamp ON public.access_log USING btree ("timestamp");


--
-- Name: ix_ai_recommendations_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_recommendations_timestamp ON public.ai_recommendations USING btree ("timestamp");


--
-- Name: ix_backup_records_backup_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_backup_records_backup_id ON public.backup_records USING btree (backup_id);


--
-- Name: ix_backup_records_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_backup_records_created_at ON public.backup_records USING btree (created_at);


--
-- Name: ix_recovery_codes_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_recovery_codes_user_id ON public.recovery_codes USING btree (user_id);


--
-- Name: ix_recovery_credentials_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_recovery_credentials_user_id ON public.recovery_credentials USING btree (user_id);


--
-- Name: ix_stock_movements_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_date ON public.stock_movements USING btree (date);


--
-- Name: ix_stock_movements_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_item_id ON public.stock_movements USING btree (item_id);


--
-- Name: ix_stock_movements_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stock_movements_warehouse_id ON public.stock_movements USING btree (warehouse_id);


--
-- Name: ix_users_google_subject_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_google_subject_id ON public.users USING btree (google_subject_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: recovery_codes recovery_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: recovery_credentials recovery_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recovery_credentials
    ADD CONSTRAINT recovery_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id);


--
-- Name: stock_movements stock_movements_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- PostgreSQL database dump complete
--

\unrestrict kc0bfHaMi9rWyj3CZQbkM9NOnqcUcVwaM29hZ8R1APcA38OkryselOYyE2AcmLz

